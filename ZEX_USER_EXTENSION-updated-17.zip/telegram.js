// ═══════════════════════════════════════════════════════════════════
//  Z EX — Telegram Web content script (runs on https://web.telegram.org/*)
//
//  Two floating panels live here:
//   1. GROUP ENGAGE — walks a Telegram group's messages top→bottom. For each
//      message that carries an X/Twitter post link it asks background.js to open that post on X and
//      run the normal Z EX reply engine on it. When X reports back it moves
//      on to the next link (with human-like gaps and periodic breaks).
//   2. LINK SWEEP — finds a message you paste, then scrolls down through the
//      chat collecting every X post link, and hands the whole list to the Z EX
//      queue (background.js runs it through the same per-link engage engine).
//
//  State lives in chrome.storage.local (written by background.js):
//    zenTgActive       — Group Engage run state (phase FIND_START/FIND_NEXT/IDLE_X)
//    zenTgWidgetArmed  — show the Group Engage panel
//    zenTgSweepArmed   — show the Link Sweep panel
//    zenTgLast         — last engaged link, for "Continue from last link"
// ═══════════════════════════════════════════════════════════════════
(function () {
  if (window.__zenTgLoaded) return;
  window.__zenTgLoaded = true;

  const FONT = "'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif";

  // ── Styles (Z EX gold/dark look) ────────────────────────────────
  const style = document.createElement('style');
  style.textContent = `
    #zen-tg-widget,#zen-tgs-widget{color:#fdf6e3;font-family:${FONT};box-sizing:border-box;}
    #zen-tg-widget *,#zen-tgs-widget *{box-sizing:border-box;}
    #zen-tg-widget.zt-collapsed .zen-bg-banner{display:none!important;}
    #zen-tg-widget.zt-card{width:274px;max-width:calc(100vw - 40px);padding:0 0 13px;border-radius:20px;overflow:hidden;
      background:radial-gradient(120% 80% at 100% 0%,rgba(234,179,8,0.18),transparent 58%),linear-gradient(165deg,rgba(28,24,14,0.97),rgba(9,9,10,0.98));
      border:1px solid rgba(250,204,21,0.28);box-shadow:0 20px 48px rgba(0,0,0,0.62),0 0 34px rgba(234,179,8,0.10),inset 0 1px 0 rgba(255,255,255,0.08);
      backdrop-filter:blur(16px) saturate(1.3);-webkit-backdrop-filter:blur(16px) saturate(1.3);}
    #zen-tg-widget-body{padding:0 13px;}
    #zen-tg-widget .zt-head{display:flex;align-items:center;gap:9px;padding:13px 11px 10px 13px;cursor:grab;}
    #zen-tg-widget .zt-mark{width:28px;height:28px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;
      font-weight:800;font-size:12px;color:#2b1d00;background:linear-gradient(180deg,#fde68a,#eab308);box-shadow:0 0 14px rgba(234,179,8,0.45);}
    #zen-tg-widget .zt-titles{display:flex;flex-direction:column;flex:1;min-width:0;gap:1px;}
    #zen-tg-widget .zt-brand{font-size:8px;letter-spacing:2.2px;font-weight:700;color:rgba(250,204,21,0.75);}
    #zen-tg-widget .zt-title{font-size:12px;font-weight:700;color:#fff8e1;line-height:1.2;}
    #zen-tg-widget .zt-min{flex:none;width:22px;height:22px;border-radius:50%;padding:0;display:inline-flex;align-items:center;justify-content:center;
      background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.08);color:rgba(253,246,227,0.7);cursor:pointer;font-size:13px;line-height:1;}
    #zen-tg-widget .zt-pill{display:inline-flex;align-items:center;gap:4px;padding:3px 7px 3px 6px;border-radius:999px;font-size:8px;font-weight:700;
      letter-spacing:0.9px;text-transform:uppercase;color:#fde047;background:rgba(234,179,8,0.13);border:1px solid rgba(250,204,21,0.34);margin-bottom:9px;}
    #zen-tg-widget .zt-pill i{width:6px;height:6px;border-radius:50%;background:currentColor;animation:zt-blink 1.2s ease-in-out infinite;}
    #zen-tg-widget .zt-pill.zt-rest{color:#e8dccb;background:rgba(255,255,255,0.07);border-color:rgba(255,255,255,0.16);}
    #zen-tg-widget .zt-pill.zt-rest i{animation:none;opacity:.7;}
    #zen-tg-widget .zt-status{margin:0 0 11px;font-size:11px;line-height:1.45;color:rgba(253,246,227,0.8);}
    #zen-tg-widget .zt-stats{display:grid;grid-template-columns:1.3fr 1fr 1fr;border-radius:14px;overflow:hidden;margin-bottom:11px;
      background:rgba(255,255,255,0.035);border:1px solid rgba(250,204,21,0.14);}
    #zen-tg-widget .zt-stat{text-align:center;padding:9px 4px 8px;}
    #zen-tg-widget .zt-stat + .zt-stat{border-left:1px solid rgba(250,204,21,0.10);}
    #zen-tg-widget .zt-stat b{display:block;font-size:20px;font-weight:700;line-height:1.1;color:#fff;}
    #zen-tg-widget .zt-done b{font-size:24px;color:#fde047;}
    #zen-tg-widget .zt-bad b{color:#ff8a8a;}
    #zen-tg-widget .zt-stat span{display:block;margin-top:3px;font-size:8px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:rgba(253,246,227,0.5);}
    #zen-tg-widget .zt-input{width:100%;padding:11px 13px;border-radius:12px;border:1px solid rgba(250,204,21,0.2);background:rgba(255,255,255,0.05);
      color:#fdf6e3;font-size:12px;outline:none;font-family:${FONT};margin-bottom:8px;}
    #zen-tg-widget .zt-input:focus{border-color:#eab308;box-shadow:0 0 0 3px rgba(234,179,8,0.16);}
    #zen-tg-widget .zt-input::placeholder{color:rgba(253,246,227,0.38);}
    #zen-tg-widget select.zt-input{appearance:auto;cursor:pointer;}
    #zen-tg-widget select.zt-input option{background:#1c180e;color:#fdf6e3;}
    #zen-tg-widget .zt-btn{width:100%;height:38px;border:none;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:11px;font-weight:700;
      letter-spacing:1.4px;text-transform:uppercase;color:#2b1d00;background:linear-gradient(180deg,#fde68a,#eab308);
      box-shadow:0 6px 18px rgba(234,179,8,0.28),inset 0 1px 0 rgba(255,255,255,0.35);margin-top:2px;}
    #zen-tg-widget .zt-stop{width:100%;height:36px;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:10.5px;font-weight:700;letter-spacing:1.6px;
      text-transform:uppercase;color:#ffd9d9;background:linear-gradient(180deg,rgba(255,92,92,0.22),rgba(255,92,92,0.07));border:1px solid rgba(255,130,130,0.4);}
    #zen-tg-widget .zt-stop:disabled{opacity:.55;cursor:default;}
    #zen-tg-widget .zt-ghost{width:100%;height:34px;margin-top:8px;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:10px;font-weight:600;
      letter-spacing:1.2px;text-transform:uppercase;color:rgba(253,246,227,0.72);background:rgba(255,255,255,0.05);border:1px solid rgba(250,204,21,0.2);}
    #zen-tg-widget .zt-last{width:100%;margin:0 0 9px;padding:8px 12px;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:10.5px;font-weight:600;
      color:#fde047;background:rgba(234,179,8,0.10);border:1px solid rgba(250,204,21,0.34);}
    #zen-tg-widget .zt-last[hidden]{display:none;}
    #zen-tg-widget .zt-hint{font-size:11px;color:rgba(253,246,227,0.62);line-height:1.55;margin:0 0 11px;}
    #zen-tg-widget .zt-orb{display:none;width:52px;height:52px;padding:0;border-radius:50%;align-items:center;justify-content:center;cursor:grab;
      font-weight:800;font-size:16px;color:#2b1d00;background:linear-gradient(180deg,#fde68a,#eab308);border:1px solid rgba(250,204,21,0.5);box-shadow:0 10px 26px rgba(0,0,0,0.55),0 0 22px rgba(234,179,8,0.3);}
    #zen-tg-widget.zt-card.zt-collapsed{width:auto;padding:0;background:none;border:none;box-shadow:none;backdrop-filter:none;-webkit-backdrop-filter:none;overflow:visible;}
    @keyframes zt-blink{0%,100%{opacity:1;}50%{opacity:.35;}}
    @media (prefers-reduced-motion: reduce){#zen-tg-widget *{animation:none!important;}}
  `;
  document.head.appendChild(style);

  // ── Small helpers ───────────────────────────────────────────────
  function send(msg) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(msg, res => { void chrome.runtime.lastError; resolve(res); });
      } catch (e) { resolve(undefined); }
    });
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const REASONS = {
    session: 'Session expired — open Z EX and log in again.',
    queue_busy: 'Another Z EX queue is running — stop it first, then try again.',
    engage_busy: 'Telegram Group Engage is running — stop it first, then try again.',
    already_running: 'A session is already running.',
    no_links: 'Nothing to send — no links were caught.',
  };

  function toast(text, ms = 4000) {
    let el = document.getElementById('zen-tg-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'zen-tg-toast';
      Object.assign(el.style, {
        position: 'fixed', top: '16px', left: '50%', transform: 'translateX(-50%)',
        background: 'rgba(10,10,10,0.95)', color: '#f4f4f5', padding: '11px 16px', borderRadius: '12px',
        zIndex: '2147483647', fontSize: '12.5px', fontFamily: FONT, transition: 'opacity 0.25s', opacity: '0',
        pointerEvents: 'none', maxWidth: 'calc(100vw - 40px)', width: '280px', boxSizing: 'border-box',
        lineHeight: '1.5', border: '1px solid rgba(250,204,21,0.3)', boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
      });
      document.body.appendChild(el);
    }
    el.textContent = text;
    el.style.opacity = '1';
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.style.opacity = '0'; }, ms);
  }

  // ── X link parsing ──────────────────────────────────────────────
  const X_LINK_RE = /(?:https?:\/\/)?(?:www\.)?(?:x\.com|twitter\.com)\/[a-zA-Z0-9_]+\/status\/\d{5,19}/i;

  function normalizeLink(text) {
    if (!text) return null;
    const m = text.match(X_LINK_RE);
    if (!m) return null;
    let link = m[0].replace(/[)\].,;]+$/, '');
    if (!/^https?:\/\//i.test(link)) link = 'https://' + link;
    return link;
  }
  function allLinksIn(text) {
    const out = [];
    const re = new RegExp(X_LINK_RE.source, 'gi');
    let m;
    while ((m = re.exec(text || ''))) {
      const l = normalizeLink(m[0]);
      if (l) out.push(l);
    }
    return out;
  }
  function statusId(link) {
    const m = link && link.match(/status\/(\d+)/);
    return m ? m[1] : link;
  }
  function sameLink(a, b) { return !!a && !!b && statusId(a) === statusId(b); }

  // ── Owner-link avoidance ────────────────────────────────────────
  // The X handle verified in the extension (zenDeviceSession.xHandle) is "me":
  // links to my own posts are never swept, reacted to, or engaged.
  let ownHandle = '';
  async function loadOwnHandle() {
    try {
      const d = await chrome.storage.local.get('zenDeviceSession');
      const h = d.zenDeviceSession && d.zenDeviceSession.xHandle;
      ownHandle = h ? String(h).replace(/^@/, '').trim().toLowerCase() : '';
    } catch (e) {}
    return ownHandle;
  }
  function linkUser(link) {
    const m = link && String(link).match(/(?:x\.com|twitter\.com)\/([a-zA-Z0-9_]+)\/status\//i);
    return m ? m[1].toLowerCase() : '';
  }
  function isOwnLink(link) { return !!ownHandle && linkUser(link) === ownHandle; }

  // ── Telegram message DOM helpers ────────────────────────────────
  // Telegram Web K tags each message with data-mid; older/other builds use
  // .bubble / .Message classes.
  function messageEls() {
    let els = document.querySelectorAll('.bubble[data-mid]');
    if (!els.length) {
      // Any [data-mid], but only the outermost ones (reply previews inside a bubble also carry data-mid).
      els = Array.from(document.querySelectorAll('[data-mid]')).filter(e => !e.parentElement || !e.parentElement.closest('[data-mid]'));
    }
    if (els.length) return Array.from(els);
    return Array.from(document.querySelectorAll('.bubble, .Message, [class*="message-list"] [class*="message" i]'));
  }
  // Name of the group being engaged (header of the open chat; forum topic → "Group / Topic" when both are visible).
  function getGroupName() {
    const clean = (t) => String(t || '').replace(/\s+/g, ' ').trim();
    try {
      const pick = (sels) => { for (const q of sels) { const el = document.querySelector(q); const t = el && clean(el.textContent); if (t) return t; } return ''; };
      const top = pick(['.chat-info .peer-title', '#column-center .chat-info .title', '.topbar .peer-title', '.chat-info .user-title', '.chat-info .person .peer-title', '#column-center .chat-info [class*="title"]', '.MiddleHeader .ChatInfo .title', '.MiddleHeader .fullName']);
      const grp = pick(['#column-left .sidebar-header .peer-title', '#column-left .forum-header .peer-title']);
      if (grp && top && grp !== top && !/^(telegram|chats?)$/i.test(grp)) return (grp + ' / ' + top).slice(0, 80);
      if (top) return top.slice(0, 80);
    } catch (e) {}
    return '';
  }
  function messageId(el) {
    if (!el || !el.getAttribute) return null;
    const raw = el.getAttribute('data-mid') ?? el.getAttribute('data-message-id') ?? el.getAttribute('data-msg-id');
    const n = raw != null ? Number(raw) : NaN;
    return Number.isFinite(n) ? n : null;
  }
  function firstLinkInMessage(el) {
    for (const a of el.querySelectorAll('a[href]')) {
      const l = normalizeLink(a.getAttribute('href'));
      if (l) return l;
    }
    const m = (el.textContent || '').match(X_LINK_RE);
    return m ? normalizeLink(m[0]) : null;
  }
  function findMessageWithLink(link) {
    for (const el of messageEls()) {
      if (sameLink(firstLinkInMessage(el), link)) return el;
    }
    return null;
  }
  // Have I already reacted to this message?
  function alreadyReacted(el) {
    return !!el.querySelector('[class*="chosen" i], [class*="own-reaction" i], [class*="reaction-chosen" i], [class*="reaction"][class*="my" i]');
  }

  // ── Serial order (both models) ──────────────────────────────────
  // Every X post link in the chat, sorted by Telegram message id (oldest → newest).
  // Message ids always grow down the chat, so "next" never depends on DOM order,
  // on which messages Telegram happens to have loaded, or on what is scrolled out.
  function linksInMessage(el) {
    const out = [], seen = new Set();
    const add = (raw) => {
      const l = normalizeLink(raw);
      if (!l) return;
      const id = statusId(l);
      if (seen.has(id)) return;
      seen.add(id); out.push(l);
    };
    for (const a of el.querySelectorAll('a[href]')) {
      const href = a.getAttribute('href') || '';
      if (/intent/i.test(href)) continue;
      add(href);
    }
    for (const l of allLinksIn(el.textContent || '')) add(l);
    return out;
  }
  function serialItems() {
    const items = [];
    let prevMid = 0, order = 0;
    for (const el of messageEls()) {
      let mid = messageId(el);
      if (mid == null) mid = prevMid; else prevMid = mid;
      let idx = 0;
      for (const link of linksInMessage(el)) items.push({ el, link, id: statusId(link), mid, idx: idx++, order: order++ });
    }
    items.sort((x, y) => (x.mid - y.mid) || (x.idx - y.idx) || (x.order - y.order));
    return items;
  }
  // The message that carries the run's starting post (Start ID, or the pasted starting link).
  function findStartItem(active) {
    const id = String(active.startId || statusId(active.targetLink || ''));
    return serialItems().find(x => x.id === id) || null;
  }
  // Telegram only keeps a window of messages in the DOM. If the next link is not loaded
  // yet, nudge the chat so Telegram loads its neighbours (dir +1 = newer/down, -1 = older/up).
  let gapScrolls = 0;
  async function stepChat(dir) {
    try {
      const els = messageEls();
      const sc = findScroller(els[0] || document.body);
      const info = scrollInfo(sc);
      await scrollByAmount(sc, dir * info.step);
    } catch (e) {}
  }
  function loadedMidRange() {
    const mids = messageEls().map(messageId).filter(m => m != null);
    return mids.length ? { min: Math.min(...mids), max: Math.max(...mids) } : null;
  }

  // Next unengaged link strictly after the last engaged message (never goes back up).
  function findNextSerial(engagedIds, lastMid, endLink) {
    const done = new Set((engagedIds || []).map(String));
    let skipped = 0;
    for (const { el, link, id, mid } of serialItems()) {
      if (lastMid != null && mid < lastMid) continue;
      if (done.has(id)) continue;
      // My own post: never engage it. If it is the end link, the run is over.
      if (isOwnLink(link)) {
        if (endLink && sameLink(link, endLink)) return { el: null, link: null, skipped, ownEnd: true };
        continue;
      }
      if (isEngaged(id)) { noteSkip(link, id); continue; }   // link database / some engine already engaged it
      if (alreadyReacted(el)) { skipped++; continue; }
      return { el, link, skipped: skipped + flushSkips() };
    }
    return { el: null, link: null, skipped };
  }

  // ── Shared "already engaged by any engine" list (written by content.js) ──
  // A link any engine (REP/FED/SEA/GIV/TAR/TG) already replied to is skipped here
  // BEFORE opening it on X, and noted in History as "Already engaged by <engine>".
  let repliedIds = new Set();
  // Shared link database (linkdb.js): found -> skip, not found -> normal.
  function isEngaged(id) { return repliedIds.has(id) || (typeof ZexDB !== 'undefined' && ZexDB.has(id)); }
  let repliedBy = {};
  let skipBank = 0;                       // newly seen skips, reported with the next engaged link
  const skipSeen = new Set();
  function flushSkips() { const n = skipBank; skipBank = 0; return n; }
  async function loadReplied() {
    try {
      if (typeof ZexDB !== 'undefined') await ZexDB.ready;
      const d = await chrome.storage.local.get(['zenRepliedStatusIds', 'zenRepliedBy', 'zenReplyHistory']);
      repliedIds = new Set(Array.isArray(d.zenRepliedStatusIds) ? d.zenRepliedStatusIds.map(String) : []);
      if (Array.isArray(d.zenReplyHistory)) for (const h of d.zenReplyHistory) { const m = h && String(h.link || '').match(/\/status\/(\d+)/); if (m) repliedIds.add(m[1]); }
      repliedBy = (d.zenRepliedBy && typeof d.zenRepliedBy === 'object') ? d.zenRepliedBy : {};
    } catch (e) {}
  }
  function engTag(raw) {
    const u = String(raw || '').trim().toUpperCase();
    if (u === 'FED-GIV') return 'FED';
    if (u === 'GET') return 'MANUAL';
    return ['REP', 'FED', 'SEA', 'GIV', 'TAR', 'TG', 'SESS', 'MANUAL'].indexOf(u) >= 0 ? u : '';
  }
  function noteSkip(link, sid) {
    if (skipSeen.has(sid)) return;
    skipSeen.add(sid);
    skipBank++;
    try {
      chrome.storage.local.get(['zenReplyHistory', 'zenSkipLog'], (d) => {
        const hist = Array.isArray(d.zenReplyHistory) ? d.zenReplyHistory : [];
        const log = Array.isArray(d.zenSkipLog) ? d.zenSkipLog : [];
        if (log.some((x) => x && x.sid === sid && x.cur === 'TG')) return;
        const prev = hist.find((h) => h && statusId(h.link || '') === sid);
        const db = (typeof ZexDB !== 'undefined') ? ZexDB.get(sid) : null;
        const by = (repliedBy[sid] && repliedBy[sid].eng) || (prev ? engTag(prev.eng || prev.src || prev.tone) : '') || (db && db.code === 'd' ? engTag(db.eng) : '');
        const why = db && db.code === 'o' ? 'comment_off' : db && db.code === 'b' ? 'commented_before' : undefined;
        log.unshift({ sid, link: link || (prev && prev.link) || '', author: linkUser(link) || (prev && prev.author) || '',
          by, cur: 'TG', reason: why, prevReply: prev ? (prev.reply || '') : '', ts: Date.now() });
        chrome.storage.local.set({ zenSkipLog: log.slice(0, 300) });
      });
    } catch (e) {}
  }

  // ── Drag support (mouse + touch) ────────────────────────────────
  function makeDraggable(box, handle) {
    let sx = 0, sy = 0, ox = 0, oy = 0, dragging = false, moved = false;
    handle.style.touchAction = 'none';
    handle.addEventListener('pointerdown', e => {
      if (e.target.closest('button,input')) return;
      const r = box.getBoundingClientRect();
      ox = r.left; oy = r.top; sx = e.clientX; sy = e.clientY;
      dragging = true; moved = false;
      try { handle.setPointerCapture(e.pointerId); } catch (err) {}
    });
    handle.addEventListener('pointermove', e => {
      if (!dragging) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) moved = true;
      if (!moved) return;
      const r = box.getBoundingClientRect();
      const x = Math.min(Math.max(4, ox + dx), Math.max(4, window.innerWidth - r.width - 4));
      const y = Math.min(Math.max(4, oy + dy), Math.max(4, window.innerHeight - r.height - 4));
      box.style.left = x + 'px'; box.style.top = y + 'px';
      box.style.right = 'auto'; box.style.bottom = 'auto';
    });
    const end = e => {
      if (!dragging) return;
      dragging = false;
      try { handle.releasePointerCapture(e.pointerId); } catch (err) {}
      if (moved) { e.preventDefault(); e.stopPropagation(); }
    };
    handle.addEventListener('pointerup', end);
    handle.addEventListener('pointercancel', end);
  }

  // ═════════════════ GROUP ENGAGE ═════════════════
  let tickBusy = false;
  let lastNotFoundToast = 0;
  let engageView = null;           // 'idle' | 'running' — which body is rendered
  let collapsed = false;
  let stopCountdown = null;
  let breakTimer = null;

  async function getState() {
    try {
      const d = await chrome.storage.local.get(['zenTgActive', 'zenTgWidgetArmed']);
      return { active: d.zenTgActive || null, armed: !!d.zenTgWidgetArmed };
    } catch (e) { return { active: null, armed: false }; }
  }

  async function tick() {
    if (tickBusy) return;
    tickBusy = true;
    try { await tickInner(); } finally { tickBusy = false; }
  }

  async function tickInner() {
    const { active, armed } = await getState();
    renderEngageWidget(active, armed);
    if (!active || !active.running) return;
    if (active.phase !== 'FIND_START' && active.phase !== 'FIND_NEXT') return;
    await loadOwnHandle();
    await loadReplied();

    if (active.phase === 'FIND_START') {
      const hit = findStartItem(active);
      const el = hit ? hit.el : null;
      const startLink = hit ? hit.link : active.targetLink;
      if (!el) {
        const now = Date.now();
        if (now - lastNotFoundToast > 8000) {
          lastNotFoundToast = now;
          toast(messageEls().length
            ? 'Could not find that link in this chat yet. Still checking every few seconds…'
            : 'No chat is open on Telegram yet. Open the group, then this picks up automatically.', 4500);
        }
        await send({ type: 'zenTgNoLink', failed: false });   // just waiting — not a failure
        return;
      }
      if (isOwnLink(startLink)) {
        // The starting link is my own post — don't react or engage it, just carry on from here.
        toast('That starting link is your own post — skipping it and continuing from the next one.', 3500);
        await send({ type: 'zenTgStartOwn', link: startLink, mid: messageId(el) });
        return;
      }
      if (isEngaged(statusId(startLink))) {
        // Starting link was already engaged by some engine — skip it, continue with the next one.
        toast('The starting link was already engaged — skipping it and continuing from the next one.', 3500);
        noteSkip(startLink, statusId(startLink));
        await send({ type: 'zenTgStartOwn', link: startLink, mid: messageId(el) });
        return;
      }
      // Reaction is turned off: just bring the message into view and open the link on X.
      try { el.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (e) {}
      await sleep(300);
      toast('Opening this link on X.', 2500);
      await send({ type: 'zenTgReacted', link: startLink, skipped: 0, mid: messageId(el) });
      return;
    }

    // FIND_NEXT
    if (active.breakUntil && Date.now() < active.breakUntil) return;
    const anchorMid = active.lastMid != null ? active.lastMid : active.startMid;
    // The window Telegram has loaded starts AFTER the current anchor → older messages between
    // them are not loaded. Scroll up until the anchor is reachable so nothing in between is missed.
    const rng = loadedMidRange();
    if (anchorMid != null && rng && rng.min > anchorMid && gapScrolls < 8) {
      gapScrolls++;
      await stepChat(-1);
      setTimeout(() => tick().catch(() => {}), 1200);
      return;
    }
    const found = findNextSerial(active.engagedLinks, anchorMid, active.endLink);
    if (found.el) gapScrolls = 0;
    const { el, link, skipped, ownEnd } = found;
    if (ownEnd) { await send({ type: 'zenTgOwnEnd' }); return; }
    if (!el) {
      // Nothing after the anchor is loaded → load newer messages and look again.
      await stepChat(1);
      setTimeout(() => tick().catch(() => {}), 1500);
      await send({ type: 'zenTgNoLink', failed: false });
      return;
    }
    try { el.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (e) {}
    await sleep(300);
    toast('Opening the next link on X. (' + skipped + ' already-engaged skipped)', 2500);
    await send({ type: 'zenTgReacted', link, skipped, mid: messageId(el) });
  }

  function ensureEngageWidget() {
    if (document.getElementById('zen-tg-widget')) return;
    const box = document.createElement('div');
    box.id = 'zen-tg-widget';
    box.className = 'zt-card';
    Object.assign(box.style, { position: 'fixed', bottom: '20px', right: '20px', zIndex: '2147483000' });
    box.innerHTML = `
      <div id="zen-tg-widget-header" class="zt-head">
        <div class="zt-mark">Z</div>
        <div class="zt-titles"><span class="zt-brand">Z EX</span><span class="zt-title">Telegram Group Engage</span></div>
        <button type="button" id="zen-tg-minimize" class="zt-min" title="Minimize">–</button>
      </div>
      <div id="zen-tg-widget-body"></div>
      <button type="button" id="zen-tg-orb" class="zt-orb" title="Expand">Z</button>`;
    document.body.appendChild(box);
    if (window.ZEX_PANEL_BG) ZEX_PANEL_BG.attach(box, { height: 92, before: box.querySelector('#zen-tg-widget-body'), style: 'margin:0 0 8px;' });
    const setCollapsed = c => {
      collapsed = c;
      box.querySelector('#zen-tg-widget-header').style.display = c ? 'none' : 'flex';
      box.querySelector('#zen-tg-widget-body').style.display = c ? 'none' : 'block';
      box.querySelector('#zen-tg-orb').style.display = c ? 'flex' : 'none';
      box.classList.toggle('zt-collapsed', c);
    };
    box.querySelector('#zen-tg-minimize').onclick = () => setCollapsed(true);
    box.querySelector('#zen-tg-orb').onclick = () => setCollapsed(false);
    makeDraggable(box, box.querySelector('#zen-tg-widget-header'));
    makeDraggable(box, box.querySelector('#zen-tg-orb'));
  }

  // Accepts a bare ID or anything containing one: full link, "user/status/ID", "x.com//status/ID",
  // links with ?s=20 etc. Returns the digits, or '' if none found.
  function extractPostId(text) {
    const t = String(text || '').trim();
    let m = t.match(/status(?:es)?\/+(\d{5,19})/i);
    if (m) return m[1];
    m = t.match(/(?:^|\D)(\d{5,19})(?!\d)/);
    return m ? m[1] : '';
  }

  function renderEngageIdle(body) {
    body.innerHTML = `
      <p class="zt-hint">Open the group you want to work through, pick a model, then give it a starting point. It goes down the chat in order from there.</p>
      <button type="button" id="zen-tg-last" class="zt-last" hidden>Continue from the last link</button>
      <input id="zen-tg-group-input" class="zt-input" type="text" placeholder="Group name (auto-detected)" autocomplete="off" spellcheck="false" title="Detected from the open chat. Failed links are saved under this name. Edit it if it is wrong." />
      <select id="zen-tg-model" class="zt-input">
        <option value="model1">Model 1 — Start ID</option>
        <option value="model2">Model 2 — Starting link</option>
      </select>
      <p id="zen-tg-model-hint" class="zt-hint" style="margin-bottom:8px;"></p>
      <input id="zen-tg-startid-input" class="zt-input" type="text" inputmode="numeric" placeholder="Start ID or whole link" autocomplete="off" spellcheck="false" />
      <input id="zen-tg-start-input" class="zt-input" type="text" placeholder="Starting link or whole message" autocomplete="off" spellcheck="false" />
      <input id="zen-tg-end-input" class="zt-input" type="text" placeholder="End link, optional" autocomplete="off" spellcheck="false" />
      <button type="button" id="zen-tg-start-btn" class="zt-btn">Start by ID</button>
      <button type="button" id="zen-tg-exit-btn" class="zt-ghost">Not now, go back</button>`;

    // Group name: auto-detected from the open chat and kept in sync while this panel is open (edit it to override; clear it to go back to auto).
    const groupInput = body.querySelector('#zen-tg-group-input');
    let groupManual = false;
    groupInput.addEventListener('input', () => { groupManual = groupInput.value.trim() !== ''; });
    const syncGroup = () => {
      if (!groupInput.isConnected) { clearInterval(groupTimer); return; }
      if (!groupManual && document.activeElement !== groupInput) { const g = getGroupName(); if (g !== groupInput.value) groupInput.value = g; }
    };
    const groupTimer = setInterval(syncGroup, 1500);
    syncGroup();
    const modelSel = body.querySelector('#zen-tg-model');
    const idInput = body.querySelector('#zen-tg-startid-input');
    const linkInput = body.querySelector('#zen-tg-start-input');
    const startBtn = body.querySelector('#zen-tg-start-btn');
    const modelHint = body.querySelector('#zen-tg-model-hint');
    const applyModel = (m) => {
      const one = m !== 'model2';
      modelSel.value = one ? 'model1' : 'model2';
      idInput.style.display = one ? '' : 'none';
      linkInput.style.display = one ? 'none' : '';
      startBtn.textContent = one ? 'Start by ID' : 'Start session';
      modelHint.textContent = one
        ? 'Model 1: type the X post ID. It starts at that post and goes down the chat in order.'
        : 'Model 2: paste the starting link (the whole message works too). It starts there and goes down the chat in order.';
    };
    applyModel('model1');
    try { chrome.storage.local.get('zenTgModel').then(d => applyModel(d && d.zenTgModel)); } catch (e) {}
    modelSel.onchange = () => {
      applyModel(modelSel.value);
      try { chrome.storage.local.set({ zenTgModel: modelSel.value }); } catch (e) {}
    };

    const cleanId = () => {
      const raw = idInput.value.trim();
      if (!raw) return;
      const id = extractPostId(raw);
      if (id && id !== raw) idInput.value = id;      // link pasted → keep only the ID
    };
    idInput.addEventListener('input', cleanId);
    idInput.addEventListener('paste', () => setTimeout(cleanId, 0));

    startBtn.onclick = async () => {
      const endText = body.querySelector('#zen-tg-end-input').value.trim();
      const endLink = endText ? normalizeLink(endText) : null;
      let res;
      if (modelSel.value === 'model2') {
        const link = normalizeLink(linkInput.value.trim());
        if (!link) { toast('Paste a real x.com link (or the whole message containing one) first.', 3500); return; }
        res = await send({ type: 'zenTgStart', link, endLink, group: groupInput.value.trim() || getGroupName() });
      } else {
        const id = extractPostId(idInput.value);
        if (!/^\d{5,19}$/.test(id)) { toast('Enter an X post ID or paste the post link.', 3500); return; }
        idInput.value = id;
        res = await send({ type: 'zenTgStart', link: 'https://x.com/i/status/' + id, endLink, startId: id, group: groupInput.value.trim() || getGroupName() });
      }
      if (!res || !res.ok) toast((res && REASONS[res.reason]) || 'Could not start. Try again.', 4000);
    };

    try {
      chrome.storage.local.get('zenTgLast').then(d => {
        const last = d && d.zenTgLast;
        const btn = body.querySelector('#zen-tg-last');
        if (!btn || !last || !last.link || Date.now() - last.ts > 86400000) return;
        btn.hidden = false;
        btn.onclick = () => {
          // Fills whichever model is selected: the ID for Model 1, the link for Model 2.
          if (modelSel.value === 'model2') linkInput.value = last.link;
          else idInput.value = extractPostId(last.link);
          if (last.endLink) body.querySelector('#zen-tg-end-input').value = last.endLink;
          btn.hidden = true;
        };
      });
    } catch (e) {}

    const exit = body.querySelector('#zen-tg-exit-btn');
    exit.onclick = () => {
      if (exit.disabled) return;
      exit.disabled = true;
      let n = 3;
      exit.textContent = 'Going back in ' + n + '…';
      const t = setInterval(() => {
        n--;
        if (n <= 0) {
          clearInterval(t);
          send({ type: 'zenTgStop' });
          document.getElementById('zen-tg-widget')?.remove();
          engageView = null;
          return;
        }
        exit.textContent = 'Going back in ' + n + '…';
      }, 1000);
    };
  }

  function fmtCountdown(until, label) {
    const secs = Math.max(0, Math.ceil((until - Date.now()) / 1000));
    const long = /break/i.test(label || '') || secs >= 60;
    const t = long ? Math.floor(secs / 60) + ':' + String(secs % 60).padStart(2, '0') : secs + 's';
    return (label || 'Next in') + ' ' + t;
  }

  function renderEngageRunning(body, s) {
    if (stopCountdown !== null) return;           // keep the STOPPING… button stable
    if (breakTimer) { clearInterval(breakTimer); breakTimer = null; }
    const onBreak = s.breakUntil && Date.now() < s.breakUntil;
    const statusText = onBreak ? fmtCountdown(s.breakUntil, s.breakLabel)
      : s.waitStartedAt ? 'Waiting for a new link.'
      : s.phase === 'IDLE_X' ? 'Engaging this link on X.'
      : 'Finding the next link' + (s.anchorId ? ' after …' + String(s.anchorId).slice(-6) : '') + '.';
    const stat = (n, label, cls = '') => `<div class="zt-stat ${cls}"><b>${n || 0}</b><span>${label}</span></div>`;
    body.innerHTML = `
      <div><span class="zt-pill${onBreak ? ' zt-rest' : ''}"><i></i>${onBreak ? 'Break' : 'Live'}</span></div>
      <p id="zen-tg-status-text" class="zt-status">${statusText}</p>
      <div class="zt-stats">
        ${stat(s.doneCount, 'Replied', 'zt-done')}
        ${stat(s.skippedCount, 'Skipped')}
        ${stat(s.failedCount, 'Failed', s.failedCount > 0 ? 'zt-bad' : '')}
      </div>
      <button type="button" id="zen-tg-stop-btn" class="zt-stop">STOP</button>`;
    if (onBreak) {
      const el = body.querySelector('#zen-tg-status-text');
      breakTimer = setInterval(() => {
        if (!el.isConnected || Date.now() >= s.breakUntil) { clearInterval(breakTimer); breakTimer = null; return; }
        el.textContent = fmtCountdown(s.breakUntil, s.breakLabel);
      }, 1000);
    }
    const stopBtn = body.querySelector('#zen-tg-stop-btn');
    stopBtn.onclick = () => {
      if (stopCountdown !== null) return;
      stopCountdown = 3;
      stopBtn.disabled = true;
      stopBtn.textContent = 'STOPPING ' + stopCountdown + '…';
      const t = setInterval(() => {
        stopCountdown--;
        if (stopCountdown <= 0) {
          clearInterval(t);
          stopCountdown = null;
          send({ type: 'zenTgStop' });
          return;
        }
        stopBtn.textContent = 'STOPPING ' + stopCountdown + '…';
      }, 1000);
    };
  }

  function renderEngageWidget(active, armed) {
    if (!(active && active.running) && !armed) {
      document.getElementById('zen-tg-widget')?.remove();
      engageView = null;
      return;
    }
    ensureEngageWidget();
    const body = document.getElementById('zen-tg-widget-body');
    if (!body) return;
    if (active && active.running) {
      renderEngageRunning(body, active);
      engageView = 'running';
    } else if (engageView !== 'idle') {
      renderEngageIdle(body);
      engageView = 'idle';
    }
  }

  // ═════════════════ LINK SWEEP ═════════════════
  let sweep = { phase: 'idle', collected: [] };
  let sweepBusy = false;
  let sweepCancel = false;
  let sweepEl = null;
  let sweepArmedSeen = false;
  let sweepLastInput = '';
  let sweepCarry = [];               // links kept when re-sweeping ("Sweep again")

  // Finds the scrollable message list (Telegram nests several scroll areas).
  function findScroller(fromEl) {
    const cands = Array.from(document.querySelectorAll(
      '#column-center .scrollable-y, #column-center .scrollable, #column-center .bubbles, #column-center .bubbles-inner,' +
      '.scrollable-y, .scrollable, .bubbles, .bubbles-inner, [class*="MessageList"], [class*="message-list"], [class*="Messages"]'
    )).filter(e => e.scrollHeight > e.clientHeight + 40).sort((a, b) => b.clientHeight - a.clientHeight);
    if (cands[0]) return cands[0];
    const chain = [];
    let n = fromEl;
    for (let i = 0; i < 12 && n; i++) {
      if (n.scrollHeight > n.clientHeight + 40) chain.push(n);
      n = n.parentElement;
    }
    chain.push(document.scrollingElement || document.documentElement);
    for (const c of chain) {
      const top = c.scrollTop;
      let moved = false;
      try { c.scrollTop = top + 50; moved = c.scrollTop !== top; } catch (e) { continue; }
      if (!moved) { try { c.scrollTop = top - 50; moved = c.scrollTop !== top; } catch (e) {} }
      try { c.scrollTop = top; } catch (e) {}
      if (moved) return c;
    }
    return chain[chain.length - 1];
  }

  // Stops Telegram's scroll anchoring from fighting our programmatic scrolling.
  function lockScrollBehavior(scroller) {
    const els = Array.from(new Set([scroller, ...scroller.querySelectorAll('[style*="overflow"]')]));
    const saved = els.map(el => ({
      el,
      anchor: el.style.getPropertyValue('overflow-anchor'),
      overscroll: el.style.getPropertyValue('overscroll-behavior'),
      behavior: el.style.getPropertyValue('scroll-behavior'),
    }));
    for (const el of els) {
      el.style.setProperty('overflow-anchor', 'none');
      el.style.setProperty('overscroll-behavior', 'contain');
      el.style.setProperty('scroll-behavior', 'auto');
    }
    return () => {
      for (const s of saved) {
        s.el.style.setProperty('overflow-anchor', s.anchor);
        s.el.style.setProperty('overscroll-behavior', s.overscroll);
        s.el.style.setProperty('scroll-behavior', s.behavior);
      }
    };
  }
  function scrollInfo(scroller) {
    if (scroller) {
      return { top: scroller.scrollTop, max: Math.max(0, scroller.scrollHeight - scroller.clientHeight), step: Math.max(360, scroller.clientHeight * 0.85) };
    }
    return { top: window.scrollY, max: Math.max(0, document.documentElement.scrollHeight - window.innerHeight), step: Math.max(360, window.innerHeight * 0.85) };
  }
  async function scrollByAmount(scroller, dy) {
    const cur = () => scroller ? scroller.scrollTop : window.scrollY;
    const before = cur();
    try { (scroller || window).scrollBy(0, dy); } catch (e) {
      if (scroller) scroller.scrollTop = before + dy; else window.scrollTo(0, before + dy);
    }
    await sleep(80);
    if (Math.abs(cur() - before) < 2) {
      try { if (scroller) scroller.scrollTop = before + dy; else window.scrollTo(0, before + dy); } catch (e) {}
      await sleep(80);
    }
    try { (scroller || window).dispatchEvent(new Event('scroll', { bubbles: true })); } catch (e) {}
  }

  async function reportSweep() {
    try { await send({ type: 'zenTgSweepProgress', collected: sweep.collected, phase: sweep.phase }); } catch (e) {}
  }

  // Scrolls UP through history until the message carrying this post ID is on screen.
  // Returns the serial item ({ el, link, id, mid, idx }) or null.
  async function locateStart(id) {
    const find = () => serialItems().find(x => x.id === String(id)) || null;
    let it = find();
    if (it) return it;
    const scroller = findScroller(messageEls()[0] || document.body);
    for (let i = 0; i < 150 && !sweepCancel; i++) {
      const before = scrollInfo(scroller);
      await scrollByAmount(scroller, -before.step);
      await sleep(250);
      it = find();
      if (it) return it;
      const after = scrollInfo(scroller);
      if (after.top === before.top && before.top <= 0) break;
    }
    return null;
  }

  function finishSweep() {
    if (sweepCarry.length) {
      sweep.collected = Array.from(new Set([...sweepCarry, ...sweep.collected]));
      sweepCarry = [];
    }
    sweep.phase = 'done';
  }

  async function runSweep(inputText) {
    if (sweepBusy) return;
    // Start point: a link, a whole message containing one, or just the post ID.
    const startLink = allLinksIn(inputText)[0] || null;
    const startId = startLink ? statusId(startLink) : extractPostId(inputText);
    if (!startId) { toast('No X link or post ID in that. Paste one from the message you want to start at.', 3500); return; }
    sweepLastInput = inputText;
    sweepBusy = true;
    sweepCancel = false;
    sweep = { phase: 'searching', collected: [], skipped: 0 };
    renderSweep();
    await reportSweep();

    const startItem = await locateStart(startId);
    if (!startItem) {
      const cancelled = sweepCancel;
      sweepBusy = false;
      sweep.phase = 'idle';
      renderSweep();
      if (!cancelled) toast('Could not find that message anywhere in this chat.', 4500);
      return;
    }

    await loadOwnHandle();
    await loadReplied();
    const startEl = startItem.el;
    const startMid = startItem.mid, startIdx = startItem.idx;
    sweep.phase = 'scanning';
    renderSweep();
    const scroller = findScroller(startEl);
    const unlock = lockScrollBehavior(scroller);
    // Serial collection: start at the start link, then every X link below it in chat order
    // (Telegram message id, then position inside the message). Keyed by post ID, so the list
    // re-rendering or messages unloading never duplicates or loses anything already caught.
    const got = new Map();          // post id → { link, mid, idx }
    const skippedIds = new Set();   // already engaged by some engine → left out
    let stuckRounds = 0;
    let lastTop = -1;

    const collectVisible = () => {
      let changed = false;
      for (const it of serialItems()) {
        if (it.mid < startMid) continue;
        if (it.mid === startMid && it.idx < startIdx) continue;
        if (got.has(it.id) || skippedIds.has(it.id)) continue;
        if (isOwnLink(it.link)) continue;                        // my own post — leave it out
        if (isEngaged(it.id)) { skippedIds.add(it.id); changed = true; continue; }   // already done → skip
        got.set(it.id, { link: it.link, mid: it.mid, idx: it.idx });
        changed = true;
      }
      sweep.collected = [...got.values()].sort((a, b) => (a.mid - b.mid) || (a.idx - b.idx)).map(x => x.link);
      sweep.skipped = skippedIds.size;
      return changed;
    };

    while (!sweepCancel) {
      const changed = collectVisible();
      renderSweep();
      await reportSweep();
      const { top, max, step } = scrollInfo(scroller);
      const atBottom = top >= max - 4;
      if (atBottom && top === lastTop && !changed) stuckRounds++; else stuckRounds = 0;
      lastTop = top;
      if (atBottom && stuckRounds === 3) { await scrollByAmount(scroller, step * 1.6); await sleep(500); }
      if (stuckRounds >= 5) break;
      await scrollByAmount(scroller, step);
      await sleep(atBottom ? 500 : 250);
    }

    if (!sweepCancel) { await sleep(900); collectVisible(); renderSweep(); await reportSweep(); }
    unlock();
    sweepBusy = false;
    if (sweep.phase !== 'stopping') { finishSweep(); renderSweep(); await reportSweep(); }
  }

  function stopSweep() {
    if (sweep.phase !== 'scanning' && sweep.phase !== 'searching') return;
    sweepCancel = true;
    sweep.phase = 'stopping';
    sweep.stopCountdown = 3;
    renderSweep();
    const step = () => {
      sweep.stopCountdown--;
      if (sweep.stopCountdown <= 0) { finishSweep(); renderSweep(); reportSweep(); return; }
      renderSweep();
      setTimeout(step, 1000);
    };
    setTimeout(step, 1000);
  }

  async function sendSweepToQueue() {
    const links = sweep.collected.slice();
    if (!links.length) { toast('Nothing to send — no links were caught.', 3000); return; }
    const res = await send({ type: 'zenTgSweepSend', links });
    if (res && res.ok) {
      toast('Queue started — ' + links.length + ' link' + (links.length === 1 ? '' : 's') + ' will be engaged in the background.', 4500);
      removeSweepWidget();
      send({ type: 'zenTgSweepCancel' });
    } else {
      toast((res && REASONS[res.reason]) || 'Could not start the queue. Try again.', 4000);
    }
  }

  async function cancelSweepPanel() {
    sweepCarry = [];
    sweepCancel = true;
    try { await send({ type: 'zenTgSweepCancel' }); } catch (e) {}
    removeSweepWidget();
  }

  // ── Saved sweep folders (chrome.storage.local.zenTgSweepFolders) ──
  async function getSweepFolders() {
    try {
      const d = await chrome.storage.local.get('zenTgSweepFolders');
      return Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders : [];
    } catch (e) { return []; }
  }
  async function saveSweepFolder(name) {
    const links = sweep.collected.slice();
    if (!links.length) { toast('Nothing to save — no links were caught.', 3000); return false; }
    const list = await getSweepFolders();
    const label = (name || '').trim() ||
      'Sweep ' + new Date().toLocaleString([], { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
    list.unshift({ id: 'f' + Date.now().toString(36), name: label.slice(0, 60), links, createdAt: Date.now() });
    try { await chrome.storage.local.set({ zenTgSweepFolders: list.slice(0, 100) }); }
    catch (e) { toast('Could not save the folder. Try again.', 3500); return false; }
    toast('Saved "' + label.slice(0, 60) + '" — ' + links.length + ' link' + (links.length === 1 ? '' : 's') + '. Run it anytime from the Sweep tab.', 4500);
    return true;
  }
  async function runSweepFolder(id) {
    const f = (await getSweepFolders()).find(x => x.id === id);
    if (!f || !f.links || !f.links.length) { toast('That folder is empty or missing.', 3000); return; }
    const res = await send({ type: 'zenTgSweepSend', links: f.links.slice(), retryIds: f.auto === 'zexerr' ? f.links.map((u) => { const m = String(u).match(/status\/(\d+)/); return m ? m[1] : ''; }).filter(Boolean) : [] });
    if (res && res.ok) {
      toast('Queue started — "' + f.name + '" (' + f.links.length + ' links) is running in the background.', 4500);
      removeSweepWidget();
      send({ type: 'zenTgSweepCancel' });
    } else {
      toast((res && REASONS[res.reason]) || 'Could not start the queue. Try again.', 4000);
    }
  }
  async function fillFolderPicker(box) {
    const holder = box.querySelector('#zen-tgs-folders');
    if (!holder) return;
    const list = (await getSweepFolders()).filter(f => !(f && f.auto === 'tgfail' && Date.now() - (f.createdAt || 0) > 86400000));
    if (!list.length) return;
    holder.innerHTML =
      `<div style="font-size:9px;letter-spacing:1.6px;font-weight:700;color:rgba(250,204,21,0.75);margin:2px 0 6px;">SAVED FOLDERS</div>` +
      `<select id="zen-tgs-folder-sel" style="${SW_INPUT}"></select>` +
      `<button id="zen-tgs-folder-run" type="button" style="${swGhost}">Run selected folder</button>`;
    const sel = holder.querySelector('#zen-tgs-folder-sel');
    list.forEach(f => {
      const o = document.createElement('option');
      o.value = f.id;
      o.textContent = f.name + ' (' + f.links.length + ')';
      sel.appendChild(o);
    });
    holder.querySelector('#zen-tgs-folder-run').onclick = () => runSweepFolder(sel.value);
  }

  function ensureSweepWidget() {
    if (sweepEl) return sweepEl;
    if (!document.body) return null;
    sweepEl = document.createElement('div');
    sweepEl.id = 'zen-tgs-widget';
    Object.assign(sweepEl.style, {
      position: 'fixed', bottom: '18px', left: '18px', zIndex: '2147483000', width: '270px', maxWidth: 'calc(100vw - 36px)',
      fontSize: '12px', borderRadius: '20px', overflow: 'hidden', padding: '13px 14px 14px',
      background: 'radial-gradient(120% 80% at 100% 0%,rgba(234,179,8,0.18),transparent 58%),linear-gradient(165deg,rgba(28,24,14,0.97),rgba(9,9,10,0.98))',
      border: '1px solid rgba(250,204,21,0.28)',
      boxShadow: '0 20px 48px rgba(0,0,0,0.62),0 0 34px rgba(234,179,8,0.10),inset 0 1px 0 rgba(255,255,255,0.08)',
      backdropFilter: 'blur(16px) saturate(1.3)', WebkitBackdropFilter: 'blur(16px) saturate(1.3)',
      cursor: 'move', touchAction: 'none',
    });
    document.body.appendChild(sweepEl);
    if (window.ZEX_PANEL_BG) ZEX_PANEL_BG.attach(sweepEl, { height: 84, prepend: true, pin: true, style: 'width:calc(100% + 28px);margin:-13px -14px 10px;' });
    makeDraggable(sweepEl, sweepEl);
    return sweepEl;
  }
  function removeSweepWidget() {
    if (sweepEl) sweepEl.remove();
    sweepEl = null;
  }

  const SW_INPUT = `width:100%;padding:10px 12px;border-radius:12px;border:1px solid rgba(250,204,21,0.2);background:rgba(255,255,255,0.05);color:#fdf6e3;font-size:12px;outline:none;font-family:${FONT};margin-bottom:8px;box-sizing:border-box;`;
  const swBtn = primary => primary
    ? `width:100%;height:36px;border:none;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:10.5px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase;color:#2b1d00;background:linear-gradient(180deg,#fde68a,#eab308);box-shadow:0 6px 18px rgba(234,179,8,0.28);margin-bottom:7px;`
    : `width:100%;height:34px;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:10px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:#ffd9d9;background:linear-gradient(180deg,rgba(255,92,92,0.22),rgba(255,92,92,0.07));border:1px solid rgba(255,130,130,0.4);margin-bottom:7px;`;
  const swGhost = `width:100%;height:32px;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:10px;font-weight:600;letter-spacing:1.1px;text-transform:uppercase;color:rgba(253,246,227,0.72);background:rgba(255,255,255,0.05);border:1px solid rgba(250,204,21,0.2);margin-bottom:7px;`;
  const swHead = `<div style="font-size:8px;letter-spacing:2.2px;font-weight:700;color:rgba(250,204,21,0.75);margin-bottom:2px;">Z EX</div><div style="font-size:12px;font-weight:700;color:#fff8e1;margin-bottom:9px;">Link Sweep</div>`;
  const swText = 'font-size:11px;color:rgba(253,246,227,0.8);margin-bottom:9px;line-height:1.5;';

  function renderSweep() {
    const box = ensureSweepWidget();
    if (!box) return;
    const n = sweep.collected.length;
    const plural = n === 1 ? '' : 's';

    if (sweep.phase === 'idle') {
      box.innerHTML = swHead +
        `<div style="font-size:10.5px;line-height:1.5;color:rgba(253,246,227,0.72);margin-bottom:9px;">Drop a link, a post ID or a whole message from where you want to start. Every X link from there down to the newest message gets swept up, one by one in chat order. Links you already engaged are skipped.</div>` +
        `<input id="zen-tgs-input" type="text" placeholder="Link or post ID to start from" style="${SW_INPUT}" autocomplete="off" spellcheck="false" />` +
        `<button id="zen-tgs-start" type="button" style="${swBtn(true)}">Start sweep</button>` +
        `<div id="zen-tgs-folders"></div>` +
        `<button id="zen-tgs-cancel" type="button" style="${swGhost}">Not now, go back</button>`;
      fillFolderPicker(box);
      const input = box.querySelector('#zen-tgs-input');
      box.querySelector('#zen-tgs-start').onclick = () => { sweepCarry = []; runSweep(input.value); };
      input.addEventListener('keydown', e => { if (e.key === 'Enter') { sweepCarry = []; runSweep(input.value); } });
      box.querySelector('#zen-tgs-cancel').onclick = cancelSweepPanel;
    } else if (sweep.phase === 'searching') {
      box.innerHTML = swHead + `<div style="${swText}">Locating that message…</div>` +
        `<button id="zen-tgs-stop-search" type="button" style="${swBtn(false)}">Stop</button>`;
      box.querySelector('#zen-tgs-stop-search').onclick = stopSweep;
    } else if (sweep.phase === 'scanning') {
      box.innerHTML = swHead +
        `<div style="${swText}">Sweeping… <b style="color:#fde047;">${n}</b> caught so far.${sweep.skipped ? ` <span style="opacity:.7">(${sweep.skipped} already done, skipped)</span>` : ''}</div>` +
        `<button id="zen-tgs-stop" type="button" style="${swBtn(false)}">Stop &amp; keep what's caught</button>`;
      box.querySelector('#zen-tgs-stop').onclick = stopSweep;
    } else if (sweep.phase === 'stopping') {
      box.innerHTML = swHead +
        `<div style="${swText}">Stopping in <b style="color:#fde047;">${sweep.stopCountdown}</b>… keeping <b style="color:#fde047;">${n}</b> link${plural}.</div>`;
    } else if (sweep.phase === 'done') {
      box.innerHTML = swHead +
        `<div style="${swText}">Swept clean. <b style="color:#fde047;">${n}</b> link${plural} caught.${sweep.skipped ? ` <span style="opacity:.7">(${sweep.skipped} already done, skipped)</span>` : ''}</div>` +
        `<button id="zen-tgs-send" type="button" style="${swBtn(true)}">Send to queue</button>` +
        `<input id="zen-tgs-fname" type="text" placeholder="Folder name (optional)" style="${SW_INPUT}" autocomplete="off" spellcheck="false" />` +
        `<button id="zen-tgs-save" type="button" style="${swGhost}">Save to queue</button>` +
        `<button id="zen-tgs-again" type="button" style="${swGhost}">Sweep again (keep these)</button>` +
        `<button id="zen-tgs-new" type="button" style="${swGhost}">Start over</button>`;
      box.querySelector('#zen-tgs-send').onclick = sendSweepToQueue;
      box.querySelector('#zen-tgs-save').onclick = async () => {
        const inp = box.querySelector('#zen-tgs-fname');
        if (await saveSweepFolder(inp ? inp.value : '') && inp) inp.value = '';
      };
      box.querySelector('#zen-tgs-again').onclick = () => {
        if (!sweepLastInput) { sweep = { phase: 'idle', collected: [] }; renderSweep(); return; }
        sweepCarry = sweep.collected.slice();
        runSweep(sweepLastInput);
      };
      box.querySelector('#zen-tgs-new').onclick = () => {
        sweep = { phase: 'idle', collected: [] };
        sweepCarry = [];
        sweepLastInput = '';
        renderSweep();
      };
    }
  }

  async function sweepTick() {
    let armed = false;
    try { armed = !!(await chrome.storage.local.get('zenTgSweepArmed')).zenTgSweepArmed; } catch (e) {}
    if (armed === sweepArmedSeen && (armed ? sweepEl : !sweepEl)) return;
    sweepArmedSeen = armed;
    if (armed) {
      if (!sweepEl) { sweep = { phase: 'idle', collected: [] }; sweepCarry = []; sweepLastInput = ''; }
      renderSweep();
    } else {
      removeSweepWidget();
      sweepCancel = true;
    }
  }

  // ═════════════════ LINK STATUS TAGS ═════════════════
  // A small tag under every X link in the chat while a Z EX Telegram panel is armed:
  //   DONE · FAIL · NOW · NEXT · ALREADY COMPLETED · SKIP
  // Read-only: derived from what the extension already stores (History, skip log, run state).
  const TAG_FAIL = ['failed', 'no_get_reply', 'stuck'];
  const TAG_LABEL = { done: 'DONE', fail: 'FAIL', now: 'NOW', next: 'NEXT', already: 'ALREADY COMPLETED', skip: 'SKIP' };
  const TAG_COLOR = { done: '#16a34a', fail: '#dc2626', now: '#0ea5e9', next: '#eab308', already: '#0d9488', skip: '#f97316' };
  const tagData = { dirty: true, loading: false, replied: new Set(), by: {}, skipLog: {}, active: null, jobs: {}, armed: false };

  function injectTagStyle() {
    if (document.getElementById('zex-tg-tag-style')) return;
    const st = document.createElement('style');
    st.id = 'zex-tg-tag-style';
    st.textContent = '.zex-tg-tags{display:flex;flex-wrap:wrap;gap:4px;margin:3px 8px 4px;pointer-events:none;user-select:none;-webkit-user-select:none;}'
      + '.zex-tg-tag{font:700 9px/1 Arial,sans-serif;letter-spacing:.3px;padding:3px 6px;border-radius:5px;color:#fff;white-space:nowrap;}'
      + '.zex-tg-tag.next{color:#17181a;}';
    document.head.appendChild(st);
  }
  function removeTags() {
    document.querySelectorAll('.zex-tg-tags').forEach(n => n.remove());
  }
  async function loadTagData() {
    if (tagData.loading) return;
    tagData.loading = true;
    try {
      const d = await chrome.storage.local.get(['zenRepliedStatusIds', 'zenRepliedBy', 'zenReplyHistory', 'zenSkipLog', 'zenTgActive', 'zSessAutoJobs', 'zenTgWidgetArmed', 'zenTgSweepArmed']);
      await loadOwnHandle();
      const rep = new Set(Array.isArray(d.zenRepliedStatusIds) ? d.zenRepliedStatusIds.map(String) : []);
      if (Array.isArray(d.zenReplyHistory)) for (const h of d.zenReplyHistory) { const m = h && String(h.link || '').match(/\/status\/(\d+)/); if (m) rep.add(m[1]); }
      tagData.replied = rep;
      tagData.by = (d.zenRepliedBy && typeof d.zenRepliedBy === 'object') ? d.zenRepliedBy : {};
      const sk = {};
      if (Array.isArray(d.zenSkipLog)) for (const x of d.zenSkipLog) { if (x && x.sid) (sk[x.sid] = sk[x.sid] || []).push(x); }
      tagData.skipLog = sk;
      tagData.active = d.zenTgActive || null;
      tagData.jobs = (d.zSessAutoJobs && typeof d.zSessAutoJobs === 'object') ? d.zSessAutoJobs : {};
      tagData.armed = !!(d.zenTgWidgetArmed || d.zenTgSweepArmed);
      tagData.dirty = false;
    } catch (e) {} finally { tagData.loading = false; }
  }
  function tagStatus(id, link, el) {
    const db = (typeof ZexDB !== 'undefined') ? ZexDB.get(id) : null;
    if (db && db.code === 'o') return { k: 'skip', note: 'comments off' };
    if (db && db.code === 'b') return { k: 'already' };
    if (db && db.code === 'd' && (db.eng === 'TG' || db.eng === 'SESS')) return { k: 'done' };
    const by = tagData.by[id];
    if (by && (by.eng === 'TG' || by.eng === 'SESS')) return { k: 'done' };
    const logs = tagData.skipLog[id] || [];
    if (logs.some(x => x.reason === 'comment_off')) return { k: 'skip', note: 'comments off' };
    if (isOwnLink(link)) return { k: 'skip', note: 'own post' };
    if (db || tagData.replied.has(id) || logs.some(x => !x.reason || x.reason === 'commented_before')) return { k: 'already' };
    const f = logs.find(x => TAG_FAIL.indexOf(x.reason) >= 0);
    if (f) return { k: 'fail', note: f.reason === 'no_get_reply' ? 'no GET Reply' : f.reason === 'stuck' ? 'stuck' : '' };
    if (alreadyReacted(el)) return { k: 'already' };
    return null;
  }
  // id -> 'now' | 'next' for the run that is going right now (read-only, no side effects).
  function tagLiveMarks() {
    const m = {};
    const a = tagData.active;
    if (a && a.running) {
      if (a.phase === 'IDLE_X' && a.currentUrl) m[statusId(a.currentUrl)] = 'now';
      if (a.phase === 'FIND_START') {
        const hit = findStartItem(a);
        if (hit) m[hit.id] = 'next';
      } else {
        const anchor = a.lastMid != null ? a.lastMid : a.startMid;
        const done = new Set((a.engagedLinks || []).map(String));
        const cur = a.currentUrl ? statusId(a.currentUrl) : '';
        for (const it of serialItems()) {
          if (anchor != null && it.mid < anchor) continue;
          if (done.has(it.id) || it.id === cur) continue;
          if (isOwnLink(it.link) || tagData.replied.has(it.id) || isEngaged(it.id) || alreadyReacted(it.el)) continue;
          m[it.id] = 'next'; break;
        }
      }
    }
    const j = tagData.jobs && tagData.jobs.telegram_sweep;
    if (j && Array.isArray(j.queue) && (j.status === 'working' || j.status === 'navigating')) {
      const c = j.queue[j.currentIndex], n = j.queue[j.currentIndex + 1];
      if (c && c.xUrl) m[statusId(c.xUrl)] = 'now';
      if (n && n.xUrl) m[statusId(n.xUrl)] = 'next';
    }
    return m;
  }
  async function tagLoop() {
    try {
      if (document.hidden) return;
      if (tagData.dirty) await loadTagData();
      if (!tagData.armed) { removeTags(); return; }
      injectTagStyle();
      const marks = tagLiveMarks();
      for (const el of messageEls()) {
        const links = linksInMessage(el);
        let box = el.querySelector('.zex-tg-tags');
        const parts = [];
        links.forEach((l, i) => {
          const id = statusId(l);
          const st = marks[id] === 'now' ? { k: 'now' } : (tagStatus(id, l, el) || (marks[id] === 'next' ? { k: 'next' } : null));
          if (st) parts.push({ k: st.k, note: st.note || '', n: links.length > 1 ? i + 1 : 0 });
        });
        if (!parts.length) { if (box) box.remove(); continue; }
        const sig = JSON.stringify(parts);
        if (box && box.dataset.sig === sig) continue;
        if (!box) {
          box = document.createElement('div');
          box.className = 'zex-tg-tags';
          (el.querySelector('.bubble-content') || el).appendChild(box);
        }
        box.dataset.sig = sig;
        box.innerHTML = parts.map(p => '<span class="zex-tg-tag ' + p.k + '" style="background:' + TAG_COLOR[p.k] + '">'
          + (p.n ? '#' + p.n + ' ' : '') + TAG_LABEL[p.k] + (p.note ? ' · ' + p.note : '') + '</span>').join('');
      }
    } catch (e) {}
  }
  function startTags() {
    setInterval(() => tagLoop(), 2000);
    try {
      chrome.storage.onChanged.addListener(ch => {
        if (ch.zenRepliedStatusIds || ch.zenRepliedBy || ch.zenReplyHistory || ch.zenSkipLog || ch.zenTgActive || ch.zSessAutoJobs || ch.zenTgWidgetArmed || ch.zenTgSweepArmed) tagData.dirty = true;
      });
    } catch (e) {}
    tagLoop();
  }

  // ═════════════════ BOOT ═════════════════
  function boot() {
    startTags();
    tick().catch(e => console.error('[Z EX TG] tick failed:', e));
    sweepTick().catch(e => console.error('[Z EX TG] sweepTick failed:', e));
    setInterval(() => tick().catch(() => {}), 4000);
    setInterval(() => sweepTick().catch(() => {}), 4000);
    try {
      chrome.storage.onChanged.addListener(changes => {
        if (changes.zenTgActive || changes.zenTgWidgetArmed) tick().catch(() => {});
        if (changes.zenTgSweepArmed) sweepTick().catch(() => {});
      });
    } catch (e) {}
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') { tick().catch(() => {}); sweepTick().catch(() => {}); }
    });
  }

  // Lets background.js check whether this script is alive in the tab.
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === 'zenTgPing') { sendResponse(true); return true; }
      return false;
    });
  } catch (e) {}

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
