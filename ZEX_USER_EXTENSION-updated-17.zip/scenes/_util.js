/* Z EX — shared helpers for the background scenes (no assets, no DOM access).
   Loaded before every scene file and before hands_bg.js. */
(function () {
  'use strict';
  var U = window.ZEX_UTIL = window.ZEX_UTIL || {};

  U.snap = function (v, g) { return Math.round(v / g) * g; };
  U.clamp01 = function (x) { return x < 0 ? 0 : (x > 1 ? 1 : x); };
  U.smooth = function (x) { x = x < 0 ? 0 : (x > 1 ? 1 : x); return x * x * (3 - 2 * x); };
  // alpha (0..1) → index into opts.ia / opts.ga colour tables (41 steps, no string building per frame)
  U.q = function (a) { a = a < 0 ? 0 : (a > 1 ? 1 : a); return (a * 40 + 0.5) | 0; };
  // tiny seeded RNG → same layout on every open
  U.rng = function (seed) {
    var s = seed;
    return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
  };

  /* ── Pixel "Z" (5 x 7 bitmap) with a soft gold halo ── */
  var ZB = ['11111', '00001', '00010', '00100', '01000', '10000', '11111'];
  var ZC = [], ZR = [];
  ZB.forEach(function (row, r) {
    for (var c = 0; c < 5; c++) if (row.charAt(c) === '1') { ZC.push(c); ZR.push(r); }
  });
  U.Z_COLS = ZC; U.Z_ROWS = ZR;

  // cx,cy = centre · c = cell size in px · a = overall alpha 0..1
  U.drawZ = function (ctx, o, cx, cy, c, t, a) {
    if (a <= 0.01) return;
    var n = ZC.length, q = U.q, ga = o.ga, i, al;
    ctx.fillStyle = ga[q(0.05 * a)];
    ctx.beginPath(); ctx.arc(cx, cy, c * 6.5, 0, 6.2832); ctx.fill();
    ctx.fillStyle = ga[q(0.09 * a)];
    ctx.beginPath(); ctx.arc(cx, cy, c * 4, 0, 6.2832); ctx.fill();
    var w = c >= 4 ? c - 1 : c;
    for (i = 0; i < n; i++) {
      al = a * (0.72 + 0.28 * Math.sin(t * 2.6 + i * 0.9));
      ctx.fillStyle = ga[q(al)];
      ctx.fillRect(Math.round(cx + (ZC[i] - 2.5) * c), Math.round(cy + (ZR[i] - 3.5) * c), w, w);
    }
  };

  /* ── Dot-matrix eye ──
     ex,ey centre · e half-width in px · open 0..1 · flip ±1 (mirror) · a alpha
     mode 0 = 4-point gold star pupil, 1 = pixel Z pupil · lx,ly gaze −1..1 */
  function inLid(x, y, open) {
    var s = 1 - x * x;
    if (s <= 0) return false;
    var tl = -0.12 * x;
    return y > tl - 0.52 * open * Math.pow(s, 0.75) + 0.04 && y < tl + 0.34 * open * s - 0.03;
  }
  U.drawEye = function (ctx, o, ex, ey, e, open, flip, t, a, mode, lx, ly) {
    if (a <= 0.01) return;
    var g = o.g, ia = o.ia, ga = o.ga, q = U.q, M = 24, i, x, s, yu, yl, tl, gx, gy, ix, iy;
    if (open < 0.04) {                                    // closed: a flat dotted lid line
      ctx.fillStyle = ia[q(0.8 * a)];
      for (i = 0; i <= M; i++) {
        x = -1 + 2 * i / M;
        ctx.fillRect(Math.round(ex + x * e * flip), Math.round(ey - 0.12 * x * e), g, g);
      }
      return;
    }
    // upper lid (bright) + lower lid (dim)
    ctx.fillStyle = ia[q(0.9 * a)];
    for (i = 0; i <= M; i++) {
      x = -1 + 2 * i / M; s = 1 - x * x; tl = -0.12 * x;
      yu = tl - 0.52 * open * Math.pow(s, 0.75);
      ctx.fillRect(Math.round(ex + x * e * flip), Math.round(ey + yu * e), g, g);
    }
    ctx.fillStyle = ia[q(0.55 * a)];
    for (i = 1; i < M; i++) {
      x = -1 + 2 * i / M; s = 1 - x * x; tl = -0.12 * x;
      yl = tl + 0.34 * open * s;
      ctx.fillRect(Math.round(ex + x * e * flip), Math.round(ey + yl * e), g, g);
    }
    // lashes
    ctx.beginPath();
    for (i = 4; i < M - 1; i += 2) {
      x = -1 + 2 * i / M; s = 1 - x * x; tl = -0.12 * x;
      yu = tl - 0.52 * open * Math.pow(s, 0.75);
      ctx.moveTo(ex + x * e * flip, ey + yu * e);
      ctx.lineTo(ex + (x + 0.13) * e * flip, ey + (yu - 0.17 * open - 0.03) * e);
    }
    ctx.lineWidth = 1; ctx.strokeStyle = ia[q(0.6 * a)]; ctx.stroke();

    // halftone "white" of the eye
    var icx = lx * 0.28, icy = ly * 0.12, ir = 0.36;
    ctx.fillStyle = ia[q(0.3 * a)];
    for (iy = 0; iy < 9; iy++) {
      gy = -0.5 + iy * 0.105;
      for (ix = 0; ix < 17; ix++) {
        if (((ix * 7 + iy * 13) & 3) === 0) continue;
        gx = -0.9 + ix * 0.1125;
        if (!inLid(gx, gy, open)) continue;
        if ((gx - icx) * (gx - icx) + (gy - icy) * (gy - icy) < (ir + 0.05) * (ir + 0.05)) continue;
        ctx.fillRect(Math.round(ex + gx * e * flip), Math.round(ey + gy * e), g, g);
      }
    }
    // iris rings
    ctx.fillStyle = ia[q(0.85 * a)];
    for (i = 0; i < 22; i++) {
      gx = icx + Math.cos(i * 0.2856) * ir; gy = icy + Math.sin(i * 0.2856) * ir;
      if (inLid(gx, gy, open)) ctx.fillRect(Math.round(ex + gx * e * flip), Math.round(ey + gy * e), g, g);
    }
    ctx.fillStyle = ia[q(0.45 * a)];
    for (i = 0; i < 14; i++) {
      gx = icx + Math.cos(i * 0.4488) * ir * 0.64; gy = icy + Math.sin(i * 0.4488) * ir * 0.64;
      if (inLid(gx, gy, open)) ctx.fillRect(Math.round(ex + gx * e * flip), Math.round(ey + gy * e), g, g);
    }
    // pupil
    var px = ex + icx * e * flip, py = ey + icy * e;
    if (mode === 1) {
      U.drawZ(ctx, o, px, py, Math.max(2, Math.round(e * 0.075)), t, a * U.clamp01(open * 1.5));
    } else {
      var L = e * 0.95 * open, L2 = e * 0.62 * open, w = e * 0.05 + 0.5;
      ctx.fillStyle = ga[q(0.08 * a)];
      ctx.beginPath(); ctx.arc(px, py, e * 0.3, 0, 6.2832); ctx.fill();
      ctx.fillStyle = ga[q(0.95 * a)];
      ctx.beginPath();
      ctx.moveTo(px, py - L); ctx.lineTo(px + w, py); ctx.lineTo(px, py + L); ctx.lineTo(px - w, py); ctx.closePath();
      ctx.moveTo(px - L2, py); ctx.lineTo(px, py + w * 0.9); ctx.lineTo(px + L2, py); ctx.lineTo(px, py - w * 0.9); ctx.closePath();
      ctx.fill();
      ctx.fillRect(Math.round(px - g), Math.round(py - g), g * 2, g * 2);
    }
  };
})();
