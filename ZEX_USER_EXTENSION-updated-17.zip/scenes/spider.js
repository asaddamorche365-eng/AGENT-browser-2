/* Z EX scene — "the watcher": a pair of eyes flash on the dark, then a dot-matrix sci-fi spider
   drops down a thread from the top edge through a web, a glowing pixel "Z" at its core.
   Body = two halftone ovals; legs = 3-bone chains that bend, so it scuttles. */
(function () {
  'use strict';
  var U = window.ZEX_UTIL;
  var SC = window.ZEX_SCENES = window.ZEX_SCENES || [];
  var impl = null;

  // Heavy point-cloud / mesh building is deferred to the first draw, so merely loading the
  // file (e.g. on every x.com page) costs nothing.
  function build() {
    var rnd = U.rng(23);

    // right-hand legs (unit space: junction at 0,0 · y down) — the left ones are mirrored
    var LEG = [
      { j: [[0.10, -0.12], [0.95, -0.85], [1.95, -0.95], [2.55, -0.25]], ph: 0.0 },
      { j: [[0.12, -0.02], [1.15, -0.32], [2.15, -0.28], [2.85, 0.45]],  ph: 1.4 },
      { j: [[0.12, 0.08],  [1.05, 0.42],  [1.85, 0.95],  [2.15, 1.75]],  ph: 2.8 },
      { j: [[0.10, 0.16],  [0.85, 0.95],  [1.35, 1.70],  [1.30, 2.45]],  ph: 4.2 }
    ];
    var LW = [0.17, 0.13, 0.09, 0.03];
    var NL = 8;
    var SIDE = [], RJX = new Float32Array(NL * 4), RJY = new Float32Array(NL * 4), LPH = [];
    for (var l = 0; l < 4; l++) for (var sd = 0; sd < 2; sd++) {
      var li = l * 2 + sd, sg = sd ? -1 : 1;
      SIDE[li] = sg; LPH[li] = LEG[l].ph + (sd ? 0.9 : 0);
      for (var k = 0; k < 4; k++) { RJX[li * 4 + k] = LEG[l].j[k][0] * sg; RJY[li * 4 + k] = LEG[l].j[k][1]; }
    }

    // ── point cloud: {x,y} rest position · lv style level · leg/b/f/uu pin for leg points (leg −1 = body) ──
    var P = [], rings = [];
    function addBodyOval(cx, cy, rx, ry) {
      var ring = [], n = 52, a, i, gx, gy, d, gl;
      for (i = 0; i < n; i++) {
        a = i / n * 6.2832;
        ring.push(P.length);
        P.push({ x: cx + Math.cos(a) * rx, y: cy + Math.sin(a) * ry, lv: 2, leg: -1, edge: true });
      }
      ring.push(ring[0]); rings.push(ring);
      for (gy = -ry; gy <= ry; gy += 0.12) for (gx = -rx; gx <= rx; gx += 0.12) {
        if ((gx * gx) / (rx * rx) + (gy * gy) / (ry * ry) > 0.78) continue;
        d = Math.sqrt((cx + gx) * (cx + gx) + (cy + gy) * (cy + gy));
        gl = Math.exp(-d * d / 0.9);
        if (rnd() > 0.42 + 0.58 * gl) continue;
        P.push({ x: cx + gx, y: cy + gy, lv: gl > 0.62 ? 4 : (gl > 0.36 ? 3 : (rnd() < 0.5 ? 1 : 0)), leg: -1, edge: false });
      }
    }
    addBodyOval(0, -0.92, 0.34, 0.86);
    addBodyOval(0, 1.0, 0.39, 0.93);

    var chains = [];
    for (var L = 0; L < NL; L++) {
      var sideA = [], sideB = [];
      for (var b = 0; b < 3; b++) {
        var dx = RJX[L * 4 + b + 1] - RJX[L * 4 + b], dy = RJY[L * 4 + b + 1] - RJY[L * 4 + b];
        var len = Math.sqrt(dx * dx + dy * dy), steps = Math.max(1, Math.round(len / 0.11));
        for (var s = 0; s < steps + (b === 2 ? 1 : 0); s++) for (var m = 0; m < 3; m++) {
          var u = m - 1, edge = m !== 1;
          if (!edge && rnd() < 0.3) continue;
          if (edge) (u < 0 ? sideA : sideB).push(P.length);
          P.push({ leg: L, b: b, f: s / steps, u: u, lv: edge ? 2 : (rnd() < 0.5 ? 1 : 0), edge: edge });
        }
      }
      sideA.push(P.length); sideB.push(P.length);        // glowing claw tip
      P.push({ leg: L, b: 2, f: 1.05, u: 0, lv: 3, edge: true });
      chains.push(sideA, sideB);
    }
    var N = P.length;

    // pose (body space) — bones bend with a travelling wave so the legs scuttle
    var JX = new Float32Array(NL * 4), JY = new Float32Array(NL * 4), NX = new Float32Array(NL * 3), NY = new Float32Array(NL * 3);
    var WX = new Float32Array(N), WY = new Float32Array(N), DX = new Float32Array(N), DY = new Float32Array(N);
    function pose(t, amp, out, outY) {
      var L, i, a, dx, dy, c, s, rx, ry, ll, p, q, half;
      for (L = 0; L < NL; L++) {
        a = 0; JX[L * 4] = RJX[L * 4]; JY[L * 4] = RJY[L * 4];
        for (i = 0; i < 3; i++) {
          dx = RJX[L * 4 + i + 1] - RJX[L * 4 + i]; dy = RJY[L * 4 + i + 1] - RJY[L * 4 + i];
          if (amp) a += SIDE[L] * amp * Math.sin(t * 2.3 + LPH[L] + i * 0.8) * (0.6 + 0.5 * i);
          c = Math.cos(a); s = Math.sin(a);
          rx = dx * c - dy * s; ry = dx * s + dy * c;
          JX[L * 4 + i + 1] = JX[L * 4 + i] + rx; JY[L * 4 + i + 1] = JY[L * 4 + i] + ry;
          ll = Math.sqrt(rx * rx + ry * ry) || 1;
          NX[L * 3 + i] = -ry / ll; NY[L * 3 + i] = rx / ll;
        }
      }
      for (p = 0; p < N; p++) {
        q = P[p];
        if (q.leg < 0) { out[p] = q.x; outY[p] = q.y; continue; }
        L = q.leg;
        half = (LW[q.b] + (LW[q.b + 1] - LW[q.b]) * Math.min(q.f, 1)) / 2;
        var x0 = JX[L * 4 + q.b], y0 = JY[L * 4 + q.b], x1 = JX[L * 4 + q.b + 1], y1 = JY[L * 4 + q.b + 1];
        out[p] = x0 + (x1 - x0) * q.f + NX[L * 3 + q.b] * q.u * half;
        outY[p] = y0 + (y1 - y0) * q.f + NY[L * 3 + q.b] * q.u * half;
      }
    }

    // mesh edges (nearest neighbours at rest) + a few long cobweb strands
    pose(0, 0, WX, WY);
    var edges = [], strands = [], outline = [], seen = {};
    function addEdge(list, i, j) { var key = i < j ? i * N + j : j * N + i; if (seen[key]) return; seen[key] = 1; list.push(i, j); }
    for (var i = 0; i < N; i++) {
      var cand = [];
      for (var j = 0; j < N; j++) {
        if (i === j) continue;
        var ddx = WX[i] - WX[j], ddy = WY[i] - WY[j], dd = ddx * ddx + ddy * ddy;
        if (dd < 0.2 * 0.2) cand.push([dd, j]);
      }
      cand.sort(function (a, b) { return a[0] - b[0]; });
      for (var c2 = 0; c2 < Math.min(3, cand.length); c2++) addEdge(edges, i, cand[c2][1]);
    }
    chains.concat(rings).forEach(function (c) { for (var q = 0; q < c.length - 1; q++) outline.push(c[q], c[q + 1]); });
    for (var s2 = 0, tries = 0; s2 < 34 && tries < 900; tries++) {
      var a2 = Math.floor(rnd() * N), b2 = Math.floor(rnd() * N);
      var sx = WX[a2] - WX[b2], sy = WY[a2] - WY[b2], sdd = Math.sqrt(sx * sx + sy * sy);
      if (sdd > 0.55 && sdd < 1.5) { addEdge(strands, a2, b2); s2++; }
    }
    var LV = new Int8Array(N), EDGE = new Uint8Array(N);
    for (var z = 0; z < N; z++) { LV[z] = P[z].lv; EDGE[z] = P[z].edge ? 1 : 0; }

    // web rays (angle from straight down) and the sagging rings between them
    var RAYS = [-1.0, -0.72, -0.46, -0.22, 0.22, 0.46, 0.72, 1.0];
    var RINGS = [0.3, 0.52, 0.74, 0.95];

    var styles = ['', '', '', '', ''];

    function eyeOpen(t) {                                     // flashes open, strobes, then fades out
      if (t < 0.25 || t > 2.95) return 0;
      var o = U.smooth((t - 0.25) / 0.45);
      if ((t > 0.95 && t < 1.08) || (t > 1.35 && t < 1.45) || (t > 1.75 && t < 1.82)) o = 0;
      if (t > 2.3) o *= 1 - U.smooth((t - 2.3) / 0.65);
      return o;
    }

    function draw(ctx, t, o) {
      var S = o.S, u = S * 0.34, g = o.g, cx = o.cx, cy = o.cy, bot = o.bot;
      var ia = o.ia, ga = o.ga, q = U.q, i, k, p, e;

      // 1 · eyes flashing on the dark
      var op = eyeOpen(t);
      if (op > 0) {
        var ee = S * 0.5, flick = (t > 0.6 && t < 2.3) ? 0.75 + 0.25 * Math.sin(t * 40) : 1;
        U.drawEye(ctx, o, cx - ee * 1.45, cy, ee, op, -1, t, flick, 0, 0.3 * Math.sin(t * 3), 0);
        U.drawEye(ctx, o, cx + ee * 1.45, cy, ee, op, 1, t, flick, 0, 0.3 * Math.sin(t * 3), 0);
      }

      // 2 · web hanging from the top edge
      var wa = U.smooth((t - 2.3) / 1.3);
      if (wa > 0.01) {
        var sw = Math.sin(t * 0.6) * 0.012, R, r0, a0, a1, x0, y0, x1, y1;
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (i = 0; i < RAYS.length; i++) {
          a0 = RAYS[i] + sw;
          ctx.moveTo(cx, -2); ctx.lineTo(cx + Math.sin(a0) * bot * 1.25, -2 + Math.cos(a0) * bot * 1.25);
        }
        ctx.strokeStyle = ia[q(0.16 * wa)]; ctx.stroke();
        ctx.beginPath();
        for (k = 0; k < RINGS.length; k++) {
          r0 = bot * RINGS[k] * 1.25;
          for (i = 0; i < RAYS.length - 1; i++) {
            if (i === 3) continue;                              // gap where the thread hangs
            a0 = RAYS[i] + sw; a1 = RAYS[i + 1] + sw;
            x0 = cx + Math.sin(a0) * r0; y0 = -2 + Math.cos(a0) * r0;
            x1 = cx + Math.sin(a1) * r0; y1 = -2 + Math.cos(a1) * r0;
            ctx.moveTo(x0, y0);
            ctx.quadraticCurveTo(cx + Math.sin((a0 + a1) / 2) * r0 * 0.9, -2 + Math.cos((a0 + a1) / 2) * r0 * 0.9, x1, y1);
          }
        }
        ctx.strokeStyle = ia[q(0.11 * wa)]; ctx.stroke();
      }

      // 3 · spider: lowers itself down the thread, then hangs and scuttles
      var pr = U.clamp01((t - 2.7) / 2.8), ease = 1 - Math.pow(1 - pr, 3);
      var oy = cy - (cy + 3.4 * u) * (1 - ease) + Math.sin(t * 1.4) * 0.07 * u * ease;
      if (oy + 2.6 * u < 0) return;
      var sway = 0.045 * Math.sin(t * 0.9) * ease, cs = Math.cos(sway), sn = Math.sin(sway);
      // thread (dotted) from the top edge down to the body
      var ty = oy - 1.8 * u;
      ctx.fillStyle = ia[q(0.4)];
      for (e = 0; e < ty; e += g * 2) ctx.fillRect(Math.round(cx), Math.round(e), 1, g);

      pose(t, (0.12 + 0.10 * (1 - ease)), WX, WY);
      for (p = 0; p < N; p++) {
        DX[p] = cx + (WX[p] * cs - WY[p] * sn) * u;
        DY[p] = oy + (WX[p] * sn + WY[p] * cs) * u;
      }
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (k = 0; k < strands.length; k += 2) { ctx.moveTo(DX[strands[k]], DY[strands[k]]); ctx.lineTo(DX[strands[k + 1]], DY[strands[k + 1]]); }
      ctx.strokeStyle = o.i10; ctx.stroke();
      ctx.beginPath();
      for (k = 0; k < edges.length; k += 2) { ctx.moveTo(DX[edges[k]], DY[edges[k]]); ctx.lineTo(DX[edges[k + 1]], DY[edges[k + 1]]); }
      ctx.strokeStyle = o.i26; ctx.stroke();
      ctx.beginPath();
      for (k = 0; k < outline.length; k += 2) { ctx.moveTo(DX[outline[k]], DY[outline[k]]); ctx.lineTo(DX[outline[k + 1]], DY[outline[k + 1]]); }
      ctx.strokeStyle = o.i55; ctx.stroke();

      styles[0] = ia[q(0.3)]; styles[1] = ia[q(0.5)]; styles[2] = ia[q(0.78)]; styles[3] = ga[q(0.6)]; styles[4] = ga[q(0.95)];
      for (var lv = 0; lv < 5; lv++) {
        ctx.fillStyle = styles[lv];
        var sz = lv === 2 ? g : g * 0.85;
        for (p = 0; p < N; p++) if (LV[p] === lv) ctx.fillRect(Math.round(DX[p] / g) * g, Math.round(DY[p] / g) * g, sz, sz);
      }

      // scan line through the core (like the reference) + the Z
      if (ease > 0.97) {
        var span = S * 2.4;
        for (e = -span; e <= span; e += g * 5) {
          ctx.fillStyle = ga[q(0.75 * (1 - Math.abs(e) / span))];
          ctx.fillRect(Math.round((cx + e) / g) * g, Math.round(oy / g) * g, g, g);
        }
      }
      U.drawZ(ctx, o, cx, oy, Math.max(g, Math.round(u * 0.11)), t, ease);
    }

    return draw;
  }

  SC.push({
    name: 'spider', still: 6.5,
    init: function () { if (!impl) impl = build(); },
    draw: function (ctx, t, o) { if (!impl) impl = build(); impl(ctx, t, o); },
    resize: function () {}
  });
})();
