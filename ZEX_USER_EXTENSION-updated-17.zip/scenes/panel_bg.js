/* Z EX — animated banner for the floating panels (X agent status + Telegram panels).
   Same scenes as the popup (window.ZEX_SCENES), rotated the same way (12-15 s, 1 s cross-fade,
   never the same scene twice in a row), drawn on a small canvas inside the panel.

     ZEX_PANEL_BG.attach(hostElement, { height, before, prepend, pin, style }) → canvas

   before  : insert the banner before this child of host (default: append)
   prepend : insert as first child          pin : keep it first even if host.innerHTML is rewritten
   The loop pauses while the tab is hidden or the banner is not displayed (e.g. collapsed panel)
   and stops for good once the canvas has left the page. */
(function () {
  'use strict';
  if (window.ZEX_PANEL_BG) return;

  var FADE = 1, DUR_MIN = 12, DUR_MAX = 15, FADE_IN = 1.0, MIN_DT = 30;   // ≈ 30 fps
  var INK = '235,235,235', GOLD = '250,204,21';                           // panels are always dark
  var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  function makeOpts() {
    var o = { W: 0, H: 0, S: 40, cx: 0, cy: 0, bot: 0, g: 2, dark: true, ink: INK, gold: GOLD, ia: [], ga: [] };
    o.i10 = 'rgba(' + INK + ',0.10)'; o.i26 = 'rgba(' + INK + ',0.26)'; o.i38 = 'rgba(' + INK + ',0.38)';
    o.i55 = 'rgba(' + INK + ',0.55)'; o.i78 = 'rgba(' + INK + ',0.78)';
    for (var k = 0; k <= 40; k++) { o.ia[k] = 'rgba(' + INK + ',' + (k / 40) + ')'; o.ga[k] = 'rgba(' + GOLD + ',' + (k / 40) + ')'; }
    return o;
  }

  function attach(host, cfg) {
    cfg = cfg || {};
    var canvas = document.createElement('canvas');
    canvas.className = 'zen-bg-banner';
    canvas.setAttribute('aria-hidden', 'true');
    canvas.style.cssText = 'display:block;flex:none;position:relative;z-index:1;width:100%;height:' + (cfg.height || 96) +
      'px;pointer-events:none;' + (cfg.style || '');
    if (cfg.before && cfg.before.parentNode === host) host.insertBefore(canvas, cfg.before);
    else if (cfg.prepend) host.insertBefore(canvas, host.firstChild);
    else host.appendChild(canvas);

    var scenes = window.ZEX_SCENES;
    if (!scenes || !scenes.length) return canvas;
    var ctx = canvas.getContext('2d');
    var o = makeOpts();

    var observer = null;
    if (cfg.pin && window.MutationObserver) {
      observer = new MutationObserver(function () {
        if (canvas.parentNode !== host) host.insertBefore(canvas, host.firstChild);
      });
      observer.observe(host, { childList: true });
    }

    var dpr = 1, raf = 0, timer = 0, gone = 0, last = 0, lastDraw = 0, dirty = true;
    var cur = (Math.random() * scenes.length) | 0, next = -1, sceneT = 0, nextT = 0, dur = rndDur(), fadeIn = reduce ? 1 : 0;
    function rndDur() { return DUR_MIN + Math.random() * (DUR_MAX - DUR_MIN); }
    function pick(excl) { var n = scenes.length, r; if (n < 2) return 0; do { r = (Math.random() * n) | 0; } while (r === excl); return r; }
    function ease(x) { return x * x * (3 - 2 * x); }

    function layout(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      o.W = w; o.H = h; o.cx = w / 2; o.cy = h * 0.52; o.bot = h;
      o.S = Math.max(24, Math.min(w * 0.24, h * 0.5));
      o.g = Math.max(2, Math.round(o.S / 34));
      for (var i = 0; i < scenes.length; i++) if (scenes[i].resize) scenes[i].resize(w, h);
      dirty = true;
    }
    function step(dt) {
      if (fadeIn < 1) fadeIn = Math.min(1, fadeIn + dt / FADE_IN);
      sceneT += dt;
      if (next < 0) { if (scenes.length > 1 && sceneT >= dur - FADE) { next = pick(cur); nextT = 0; } }
      else { nextT += dt; if (nextT >= FADE) { cur = next; sceneT = nextT; next = -1; dur = rndDur(); } }
    }
    function render() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, o.W, o.H);
      var base = ease(fadeIn);
      if (reduce) { ctx.globalAlpha = 1; scenes[cur].draw(ctx, scenes[cur].still || 2, o); }
      else if (next < 0) { ctx.globalAlpha = base; scenes[cur].draw(ctx, sceneT, o); }
      else {
        var f = ease(Math.min(1, nextT / FADE));
        ctx.globalAlpha = base * (1 - f); scenes[cur].draw(ctx, sceneT, o);
        ctx.globalAlpha = base * f;       scenes[next].draw(ctx, nextT, o);
      }
      ctx.globalAlpha = 1;
    }
    function stop() {
      if (raf) cancelAnimationFrame(raf); if (timer) clearTimeout(timer);
      raf = timer = 0;
      if (observer) { observer.disconnect(); observer = null; }
      document.removeEventListener('visibilitychange', onVis);
    }
    function loop(now) {
      raf = 0; timer = 0;
      if (now === undefined) now = performance.now();
      if (!canvas.isConnected) {                                   // removed (panel closed) → stop after a short grace
        if (!gone) gone = now;
        if (now - gone > 1500) { stop(); return; }
        timer = setTimeout(loop, 200); return;
      }
      gone = 0;
      if (document.hidden) return;                                  // onVis restarts it
      if (!canvas.getClientRects().length) { last = now; timer = setTimeout(loop, 300); return; }   // collapsed / display:none
      var w = canvas.clientWidth, h = canvas.clientHeight;
      if (w !== o.W || h !== o.H) layout(w, h);
      if (reduce) {
        if (dirty) { render(); dirty = false; }
        timer = setTimeout(loop, 500); return;
      }
      if (!last) last = now;
      if (now - lastDraw >= MIN_DT) {
        var dt = (now - last) / 1000; last = now; lastDraw = now;
        if (dt > 0.1 || dt < 0) dt = 0.1;
        step(dt); render();
      }
      raf = requestAnimationFrame(loop);
    }
    function kick() { if (!raf && !timer) { last = 0; raf = requestAnimationFrame(loop); } }
    function onVis() { if (!document.hidden) kick(); }
    document.addEventListener('visibilitychange', onVis);
    kick();
    return canvas;
  }

  window.ZEX_PANEL_BG = { attach: attach };
})();
