/* Z EX scene #1 — two pixel-wireframe hands reaching toward each other, with a glowing
   pixel "Z" forming in the gap between the fingertips (the original look, unchanged). */
(function () {
  'use strict';
  var U = window.ZEX_UTIL;
  var SC = window.ZEX_SCENES = window.ZEX_SCENES || [];
  var impl = null;

  // Heavy point-cloud / mesh building is deferred to the first draw, so merely loading the
  // file (e.g. on every x.com page) costs nothing.
  function build() {

    // Small seeded RNG so the mesh looks the same on every open (no random flicker of layout).
    var seed = 11;
    function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }

    /* ── Hand model (unit space: wrist at 0,0 · fingers point +x · y is down) ───────────
       Each limb is a bone chain with a width at every joint. `flex` > 0 lets it bend. */
    var LIMBS = [
      { j: [[-2.7, 0], [-1.4, 0], [0, 0]],           w: [0.66, 0.60, 0.56], flex: 0,    step: 0.20, lat: 7 },
      { j: [[0, 0], [0.45, 0], [0.88, 0]],           w: [0.56, 0.68, 0.70], flex: 0,    step: 0.14, lat: 9 },
      { j: [[0.10, -0.26], [0.50, -0.56], [0.78, -0.78], [1.00, -0.90]], w: [0.20, 0.17, 0.15, 0.12], flex: 1.0, step: 0.09, lat: 5, phase: 0.0 },
      { j: [[0.86, -0.27], [1.18, -0.33], [1.42, -0.36], [1.62, -0.36]], w: [0.14, 0.12, 0.11, 0.09], flex: 1.0, step: 0.09, lat: 5, phase: 0.7 },
      { j: [[0.88, -0.08], [1.26, -0.10], [1.53, -0.10], [1.77, -0.08]], w: [0.14, 0.12, 0.11, 0.09], flex: 1.0, step: 0.09, lat: 5, phase: 1.3 },
      { j: [[0.86, 0.12], [1.20, 0.17], [1.44, 0.21], [1.65, 0.24]],     w: [0.14, 0.12, 0.11, 0.09], flex: 1.0, step: 0.09, lat: 5, phase: 1.9 },
      { j: [[0.82, 0.30], [1.08, 0.40], [1.26, 0.50], [1.40, 0.58]],     w: [0.12, 0.10, 0.09, 0.07], flex: 1.0, step: 0.09, lat: 5, phase: 2.5 }
    ];
    var HAND_TIP = 1.78; // farthest fingertip along +x (unit space)

    // ── Build the point cloud once: each point is pinned to (limb, bone, f along bone, u across) ──
    var pts = [];
    var tipIdx = [];
    var chains = [];   // outline silhouettes (ordered point indices per limb side)
    LIMBS.forEach(function (L, li) {
      var sideA = [], sideB = [];
      for (var b = 0; b < L.j.length - 1; b++) {
        var dx = L.j[b + 1][0] - L.j[b][0], dy = L.j[b + 1][1] - L.j[b][1];
        var len = Math.sqrt(dx * dx + dy * dy);
        var steps = Math.max(1, Math.round(len / L.step));
        var last = b === L.j.length - 2;
        for (var k = 0; k < steps + (last ? 1 : 0); k++) {
          var f = k / steps;
          for (var m = 0; m < L.lat; m++) {
            var u = -1 + (2 * m) / (L.lat - 1);
            var edge = Math.abs(u) > 0.99;
            if (!edge && rnd() < 0.2) continue;              // thin out the inside → web-like
            if (edge) (u < 0 ? sideA : sideB).push(pts.length);
            pts.push({ l: li, b: b, f: f, u: u + (edge ? 0 : (rnd() - 0.5) * 0.25), edge: edge, ph: rnd() * 6.28 });
          }
        }
      }
      if (L.flex > 0) {                                       // fingertip
        tipIdx.push(pts.length);
        sideA.push(pts.length); sideB.push(pts.length);
        pts.push({ l: li, b: L.j.length - 2, f: 1.14, u: 0, edge: true, ph: rnd() * 6.28, tip: true });
      }
      chains.push(sideA, sideB);
    });
    var N = pts.length;

    // ── Pose: bend the fingers a little, then turn (limb, bone, f, u) into unit-space x/y ──
    var jointX = [], jointY = [], normX = [], normY = [];
    function pose(t, reach, out) {
      LIMBS.forEach(function (L, li) {
        var n = L.j.length;
        var px = [L.j[0][0]], py = [L.j[0][1]];
        var nx = [], ny = [];
        var a = 0;
        for (var i = 0; i < n - 1; i++) {
          var dx = L.j[i + 1][0] - L.j[i][0], dy = L.j[i + 1][1] - L.j[i][1];
          if (L.flex) a += L.flex * (0.10 * Math.sin(t * 1.1 + L.phase) - 0.06 * reach) * (0.7 + 0.35 * i);
          var c = Math.cos(a), s = Math.sin(a);
          var rx = dx * c - dy * s, ry = dx * s + dy * c;
          px.push(px[i] + rx); py.push(py[i] + ry);
          var ll = Math.sqrt(rx * rx + ry * ry) || 1;
          nx.push(-ry / ll); ny.push(rx / ll);
        }
        jointX[li] = px; jointY[li] = py; normX[li] = nx; normY[li] = ny;
      });
      for (var p = 0; p < N; p++) {
        var q = pts[p], L2 = LIMBS[q.l];
        var x0 = jointX[q.l][q.b], y0 = jointY[q.l][q.b];
        var x1 = jointX[q.l][q.b + 1], y1 = jointY[q.l][q.b + 1];
        var half = (L2.w[q.b] + (L2.w[q.b + 1] - L2.w[q.b]) * Math.min(q.f, 1)) / 2;
        var wob = 0.012 * Math.sin(t * 1.8 + q.ph);
        out[p * 2]     = x0 + (x1 - x0) * q.f + normX[q.l][q.b] * (q.u * half + wob);
        out[p * 2 + 1] = y0 + (y1 - y0) * q.f + normY[q.l][q.b] * (q.u * half + wob);
      }
    }

    // ── Mesh edges from the rest pose: nearest neighbours + a few long "cobweb" strands ──
    var rest = new Float32Array(N * 2);
    pose(0, 0, rest);
    var edges = [], strands = [], outline = [], seen = {};
    function addEdge(list, i, j) {
      var key = i < j ? i * N + j : j * N + i;
      if (seen[key]) return; seen[key] = 1; list.push(i, j);
    }
    for (var i = 0; i < N; i++) {
      var cand = [];
      for (var j = 0; j < N; j++) {
        if (i === j) continue;
        var dx = rest[i * 2] - rest[j * 2], dy = rest[i * 2 + 1] - rest[j * 2 + 1];
        var d = dx * dx + dy * dy;
        if (d < 0.19 * 0.19) cand.push([d, j]);
      }
      cand.sort(function (a, b) { return a[0] - b[0]; });
      for (var c = 0; c < Math.min(3, cand.length); c++) addEdge(edges, i, cand[c][1]);
    }
    chains.forEach(function (c) { for (var q = 0; q < c.length - 1; q++) outline.push(c[q], c[q + 1]); });
    for (var s = 0, tries = 0; s < 46 && tries < 900; tries++) {
      var a2 = Math.floor(rnd() * N), b2 = Math.floor(rnd() * N);
      var ddx = rest[a2 * 2] - rest[b2 * 2], ddy = rest[a2 * 2 + 1] - rest[b2 * 2 + 1];
      var dd = Math.sqrt(ddx * ddx + ddy * ddy);
      if (dd > 0.25 && dd < 0.6) { addEdge(strands, a2, b2); s++; }
    }

    // ── Z made of pixels (unit: 1 = hand scale S) ──
    var ZW = 0.62, ZH = 0.92;
    var zPts = [];
    (function () {
      var corners = [[-ZW / 2, -ZH / 2], [ZW / 2, -ZH / 2], [-ZW / 2, ZH / 2], [ZW / 2, ZH / 2]];
      var segs = [[0, 1], [1, 2], [2, 3]];
      segs.forEach(function (sg) {
        var A = corners[sg[0]], B = corners[sg[1]];
        var L = Math.sqrt(Math.pow(B[0] - A[0], 2) + Math.pow(B[1] - A[1], 2));
        var n = Math.round(L / 0.055);
        for (var k = 0; k <= n; k++) zPts.push([A[0] + (B[0] - A[0]) * k / n, A[1] + (B[1] - A[1]) * k / n, rnd() * 6.28]);
      });
    })();

    // ── Particles that travel from fingertips to the Z ──
    var parts = [];
    for (var pi = 0; pi < 18; pi++) {
      parts.push({ hand: pi % 2, tip: Math.floor(rnd() * tipIdx.length), z: Math.floor(rnd() * zPts.length), per: 2.2 + rnd() * 2.4, off: rnd() * 5 });
    }


    var W = 0, H = 0, anchorX = 0, anchorY = 0, S = 60;
    var tmp = new Float32Array(N * 2);
    var handXY = [new Float32Array(N * 2), new Float32Array(N * 2)];

    function place(h, t, gap) {
      var theta = (h === 0 ? -0.16 : Math.PI - 0.16);
      var ux = Math.cos(theta), uy = Math.sin(theta);
      var ox = anchorX - ux * (HAND_TIP * S + gap / 2) + (-uy) * 0.2 * S;
      var oy = anchorY - uy * (HAND_TIP * S + gap / 2) + (ux) * 0.2 * S;
      var out = handXY[h];
      for (var p = 0; p < N; p++) {
        var x = tmp[p * 2] * S, y = tmp[p * 2 + 1] * S;
        out[p * 2]     = ox + x * ux - y * uy;
        out[p * 2 + 1] = oy + x * uy + y * ux;
      }
    }

    function snap(v, g) { return Math.round(v / g) * g; }

    function draw(ctx, t, o) {
      S = o.S; anchorX = o.cx; anchorY = o.cy;
      var ga = o.ga, q = U.q;
      var g = o.g;                                        // pixel size

      var breathe = Math.sin(t * 0.7);
      var gap = S * (1.05 + 0.22 * breathe);
      var reach = (breathe + 1) / 2;
      pose(t, reach, tmp);

      for (var h = 0; h < 2; h++) {
        place(h, t, gap);
        var P = handXY[h];
        // strands (faint long lines)
        ctx.beginPath();
        for (var e = 0; e < strands.length; e += 2) {
          ctx.moveTo(P[strands[e] * 2], P[strands[e] * 2 + 1]);
          ctx.lineTo(P[strands[e + 1] * 2], P[strands[e + 1] * 2 + 1]);
        }
        ctx.lineWidth = 1; ctx.strokeStyle = o.i10; ctx.stroke();
        // mesh
        ctx.beginPath();
        for (var k = 0; k < edges.length; k += 2) {
          ctx.moveTo(P[edges[k] * 2], P[edges[k] * 2 + 1]);
          ctx.lineTo(P[edges[k + 1] * 2], P[edges[k + 1] * 2 + 1]);
        }
        ctx.strokeStyle = o.i26; ctx.stroke();
        // silhouette
        ctx.beginPath();
        for (var oo = 0; oo < outline.length; oo += 2) {
          ctx.moveTo(P[outline[oo] * 2], P[outline[oo] * 2 + 1]);
          ctx.lineTo(P[outline[oo + 1] * 2], P[outline[oo + 1] * 2 + 1]);
        }
        ctx.strokeStyle = o.i55; ctx.stroke();
        // pixel nodes: inner (dim) then outline (bright)
        ctx.fillStyle = o.i38;
        for (var p = 0; p < N; p++) if (!pts[p].edge) ctx.fillRect(snap(P[p * 2], g), snap(P[p * 2 + 1], g), g * 0.8, g * 0.8);
        ctx.fillStyle = o.i78;
        for (var qq = 0; qq < N; qq++) if (pts[qq].edge) ctx.fillRect(snap(P[qq * 2], g), snap(P[qq * 2 + 1], g), g, g);
      }

      // Z between the hands
      var zs = S, zg = g * 1.5;
      ctx.save();
      ctx.shadowColor = 'rgba(234,179,8,0.9)';
      ctx.shadowBlur = 10;
      for (var z = 0; z < zPts.length; z++) {
        var zp = zPts[z];
        var a = 0.62 + 0.38 * Math.sin(t * 2.6 + zp[2]);
        ctx.fillStyle = ga[q(a)];
        ctx.fillRect(snap(anchorX + zp[0] * zs, g) - zg / 2, snap(anchorY + zp[1] * zs, g) - zg / 2, zg, zg);
      }
      ctx.restore();

      // energy: fingertip → Z
      for (var i2 = 0; i2 < parts.length; i2++) {
        var pr = parts[i2];
        var ph = ((t + pr.off) % pr.per) / pr.per;
        var ease = ph * ph * (3 - 2 * ph);
        var tp = handXY[pr.hand], ti = tipIdx[pr.tip] * 2;
        var tx = anchorX + zPts[pr.z][0] * zs, ty = anchorY + zPts[pr.z][1] * zs;
        var px = tp[ti] + (tx - tp[ti]) * ease;
        var py = tp[ti + 1] + (ty - tp[ti + 1]) * ease;
        ctx.fillStyle = ga[q(Math.sin(Math.PI * ph) * 0.9)];
        ctx.fillRect(snap(px, g), snap(py, g), g, g);
      }
    }

    return draw;
  }

  SC.push({
    name: 'hands', still: 2,
    init: function () { if (!impl) impl = build(); },
    draw: function (ctx, t, o) { if (!impl) impl = build(); impl(ctx, t, o); },
    resize: function () {}
  });
})();
