/* Z EX scene — a field of drifting stars pulls together into a pixel "Z" (joined by thin
   constellation lines), holds, glows gold, then scatters again. Fully deterministic in t. */
(function () {
  'use strict';
  var U = window.ZEX_UTIL;
  var SC = window.ZEX_SCENES = window.ZEX_SCENES || [];
  var impl = null;

  // Heavy point-cloud / mesh building is deferred to the first draw, so merely loading the
  // file (e.g. on every x.com page) costs nothing.
  function build() {
    var rnd = U.rng(73);
    var CYCLE = 9.5;

    // targets: each cell of the 5x7 Z bitmap split into 2x2 stars (unit = S; cell = 0.2)
    var TX = [], TY = [], i, j, k;
    for (i = 0; i < U.Z_COLS.length; i++) for (j = 0; j < 4; j++) {
      TX.push((U.Z_COLS[i] - 2.5) * 0.2 + (j & 1) * 0.1 + 0.05);
      TY.push((U.Z_ROWS[i] - 3.5) * 0.2 + (j >> 1) * 0.1 + 0.05);
    }
    var NZ = TX.length, NF = 56, N = NZ + NF;
    var HX = new Float32Array(N), HY = new Float32Array(N), AX = new Float32Array(N), AY = new Float32Array(N);
    var WA = new Float32Array(N), WB = new Float32Array(N), PH = new Float32Array(N), DL = new Float32Array(N);
    for (i = 0; i < N; i++) {
      HX[i] = (rnd() - 0.5) * 4.6; HY[i] = (rnd() - 0.5) * 1.9;              // home (scatter) position
      AX[i] = 0.08 + rnd() * 0.22; AY[i] = 0.06 + rnd() * 0.16;              // drift amplitude
      WA[i] = 0.25 + rnd() * 0.5; WB[i] = 0.2 + rnd() * 0.5; PH[i] = rnd() * 6.28;
      DL[i] = rnd() * 0.35;                                                   // arrival stagger
    }
    // Z mesh (adjacent target stars) and free-star cobweb strands
    var zEdges = [], strands = [];
    for (i = 0; i < NZ; i++) for (j = i + 1; j < NZ; j++) {
      var dx = TX[i] - TX[j], dy = TY[i] - TY[j];
      if (dx * dx + dy * dy < 0.15 * 0.15) zEdges.push(i, j);
    }
    for (i = 0; i < 18; i++) strands.push(NZ + Math.floor(rnd() * NF), NZ + Math.floor(rnd() * NF));

    var PX = new Float32Array(N), PY = new Float32Array(N), EA = new Float32Array(N);

    function assemble(ph) {                          // 0 scattered → 1 assembled over one cycle
      if (ph < 1.4) return 0;
      if (ph < 4.6) return U.smooth((ph - 1.4) / 3.2);
      if (ph < 7.6) return 1;
      if (ph < 9.2) return 1 - U.smooth((ph - 7.6) / 1.6);
      return 0;
    }

    function draw(ctx, t, o) {
      var S = o.S, cx = o.cx, cy = o.cy, g = o.g, ia = o.ia, ga = o.ga, q = U.q, p, m, x, y;
      var ph = t % CYCLE, e0 = assemble(ph), e, dx, dy, lim = S * 0.52;

      for (p = 0; p < N; p++) {
        x = cx + (HX[p] * S + Math.sin(t * WA[p] + PH[p]) * AX[p] * S);
        y = cy + (HY[p] * S * 0.62 + Math.cos(t * WB[p] + PH[p]) * AY[p] * S);
        if (p < NZ) {
          e = U.clamp01((e0 * (1 + 0.35) - DL[p]) / 1); e = U.smooth(e);
          EA[p] = e;
          x += (cx + TX[p] * S - x) * e; y += (cy + TY[p] * S - y) * e;
        } else EA[p] = 0;
        PX[p] = x; PY[p] = y;
      }

      // long faint strands between free stars
      ctx.lineWidth = 1; ctx.beginPath();
      for (m = 0; m < strands.length; m += 2) { ctx.moveTo(PX[strands[m]], PY[strands[m]]); ctx.lineTo(PX[strands[m + 1]], PY[strands[m + 1]]); }
      ctx.strokeStyle = ia[q(0.07)]; ctx.stroke();

      // proximity mesh between nearby stars
      ctx.beginPath();
      for (p = 0; p < N; p++) for (m = p + 1; m < N; m++) {
        dx = PX[p] - PX[m]; if (dx > lim || dx < -lim) continue;
        dy = PY[p] - PY[m]; if (dx * dx + dy * dy < lim * lim * 0.45) { ctx.moveTo(PX[p], PY[p]); ctx.lineTo(PX[m], PY[m]); }
      }
      ctx.strokeStyle = ia[q(0.13)]; ctx.stroke();

      // the Z mesh lights up when assembled
      if (e0 > 0.6) {
        var za = U.smooth((e0 - 0.6) / 0.4);
        ctx.beginPath();
        for (m = 0; m < zEdges.length; m += 2) { ctx.moveTo(PX[zEdges[m]], PY[zEdges[m]]); ctx.lineTo(PX[zEdges[m + 1]], PY[zEdges[m + 1]]); }
        ctx.strokeStyle = ga[q(0.35 * za)]; ctx.stroke();
        ctx.fillStyle = ga[q(0.07 * za)];
        ctx.beginPath(); ctx.arc(cx, cy, S * 0.95, 0, 6.2832); ctx.fill();
      }

      // stars
      for (p = 0; p < N; p++) {
        e = EA[p];
        ctx.fillStyle = ia[q((0.35 + 0.35 * Math.sin(t * 1.7 + PH[p] * 3)) * (1 - e) + 0.05)];
        ctx.fillRect(Math.round(PX[p] / g) * g, Math.round(PY[p] / g) * g, g, g);
        if (e > 0.03) {
          ctx.fillStyle = ga[q(e * (0.7 + 0.3 * Math.sin(t * 2.6 + PH[p])))];
          ctx.fillRect(Math.round(PX[p] / g) * g, Math.round(PY[p] / g) * g, g * (1 + 1.2 * e), g * (1 + 1.2 * e));
        }
      }
    }

    return draw;
  }

  SC.push({
    name: 'constellation', still: 6,
    init: function () { if (!impl) impl = build(); },
    draw: function (ctx, t, o) { if (!impl) impl = build(); impl(ctx, t, o); },
    resize: function () {}
  });
})();
