/* Z EX scene — a beating dot-matrix heart with an ECG line running through it;
   the pixel "Z" sits in the middle and pulses with every beat (lub-dub). */
(function () {
  'use strict';
  var U = window.ZEX_UTIL;
  var SC = window.ZEX_SCENES = window.ZEX_SCENES || [];
  var impl = null;

  // Heavy point-cloud / mesh building is deferred to the first draw, so merely loading the
  // file (e.g. on every x.com page) costs nothing.
  function build() {
    var rnd = U.rng(57);

    // heart point cloud: a few concentric, slightly jittered copies of the parametric heart
    var HX = [], HY = [], HE = [], ring = [], RL = [0.34, 0.6, 0.82, 1.0];
    (function () {
      var r, n, i, a, s, c, hx, hy, cnt = [14, 24, 36, 58];
      for (r = 0; r < RL.length; r++) {
        n = cnt[r];
        for (i = 0; i < n; i++) {
          a = i / n * 6.2832 + (r & 1) * 0.12;
          s = Math.sin(a);
          hx = 16 * s * s * s / 17;
          hy = -(13 * Math.cos(a) - 5 * Math.cos(2 * a) - 2 * Math.cos(3 * a) - Math.cos(4 * a)) / 17 + 0.12;
          if (r < 3 && rnd() < 0.18) continue;
          if (r === 3) ring.push(HX.length);
          HX.push(hx * RL[r] + (r < 3 ? (rnd() - 0.5) * 0.05 : 0)); HY.push(hy * RL[r] + (r < 3 ? (rnd() - 0.5) * 0.05 : 0)); HE.push(r === 3 ? 1 : 0);
        }
      }
      ring.push(ring[0]);
    })();
    var N = HX.length, edges = [], strands = [], i, j;
    for (i = 0; i < N; i++) {
      var cand = [];
      for (j = 0; j < N; j++) {
        if (i === j) continue;
        var dx = HX[i] - HX[j], dy = HY[i] - HY[j], d = dx * dx + dy * dy;
        if (d < 0.3 * 0.3) cand.push([d, j]);
      }
      cand.sort(function (a, b) { return a[0] - b[0]; });
      for (var c = 0; c < Math.min(3, cand.length); c++) edges.push(i, cand[c][1]);
    }
    for (i = 0; i < 26; i++) {                                     // long cobweb strands, heart → far away
      var a = rnd() * 6.2832, b = ring[Math.floor(rnd() * (ring.length - 1))], rr = 1.5 + rnd() * 1.4;
      strands.push(b, Math.cos(a) * rr, Math.sin(a) * rr * 0.4);
    }
    var DX = new Float32Array(N), DY = new Float32Array(N);

    var BEAT = 1.15;
    function beat(ph) {                                            // 0..1 phase → pulse 0..1 (lub, then a softer dub)
      var x = (ph - 0.07) / 0.06, y = (ph - 0.3) / 0.08;
      return Math.exp(-x * x) + 0.55 * Math.exp(-y * y);
    }
    function ecg(x) {                                              // x in 0..1 (one period) → −1..1 (up = negative y)
      var v = 0, d;
      d = (x - 0.18) / 0.05; v += 0.16 * Math.exp(-d * d);        // P
      d = (x - 0.36) / 0.012; v -= 0.22 * Math.exp(-d * d);       // Q
      d = (x - 0.40) / 0.016; v += 1.0 * Math.exp(-d * d);        // R
      d = (x - 0.44) / 0.014; v -= 0.35 * Math.exp(-d * d);       // S
      d = (x - 0.68) / 0.07; v += 0.26 * Math.exp(-d * d);        // T
      return v;
    }

    function draw(ctx, t, o) {
      var S = o.S, cx = o.cx, cy = o.cy, g = o.g, W = o.W, ia = o.ia, ga = o.ga, q = U.q, k, p, x, y;
      var ph = (t / BEAT) % 1, bt = beat(ph), sc = S * 0.64 * (1 + 0.1 * bt);

      // strands
      ctx.lineWidth = 1; ctx.beginPath();
      for (k = 0; k < strands.length; k += 3) {
        ctx.moveTo(cx + HX[strands[k]] * sc, cy + HY[strands[k]] * sc);
        ctx.lineTo(cx + strands[k + 1] * sc, cy + strands[k + 2] * sc);
      }
      ctx.strokeStyle = o.i10; ctx.stroke();

      // heart mesh
      for (p = 0; p < N; p++) { DX[p] = cx + HX[p] * sc; DY[p] = cy + HY[p] * sc; }
      ctx.beginPath();
      for (k = 0; k < edges.length; k += 2) { ctx.moveTo(DX[edges[k]], DY[edges[k]]); ctx.lineTo(DX[edges[k + 1]], DY[edges[k + 1]]); }
      ctx.strokeStyle = ia[q(0.2 + 0.1 * bt)]; ctx.stroke();
      ctx.beginPath();
      for (k = 0; k < ring.length; k++) { if (k) ctx.lineTo(DX[ring[k]], DY[ring[k]]); else ctx.moveTo(DX[ring[k]], DY[ring[k]]); }
      ctx.strokeStyle = o.i55; ctx.stroke();
      ctx.fillStyle = o.i38;
      for (p = 0; p < N; p++) if (!HE[p]) ctx.fillRect(Math.round(DX[p] / g) * g, Math.round(DY[p] / g) * g, g * 0.8, g * 0.8);
      ctx.fillStyle = o.i78;
      for (p = 0; p < N; p++) if (HE[p]) ctx.fillRect(Math.round(DX[p] / g) * g, Math.round(DY[p] / g) * g, g, g);

      // ECG line: scrolls right, its R-spike crosses the centre exactly on the beat
      var per = S * 2.6, amp = S * 0.72, step = g * 2, half = W / 2, ex, f, yy, fade, prevY = 0;
      ctx.beginPath();
      for (x = 0, k = 0; x <= W; x += step, k++) {
        f = ((x - cx) / per - t / BEAT) % 1; if (f < 0) f += 1;
        yy = cy - ecg(f) * amp;
        if (k) ctx.lineTo(x, yy); else ctx.moveTo(x, yy);
      }
      ctx.strokeStyle = ia[q(0.2)]; ctx.stroke();
      for (x = 0; x <= W; x += step) {
        f = ((x - cx) / per - t / BEAT) % 1; if (f < 0) f += 1;
        yy = cy - ecg(f) * amp;
        fade = 1 - Math.abs(x - cx) / half; fade = fade * fade;
        ctx.fillStyle = Math.abs(yy - cy) > amp * 0.25 ? ga[q(0.95 * fade)] : ia[q(0.8 * fade)];
        ctx.fillRect(Math.round(x / g) * g, Math.round(yy / g) * g, g, g);
      }

      U.drawZ(ctx, o, cx, cy, Math.max(g, Math.round(S * 0.085 * (1 + 0.12 * bt))), t, 1);
    }

    return draw;
  }

  SC.push({
    name: 'heart', still: 0.42,
    init: function () { if (!impl) impl = build(); },
    draw: function (ctx, t, o) { if (!impl) impl = build(); impl(ctx, t, o); },
    resize: function () {}
  });
})();
