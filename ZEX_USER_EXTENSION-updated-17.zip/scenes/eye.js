/* Z EX scene — one big dot-matrix eye that opens, looks around, blinks and closes,
   with a glowing pixel "Z" for a pupil and cobweb strands radiating out of it. */
(function () {
  'use strict';
  var U = window.ZEX_UTIL;
  var SC = window.ZEX_SCENES = window.ZEX_SCENES || [];
  var impl = null;

  // Heavy point-cloud / mesh building is deferred to the first draw, so merely loading the
  // file (e.g. on every x.com page) costs nothing.
  function build() {
    var rnd = U.rng(41);

    var KT = [0, 0.6, 1.5, 3.6, 3.72, 3.84, 4.3, 4.42, 4.54, 5.6, 6.6, 8];     // blink keyframes (seconds)
    var KV = [0, 0,   1,   1,   0.05, 1,    1,   0.05, 1,    1,   0,   0];
    var PERIOD = 8;
    function openness(t) {
      var ph = t % PERIOD, i = 0;
      while (i < KT.length - 2 && ph > KT[i + 1]) i++;
      return KV[i] + (KV[i + 1] - KV[i]) * U.smooth((ph - KT[i]) / (KT[i + 1] - KT[i]));
    }

    // cobweb strands (unit = eye half-width): from the lid line out to far points
    var NS = 30, SA = new Float32Array(NS * 4), i, a, r;
    for (i = 0; i < NS; i++) {
      a = rnd() * 6.2832;
      SA[i * 4]     = Math.cos(a) * 1.05;           SA[i * 4 + 1] = Math.sin(a) * 0.4;
      r = 1.5 + rnd() * 0.9;
      SA[i * 4 + 2] = Math.cos(a + (rnd() - 0.5) * 0.5) * r; SA[i * 4 + 3] = Math.sin(a) * r * 0.36;
    }
    var NR = 54;                                      // orbit ring of pixels

    function draw(ctx, t, o) {
      var S = o.S, cx = o.cx, cy = o.cy, g = o.g, e = S * 1.15, ia = o.ia, ga = o.ga, q = U.q;
      var op = openness(t), k, an, x, y;
      var lx = 0.55 * Math.sin(t * 0.7), ly = 0.4 * Math.sin(t * 0.5);

      // strands
      ctx.lineWidth = 1; ctx.beginPath();
      for (k = 0; k < NS; k++) {
        ctx.moveTo(cx + SA[k * 4] * e, cy + SA[k * 4 + 1] * e);
        ctx.lineTo(cx + SA[k * 4 + 2] * e, cy + SA[k * 4 + 3] * e);
      }
      ctx.strokeStyle = ia[q(0.09 + 0.04 * op)]; ctx.stroke();

      // orbit ring: pixels + thin mesh
      ctx.beginPath();
      for (k = 0; k <= NR; k++) {
        an = k / NR * 6.2832 + t * 0.12;
        x = cx + Math.cos(an) * 1.5 * e; y = cy + Math.sin(an) * 0.66 * e;
        if (k) ctx.lineTo(x, y); else ctx.moveTo(x, y);
      }
      ctx.strokeStyle = o.i10; ctx.stroke();
      for (k = 0; k < NR; k++) {
        an = k / NR * 6.2832 + t * 0.12;
        x = Math.round((cx + Math.cos(an) * 1.5 * e) / g) * g; y = Math.round((cy + Math.sin(an) * 0.66 * e) / g) * g;
        ctx.fillStyle = (k % 9 === 0) ? ga[q(0.5 + 0.4 * Math.sin(t * 2 + k))] : ia[q(0.3)];
        ctx.fillRect(x, y, g, g);
      }

      U.drawEye(ctx, o, cx, cy, e, op, 1, t, 1, 1, lx, ly);
    }

    return draw;
  }

  SC.push({
    name: 'eye', still: 2.6,
    init: function () { if (!impl) impl = build(); },
    draw: function (ctx, t, o) { if (!impl) impl = build(); impl(ctx, t, o); },
    resize: function () {}
  });
})();
