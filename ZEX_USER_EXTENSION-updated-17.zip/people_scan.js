// Z EX — Following Analysis scanner (runs on https://x.com/<you>/following).
// Started from Dashboard → "Following Analysis". background.js opens the page and stores:
//   zexPeopleRun  — true while a scan should be going        zexPeopleCfg  — { handle, tabId }
//   zexPeopleScan — { running, found, scored, status, done, ts }  (read by the popup card)
// Scrolls the Following list, saves every @username + Wallchain score into the shared People DB (f:1 = already followed).
(function () {
  if (window.__zexPeopleScan) return; window.__zexPeopleScan = true;
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var get = function (k) { return new Promise(function (res) { try { chrome.storage.local.get(k, function (r) { void chrome.runtime.lastError; res(r || {}); }); } catch (e) { res({}); } }); };
  var set = function (o) { return new Promise(function (res) { try { chrome.storage.local.set(o, function () { void chrome.runtime.lastError; res(); }); } catch (e) { res(); } }); };
  var ask = function (m) { return new Promise(function (res) { try { chrome.runtime.sendMessage(m, function (r) { void chrome.runtime.lastError; res(r); }); } catch (e) { res(undefined); } }); };
  var running = false, cfg = null, wake = null;
  var seen = {}, found = 0, scored = 0;

  function cellUser(cell) {
    var a = cell.querySelector('a[href^="/"]'), href = a ? a.getAttribute('href') : '', u = (href || '').replace('/', '');
    if (!u || u === 'i' || u.indexOf('/') >= 0 || !/^[A-Za-z0-9_]{1,15}$/.test(u)) return null;
    return u.toLowerCase();
  }
  var onPage = function () { var m = location.pathname.match(/^\/([^/]+)\/following\/?$/i); return !!m && !!cfg && m[1].toLowerCase() === cfg.handle; };
  var runFlag = async function () { return !!(await get('zexPeopleRun')).zexPeopleRun; };
  function push(status, over) { return set({ zexPeopleScan: Object.assign({ running: running, found: found, scored: scored, status: status || '', ts: Date.now() }, over || {}) }); }
  async function hold() { try { if ('wakeLock' in navigator && !wake) { wake = await navigator.wakeLock.request('screen'); wake.addEventListener('release', function () { wake = null; if (running) setTimeout(hold, 1000); }); } } catch (e) { wake = null; } }
  async function unhold() { try { if (wake) await wake.release(); } catch (e) {} wake = null; }

  // ── load / error handling ─────────────────────────────────────
  // X sometimes shows "Something went wrong. Try reloading." + a Retry button in the list. Press it
  // (a human would), and never scroll further while the next batch is still loading.
  var retries = 0;
  var rnd = function (a, b) { return Math.floor(a + Math.random() * (b - a + 1)); };
  function col() { return document.querySelector('[data-testid="primaryColumn"]') || document; }
  function retryBtn() {
    var els = col().querySelectorAll('[role="button"], button');
    for (var i = 0; i < els.length; i++) {
      var t = (els[i].innerText || els[i].textContent || '').trim();
      if (/^retry$/i.test(t)) return els[i];
    }
    return null;
  }
  function busy() { return !!col().querySelector('[role="progressbar"]'); }
  function cellCount() { return document.querySelectorAll('[data-testid="UserCell"]').length; }
  function tap(el) {
    try { el.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (e) {}
    try {
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (t) {
        el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
      });
    } catch (e) { try { el.click(); } catch (e2) {} }
  }
  // Waits until the list stops loading (no spinner, row count steady). 'ok' | 'error' | 'timeout'
  async function settle(maxMs) {
    var end = Date.now() + maxMs, n0 = cellCount(), since = Date.now();
    while (Date.now() < end) {
      await sleep(400);
      if (retryBtn()) return 'error';
      var n = cellCount();
      if (busy() || n !== n0) { n0 = n; since = Date.now(); continue; }
      if (Date.now() - since >= 1200) return 'ok';
    }
    return retryBtn() ? 'error' : 'timeout';
  }
  // If the error screen is up: press Retry and wait. After 6 failed retries, reload the page. true = handled.
  async function fixError() {
    var b = retryBtn(); if (!b) return false;
    retries++;
    if (retries > 6) {   // X keeps failing: cool down, then try again (no page reload — that would lose this run's progress)
      retries = 1;
      await push('X keeps failing — waiting a minute, then retrying…');
      await sleep(rnd(50000, 70000));
      b = retryBtn(); if (!b) return true;
    }
    await push('Something went wrong — pressing Retry (' + retries + ')…');
    await sleep(rnd(1200, 2400));
    tap(b);
    await sleep(2500);
    await settle(10000);
    return true;
  }

  function readRound() {
    var n = 0;
    document.querySelectorAll('[data-testid="UserCell"]').forEach(function (c) {
      var u = cellUser(c); if (!u || u === cfg.handle) return;
      var sc = null; try { if (window.zexWcCell) sc = window.zexWcCell(c); } catch (e) {}
      var prev = seen[u];
      if (!prev) { seen[u] = { s: sc }; found++; if (sc != null) scored++; n++; }
      else if (prev.s == null && sc != null) { prev.s = sc; scored++; }
      else return;
      window.ZexPeople.add(u, { s: sc, f: 1, src: 'FOL' });
    });
    return n;
  }

  async function loop() {
    running = true; await hold();
    var stall = 0, complete = false, reason = 'Done';
    await push('Loading your Following list…');
    await sleep(2500);
    while (await runFlag()) {
      if (!onPage()) { await push('Recovering…'); location.href = 'https://x.com/' + cfg.handle + '/following'; await sleep(6000); continue; }
      if (await fixError()) continue;                 // error screen → press Retry first
      var before = found;
      readRound();
      await sleep(1200); readRound();   // Wallchain badges land a moment after the row
      await push('Reading… ' + found + ' accounts · ' + scored + ' with score');
      var st0 = await settle(8000);                   // finish loading before scrolling any further
      if (st0 === 'error') continue;
      readRound();
      if (found > before) { stall = 0; retries = 0; } else stall++;
      window.scrollBy(0, window.innerHeight * 1.5);
      await sleep(1500);
      if ((await settle(10000)) === 'error') continue;
      if (stall >= 8) {
        window.scrollTo(0, document.documentElement.scrollHeight);
        await sleep(2000);
        var st2 = await settle(10000);
        if (st2 === 'error' || retryBtn()) { stall = 7; continue; }   // never call it "done" while an error is showing
        var b2 = found; readRound();
        if (found === b2) { complete = true; break; }
        stall = 0;
      }
    }
    if (!complete && !(await runFlag())) reason = 'Stopped';
    window.ZexPeople.flushNow();
    var removed = 0;
    if (complete) { await sleep(600); try { removed = await window.ZexPeople.reconcile(Object.keys(seen).reduce(function (o, k) { o[k] = 1; return o; }, {})); } catch (e) {} }
    running = false; await unhold();
    await set({ zexPeopleRun: false });
    await push(reason === 'Done' ? ('Finished — ' + found + ' following saved (' + scored + ' with score)' + (removed ? ' · ' + removed + ' no longer followed' : '')) : ('Stopped — ' + found + ' saved so far'), { running: false, done: true });
  }

  async function boot() {
    if (running) return;
    var m = location.pathname.match(/^\/([^/]+)\/following\/?$/i); if (!m) return;
    var d = await get(['zexPeopleRun']); if (!d.zexPeopleRun) return;
    var r = await ask({ type: 'zexPeopleClaim' }); if (!r || !r.ok) return;
    cfg = r.cfg; if (!cfg || cfg.handle !== m[1].toLowerCase()) return;
    if (!window.ZexPeople) return;
    window.ZexPeople.whenReady(function () { loop(); });
  }
  boot();
  try { chrome.storage.onChanged.addListener(function (c, a) { if (a === 'local' && c.zexPeopleRun && c.zexPeopleRun.newValue === true && !running) boot(); }); } catch (e) {}
})();
