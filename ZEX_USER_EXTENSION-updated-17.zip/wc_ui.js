/* Z EX — Wallchain Score options (popup).
   Puts a small "WALLCHAIN SCORE" card inside each engine's own page and saves everything
   to chrome.storage.local.zexWc (read by content.js / unfollow.js through wc_score.js). */
(function () {
  'use strict';
  var KEY = 'zexWc';
  var DEF = {
    feedFollow: { on: false, min: 100, max: 105, limit: 20, only: false },
    searchFollow: { on: false, min: 100, max: 105, limit: 20, only: false },
    feedEngage: { on: false, min: 100, max: 105 },
    searchEngage: { on: false, min: 100, max: 105 },
    rep: { on: false, min: 100, max: 105 },
    unf: { on: false, min: 100, max: 105 },
    tgEngage: { on: false, min: 100, max: 105 },
    tgSweep: { on: false, min: 100, max: 105 },
    feedCollect: { on: false, min: 100, max: 105 },
    searchCollect: { on: false, min: 100, max: 105 }
  };
  var cfg = JSON.parse(JSON.stringify(DEF));
  function merge(sv) {
    var o = JSON.parse(JSON.stringify(DEF));
    if (sv && typeof sv === 'object') Object.keys(o).forEach(function (k) {
      if (sv[k] && typeof sv[k] === 'object') Object.keys(o[k]).forEach(function (f) { if (sv[k][f] !== undefined) o[k][f] = sv[k][f]; });
    });
    return o;
  }
  var t = null;
  function save() { clearTimeout(t); t = setTimeout(function () { var o = {}; o[KEY] = cfg; try { chrome.storage.local.set(o); } catch (e) {} }, 250); }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html; return d.firstElementChild; }
  function num(v, d) { v = parseInt(v, 10); return isFinite(v) && v >= 0 ? v : d; }

  var css = '.zw-card{background:rgba(255,255,255,0.88);border:1px solid var(--border);padding:12px 14px;margin:0 0 12px}' +
    '.zw-title{font-size:13px;font-weight:800;color:var(--text)}.zw-sub{font-size:11px;color:var(--dim);margin-top:2px;line-height:1.5}' +
    '.zw-row{display:flex;align-items:center;gap:6px;margin-top:8px;flex-wrap:wrap}.zw-row label{font-size:11px;color:var(--dim);flex:1 1 110px}' +
    '.zw-in{flex:none;width:62px;text-align:center;padding:7px 2px;background:#f7f7f5;border:1px solid var(--border);color:#17181a;font-size:12px;font-weight:600;outline:none}' +
    '.zw-u{font-size:11px;color:var(--dim)}.zw-head{display:flex;align-items:center;justify-content:space-between;gap:10px}' +
    '.zw-body{display:none}.zw-card.on .zw-body{display:block}.zw-btn{padding:7px 10px;border:1px solid var(--border);background:var(--dark2);color:var(--text);font-size:11px;font-weight:700;cursor:pointer}' +
    '.zw-chk{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--dim);margin-top:8px}' +
    '.zw-det{margin-top:8px;border:1px solid var(--border);background:#f7f7f5}.zw-det summary{cursor:pointer;padding:7px 9px;font-size:11px;font-weight:800;color:var(--text)}' +
    '.zw-list{max-height:180px;overflow:auto;padding:0 9px 7px}.zw-li{display:flex;justify-content:space-between;gap:6px;font-size:11px;padding:3px 0;border-top:1px solid var(--border)}' +
    '.zw-li a{color:var(--text);font-weight:600;text-decoration:none}.zw-li span{color:var(--dim);white-space:nowrap}.zw-empty{font-size:11px;color:var(--dim);padding:4px 0}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  // kind: 'range' (min–max), 'follow' (range + limit + follow-only), 'below' (single number)
  function card(key, title, sub, kind) {
    var c = cfg[key];
    var h = '<div class="zw-card' + (c.on ? ' on' : '') + '" data-k="' + key + '"><div class="zw-head"><div><div class="zw-title">' + title + '</div><div class="zw-sub">' + sub + '</div></div>' +
      '<label class="toggle"><input type="checkbox" data-f="on' + '"' + (c.on ? ' checked' : '') + '><span class="toggle-slider"></span></label></div><div class="zw-body">';
    if (kind === 'below') {
      h += '<div class="zw-row"><label>Unfollow if score is below</label><input type="number" class="zw-in" data-f="below" min="0" value="' + c.below + '"></div>';
    } else {
      h += '<div class="zw-row"><label>Score range</label><input type="number" class="zw-in" data-f="min" min="0" value="' + c.min + '"><span class="zw-u">to</span><input type="number" class="zw-in" data-f="max" min="0" value="' + c.max + '"></div>';
    }
    if (kind === 'follow') {
      h += '<div class="zw-row"><label>Max follows (0 = no limit)</label><input type="number" class="zw-in" data-f="limit" min="0" value="' + c.limit + '"></div>';
      h += '<div class="zw-chk"><input type="checkbox" data-f="only"' + (c.only ? ' checked' : '') + '> Follow only — no replies</div>';
      h += '<div class="zw-row"><span class="zw-u" data-stat></span><button class="zw-btn" data-reset type="button">Reset count</button></div>';
      h += '<details class="zw-det"><summary>NEW FOLLOW · <span data-n="new">0</span></summary><div class="zw-list" data-l="new"></div></details>';
      h += '<details class="zw-det"><summary>ALREADY FOLLOWED · <span data-n="already">0</span></summary><div class="zw-list" data-l="already"></div></details>';
      h += '<div class="zw-row"><span class="zw-u">Saved names are skipped next time.</span><button class="zw-btn" data-clearlog type="button">Clear list</button></div>';
    }
    return el(h + '</div></div>');
  }
  function wire(node) {
    var key = node.dataset.k;
    node.addEventListener('input', function (e) {
      var f = e.target.dataset && e.target.dataset.f; if (!f) return;
      var c = cfg[key];
      if (e.target.type === 'checkbox') c[f] = e.target.checked; else c[f] = num(e.target.value, c[f]);
      if (f === 'on') node.classList.toggle('on', c.on);
      save();
    });
    var cl = node.querySelector('[data-clearlog]');
    if (cl) cl.addEventListener('click', function () {
      if (confirm('Clear the saved New follow / Already followed list? These accounts can be opened again.')) chrome.storage.local.set({ zexWcFollowLog: {} });
    });
    var rs = node.querySelector('[data-reset]');
    if (rs) rs.addEventListener('click', function () {
      chrome.storage.local.get(['zexWcFollowStat', 'zexWcFollowed'], function (d) {
        var s = d.zexWcFollowStat || {}; s[key === 'feedFollow' ? 'feed' : 'search'] = 0;
        chrome.storage.local.set({ zexWcFollowStat: s, zexWcFollowed: {} });
      });
    });
  }
  function put(anchorId, where, key, title, sub, kind) {
    var a = document.getElementById(anchorId); if (!a || !a.parentNode) return null;
    var n = card(key, title, sub, kind); wire(n);
    if (where === 'before') a.parentNode.insertBefore(n, a); else a.parentNode.insertBefore(n, a.nextSibling);
    return n;
  }

  var statNodes = [];
  var ENGN = { feed: 'FEED', search: 'SEARCH' };
  function renderLog(log) {
    var rows = { new: [], already: [] };
    Object.keys(log).forEach(function (h) { var x = log[h]; if (x && rows[x.r]) rows[x.r].push({ h: h, x: x }); });
    statNodes.forEach(function (n) {
      ['new', 'already'].forEach(function (r) {
        var list = n.card.querySelector('[data-l="' + r + '"]'), cnt = n.card.querySelector('[data-n="' + r + '"]'); if (!list) return;
        var a = rows[r].sort(function (p, q) { return (q.x.t || 0) - (p.x.t || 0); });
        if (cnt) cnt.textContent = a.length;
        list.textContent = '';
        if (!a.length) { var em = document.createElement('div'); em.className = 'zw-empty'; em.textContent = 'Nothing yet.'; list.appendChild(em); return; }
        a.slice(0, 200).forEach(function (it) {
          var li = document.createElement('div'); li.className = 'zw-li';
          var l = document.createElement('a'); l.href = 'https://x.com/' + it.h; l.target = '_blank'; l.rel = 'noopener'; l.textContent = '@' + it.h;
          var m = document.createElement('span'), d = new Date(it.x.t || 0);
          m.textContent = (it.x.s != null ? 'WC ' + it.x.s + ' · ' : '') + (ENGN[it.x.eng] || '') + ' · ' + d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
          li.appendChild(l); li.appendChild(m); list.appendChild(li);
        });
        if (a.length > 200) { var mo = document.createElement('div'); mo.className = 'zw-empty'; mo.textContent = '+ ' + (a.length - 200) + ' more'; list.appendChild(mo); }
      });
    });
  }
  function refreshStat() {
    chrome.storage.local.get(['zexWcFollowStat', 'zexWcFollowPool', 'zexWcFollowLog'], function (d) {
      var s = d.zexWcFollowStat || {};
      renderLog(d.zexWcFollowLog || {});
      statNodes.forEach(function (x) {
        var k = x.card.dataset.k === 'feedFollow' ? 'feed' : 'search', lim = cfg[x.card.dataset.k].limit;
        x.el.textContent = 'Followed ' + (s[k] || 0) + (lim ? ' / ' + lim : '');
      });
      var pn = document.getElementById('zwPoolCount'); if (pn) pn.textContent = (d.zexWcFollowPool || []).length;
    });
  }

  function poolRow() {
    var box = document.getElementById('followListInput'); if (!box || document.getElementById('zwPool')) return;
    var n = el('<div class="zw-card" id="zwPool"><div class="zw-title">SAVED FROM WALLCHAIN</div><div class="zw-sub">Commenters Telegram found in your score range. <b id="zwPoolCount">0</b> saved.</div>' +
      '<div class="zw-row"><button class="zw-btn" data-act="move" type="button">Move to list</button><button class="zw-btn" data-act="clear" type="button">Clear</button></div></div>');
    n.addEventListener('click', function (e) {
      var a = e.target.dataset && e.target.dataset.act; if (!a) return;
      chrome.storage.local.get(['zexWcFollowPool'], function (d) {
        var pool = d.zexWcFollowPool || [];
        if (a === 'move' && pool.length) {
          box.value = (box.value ? box.value.replace(/\s+$/, '') + '\n' : '') + pool.map(function (h) { return '@' + h; }).join('\n');
          box.dispatchEvent(new Event('input', { bubbles: true }));
        }
        if (a === 'move' || a === 'clear') chrome.storage.local.set({ zexWcFollowPool: [] }, refreshStat);
      });
    });
    box.parentNode.insertBefore(n, box);
  }

  function init() {
    chrome.storage.local.get([KEY], function (d) {
      cfg = merge(d[KEY]);
      var FOL = 'Automatically follows users whose Wallchain scores match your set range. The engine opens their profile, follows them, and returns to the feed. Auto Mode must be ON. Works only with Wallchain scores.';
      var f1 = put('feedStatsSectionLabel', 'before', 'feedFollow', 'FOLLOW BY WALLCHAIN SCORE', FOL, 'follow');
      var COLS = 'While the engine runs, it collects usernames whose Wallchain scores match your set range and saves them to the shared list. Already-followed accounts are skipped. You can find this list in the SWEEP ENGINE.';
      put('feedStatsSectionLabel', 'before', 'feedCollect', 'COLLECT USERNAME BY WALLCHAIN WHILE ENGAGING', COLS, 'range');
      put('feedStatsSectionLabel', 'before', 'feedEngage', 'ENGAGE BY WALLCHAIN SCORE', 'Score outside the range = no FED button on that post.', 'range');
      var f2 = put('seaCollectSectionLabel', 'before', 'searchFollow', 'FOLLOW BY WALLCHAIN SCORE', FOL, 'follow');
      put('seaCollectSectionLabel', 'before', 'searchCollect', 'COLLECT USERNAME BY WALLCHAIN WHILE ENGAGING', COLS, 'range');
      put('seaCollectSectionLabel', 'before', 'searchEngage', 'ENGAGE BY WALLCHAIN SCORE', 'Score outside the range = no SEA button on that post.', 'range');
      put('repSpeedSectionLabel', 'before', 'rep', 'REPLY BY WALLCHAIN SCORE', 'Reply only to comments whose author score is in range.', 'range');
      put('unfStartBtn', 'before', 'unf', 'UNFOLLOW BY SCORE', 'Score inside the range = kept. Outside the range, or no score seen = unfollowed.', 'range');
      var TGS = 'Commenters visible on the opened post, score in range → saved to the Follow list.';
      ['activityTgEngageSection:tgEngage:TELEGRAM ENGAGE', 'activityTgSweepSection:tgSweep:TELEGRAM SWEEP'].forEach(function (x) {
        var p = x.split(':'), sec = document.getElementById(p[0]); if (!sec) return;
        var n = card(p[1], 'COLLECT USERNAME BY WALLCHAIN WHILE ENGAGING', p[2] + ' — ' + TGS, 'range'); wire(n);
        // place it below the Break / Delay settings, right above the status block (Run Status / Queue Status)
        var anchor = null;
        sec.querySelectorAll('.sec-label').forEach(function (l) { if (!anchor && /^(run|queue) status$/i.test((l.textContent || '').trim())) anchor = l; });
        if (anchor) anchor.parentNode.insertBefore(n, anchor);
        else sec.appendChild(n);
      });
      [f1, f2].forEach(function (n) { if (n) statNodes.push({ card: n, el: n.querySelector('[data-stat]') }); });
      poolRow();
      refreshStat();
    });
    chrome.storage.onChanged.addListener(function (c, a) { if (a === 'local' && (c.zexWcFollowStat || c.zexWcFollowPool || c.zexWcFollowLog)) refreshStat(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
