/* Animated cursor skin picker (popup). Saves zen_cursor_skin: '' | navy | teal | gold | crim | beat */
(function () {
  var grid = document.getElementById('zexSkinGrid');
  if (!grid || typeof ZexCursorFX === 'undefined') return;
  var FX = ZexCursorFX, cards = {}, current = '', prev = null, chips = {}, autoT = null, autoI = 0;
  var LABEL = { scroll: 'Scroll', search: 'Search', found: 'Got post', like: 'Like', comment: 'Comment', type: 'Typing', typed: 'Typed', reply: 'Reply', done: 'Done', rest: 'Rest' };

  function card(id, name) {
    var d = document.createElement('div');
    d.style.cssText = 'border:2px solid #e3e3e8;border-radius:10px;padding:6px 4px;text-align:center;cursor:pointer;background:#15161a;';
    var cv = document.createElement('canvas'); cv.style.cssText = 'image-rendering:pixelated;display:block;margin:0 auto;';
    var t = document.createElement('div'); t.textContent = name; t.style.cssText = 'font-size:11px;font-weight:700;color:#facc15;margin-top:4px;';
    d.appendChild(cv); d.appendChild(t);
    d.addEventListener('click', function () { choose(id); });
    grid.appendChild(d);
    return { el: d, cv: cv };
  }

  // "Off" card = normal arrow / custom image
  var off = card('', 'Off'); cards[''] = off;
  var o2 = off.cv.getContext('2d'); off.cv.width = 38; off.cv.height = 38; off.cv.style.width = '57px'; off.cv.style.height = '57px';
  o2.fillStyle = '#fff'; o2.fillRect(10, 6, 4, 24); o2.fillRect(14, 10, 4, 4); o2.fillRect(14, 22, 4, 6); o2.fillRect(18, 14, 4, 4); o2.fillRect(18, 26, 4, 4);

  FX.SKINS.forEach(function (s, i) {
    var c = card(s.id, s.name);
    var r = FX.create(c.cv, { skin: s.id, u: 3, bubble: false, arrow: false });
    r.setState(['like', 'found', 'typed', 'done', 'reply'][i % 5], true); r.start();
    c.fx = r; cards[s.id] = c;
  });

  function ensurePrev() {
    var wrap = document.getElementById('zexSkinPrevWrap'), cv = document.getElementById('zexSkinPrev');
    if (!current) { wrap.style.display = 'none'; if (prev) prev.stop(); clearInterval(autoT); return; }
    wrap.style.display = 'block';
    if (!prev) {
      prev = FX.create(cv, { skin: current, u: 2, bubble: true, arrow: true });
      var box = document.getElementById('zexSkinChips');
      FX.STATE_KEYS.forEach(function (k) {
        var b = document.createElement('button'); b.textContent = LABEL[k];
        b.style.cssText = 'padding:4px 8px;border-radius:6px;border:1px solid #3a3b44;background:#22232a;color:#facc15;font-size:11px;cursor:pointer;';
        b.addEventListener('click', function () { clearInterval(autoT); prev.setState(k, true); });
        box.appendChild(b); chips[k] = b;
      });
    }
    prev.setSkin(current); prev.setState('like', true); prev.start();
    clearInterval(autoT);
    autoT = setInterval(function () { autoI = (autoI + 1) % FX.STATE_KEYS.length; prev.setState(FX.STATE_KEYS[autoI], true); }, 3200);
  }

  function mark() {
    Object.keys(cards).forEach(function (k) { cards[k].el.style.borderColor = (k === current) ? '#facc15' : '#e3e3e8'; });
  }
  function choose(id) {
    current = id; mark(); ensurePrev();
    try { chrome.storage.local.set({ zen_cursor_skin: id }); } catch (e) {}
  }

  try {
    chrome.storage.local.get(['zen_cursor_skin'], function (d) {
      current = (d && d.zen_cursor_skin) || ''; mark(); ensurePrev();
    });
  } catch (e) { mark(); }
})();
