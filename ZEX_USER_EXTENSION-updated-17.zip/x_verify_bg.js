// X VERIFY - runs in the background service worker so it survives the popup closing.
// Popup sends {type:'zexXVerifyStart', handle}. Progress / result lives in storage key zexXVerifyJob:
//   { handle, status: 'running'|'verified'|'notlogged'|'fake'|'muted'|'taken'|'network'|'error'|'nosession'|'badhandle', msg, startedAt, at, retried }
// The popup only renders this key (on open, and live while open), so closing / reopening it never loses a verification.
(function () {
  var KEY = 'zexXVerifyJob', MAX_FAILS = 3, inflight = false;
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var getS = function (k) { return new Promise(function (r) { chrome.storage.local.get(k, r); }); };
  var setS = function (o) { return new Promise(function (r) { chrome.storage.local.set(o, r); }); };
  var emailKey = function (e) { return String(e || '').replace(/\./g, '_dot_').replace(/@/g, '_at_'); };
  function put(job) { return setS({ [KEY]: job }); }

  // Injected into the profile tab: X shows "Edit profile" only on the logged-in user's own profile.
  function ownerScript() {
    if (document.querySelector('[data-testid="editProfileButton"]')) return { isOwner: true, method: 'editProfileButton' };
    var els = Array.from(document.querySelectorAll('a[href], button, div[role="button"]'));
    for (var i = 0; i < els.length; i++) { var t = els[i].innerText && els[i].innerText.trim(); if (t === 'Edit profile') return { isOwner: true, method: 'editProfileText' }; }
    if (document.querySelector('[data-testid="followButton"], [data-testid="placementTracking"], [data-testid="unfollow"]')) return { isOwner: false, method: 'followButton' };
    return { isOwner: null, method: 'inconclusive' };
  }

  function waitComplete(tabId, ms) {
    return new Promise(function (res) {
      var done = false;
      var fin = function () { if (done) return; done = true; try { chrome.tabs.onUpdated.removeListener(l); } catch (e) {} res(); };
      var l = function (id, info) { if (id === tabId && info.status === 'complete') fin(); };
      chrome.tabs.onUpdated.addListener(l);
      chrome.tabs.get(tabId, function (t) { void chrome.runtime.lastError; if (t && t.status === 'complete') fin(); });
      setTimeout(fin, ms);
    });
  }

  // Open the profile, poll until X has rendered enough to decide (up to ~15s), close the tab.
  async function probe(url) {
    var tab = await new Promise(function (r) { chrome.tabs.create({ url: url, active: false }, function (t) { void chrome.runtime.lastError; r(t || null); }); });
    if (!tab) return null;
    var last = null;
    try {
      await waitComplete(tab.id, 15000);
      for (var i = 0; i < 8; i++) {
        await sleep(1800);
        try {
          var r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: ownerScript });
          last = r && r[0] && r[0].result;
        } catch (e) { last = null; }
        if (last && last.isOwner !== null) break;
      }
    } finally { try { chrome.tabs.remove(tab.id); } catch (e) {} }
    return last;
  }

  async function claim(handle) {
    try {
      var tok = await zGetToken();
      if (!tok) return { ok: false, error: 'NO_AUTH' };
      var res = await fetch(ZEXPAY_URL + '/v1/xclaim', { method: 'POST', headers: { 'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: JSON.stringify({ handle: handle }) });
      var j = {}; try { j = await res.json(); } catch (e) {}
      if (res.ok && j.ok !== false) return { ok: true };
      return { ok: false, error: j.error || ('HTTP_' + res.status) };
    } catch (e) { return { ok: false, error: 'NETWORK' }; }
  }

  async function run(handle, retried) {
    if (inflight) return;
    inflight = true;
    var keep = setInterval(function () { try { chrome.runtime.getPlatformInfo(function () { void chrome.runtime.lastError; }); } catch (e) {} }, 20000);
    var startedAt = Date.now();
    var fin = function (status, msg, extra) { return put(Object.assign({ handle: handle, status: status, msg: msg, startedAt: startedAt, at: Date.now(), retried: !!retried }, extra || {})); };
    try {
      var session = (await getS(['zenDeviceSession'])).zenDeviceSession;
      if (!session || !session.email) { await fin('nosession', 'Login first, then verify.'); return; }
      await put({ handle: handle, status: 'running', msg: 'Checking @' + handle + ' ...', startedAt: startedAt, at: startedAt, retried: !!retried });

      // Mute (3 fake attempts = 1 day), local only (S4: no Firebase).
      var st = await getS(['xVerifyMuteUntil', 'xVerifyFailCount']);
      if (st.xVerifyMuteUntil && Date.now() >= st.xVerifyMuteUntil) { chrome.storage.local.remove(['xVerifyMuteUntil', 'xVerifyFailCount']); st = {}; }
      else if (st.xVerifyMuteUntil) {
        await fin('muted', 'Muted for ' + Math.ceil((st.xVerifyMuteUntil - Date.now()) / 60000) + ' more minutes.'); return;
      }

      var result = await probe('https://x.com/' + handle);
      if (!result || result.isOwner === null) { await fin('notlogged', 'Not logged into X, or the profile failed to load. Log into X and try again.'); return; }

      if (result.isOwner === true) {
        var c = await claim(handle);
        if (!c.ok) { await fin(c.error === 'X_TAKEN' ? 'taken' : 'network', c.error === 'X_TAKEN' ? 'This X account is already verified on another ZEX account.' : 'Could not verify right now (network). Try again.'); return; }
        // S4: ownership lives in D1 (x_handles) via /v1/xclaim above; /v1/profile reads it back. Nothing else to save.
        var cur = (await getS(['zenDeviceSession'])).zenDeviceSession || session;
        await setS({ zenDeviceSession: Object.assign({}, cur, { xHandle: handle }), xVerifyFailCount: 0 });
        await fin('verified', 'Verified: @' + handle);
        return;
      }

      // Follow button = somebody else's account
      var failCount = (st.xVerifyFailCount || 0) + 1;
      await setS({ xVerifyFailCount: failCount });
      if (failCount >= MAX_FAILS) {
        var until = Date.now() + 24 * 60 * 60 * 1000;
        await setS({ xVerifyMuteUntil: until, xVerifyFailCount: 0 });
        await fin('muted', 'Attempted to verify a fake X account - muted for 1 day.');
      } else {
        await fin('fake', 'Fake account attempt detected - @' + handle + ' is not your account. ' + (MAX_FAILS - failCount) + ' attempt(s) remaining.');
      }
    } catch (e) {
      try { await fin('error', 'Verification failed. Please try again.'); } catch (e2) {}
    } finally { clearInterval(keep); inflight = false; }
  }

  // Server says X_NOT_VERIFIED (admin released the handle / claim is gone) -> drop the stale local + Firebase verification
  // so the popup shows the Verify page again and the user can re-verify. Called by background.js on that server error.
  var resetting = false;
  self.zexXResetLocal = async function () {
    if (resetting || inflight) return false;
    resetting = true;
    try {
      var session = (await getS(['zenDeviceSession'])).zenDeviceSession;
      if (!session || !session.email || !session.xHandle) return false;
      var cur = (await getS(['zenDeviceSession'])).zenDeviceSession || session;
      await setS({ zenDeviceSession: Object.assign({}, cur, { xHandle: '' }) });
      await chrome.storage.local.remove([KEY]);
      return true;
    } catch (e) { return false; }
    finally { resetting = false; }
  };

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.type !== 'zexXVerifyStart') return;
    if (sender && sender.id && sender.id !== chrome.runtime.id) return;
    var h = String(msg.handle || '').trim().replace(/^@/, '');
    if (!/^[A-Za-z0-9_]{1,15}$/.test(h)) {
      put({ handle: h, status: 'badhandle', msg: 'Enter a valid X username (letters, numbers, underscore).', startedAt: Date.now(), at: Date.now() });
      sendResponse({ ok: false, error: 'badhandle' }); return;
    }
    if (inflight) { sendResponse({ ok: true, already: true }); return; }
    run(h.toLowerCase(), false);        // not awaited: the popup may close at any moment
    sendResponse({ ok: true });
  });

  // The service worker can be killed mid-run (browser memory pressure). If it wakes up and a "running" job has no live run, resume it once.
  getS(KEY).then(function (d) {
    var j = d && d[KEY];
    if (j && j.status === 'running' && !inflight && j.handle) {
      if (!j.retried && Date.now() - (j.startedAt || 0) < 5 * 60 * 1000) run(j.handle, true);
      else put(Object.assign({}, j, { status: 'error', msg: 'Verification was interrupted. Tap Verify again.', at: Date.now() }));
    }
  });
})();
