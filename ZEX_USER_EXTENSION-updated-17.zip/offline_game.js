/* Z EX — offline page + mini game (like Chrome's dino).
   Self-contained: injects its own CSS + overlay, no HTML edits needed.
   Shows when the browser goes offline (popup / agent / hub), hides itself when the connection returns.
   Jump: tap the screen, Space or ArrowUp.  Hi-score saved in localStorage ("zexOfflineHi"). */
(function () {
  'use strict';
  if (window.__zexOfflineGame) return;
  window.__zexOfflineGame = true;

  var HI_KEY = 'zexOfflineHi';
  var W = 600, H = 150, GROUND = 124;
  var overlay, canvas, ctx, hiEl, scoreEl, hintEl, statusEl;
  var shown = false, dismissed = false, raf = 0, last = 0;
  var g; // game state

  function css() {
    var s = document.createElement('style');
    s.textContent =
      '#zexOff{position:fixed;inset:0;z-index:10000;display:none;flex-direction:column;align-items:center;justify-content:center;' +
      'padding:20px 14px;box-sizing:border-box;background:#fffdf5;color:#17181a;font-family:"Courier New",monospace;text-align:center;-webkit-user-select:none;user-select:none;touch-action:manipulation}' +
      'html.zex-dark #zexOff,body.zex-legacy-dark #zexOff{background:#0f1013;color:#f0f0f0}' +
      '#zexOff.on{display:flex}' +
      '#zexOff .zo-ico{font-size:34px;line-height:1;margin-bottom:6px}' +
      '#zexOff h2{margin:0 0 4px;font-size:18px;letter-spacing:1px}' +
      '#zexOff p{margin:0 0 14px;font-size:11px;color:#8a8d93;max-width:300px;line-height:1.5}' +
      '#zexOff .zo-box{width:100%;max-width:420px;border:2px solid #17181a;border-radius:10px;background:#fff;padding:6px 6px 4px;position:relative;box-sizing:border-box}' +
      'html.zex-dark #zexOff .zo-box,body.zex-legacy-dark #zexOff .zo-box{background:#17181b;border-color:#eab308}' +
      '#zexOff canvas{width:100%;height:auto;display:block;image-rendering:pixelated}' +
      '#zexOff .zo-row{display:flex;justify-content:space-between;width:100%;max-width:420px;font-size:11px;margin:8px 0 0;font-weight:700;letter-spacing:1px}' +
      '#zexOff .zo-row b{color:#ca8a04}' +
      '#zexOff .zo-hint{margin-top:10px;font-size:11px;color:#8a8d93}' +
      '#zexOff .zo-btns{display:flex;gap:8px;margin-top:14px}' +
      '#zexOff button{font:inherit;font-size:11px;font-weight:700;letter-spacing:1px;padding:8px 14px;border-radius:8px;border:1px solid #eab308;background:#eab308;color:#17181a;cursor:pointer}' +
      '#zexOff button.alt{background:transparent;color:inherit;border-color:#8a8d93}' +
      '#zexOff .zo-st{margin-top:10px;font-size:10px;color:#dc2626;font-weight:700;letter-spacing:1px}' +
      '#zexOffTab{position:fixed;left:50%;bottom:14px;transform:translateX(-50%);z-index:10000;display:none;font:700 11px "Courier New",monospace;' +
      'padding:8px 14px;border-radius:999px;border:1px solid #eab308;background:#fff9e6;color:#17181a;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.15)}' +
      '#zexOffTab.on{display:block}';
    document.head.appendChild(s);
  }

  function build() {
    css();
    overlay = document.createElement('div');
    overlay.id = 'zexOff';
    overlay.innerHTML =
      '<div class="zo-ico">📡</div>' +
      '<h2>NO INTERNET</h2>' +
      '<p>Z EX needs internet to work. Waiting for the connection — play while you wait.</p>' +
      '<div class="zo-box"><canvas width="' + W + '" height="' + H + '"></canvas></div>' +
      '<div class="zo-row"><span>HI <b id="zoHi">0</b></span><span>SCORE <b id="zoSc">0</b></span></div>' +
      '<div class="zo-hint" id="zoHint">TAP / SPACE to start</div>' +
      '<div class="zo-btns"><button id="zoRetry" type="button">↻ RETRY CONNECTION</button><button id="zoHide" class="alt" type="button">HIDE</button></div>' +
      '<div class="zo-st" id="zoSt"></div>';
    document.body.appendChild(overlay);

    var tab = document.createElement('button');
    tab.id = 'zexOffTab'; tab.type = 'button'; tab.textContent = '🎮 OFFLINE — PLAY';
    tab.addEventListener('click', function () { dismissed = false; show(); });
    document.body.appendChild(tab);

    canvas = overlay.querySelector('canvas');
    ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    hiEl = overlay.querySelector('#zoHi'); scoreEl = overlay.querySelector('#zoSc');
    hintEl = overlay.querySelector('#zoHint'); statusEl = overlay.querySelector('#zoSt');

    overlay.querySelector('#zoRetry').addEventListener('click', retry);
    overlay.querySelector('#zoHide').addEventListener('click', function (e) { e.stopPropagation(); dismissed = true; hide(); syncTab(); });
    // jump input: anywhere on the overlay except buttons
    overlay.addEventListener('pointerdown', function (e) {
      if (e.target.closest('button')) return;
      e.preventDefault(); press();
    });
    document.addEventListener('keydown', function (e) {
      if (!shown) return;
      if (e.code === 'Space' || e.code === 'ArrowUp') { e.preventDefault(); press(); }
    });
    reset(); draw();
  }

  // ── game ────────────────────────────────────────────────
  function hi() { try { return +localStorage.getItem(HI_KEY) || 0; } catch (e) { return 0; } }
  function saveHi(v) { try { localStorage.setItem(HI_KEY, String(v)); } catch (e) {} }

  function reset() {
    g = { state: 'ready', y: 0, vy: 0, onGround: true, obs: [], speed: 230, score: 0, dist: 0, spawnIn: 1.0, t: 0, clouds: [{ x: 80, y: 30 }, { x: 330, y: 50 }, { x: 520, y: 22 }] };
    hiEl.textContent = pad(hi()); scoreEl.textContent = '00000';
    hintEl.textContent = 'TAP / SPACE to start';
  }
  function pad(n) { return String(Math.floor(n)).padStart(5, '0'); }

  function press() {
    if (g.state === 'ready') { g.state = 'run'; hintEl.textContent = 'TAP / SPACE to jump'; jump(); }
    else if (g.state === 'run') jump();
    else if (g.state === 'over') { reset(); g.state = 'run'; hintEl.textContent = 'TAP / SPACE to jump'; jump(); }
    kick();
  }
  function jump() { if (g.onGround) { g.vy = -520; g.onGround = false; } }

  function update(dt) {
    if (g.state !== 'run') return;
    g.t += dt;
    g.speed = Math.min(520, 230 + g.t * 9);
    g.dist += g.speed * dt;
    g.score = g.dist / 12;
    // player physics
    g.vy += 1700 * dt; g.y += g.vy * dt;
    if (g.y >= 0) { g.y = 0; g.vy = 0; g.onGround = true; }
    // obstacles
    g.spawnIn -= dt;
    if (g.spawnIn <= 0) {
      var n = Math.random() < 0.3 ? 2 : 1, h = 22 + Math.floor(Math.random() * 18);
      g.obs.push({ x: W + 10, w: 12 * n + 4 * (n - 1), h: h, n: n });
      g.spawnIn = (0.75 + Math.random() * 0.9) * (300 / g.speed) * 1.25 + 0.35;
    }
    g.obs.forEach(function (o) { o.x -= g.speed * dt; });
    g.obs = g.obs.filter(function (o) { return o.x + o.w > -10; });
    g.clouds.forEach(function (c) { c.x -= 20 * dt; if (c.x < -40) { c.x = W + 20; c.y = 16 + Math.random() * 50; } });
    // collision (player box slightly forgiving)
    var px = 40, pw = 22, ph = 26, py = GROUND - ph + g.y;
    for (var i = 0; i < g.obs.length; i++) {
      var o = g.obs[i], oy = GROUND - o.h;
      if (px + pw - 3 > o.x + 2 && px + 3 < o.x + o.w - 2 && py + ph - 2 > oy + 2) { die(); break; }
    }
    scoreEl.textContent = pad(g.score);
  }

  function die() {
    g.state = 'over';
    var s = Math.floor(g.score);
    if (s > hi()) { saveHi(s); hiEl.textContent = pad(s); }
    hintEl.textContent = 'GAME OVER — TAP / SPACE to retry';
  }

  // pixel character (a little ZEX bolt-head), 11x13 grid, scale 2
  var SPR = [
    '...yyyyy...',
    '..yyyyyyy..',
    '.yyyyyyyyy.',
    '.ykkkykkky.',
    '.ykwkykwky.',
    '.yyyyyyyyy.',
    '..yyyrryy..',
    '...yyyyy...',
    '..yyyyyyy..',
    '.yyyyyyyyy.',
    '..yy...yy..',
    '..kk...kk..',
    '.kkk...kkk.'
  ];
  var PAL = { y: '#eab308', k: '#17181a', w: '#ffffff', r: '#dc2626' };
  var dark = function () { return document.documentElement.classList.contains('zex-dark') || document.body.classList.contains('zex-legacy-dark'); };

  function draw() {
    var fg = dark() ? '#f0f0f0' : '#17181a', soft = dark() ? '#3a3b40' : '#d9d9d4';
    ctx.clearRect(0, 0, W, H);
    // clouds
    ctx.fillStyle = soft;
    g.clouds.forEach(function (c) { ctx.fillRect(c.x, c.y, 34, 6); ctx.fillRect(c.x + 8, c.y - 5, 18, 5); });
    // ground
    ctx.fillStyle = fg; ctx.fillRect(0, GROUND + 1, W, 2);
    var off = Math.floor(g.dist) % 40;
    for (var x = -off; x < W; x += 40) ctx.fillRect(x + 12, GROUND + 8, 10, 2);
    // obstacles (cactus-like pillars)
    g.obs.forEach(function (o) {
      for (var k = 0; k < o.n; k++) {
        var ox = o.x + k * 16, oy = GROUND - o.h;
        ctx.fillStyle = fg; ctx.fillRect(ox, oy, 12, o.h);
        ctx.fillRect(ox - 4, oy + 8, 4, 10); ctx.fillRect(ox + 12, oy + 4, 4, 10);
        ctx.fillStyle = '#eab308'; ctx.fillRect(ox + 3, oy + 3, 3, 3);
      }
    });
    // player
    var sy = GROUND - SPR.length * 2 + g.y, sx = 38, blink = g.state === 'over';
    for (var r = 0; r < SPR.length; r++) for (var c = 0; c < SPR[r].length; c++) {
      var ch = SPR[r][c]; if (ch === '.') continue;
      // run animation: swap legs
      var cc = c;
      if (r >= 12 && g.onGround && g.state === 'run' && Math.floor(g.t * 10) % 2) cc = 10 - c;
      ctx.fillStyle = blink && ch === 'w' ? '#dc2626' : PAL[ch];
      ctx.fillRect(sx + cc * 2, sy + r * 2, 2, 2);
    }
    if (g.state === 'over') {
      ctx.fillStyle = fg; ctx.font = 'bold 16px "Courier New",monospace'; ctx.textAlign = 'center';
      ctx.fillText('G A M E   O V E R', W / 2, 62);
    }
  }

  function frame(ts) {
    raf = 0;
    if (!shown) return;
    var dt = Math.min(0.05, (ts - (last || ts)) / 1000); last = ts;
    update(dt); draw();
    raf = requestAnimationFrame(frame);
  }
  function kick() { if (!raf && shown) { last = 0; raf = requestAnimationFrame(frame); } }

  // ── show / hide ─────────────────────────────────────────
  function show() {
    if (!overlay) return;
    shown = true; overlay.classList.add('on');
    statusEl.textContent = 'OFFLINE';
    if (g.state === 'run') g.state = 'ready';
    draw(); kick(); syncTab();
  }
  function hide() { shown = false; if (overlay) overlay.classList.remove('on'); if (raf) { cancelAnimationFrame(raf); raf = 0; } }
  function syncTab() {
    var t = document.getElementById('zexOffTab'); if (!t) return;
    t.classList.toggle('on', dismissed && navigator.onLine === false);
  }
  function retry() {
    statusEl.textContent = 'CHECKING…';
    setTimeout(function () { check(true); if (navigator.onLine === false) statusEl.textContent = 'STILL OFFLINE'; }, 600);
  }
  function check() {
    if (!overlay) return;
    var off = navigator.onLine === false;
    if (off) { if (!shown && !dismissed) show(); syncTab(); }
    else { dismissed = false; if (shown) hide(); syncTab(); }
  }

  function init() {
    if (!document.body) return setTimeout(init, 50);
    build();
    window.addEventListener('offline', function () { dismissed = false; check(); });
    window.addEventListener('online', check);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) check(); });
    setInterval(check, 3000);
    check();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
