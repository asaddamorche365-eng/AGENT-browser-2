// ══════════════════════════════════════════════════════════════
//  BACKGROUND SERVICE WORKER — periodic stall watchdog for Auto/Sweep jobs
//  Runs periodically via chrome.alarms even when the popup is closed.
//  Self-contained (no DOM): service workers can't touch popup.js.
// ══════════════════════════════════════════════════════════════

try { importScripts('tracker_bg.js'); } catch (e) { console.warn('tracker_bg load failed', e); }
function ztx(evt) { try { if (typeof ztLog === 'function') ztLog(evt); } catch (e) {} }

try { importScripts('zauth.js'); zRegisterAuthMessages(); } catch (e) { console.warn('zauth load failed', e); }
try { importScripts('devices.js'); } catch (e) { console.warn('devices load failed', e); }
try { importScripts('linkdb.js'); ZexDB.migrate(); } catch (e) { console.warn('linkdb load failed', e); }   // shared link database: one-time import of the old capped lists
try { importScripts('limits_bg.js'); } catch (e) { console.warn('limits load failed', e); }
try { importScripts('zexplus_bg.js'); } catch (e) { console.warn('zexplus load failed', e); }   // ZEX+: CDP focus / typing / touch / net-test + keep-awake

// ── ZEXPAY bridge: content scripts (page origin) can't call the Worker (CORS is extension-only),
//    so they message the background, which attaches the Firebase ID token and calls the Worker.
const ZEXPAY_URL = 'https://zexpay.asaddamorche365.workers.dev';
const ZEXPAY_ALLOWED = { '/v1/generate': 'POST', '/v1/embed': 'POST', '/v1/me': 'GET', '/v1/packages': 'GET', '/v1/pay/intent': 'POST', '/v1/pay/verify': 'POST', '/v1/pay/history': 'GET', '/v1/redeem': 'POST', '/v1/xclaim': 'POST', '/v1/profile': 'GET,POST', '/v1/app-config': 'GET', '/v1/sorsa': 'POST', '/v1/sorsa/usage': 'GET', '/v1/sorsa/reserve': 'POST', '/v1/sorsa/release': 'POST', '/v1/studio/config': 'GET', '/v1/post/source': 'POST', '/v1/help-img': 'POST', '/v1/post/generate': 'POST', '/v1/image/prompt': 'POST', '/v1/image/generate': 'POST', '/v1/image/free-search': 'POST' };
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'zexpayCall') return;
  if (sender && sender.id && sender.id !== chrome.runtime.id) return;
  var allowed = ZEXPAY_ALLOWED[msg.path];
  var method = allowed ? (allowed.indexOf(',') > -1 ? (allowed.split(',').indexOf(String(msg.method || '').toUpperCase()) > -1 ? String(msg.method).toUpperCase() : (msg.body !== undefined && allowed.indexOf('POST') > -1 ? 'POST' : allowed.split(',')[0])) : allowed) : '';
  if (!method) { sendResponse({ ok: false, error: 'BAD_PATH', message: 'Bad path' }); return; }
  (async function () {
    try {
      var tok = await zGetToken();
      if (!tok) { sendResponse({ ok: false, error: 'NO_AUTH', message: 'Sign in required' }); return; }
      var ctl = new AbortController(); var to = setTimeout(function () { ctl.abort(); }, 70000);
      var res;
      try {
        res = await fetch(ZEXPAY_URL + msg.path, {
          method: method,
          headers: { 'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json' },
          body: method === 'POST' ? JSON.stringify(msg.body || {}) : undefined,
          signal: ctl.signal
        });
      } finally { clearTimeout(to); }
      var j = {}; try { j = await res.json(); } catch (e) {}
      if (res.ok && j.ok !== false) sendResponse({ ok: true, data: j });
      else {
        if (j.error === 'X_NOT_VERIFIED' && typeof self.zexXResetLocal === 'function') { try { await self.zexXResetLocal(); } catch (e) {} }
        sendResponse({ ok: false, error: j.error || ('HTTP_' + res.status), message: j.detail || j.error || ('HTTP ' + res.status), data: j });
      }
    } catch (e) {
      sendResponse({ ok: false, error: 'NETWORK', message: (e && e.name === 'AbortError') ? 'Timeout' : 'Network error' });
    }
  })();
  return true;
});

// ── Legacy: AI provider keys no longer live in the extension (they stay in the Worker) ──
try { importScripts('x_verify_bg.js'); } catch (e) { console.warn('x verify load failed', e); }   // X Verify runs here so it survives the popup closing
var ZEX_LEGACY_KEYS = ['geminiApiKey', 'openrouterApiKey', 'openaiApiKey', 'deepseekApiKey', 'groqApiKey', 'adminApiType', 'adminApiKey', 'sorsaApiKey'];
function zexPurgeLegacyKeys() { try { chrome.storage.local.remove(ZEX_LEGACY_KEYS); } catch (e) {} }
zexPurgeLegacyKeys();
chrome.runtime.onInstalled.addListener(zexPurgeLegacyKeys);
chrome.runtime.onStartup.addListener(zexPurgeLegacyKeys);

const BG_ALARM_NAME = 'sessAutoCheck';
const BG_CHECK_INTERVAL_MIN = 3; // chrome.alarms minimum is 1 min; 3 min is plenty for hour-granularity sessions

async function bgNotify(title, message) {
  try {
    if (chrome.notifications && chrome.notifications.create) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title,
        message,
        priority: 1,
      });
    }
  } catch (e) {}
}

async function bgRunCheck() {
  try {
    // Stall-watchdog: if an Auto Mode job has been sitting in "navigating"
    // or "working" for too long with no content.js report, skip that link
    // and move on rather than hanging forever (page may have failed to
    // load the reply box, network hiccup, etc.).
    await bgCheckStalledAutoJobs();
  } catch (e) {}
}

const AUTO_JOB_STALL_MS = 90000; // 90s per link before we give up and skip it

async function bgCheckStalledAutoJobs() {
  const jobs = await getAutoJobs();
  const now = Date.now();
  for (const [sessionPath, job] of Object.entries(jobs)) {
    if (!job || (job.status !== 'navigating' && job.status !== 'working')) continue;
    const pending = (await chrome.storage.local.get(['zSessAutoPending'])).zSessAutoPending;
    const referenceTs = (pending && pending.sessionPath === sessionPath) ? pending.issuedAt : job.startedAt;
    if (now - referenceTs > AUTO_JOB_STALL_MS) {
      job.currentIndex++;
      job.status = 'working';
      await setAutoJob(sessionPath, job);
      advanceAutoJob(sessionPath);
    }
  }
}


// ══════════════════════════════════════════════════════════════
//  AGENT DASHBOARD — AUTO RESET COUNTERS at user-chosen times (e.g. 06:00, 22:00).
//  Config: chrome.storage.local.zenAgentAutoReset = { on: bool, times: ['06:00','22:00'] } (browser local time).
//  Runs here (alarm) so it works with no X tab open. If the browser was closed at the scheduled time,
//  the missed reset happens at the next start. Content scripts pick up the new zenAgentStats via storage.onChanged.
// ══════════════════════════════════════════════════════════════
const ZEX_AR_ALARM = 'zexAgentAutoReset';
function zexArParse(times) {
  const out = [];
  (Array.isArray(times) ? times : []).forEach((t) => {
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(t || '').trim());
    if (!m) return;
    const h = +m[1], mi = +m[2];
    if (h > 23 || mi > 59) return;
    const v = h * 60 + mi;
    if (out.indexOf(v) < 0) out.push(v);
  });
  return out.sort((a, b) => a - b);
}
function zexArAt(mins, dayOffset) {
  const d = new Date();
  d.setDate(d.getDate() + (dayOffset || 0));
  d.setHours(Math.floor(mins / 60), mins % 60, 0, 0);
  return d.getTime();
}
async function zexArDoReset(ts) {
  const fresh = { ok: 0, fail: 0, posted: 0, drafted: 0, by: {}, lastError: '', lastErrorTs: 0, lastOkTs: 0, since: Date.now() };
  await chrome.storage.local.set({ zenAgentStats: fresh, zenAgentAutoResetLast: ts || Date.now() });
}
async function zexArSchedule() {
  try {
    await chrome.alarms.clear(ZEX_AR_ALARM);
    const d = await chrome.storage.local.get(['zenAgentAutoReset', 'zenAgentAutoResetLast', 'zenAgentStats']);
    const cfg = d.zenAgentAutoReset || {};
    if (cfg.on !== true) return;
    const mins = zexArParse(cfg.times);
    if (!mins.length) return;
    const now = Date.now();
    // missed reset: the latest scheduled moment in the past 24h that is newer than the last reset/stat start
    let lastDue = 0;
    mins.forEach((m) => { [0, -1].forEach((o) => { const t = zexArAt(m, o); if (t <= now && t > lastDue) lastDue = t; }); });
    const since = Math.max(Number(d.zenAgentAutoResetLast) || 0, Number((d.zenAgentStats || {}).since) || 0);
    if (lastDue && lastDue > since) await zexArDoReset(lastDue);
    let next = Infinity;
    mins.forEach((m) => { [0, 1].forEach((o) => { const t = zexArAt(m, o); if (t > now + 500 && t < next) next = t; }); });
    if (next !== Infinity) chrome.alarms.create(ZEX_AR_ALARM, { when: next });
  } catch (e) {}
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm || alarm.name !== ZEX_AR_ALARM) return;
  try { await zexArDoReset(Date.now()); } catch (e) {}
  zexArSchedule();
});
chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.zenAgentAutoReset) zexArSchedule(); });
chrome.runtime.onStartup.addListener(zexArSchedule);
chrome.runtime.onInstalled.addListener(zexArSchedule);
zexArSchedule();   // service worker woke up → make sure the alarm exists


// ══════════════════════════════════════════════════════════════
//  DAILY SUMMARY — every reply result (ok / failed, per engine, error text) is added to today's row, independent of
//  the Agent counters (so Reset / Auto Reset never loses it). Storage: zenAgentDayLog = { 'YYYY-MM-DD': { ok, fail, posted, by:{ENG:{ok,fail}}, err:{text:n} } } (last 90 days).
//  Written only here (one queue) so several X tabs can never overwrite each other.
// ══════════════════════════════════════════════════════════════
let _zexDayQ = Promise.resolve();
function zexDayKey(ts, startMin) {
  // custom day start (zexDayStartMin, minutes after midnight): 06:00 -> a day runs 06:00 to 06:00
  const d = new Date((ts || Date.now()) - (Number(startMin) || 0) * 60000);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function zexDayTick(m) {
  _zexDayQ = _zexDayQ.then(async () => {
    try {
      const d = await chrome.storage.local.get(['zenAgentDayLog', 'zexDayStartMin']);
      const log = (d.zenAgentDayLog && typeof d.zenAgentDayLog === 'object') ? d.zenAgentDayLog : {};
      const k = zexDayKey(0, d.zexDayStartMin);
      const row = log[k] || (log[k] = { ok: 0, fail: 0, posted: 0, by: {}, err: {} });
      const eng = String(m.eng || 'OTHER').slice(0, 8).toUpperCase();
      const b = row.by[eng] || (row.by[eng] = { ok: 0, fail: 0 });
      if (m.ok) { row.ok++; b.ok++; if (m.posted) row.posted++; }
      else {
        row.fail++; b.fail++;
        const t = String(m.err || 'Unknown error').replace(/\d{6,}/g, '#').slice(0, 60);
        row.err[t] = (row.err[t] || 0) + 1;
        const ek = Object.keys(row.err);
        if (ek.length > 25) { ek.sort((a, c) => row.err[a] - row.err[c]).slice(0, ek.length - 25).forEach((x) => delete row.err[x]); }
      }
      const keys = Object.keys(log).sort();
      if (keys.length > 90) keys.slice(0, keys.length - 90).forEach((x) => delete log[x]);
      await chrome.storage.local.set({ zenAgentDayLog: log });
    } catch (e) {}
  });
}


// ── DEBUG LOG — ring buffer of "[Z EX]" console lines from every tab (+ this worker). Storage: zexDebugLog (last 500). Exported from the System tab. ──
let _zexLogQ = Promise.resolve();
function zexLogPush(lines) {
  if (!Array.isArray(lines) || !lines.length) return;
  _zexLogQ = _zexLogQ.then(async () => {
    try {
      const d = await chrome.storage.local.get(['zexDebugLog']);
      const arr = Array.isArray(d.zexDebugLog) ? d.zexDebugLog : [];
      lines.slice(0, 60).forEach((x) => { if (x && typeof x.m === 'string') arr.push({ t: Number(x.t) || Date.now(), l: String(x.l || 'log').slice(0, 5), p: String(x.p || '').slice(0, 48), m: x.m.slice(0, 320) }); });
      await chrome.storage.local.set({ zexDebugLog: arr.slice(-500) });
    } catch (e) {}
  });
}
(function () {
  try {
    ['log', 'info', 'warn', 'error'].forEach((lv) => {
      const orig = console[lv];
      console[lv] = function () {
        try {
          const a0 = arguments[0];
          if (typeof a0 === 'string' && a0.indexOf('[Z EX]') === 0) zexLogPush([{ t: Date.now(), l: lv, p: 'background', m: Array.prototype.map.call(arguments, (v) => { try { return typeof v === 'string' ? v : JSON.stringify(v); } catch (e) { return String(v); } }).join(' ') }]);
        } catch (e) {}
        return orig.apply(this, arguments);
      };
    });
  } catch (e) {}
})();

// ── ALARM SETUP ──
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(BG_ALARM_NAME, { periodInMinutes: BG_CHECK_INTERVAL_MIN });
  applyStoredProxyConfig();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(BG_ALARM_NAME, { periodInMinutes: BG_CHECK_INTERVAL_MIN });
  applyStoredProxyConfig();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === BG_ALARM_NAME) bgRunCheck();
});

// ══════════════════════════════════════════════════════════════
//  OPTIONAL PROXY — lets a user route their own browser traffic through
//  a proxy they configure (Proxy tab in the popup), so they don't have
//  to separately open a VPN app every time a site is slow/unreachable
//  from their network. This only ever applies a proxy the user typed in
//  themselves; it has nothing to do with, and is not read by, any of the
//  Auto Mode engines above.
//  Storage key: zenProxyConfig = { enabled, scheme, host, port, username, password }
// ══════════════════════════════════════════════════════════════

function applyStoredProxyConfig() {
  chrome.storage.local.get(['zenProxyConfig'], (data) => {
    setProxyFromConfig(data.zenProxyConfig || null);
  });
}

function setProxyFromConfig(cfg) {
  if (!cfg || !cfg.enabled || !cfg.host || !cfg.port) {
    chrome.proxy.settings.clear({ scope: 'regular' });
    return;
  }
  const scheme = cfg.scheme || 'http';
  const pacScheme = scheme === 'socks5' ? 'SOCKS5' : (scheme === 'https' ? 'HTTPS' : 'PROXY');
  const proxyConfig = {
    mode: 'fixed_servers',
    rules: {
      singleProxy: { scheme, host: cfg.host, port: parseInt(cfg.port, 10) },
      bypassList: ['localhost', '127.0.0.1']
    }
  };
  chrome.proxy.settings.set({ value: proxyConfig, scope: 'regular' }, () => {
    if (chrome.runtime.lastError) console.warn('[Z EX] Proxy apply failed:', chrome.runtime.lastError.message);
  });
}

// Supplies saved username/password only when the auth challenge is the
// proxy itself (isProxy), never for a site login prompt.
chrome.webRequest.onAuthRequired.addListener(
  (details, callback) => {
    if (!details.isProxy) { callback({}); return; }
    chrome.storage.local.get(['zenProxyConfig'], (data) => {
      const cfg = data.zenProxyConfig;
      if (cfg && cfg.enabled && cfg.username) {
        callback({ authCredentials: { username: cfg.username, password: cfg.password || '' } });
      } else {
        callback({});
      }
    });
  },
  { urls: ['<all_urls>'] },
  ['asyncBlocking']
);

// ══════════════════════════════════════════════════════════════
//  SESSION AUTO MODE — per-session engage loop.
//  Storage key: zSessAutoJobs = { [sessionPath]: jobObject }
//  Each job is fully independent — starting Auto Mode on one session
//  card never touches any other session's job. Runs from the service
//  worker, so it continues even if the popup is closed. Reuses one tab
//  per job (created once, navigated repeatedly) rather than opening a
//  new tab per link.
//
//  jobObject = {
//    sessionPath, sessionLabel, likeOn, myUsername,
//    queue: [{username, xUrl}],   // links left to process, in order
//    currentIndex: number,
//    tabId: number|null,
//    status: 'idle'|'navigating'|'working'|'done'|'stopped',
//    startedAt: number
//  }
// ══════════════════════════════════════════════════════════════

async function getAutoJobs() {
  const d = await chrome.storage.local.get(['zSessAutoJobs']);
  return d.zSessAutoJobs || {};
}
async function setAutoJobs(jobs) {
  await chrome.storage.local.set({ zSessAutoJobs: jobs });
}
async function getAutoJob(sessionPath) {
  const jobs = await getAutoJobs();
  return jobs[sessionPath] || null;
}
async function setAutoJob(sessionPath, job) {
  const jobs = await getAutoJobs();
  jobs[sessionPath] = job;
  await setAutoJobs(jobs);
}
async function removeAutoJob(sessionPath) {
  const jobs = await getAutoJobs();
  delete jobs[sessionPath];
  await setAutoJobs(jobs);
}

// Start (or restart) Auto Mode for one session. Called from the popup
// (Activity tab toggle) via chrome.runtime.sendMessage.
async function startSessionAutoMode(sessionPath, sessionLabel, likeOn, myUsername, links, engageEndTs) {
  const queue = (links || []).filter(l => l && l.xUrl && (l.username || '').toLowerCase() !== (myUsername || '').toLowerCase());
  if (!queue.length) return { ok: false, reason: 'no_links' };

  const job = {
    sessionPath, sessionLabel: sessionLabel || sessionPath, likeOn: !!likeOn, myUsername: (myUsername || '').toLowerCase(),
    queue, currentIndex: 0, tabId: null, status: 'idle', startedAt: Date.now(),
    engageEndTs: typeof engageEndTs === 'number' ? engageEndTs : null,
  };
  await setAutoJob(sessionPath, job);
  await advanceAutoJob(sessionPath);
  return { ok: true };
}

async function stopSessionAutoMode(sessionPath) {
  const job = await getAutoJob(sessionPath);
  if (job) {
    job.status = 'stopped';
    await setAutoJob(sessionPath, job);
  }
  await removeAutoJob(sessionPath);
  return { ok: true };
}

// Dashboard PAUSE / RESUME: unlike Stop (which deletes the job), Pause keeps the queue + position,
// so Resume continues from the same link. Result reports for a paused job are ignored (status 'stopped').
async function pauseSessionAutoMode(sessionPath) {
  const job = await getAutoJob(sessionPath);
  if (!job || job.status === 'done' || job.status === 'stopped') return { ok: false, reason: 'not_running' };
  job.status = 'stopped';
  job.paused = true;
  await setAutoJob(sessionPath, job);
  try { chrome.alarms.clear(ZEX_SWEEP_STALL_ALARM); } catch (e) {}
  try { await chrome.storage.local.remove('zSessAutoPending'); } catch (e) {}
  return { ok: true };
}
async function resumeSessionAutoMode(sessionPath) {
  const job = await getAutoJob(sessionPath);
  if (!job || !job.paused || !job.queue || job.currentIndex >= job.queue.length) return { ok: false, reason: 'nothing_to_resume' };
  const busy = await tgBusyReason(sessionPath);
  if (busy) return { ok: false, reason: busy };
  job.status = 'idle';
  delete job.paused;
  await setAutoJob(sessionPath, job);
  advanceAutoJob(sessionPath);
  return { ok: true };
}

// Navigates the job's tab to the current queue item and marks it "working".
// content.js (on that tab) picks up the pending job for its own URL and
// runs the like+reply flow, then reports back via chrome.storage (see
// chrome.storage.onChanged listener below) which triggers the next advance.

// ── Sweep: WHY a link failed (shown next to FAILED in the Link Checker) + auto retry settings ──
// zexFailWhy = { <statusId>: { why, ts } }; cleared when the link finally succeeds / is skipped.
let _zexWhyQ = Promise.resolve();
function zexFailWhySet(link, why) {
  const id = tgTweetId(link);
  if (!id) return;
  _zexWhyQ = _zexWhyQ.then(async () => {
    try {
      const d = await chrome.storage.local.get(['zexFailWhy']);
      const m = (d.zexFailWhy && typeof d.zexFailWhy === 'object') ? d.zexFailWhy : {};
      if (why) m[id] = { why: String(why).slice(0, 80), ts: Date.now() }; else delete m[id];
      const ks = Object.keys(m);
      if (ks.length > 3000) ks.sort((a, b) => (m[a].ts || 0) - (m[b].ts || 0)).slice(0, ks.length - 3000).forEach((k) => delete m[k]);
      await chrome.storage.local.set({ zexFailWhy: m });
    } catch (e) {}
  });
}
// Auto retry: after a Sweep finishes, links that failed are run again (max N rounds). Stored in zenSweepAutoRetry = { on, max }.
async function zexAutoRetryCfg() {
  try {
    const d = await chrome.storage.local.get(['zenSweepAutoRetry']);
    const c = d.zenSweepAutoRetry || {};
    const max = Math.min(3, Math.max(1, Math.floor(Number(c.max) || 2)));
    return { on: c.on !== false, max };
  } catch (e) { return { on: true, max: 2 }; }
}

async function advanceAutoJob(sessionPath) {
  const job = await getAutoJob(sessionPath);
  if (!job || job.status === 'stopped') return;

  if (job.currentIndex >= job.queue.length) {
    // Sweep auto retry: links that FAILED in this round get another round (max N), after a short pause.
    if (sessionPath === ZEN_TG_SWEEP_PATH) {
      try {
        const rt = await zexAutoRetryCfg();
        const fl = Array.isArray(job.failedUrls) ? job.failedUrls : [];
        if (rt.on && fl.length && (job.retryRound || 0) < rt.max) {
          if (!job.fullQueue) job.fullQueue = job.queue.slice();
          job.retryRound = (job.retryRound || 0) + 1;
          job.queue = fl.map((u) => ({ xUrl: u, username: '' }));
          job.failedUrls = [];
          job.currentIndex = 0;
          job.status = 'idle';
          await setAutoJob(sessionPath, job);
          await zexRetryPrep(job.queue.map((it) => tgTweetId(it.xUrl)));
          setTimeout(() => advanceAutoJob(sessionPath), 40000 + Math.random() * 30000);
          return;
        }
      } catch (e) {}
    }
    // Loop complete — auto-off.
    job.status = 'done';
    await setAutoJob(sessionPath, job);
    if (sessionPath === ZEN_TG_SWEEP_PATH) ztx({ type: 'job_end', name: 'TG SWEEP', why: 'All links done' });
    if (sessionPath === ZEN_TG_SWEEP_PATH) {
      try {
        const _d = await chrome.storage.local.get(['zenTgSweepDone']);
        const dm = (_d.zenTgSweepDone && typeof _d.zenTgSweepDone === 'object') ? _d.zenTgSweepDone : {};
        for (const it of (job.fullQueue || job.queue)) delete dm[tgTweetId(it.xUrl)];   // finished the whole list → next run starts fresh
        await chrome.storage.local.set({ zenTgSweepDone: dm });
      } catch (e) {}
    }
    await bgNotify('✅ Auto Mode Complete', `Finished engaging all links for ${job.sessionLabel}.`);
    setTimeout(() => removeAutoJob(sessionPath), 4000); // brief grace period so UI can show "done" before it disappears
    return;
  }

  const item = job.queue[job.currentIndex];
  if (sessionPath === ZEN_TG_SWEEP_PATH) ztx({ type: 'tg_link', name: 'SWEEP', link: item.xUrl, h: tgLinkUser(item.xUrl) ? '@' + tgLinkUser(item.xUrl) : '', n: job.currentIndex + 1 });
  job.status = 'navigating';
  job.navAt = Date.now();
  await setAutoJob(sessionPath, job);
  // Telegram Sweep: per-link safety net (works even if the page never loads our script) — see zexSweepStallCheck.
  if (sessionPath === ZEN_TG_SWEEP_PATH) { try { chrome.alarms.create(ZEX_SWEEP_STALL_ALARM, { when: Date.now() + 70000 }); } catch (e) {} }

  try {
    if (job.tabId != null) {
      // Reuse the existing tab — verify it still exists first.
      try {
        await chrome.tabs.get(job.tabId);
        await chrome.tabs.update(job.tabId, { url: item.xUrl, active: false });
      } catch (e) {
        // Tab was closed by the user — open a fresh one.
        const tab = await chrome.tabs.create({ url: item.xUrl, active: false });
        job.tabId = tab.id;
      }
    } else {
      const tab = await chrome.tabs.create({ url: item.xUrl, active: false });
      job.tabId = tab.id;
    }
  } catch (e) {
    // Navigation failed entirely — skip this link and move on.
    job.currentIndex++;
    await setAutoJob(sessionPath, job);
    setTimeout(() => advanceAutoJob(sessionPath), 1000);
    return;
  }

  await setAutoJob(sessionPath, job);

  // Tell content.js (once the tab finishes loading this URL) to run the
  // engage flow for this specific job. content.js self-identifies via
  // zSessAutoPending, matching its own location.href against targetUrl.
  await chrome.storage.local.set({
    zSessAutoPending: {
      sessionPath, targetUrl: item.xUrl, targetUsername: item.username,
      myUsername: job.myUsername, engageEndTs: job.engageEndTs,
      likeOn: job.likeOn, likeDraw: sessionPath === ZEN_TG_SWEEP_PATH ? await tgLikeDraw(job.likeOn) : undefined, issuedAt: Date.now(),
    },
  });
}

const _zexResultSeen = new Set();
const ZEX_SWEEP_STALL_ALARM = 'zexSweepStall';
// Telegram Sweep: a link that is still "navigating" 60s after we opened it (page blocked, script not loaded, tab crashed…)
// is counted as failed and the sweep moves on. Breaks/gaps are safe: after a result the status is 'working', not 'navigating'.
async function zexSweepStallCheck() {
  try {
    const job = await getAutoJob(ZEN_TG_SWEEP_PATH);
    if (!job || job.status !== 'navigating' || !job.navAt || Date.now() - job.navAt < 60000) return;
    const cur = job.queue[job.currentIndex];
    if (cur) ztx({ type: 'tg_done', name: 'SWEEP', why: 'fail', link: cur.xUrl, h: tgLinkUser(cur.xUrl) ? '@' + tgLinkUser(cur.xUrl) : '' });
    if (cur) {
      try {
        const _d = await chrome.storage.local.get(['zenTgSweepDone']);
        const dm = (_d.zenTgSweepDone && typeof _d.zenTgSweepDone === 'object') ? _d.zenTgSweepDone : {};
        dm[tgTweetId(cur.xUrl)] = Date.now();
        await chrome.storage.local.set({ zenTgSweepDone: dm });
        zexErrFileAdd(cur.xUrl);
        zexFailWhySet(cur.xUrl, 'Page never loaded / script did not start (70s)');
        job.failedUrls = Array.isArray(job.failedUrls) ? job.failedUrls : [];
        if (job.failedUrls.indexOf(cur.xUrl) < 0) job.failedUrls.push(cur.xUrl);
        const _sid = String(tgTweetId(cur.xUrl) || '');
        const _z = await chrome.storage.local.get(['zl_' + _sid, 'zenSkipLog']);
        if (_sid && !_z['zl_' + _sid]) {
          const log = Array.isArray(_z.zenSkipLog) ? _z.zenSkipLog : [];
          if (!log.some((x) => x && x.sid === _sid && x.reason === 'failed')) {
            log.unshift({ sid: _sid, link: cur.xUrl, author: '', by: '', cur: 'TG', reason: 'failed', prevReply: '', ts: Date.now() });
            await chrome.storage.local.set({ zenSkipLog: log.slice(0, 300) });
          }
        }
      } catch (e) {}
    }
    job.currentIndex++;
    job.status = 'working';
    await setAutoJob(ZEN_TG_SWEEP_PATH, job);
    advanceAutoJob(ZEN_TG_SWEEP_PATH);
  } catch (e) {}
}
chrome.alarms.onAlarm.addListener((alarm) => { if (alarm && alarm.name === ZEX_SWEEP_STALL_ALARM) zexSweepStallCheck(); });

// content.js reports outcome by writing zSessAutoResult = {sessionPath, targetUrl, ok, ts}
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== 'local') return;
  if (changes.zSessAutoResult) {
    const result = changes.zSessAutoResult.newValue;
    if (!result || !result.sessionPath) return;
    const job = await getAutoJob(result.sessionPath);
    if (!job || job.status === 'stopped') return;
    // Only advance if this result matches the link we're currently waiting on
    // (guards against a stale/duplicate report advancing the queue twice).
    const current = job.queue[job.currentIndex];
    if (!current || current.xUrl !== result.targetUrl) return;
    // Same link reported twice (two events racing before the first one moved the index) → advance only once.
    const _dk = result.sessionPath + '|' + (job.retryRound || 0) + '|' + job.currentIndex + '|' + result.targetUrl;
    if (_zexResultSeen.has(_dk)) return;
    _zexResultSeen.add(_dk);
    if (_zexResultSeen.size > 200) _zexResultSeen.delete(_zexResultSeen.values().next().value);
    if (result.sessionPath === ZEN_TG_SWEEP_PATH && !result.skipped) ztx({ type: 'tg_done', name: 'SWEEP', why: result.ok ? 'ok' : 'fail', link: result.targetUrl, h: tgLinkUser(result.targetUrl) ? '@' + tgLinkUser(result.targetUrl) : '' });

    // Telegram Sweep: remember this link as done (saved immediately), so a later run resumes after it.
    if (result.sessionPath === ZEN_TG_SWEEP_PATH) {
      const _d = await chrome.storage.local.get(['zenTgSweepDone']);
      const dm = (_d.zenTgSweepDone && typeof _d.zenTgSweepDone === 'object') ? _d.zenTgSweepDone : {};
      dm[tgTweetId(result.targetUrl)] = Date.now();
      const ks = Object.keys(dm);
      if (ks.length > 20000) ks.sort((a, b) => dm[a] - dm[b]).slice(0, ks.length - 20000).forEach((k) => delete dm[k]);
      await chrome.storage.local.set({ zenTgSweepDone: dm });
      if (result.ok || result.skipped) zexErrFileRemove(result.targetUrl);
    }

    if (result.sessionPath === ZEN_TG_SWEEP_PATH) {
      if (!result.ok && !result.skipped) {
        zexFailWhySet(result.targetUrl, result.why || 'Unknown error');
        job.failedUrls = Array.isArray(job.failedUrls) ? job.failedUrls : [];
        if (job.failedUrls.indexOf(result.targetUrl) < 0) job.failedUrls.push(result.targetUrl);
      } else zexFailWhySet(result.targetUrl, '');
    }
    job.currentIndex++;
    job.status = 'working';
    // Timing page (Advanced): Sweep uses the Telegram gap + break, same as Group Engage.
    let advBreakSec = null;
    const advSw = result.sessionPath === ZEN_TG_SWEEP_PATH ? await zexAdvTg() : null;
    if (advSw && result.ok && !result.skipped) {
      job.sinceBreak = (job.sinceBreak || 0) + 1;
      const e = Math.floor(Number(advSw.breakEvery) || 0);
      if (e > 0 && job.sinceBreak >= e) { job.sinceBreak = 0; advBreakSec = tgRand(advSw.breakLen[0], advSw.breakLen[1]); }
    }
    await setAutoJob(result.sessionPath, job);

    // Auto-Stop Limit: count TG Sweep links actually engaged (skipped ones don't count)
    if (result.sessionPath === ZEN_TG_SWEEP_PATH && result.ok && !result.skipped && typeof zlimTick === 'function') {
      const lim = await zlimTick('tgSweep');
      if (lim && lim.tripped) return; // limit reached — sweep job already stopped
    }

    // Use user-configured delay if set (zenTgSweepDelayMin/Max), else default
    const delCfg = await chrome.storage.local.get(['zenTgSweepDelayMin','zenTgSweepDelayMax']);
    const delMin = ((delCfg.zenTgSweepDelayMin || 30) * 1000);
    const delMax = ((delCfg.zenTgSweepDelayMax || 60) * 1000);
    let delay  = delMin + Math.random() * Math.max(0, delMax - delMin);
    if (advSw) delay = tgRand(advSw.next[0], advSw.next[1]) * 1000;
    if (advBreakSec != null) delay = advBreakSec * 1000;
    if (result.skipped) delay = (advSw && advSw.flash) ? 300 : 1500 + Math.random() * 1500;   // already engaged by some engine — no need to wait
    setTimeout(() => advanceAutoJob(result.sessionPath), delay);
  }
});

// ══════════════════════════════════════════════════════════════
//  FOLLOW ENGINE — background job queue.
//  Storage key: zFollowJob = jobObject (single job — only one Follow run
//  active at a time, unlike session jobs which are per-sessionPath).
//
//  jobObject = {
//    queue: [username],       // full list, in order, as typed/imported
//    currentIndex: number,    // pointer into queue — resumes from here
//    followed: [username],    // usernames confirmed followed (persists across restarts)
//    failed: [username],      // usernames that errored (skipped, not retried automatically)
//    tabId: number|null,
//    status: 'idle'|'navigating'|'working'|'paused'|'done'|'stopped',
//    minGapMs, maxGapMs,      // random wait range between one follow finishing and the next starting
//    startedAt: number
//  }
//
//  Resuming: currentIndex + followed/failed are persisted to
//  chrome.storage.local on every step, so closing the popup, closing the
//  tab, or restarting the browser and calling followEngineStart() again
//  with the SAME queue simply continues from currentIndex — usernames
//  already in `followed` are skipped even if they reappear in a fresh
//  paste/import, since the popup filters against the stored list too.
// ══════════════════════════════════════════════════════════════

const FOLLOW_STALL_MS = 45000; // if a step takes longer than this, skip it and move on

async function getFollowJob() {
  const d = await chrome.storage.local.get(['zFollowJob']);
  return d.zFollowJob || null;
}
async function setFollowJob(job) {
  await chrome.storage.local.set({ zFollowJob: job });
}

// Starts a fresh run, or — if usernames is omitted/empty and a job already
// exists — resumes the existing job exactly where it left off.
async function followEngineStart(usernames, minGapMs, maxGapMs) {
  let job = await getFollowJob();
  const gap = {
    minGapMs: (typeof minGapMs === 'number' && minGapMs > 0) ? minGapMs : (job && job.minGapMs) || 120000,
    maxGapMs: (typeof maxGapMs === 'number' && maxGapMs > 0) ? maxGapMs : (job && job.maxGapMs) || 240000,
  };

  if (usernames && usernames.length) {
    const already = job ? new Set((job.followed || [])) : new Set();
    // Merge: keep prior progress, append any genuinely new usernames not
    // already followed and not already in the queue.
    const existingQueueSet = job ? new Set(job.queue) : new Set();
    const newOnes = usernames.filter(u => !already.has(u) && !existingQueueSet.has(u));
    if (job && job.status !== 'stopped' && job.status !== 'done') {
      job.queue = job.queue.concat(newOnes);
      job.minGapMs = gap.minGapMs;
      job.maxGapMs = gap.maxGapMs;
    } else {
      job = {
        queue: usernames.filter(u => !already.has(u)),
        currentIndex: 0,
        followed: job ? (job.followed || []) : [],
        failed: job ? (job.failed || []) : [],
        tabId: null, status: 'idle', startedAt: Date.now(),
        minGapMs: gap.minGapMs, maxGapMs: gap.maxGapMs,
      };
    }
  } else if (job) {
    job.minGapMs = gap.minGapMs;
    job.maxGapMs = gap.maxGapMs;
  }

  if (!job || !job.queue || job.currentIndex >= job.queue.length) {
    return { ok: false, reason: 'no_targets', job };
  }

  job.status = 'idle';
  await setFollowJob(job);
  followEngineAdvance();
  return { ok: true, job };
}

async function followEngineStop() {
  const job = await getFollowJob();
  if (job) { job.status = 'stopped'; await setFollowJob(job); }
  return { ok: true };
}

async function followEngineAdvance() {
  const job = await getFollowJob();
  if (!job || job.status === 'stopped') return;

  if (job.currentIndex >= job.queue.length) {
    job.status = 'done';
    await setFollowJob(job);
    await bgNotify('✅ Follow Engine Complete', `Finished going through the list — ${(job.followed || []).length} followed total.`);
    return;
  }

  const username = job.queue[job.currentIndex];

  // Already followed in a prior run, or already in my Following list (People DB) — skip without opening a tab.
  if ((job.followed || []).includes(username) || await zexPeopleIsFollowing(username)) {
    job.currentIndex++;
    await setFollowJob(job);
    setTimeout(followEngineAdvance, 50);
    return;
  }

  const url = `https://x.com/${username}`;
  job.status = 'navigating';
  await setFollowJob(job);

  try {
    if (job.tabId != null) {
      try {
        await chrome.tabs.get(job.tabId);
        await chrome.tabs.update(job.tabId, { url, active: false });
      } catch (e) {
        const tab = await chrome.tabs.create({ url, active: false });
        job.tabId = tab.id;
      }
    } else {
      const tab = await chrome.tabs.create({ url, active: false });
      job.tabId = tab.id;
    }
  } catch (e) {
    job.failed = (job.failed || []).concat([username]);
    job.currentIndex++;
    await setFollowJob(job);
    setTimeout(followEngineAdvance, 1000);
    return;
  }

  await setFollowJob(job);

  await chrome.storage.local.set({
    zFollowPending: { username, targetUrl: url, issuedAt: Date.now() },
  });
}

// content.js reports outcome by writing zFollowResult = {username, ok, ts}
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== 'local') return;
  if (changes.zFollowResult) {
    const result = changes.zFollowResult.newValue;
    if (!result || !result.username) return;
    const job = await getFollowJob();
    if (!job || job.status === 'stopped') return;
    const current = job.queue[job.currentIndex];
    if (current !== result.username) return; // stale/duplicate report

    if (result.ok) {
      job.followed = (job.followed || []).concat([result.username]);
      zexPeopleMarkFollowed(result.username);
    } else {
      job.failed = (job.failed || []).concat([result.username]);
    }
    job.currentIndex++;
    job.status = 'working';
    await setFollowJob(job);
    // Auto-Stop Limit: count real new follows only (not "already following")
    if (result.ok && !result.already && typeof zlimTick === 'function') {
      const lim = await zlimTick('follow');
      if (lim && lim.tripped) return; // limit reached — followEngineStop() already ran
    }
    const minGap = job.minGapMs || 120000;
    const maxGap = job.maxGapMs || 240000;
    const gap = minGap + Math.random() * Math.max(0, maxGap - minGap);
    setTimeout(followEngineAdvance, gap); // human-like gap between follows, per user's speed setting
  }
});

// Stall guard — if a tab never reports back (page stuck, follow button
// never appeared, etc), skip it after FOLLOW_STALL_MS so the loop never
// gets permanently stuck.
setInterval(async () => {
  const job = await getFollowJob();
  if (!job || job.status !== 'navigating') return;
  if (Date.now() - (job.startedAt || 0) < FOLLOW_STALL_MS) {} // no-op, startedAt is run-start not step-start
  const pendingD = await chrome.storage.local.get(['zFollowPending']);
  const pending = pendingD.zFollowPending;
  if (pending && Date.now() - (pending.issuedAt || 0) > FOLLOW_STALL_MS) {
    job.failed = (job.failed || []).concat([job.queue[job.currentIndex]]);
    job.currentIndex++;
    job.status = 'working';
    await setFollowJob(job);
    setTimeout(followEngineAdvance, 1000);
  }
}, 10000);

// ══════════════════════════════════════════════════════════════
//  TELEGRAM GROUP ENGAGE + LINK SWEEP
//
//  telegram.js (on web.telegram.org) drives the Telegram side and talks to
//  this file. Both features reuse the engine Z EX already has for engaging
//  a single X post — content.js's sessAutoCheckPending/sessAutoRunEngageFlow
//  (open post → reply box → AI reply with your tone/style → post → optional
//  like). We only tell it which link to visit, via zSessAutoPending, and hear
//  back through zSessAutoResult.
//
//  GROUP ENGAGE (dynamic — next link is found live in the Telegram chat):
//    zenTgActive = {
//      running, phase: 'FIND_START'|'FIND_NEXT'|'IDLE_X',
//      targetLink, endLink, currentUrl, tgTabId, xTabId,
//      engagedLinks: [tweetId], startMid, lastMid, anchorId, reachedEnd,
//      engagedCount, skippedCount, failedCount, doneCount,
//      sinceBreak, totalReplies, breakLabel, breakUntil, waitStartedAt, updatedAt
//    }
//    Loop: FIND_START/FIND_NEXT (Telegram reacts) → IDLE_X (X engages) →
//          result → pacing gap/break → FIND_NEXT …  until endLink or Stop.
//
//  LINK SWEEP (bulk — telegram.js collects every link, then we hand the whole
//  list to the existing queue runner, startSessionAutoMode):
//    zenTgSweepArmed, zenTgSweepState = {phase, collected}
// ══════════════════════════════════════════════════════════════
const ZEN_TG_ENGAGE_PATH = 'telegram_engage';
const ZEN_TG_SWEEP_PATH  = 'telegram_sweep';
const ZEN_TG_WATCHDOG    = 'zenTgWatchdog';
const TG_WAIT_TIMEOUT_MS = 600000;   // give up after 10 min with no new link in the chat
const TG_IDLE_X_TIMEOUT_MS = 180000; // X never reported back for this long → count as failed
const TG_GAP_MIN_SEC = 8;            // pause between two engaged links
const TG_GAP_MAX_SEC = 20;
const TG_BREAK_EVERY = 5;            // longer break after this many successful replies
const TG_BREAK_MIN_SEC = 60;
const TG_BREAK_MAX_SEC = 120;
const TG_MAX_CONSEC_FAIL = 5;        // stop the run after this many failed links in a row

function tgRand(a, b) { return Math.floor(a + Math.random() * (b - a + 1)); }
// Timing page (Advanced): Telegram numbers the popup resolved, or null in Classic mode.
async function zexAdvTg() {
  try {
    const r = (await chrome.storage.local.get(['zexTimingResolved'])).zexTimingResolved;
    return (r && r.ui === 'advanced' && r.tg) || null;
  } catch (e) { return null; }
}
// All Group Engage state changes run one at a time. content.js reports a
// finished link twice in a row, and two overlapping handlers would both read
// the same state and double-process it.
let _tgChain = Promise.resolve();
function tgSerial(fn) {
  const p = _tgChain.then(fn, fn);
  _tgChain = p.catch(() => {});
  return p;
}
// zSessAutoPending is a single slot shared with the Session queue, so only one
// per-link engage run can be active at a time.
async function tgBusyReason(exceptPath) {
  const jobs = await getAutoJobs();
  for (const path in (jobs || {})) {
    if (path === exceptPath) continue;
    const j = jobs[path];
    if (j && (j.status === 'navigating' || j.status === 'working' || j.status === 'idle')) return 'queue_busy';
  }
  const a = await tgGetActive();
  if (a && a.running && exceptPath !== ZEN_TG_ENGAGE_PATH) return 'engage_busy';
  return null;
}
function tgTweetId(link) {
  const m = link && String(link).match(/status\/(\d+)/);
  return m ? m[1] : link;
}
async function tgGetActive() {
  const d = await chrome.storage.local.get(['zenTgActive']);
  return d.zenTgActive || null;
}
// The X handle verified in the extension — links to its own posts are never engaged.
async function tgOwnHandle() {
  const d = await chrome.storage.local.get(['zenDeviceSession']);
  const h = d.zenDeviceSession && d.zenDeviceSession.xHandle;
  return h ? String(h).replace(/^@/, '').trim().toLowerCase() : '';
}
function tgLinkUser(link) {
  const m = link && String(link).match(/(?:x\.com|twitter\.com)\/([a-zA-Z0-9_]+)\/status\//i);
  return m ? m[1].toLowerCase() : '';
}
async function tgSessionValid() {
  const d = await chrome.storage.local.get(['zenDeviceSession']);
  const s = d.zenDeviceSession;
  return !!(s && typeof s.expiresAt === 'number' && Date.now() < s.expiresAt);
}
async function tgLikePct() {
  const d = await chrome.storage.local.get(['zenTgLikePct']);
  return typeof d.zenTgLikePct === 'number' ? d.zenTgLikePct : 100;
}
// Telegram posts each open as a fresh page, so the draw is made here (one card per link) and the
// deck lives in storage — fair across the whole run. Same deck rules as zexLikeRoll in content.js.
async function tgLikeDraw(on) {
  try {
    if (!on) return false;
    const c = Math.min(100, Math.max(0, Math.round(await tgLikePct())));
    if (c >= 100) return true;
    if (c <= 0) return false;
    const gcd = (a, b) => (b ? gcd(b, a % b) : a);
    const g = gcd(c, 100); let size = 100 / g, yes = c / g;
    const k = Math.max(1, Math.ceil(20 / size)); size *= k; yes *= k;
    const key = 'zenTgLikeDeck'; const d = await chrome.storage.local.get([key]);
    let deck = d[key] && d[key].pct === c && Array.isArray(d[key].cards) ? d[key].cards : [];
    if (!deck.length) {
      for (let n = 0; n < size; n++) deck.push(n < yes ? 1 : 0);
      for (let n = deck.length - 1; n > 0; n--) { const r = Math.floor(Math.random() * (n + 1)); const t = deck[n]; deck[n] = deck[r]; deck[r] = t; }
    }
    const v = deck.pop() === 1;
    await chrome.storage.local.set({ [key]: { pct: c, cards: deck } });
    return v;
  } catch (e) { return true; }
}
async function tgLikeOn() {
  const d = await chrome.storage.local.get(['zenTgLikeOn']);
  return d.zenTgLikeOn === true;
}
async function tgFocusTab(tabId) {
  if (tabId == null) return;
  try {
    const t = await chrome.tabs.get(tabId);
    await chrome.tabs.update(tabId, { active: true });
    if (t.windowId != null) await chrome.windows.update(t.windowId, { focused: true });
  } catch (e) {}
}

// Finds (or opens) the Telegram Web tab and makes sure telegram.js is alive in
// it — a tab opened before the extension was installed/reloaded needs a reload.
async function tgEnsureTelegramTab() {
  const tabs = await chrome.tabs.query({ url: 'https://web.telegram.org/*' });
  if (tabs[0]) {
    await tgFocusTab(tabs[0].id);
    const alive = await new Promise(resolve => {
      try { chrome.tabs.sendMessage(tabs[0].id, { type: 'zenTgPing' }, () => resolve(!chrome.runtime.lastError)); }
      catch (e) { resolve(false); }
    });
    if (!alive) {
      try { await chrome.tabs.reload(tabs[0].id); } catch (e) {}
      await new Promise(r => setTimeout(r, 1500));
    }
    return tabs[0].id;
  }
  const t = await chrome.tabs.create({ url: 'https://web.telegram.org/k/', active: true });
  return t.id;
}

// Popup → "Open Telegram" for Group Engage: shows the floating panel.
async function tgOpenEngagePanel() {
  await tgEnsureTelegramTab();
  await chrome.storage.local.set({ zenTgWidgetArmed: true });
  return { ok: true };
}
// Popup → "Open Telegram" for Link Sweep: shows the sweep panel.
async function tgOpenSweepPanel() {
  await tgEnsureTelegramTab();
  await chrome.storage.local.set({ zenTgSweepArmed: true, zenTgSweepState: { phase: 'idle', collected: [] } });
  return { ok: true };
}


// ── Failed Telegram links → auto Sweep folder (named by group, else Morning/Afternoon/Evening/Night) ──
// Folder shape in zenTgSweepFolders: { id, name, links, createdAt, auto:'tgfail' }.
// After 24h the popup hides these folders; the data stays saved in storage (never deleted here).
function tgFailLabel(group) {
  const now = new Date();
  const day = now.toLocaleDateString([], { day: 'numeric', month: 'short' });
  const g = String(group || '').replace(/\s+/g, ' ').trim();
  if (g) return 'Failed · ' + g.slice(0, 40) + ' · ' + day;
  const h = now.getHours();
  return 'Failed · ' + (h >= 5 && h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : h < 21 ? 'Evening' : 'Night') + ' · ' + day;
}

// ── ⚠ Error file: every link ANY engine could not comment on (FED / SEA / REP / GIV / TAR / TG Engage / TG Sweep) ──
// One permanent Sweep folder { id:'zexerr', auto:'zexerr' }. Run it from the Sweep tab to retry. A link leaves the file
// as soon as it is commented (or turns out deleted / already engaged). Comment-off posts are never added (nothing to retry).
const ZEX_ERRFILE_ID = 'zexerr', ZEX_ERRFILE_NAME = '⚠ Error file', ZEX_ERRFILE_MAX = 1000;
let _zexErrFileQ = Promise.resolve();
function zexErrFileAdd(link) {
  const id = tgTweetId(link);
  if (!link || !id || !/^\d+$/.test(String(id))) return;
  const url = /^https?:\/\//i.test(String(link)) ? String(link) : 'https://x.com/i/status/' + id;
  _zexErrFileQ = _zexErrFileQ.then(async () => {
    try {
      const d = await chrome.storage.local.get(['zenTgSweepFolders', 'zl_' + id]);
      if (Array.isArray(d['zl_' + id])) return;   // done / before ZEX / comment off / deleted → nothing to retry
      const list = Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders.slice() : [];
      let f = list.find((x) => x && x.auto === ZEX_ERRFILE_ID);
      if (!f) { f = { id: ZEX_ERRFILE_ID, name: ZEX_ERRFILE_NAME, links: [], createdAt: Date.now(), auto: ZEX_ERRFILE_ID }; list.unshift(f); }
      f.links = Array.isArray(f.links) ? f.links : [];
      if (f.links.some((u) => tgTweetId(u) === id)) return;
      f.links.push(url);
      if (f.links.length > ZEX_ERRFILE_MAX) f.links = f.links.slice(-ZEX_ERRFILE_MAX);
      await chrome.storage.local.set({ zenTgSweepFolders: list.slice(0, 100) });
    } catch (e) {}
  });
}
function zexErrFileRemove(link) {
  const id = tgTweetId(link);
  if (!link || !id) return;
  _zexErrFileQ = _zexErrFileQ.then(async () => {
    try {
      const d = await chrome.storage.local.get(['zenTgSweepFolders']);
      const list = Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders : null;
      const f = list && list.find((x) => x && x.auto === ZEX_ERRFILE_ID);
      if (!f || !Array.isArray(f.links)) return;
      const keep = f.links.filter((u) => tgTweetId(u) !== id);
      if (keep.length === f.links.length) return;
      f.links = keep;
      await chrome.storage.local.set({ zenTgSweepFolders: list });
    } catch (e) {}
  });
}
let _tgFailQ = Promise.resolve();
function tgSaveFailedLink(s, link) {
  if (!link) return;
  zexErrFileAdd(link);
  const label = (s && s.failLabel) || tgFailLabel(s && s.group);
  const id = tgTweetId(link);
  _tgFailQ = _tgFailQ.then(async () => {
    try {
      const d = await chrome.storage.local.get(['zenTgSweepFolders']);
      const list = Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders.slice() : [];
      let f = list.find((x) => x && x.auto === 'tgfail' && x.name === label);
      if (!f) { f = { id: 'tf' + Date.now().toString(36), name: label, links: [], createdAt: Date.now(), auto: 'tgfail' }; list.unshift(f); }
      f.links = Array.isArray(f.links) ? f.links : [];
      if (f.links.some((u) => tgTweetId(u) === id)) return;
      f.links.push(link);
      await chrome.storage.local.set({ zenTgSweepFolders: list.slice(0, 100) });
    } catch (e) {}
  });
}

async function tgStart(link, endLink, startId, group) {
  if (!link) return { ok: false, reason: 'no_link' };
  if (!(await tgSessionValid())) return { ok: false, reason: 'session' };
  const cur = await tgGetActive();
  if (cur && cur.running) return { ok: false, reason: 'already_running' };   // never overwrite a live run
  const busy = await tgBusyReason(ZEN_TG_ENGAGE_PATH);
  if (busy) return { ok: false, reason: busy };
  const tgTabId = await tgEnsureTelegramTab();
  await chrome.storage.local.set({
    zenTgWidgetArmed: true,
    zenTgActive: {
      running: true, phase: 'FIND_START',
      targetLink: link, endLink: endLink || null, startId: startId || null, reachedEnd: false,
      group: String(group || '').slice(0, 80), failLabel: tgFailLabel(group),
      currentUrl: null, tgTabId, xTabId: null,
      engagedLinks: [], startMid: null, lastMid: null,
      engagedCount: 0, skippedCount: 0, failedCount: 0, doneCount: 0,
      sinceBreak: 0, totalReplies: 0,
      breakLabel: null, breakUntil: null, waitStartedAt: null, updatedAt: Date.now(),
    },
  });
  chrome.alarms.create(ZEN_TG_WATCHDOG, { periodInMinutes: 1 });
  ztx({ type: 'job', name: 'TELEGRAM', src: 'telegram' });
  return { ok: true };
}

// telegram.js reacted to a message that carries `link` → open it on X and hand
// it to the engage engine.
async function tgReacted(link, skipped, mid) {
  const s = await tgGetActive();
  if (!s || !s.running || !link) return { ok: false };
  if (s.phase !== 'FIND_START' && s.phase !== 'FIND_NEXT') return { ok: false, error: 'NOT_SCANNING' };
  { const own = await tgOwnHandle(); if (own && tgLinkUser(link) === own) return { ok: false, error: 'OWN_LINK' }; }

  s.engagedCount += 1;
  s.skippedCount += skipped || 0;
  const id = tgTweetId(link);
  s.engagedLinks = s.engagedLinks || [];
  if (!s.engagedLinks.includes(id)) s.engagedLinks.push(id);
  if (typeof mid === 'number' && Number.isFinite(mid)) {
    if (s.startMid == null) s.startMid = mid;
    // Only ever moves down the chat: the next link must come after this message.
    s.lastMid = (s.lastMid == null) ? mid : Math.max(s.lastMid, mid);
  }
  s.anchorId = id;                       // rolling Start ID: the next link is searched right after this one
  s.phase = 'IDLE_X';
  s.currentUrl = link;
  s.waitStartedAt = null;
  s.breakUntil = null;
  s.reachedEnd = !!s.endLink && tgTweetId(link) === tgTweetId(s.endLink);

  // Show the post in a visible tab — X's DOM only behaves when it's in front.
  let opened = false;
  if (s.xTabId != null) {
    try {
      const t = await chrome.tabs.get(s.xTabId);
      await chrome.tabs.update(s.xTabId, { url: link, active: true });
      if (t.windowId != null) await chrome.windows.update(t.windowId, { focused: true });
      opened = true;
    } catch (e) {}
  }
  if (!opened) {
    const t = await chrome.tabs.create({ url: link, active: true });
    s.xTabId = t.id;
  }

  ztx({ type: 'tg_link', name: 'TELEGRAM', link: link, h: tgLinkUser(link) ? '@' + tgLinkUser(link) : '', n: s.engagedCount });
  s.updatedAt = Date.now();
  await chrome.storage.local.set({
    zenTgActive: s,
    // content.js on that tab picks this up by matching its own URL.
    zSessAutoPending: {
      sessionPath: ZEN_TG_ENGAGE_PATH, targetUrl: link, targetUsername: '',
      myUsername: '', engageEndTs: null, likeOn: await tgLikeOn(), likeDraw: await tgLikeDraw(await tgLikeOn()), issuedAt: Date.now(),
    },
  });
  return { ok: true };
}

// The run's starting link is my own post → don't engage it, continue after it.
async function tgStartOwn(link, mid) {
  const s = await tgGetActive();
  if (!s || !s.running || s.phase !== 'FIND_START') return { ok: false };
  s.engagedLinks = s.engagedLinks || [];
  const id = tgTweetId(link);
  if (!s.engagedLinks.includes(id)) s.engagedLinks.push(id);
  if (typeof mid === 'number' && Number.isFinite(mid)) { s.startMid = mid; s.lastMid = (s.lastMid == null) ? mid : Math.max(s.lastMid, mid); }
  s.anchorId = id;
  s.phase = 'FIND_NEXT';
  s.updatedAt = Date.now();
  await chrome.storage.local.set({ zenTgActive: s });
  return { ok: true };
}
// The end link is my own post → nothing left to engage.
async function tgOwnEnd() {
  const s = await tgGetActive();
  if (!s || !s.running) return { ok: false };
  await tgFinish(s, 'Reached the end link');
  return { ok: true, finished: true };
}

// telegram.js found nothing to do this round.
//   failed:true + link → reacting to that message failed; count it once and skip it.
//   failed:false      → just waiting for a new link to show up in the chat.
async function tgNoLinkFound(failed, link) {
  const s = await tgGetActive();
  if (!s || !s.running) return { ok: false };
  if (failed && link) {
    const id = tgTweetId(link);
    s.engagedLinks = s.engagedLinks || [];
    if (!s.engagedLinks.includes(id)) { s.engagedLinks.push(id); s.failedCount = (s.failedCount || 0) + 1; tgSaveFailedLink(s, link); ztx({ type: 'tg_done', name: 'TELEGRAM', why: 'fail', link: link, h: tgLinkUser(link) ? '@' + tgLinkUser(link) : '' }); }
    s.waitStartedAt = null;
  } else if (!s.waitStartedAt) {
    s.waitStartedAt = Date.now();
  }
  if (s.waitStartedAt && Date.now() - s.waitStartedAt > TG_WAIT_TIMEOUT_MS) {
    await tgFinish(s, 'No new link appeared for 10 minutes');
    return { ok: true, stopped: true };
  }
  s.updatedAt = Date.now();
  await chrome.storage.local.set({ zenTgActive: s });
  return { ok: true };
}

// Closes the X tab Group Engage opened for a link (best effort).
async function tgCloseXTab(s) {
  if (!s || s.xTabId == null) return;
  const id = s.xTabId;
  s.xTabId = null;
  try { await chrome.tabs.remove(id); } catch (e) {}
}

// Result of engaging one link on X (from content.js via zSessAutoResult).
async function tgItemResult(link, ok, skipped) {
  const s = await tgGetActive();
  if (!s || !s.running || s.phase !== 'IDLE_X') return { ok: false };
  if (link && s.currentUrl && tgTweetId(link) !== tgTweetId(s.currentUrl)) return { ok: false };

  await tgCloseXTab(s);   // done with this X post — close its tab
  if (!skipped) ztx({ type: 'tg_done', name: 'TELEGRAM', why: ok ? 'ok' : 'fail', link: s.currentUrl || link, h: tgLinkUser(s.currentUrl || link) ? '@' + tgLinkUser(s.currentUrl || link) : '' });

  if (skipped) { s.skippedCount = (s.skippedCount || 0) + 1; }   // already engaged by an engine — not a reply, not a failure
  else if (ok) { s.doneCount = (s.doneCount || 0) + 1; s.consecFail = 0; }
  else {
    s.failedCount = (s.failedCount || 0) + 1;
    s.consecFail = (s.consecFail || 0) + 1;
    s.failedLinks = (s.failedLinks || []).concat([s.currentUrl]).slice(-50);
    tgSaveFailedLink(s, s.currentUrl || link);
    // Same error over and over (expired session, no API key, X blocking the
    // page…) — stop instead of burning through the whole chat.
    if (s.consecFail >= TG_MAX_CONSEC_FAIL) {
      await tgFinish(s, TG_MAX_CONSEC_FAIL + ' failures in a row — check your login / API key');
      return { ok: true, finished: true };
    }
  }

  if (s.reachedEnd) {
    await tgFinish(s, 'Reached the end link');
    return { ok: true, finished: true };
  }

  let pause;
  if (skipped) { const _af = await zexAdvTg(); pause = { sec: (_af && _af.flash) ? 0 : tgRand(2, 4), label: 'Next in' }; }
  else if (ok) {
    s.sinceBreak = (s.sinceBreak || 0) + 1;
    s.totalReplies = (s.totalReplies || 0) + 1;
    // Break settings come from the popup (zenTgBreak); defaults = the old fixed values. every = 0 → no breaks.
    let bEvery = TG_BREAK_EVERY, bMin = TG_BREAK_MIN_SEC, bMax = TG_BREAK_MAX_SEC;
    try {
      const b = (await chrome.storage.local.get(['zenTgBreak'])).zenTgBreak;
      if (b && typeof b === 'object') {
        const e = Number(b.every), a = Number(b.min), c = Number(b.max);
        if (isFinite(e) && e >= 0) bEvery = Math.floor(e);
        if (isFinite(a) && a >= 0 && isFinite(c) && c >= 0) { bMin = Math.min(a, c); bMax = Math.max(a, c); }
      }
    } catch (e) {}
    const advTg = await zexAdvTg();
    if (advTg) { bEvery = Math.floor(Number(advTg.breakEvery) || 0); bMin = advTg.breakLen[0]; bMax = advTg.breakLen[1]; }
    if (bEvery > 0 && s.sinceBreak >= bEvery) {
      s.sinceBreak = 0;
      pause = { sec: tgRand(bMin, bMax), label: s.totalReplies + ' replies done · break' };
    }
  }
  if (!pause) {
    // User-set gap before the next post (seconds); falls back to the built-in 8–20s.
    let gMin = TG_GAP_MIN_SEC, gMax = TG_GAP_MAX_SEC;
    try {
      const t = (await chrome.storage.local.get(['zenTgTiming'])).zenTgTiming;
      if (t && Array.isArray(t.next)) {
        const a = Number(t.next[0]), c = Number(t.next[1]);
        if (isFinite(a) && isFinite(c) && a >= 0 && c >= 0) { gMin = Math.min(a, c); gMax = Math.max(a, c); }
      }
    } catch (e) {}
    const advTgGap = await zexAdvTg();
    if (advTgGap) { gMin = advTgGap.next[0]; gMax = advTgGap.next[1]; }
    pause = { sec: tgRand(gMin, gMax), label: 'Next in' };
  }

  if (pause.label !== 'Next in') ztx({ type: 'tg_break', name: 'TELEGRAM', n: pause.sec });
  s.phase = 'FIND_NEXT';
  s.currentUrl = null;
  s.breakUntil = Date.now() + pause.sec * 1000;
  s.breakLabel = pause.label;
  s.updatedAt = Date.now();
  await chrome.storage.local.set({ zenTgActive: s });
  await tgFocusTab(s.tgTabId);   // back to Telegram so it can react to the next message
  return { ok: true };
}

// Ends a run, keeping a summary + the last link so the panel can "Continue".
async function tgFinish(s, reason) {
  const last = s && (s.currentUrl || s.targetLink);
  const summary = {
    doneCount: (s && s.doneCount) || 0, skippedCount: (s && s.skippedCount) || 0,
    failedCount: (s && s.failedCount) || 0, reason: reason || '', finishedAt: Date.now(),
  };
  const patch = { zenTgActive: null, zenTgLastRun: summary };
  if (last) patch.zenTgLast = { link: last, endLink: (s && s.endLink) || null, ts: Date.now() };
  await chrome.storage.local.set(patch);
  chrome.alarms.clear(ZEN_TG_WATCHDOG);
  if (s) ztx({ type: 'job_end', name: 'TELEGRAM', why: reason || 'finished' });
  await tgCloseXTab(s);
  if (s && s.tgTabId != null) await tgFocusTab(s.tgTabId);
  await bgNotify('Telegram Engage finished', `${summary.doneCount} replied · ${summary.skippedCount} skipped · ${summary.failedCount} failed${reason ? ' — ' + reason : ''}`);
}

async function tgStop() {
  const s = await tgGetActive();
  if (s) {
    await tgCloseXTab(s);
    const last = s.currentUrl || s.targetLink;
    const patch = {
      zenTgActive: null,
      zenTgLastRun: { doneCount: s.doneCount || 0, skippedCount: s.skippedCount || 0, failedCount: s.failedCount || 0, reason: 'Stopped', finishedAt: Date.now() },
    };
    if (last) patch.zenTgLast = { link: last, endLink: s.endLink || null, ts: Date.now() };
    await chrome.storage.local.set(patch);
    ztx({ type: 'job_end', name: 'TELEGRAM', why: 'Stopped' });
  }
  await chrome.storage.local.set({ zenTgWidgetArmed: false });
  chrome.alarms.clear(ZEN_TG_WATCHDOG);
  return { ok: true };
}

// X page never answered (login wall, blocked, script not loaded…) — count it
// as failed and move on instead of hanging forever.
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ZEN_TG_WATCHDOG) return;
  const s = await tgGetActive();
  if (!s || !s.running) { chrome.alarms.clear(ZEN_TG_WATCHDOG); return; }
  if (s.phase === 'IDLE_X' && Date.now() - (s.updatedAt || 0) > TG_IDLE_X_TIMEOUT_MS) {
    await tgSerial(() => tgItemResult(s.currentUrl, false));
  }
});

// content.js reports every per-link outcome here; only the Group Engage ones
// are ours (Sweep results are handled by the generic queue listener above).
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== 'local' || !changes.zSessAutoResult) return;
  const r = changes.zSessAutoResult.newValue;
  if (!r || r.sessionPath !== ZEN_TG_ENGAGE_PATH) return;
  await tgSerial(() => tgItemResult(r.targetUrl, !!r.ok, !!r.skipped));
});

// ── Link Sweep ──
async function tgSweepProgress(collected, phase) {
  await chrome.storage.local.set({ zenTgSweepState: { phase: phase || 'scanning', collected: collected || [] } });
  return { ok: true };
}
async function tgSweepCancel() {
  await chrome.storage.local.set({ zenTgSweepArmed: false, zenTgSweepState: { phase: 'idle', collected: [] } });
  return { ok: true };
}
// Hands the swept links to the existing queue runner (same engine the Session
// tab uses): opens each one in a background tab, engages it, moves on.
// Link Checker "Retry": forget the failed / comment-off marks of these post IDs so the sweep tries them again.
// (Done and commented-before-ZEX links are never touched.)
async function zexRetryPrep(ids) {
  try {
    ids = (ids || []).map(String).filter(Boolean);
    if (!ids.length) return;
    const keys = ids.map((i) => 'zl_' + i);
    const d = await chrome.storage.local.get(keys.concat(['zenSkipLog', 'zenTgSweepDone']));
    const rm = keys.filter((k) => Array.isArray(d[k]) && d[k][0] === 'o');   // only comment-off entries are removed
    if (rm.length) await chrome.storage.local.remove(rm);
    const set = new Set(ids);
    const log = Array.isArray(d.zenSkipLog) ? d.zenSkipLog : [];
    const dm = (d.zenTgSweepDone && typeof d.zenTgSweepDone === 'object') ? d.zenTgSweepDone : {};
    ids.forEach((i) => { delete dm[i]; });
    await chrome.storage.local.set({
      zenSkipLog: log.filter((x) => !(x && set.has(x.sid) && (x.reason === 'comment_off' || x.reason === 'failed'))),
      zenTgSweepDone: dm,
    });
  } catch (e) { console.warn('[Z EX] retry prep failed', e); }
}
async function tgSweepSend(links, opts) {
  if (!(await tgSessionValid())) return { ok: false, reason: 'session' };
  const busy = await tgBusyReason(ZEN_TG_SWEEP_PATH);
  if (busy) return { ok: false, reason: busy };
  if (opts && Array.isArray(opts.retryIds) && opts.retryIds.length) await zexRetryPrep(opts.retryIds);
  const seen = new Set();
  const items = [];
  const own = await tgOwnHandle();
  const _lists = await chrome.storage.local.get(['zexBlackList', 'zexWhiteList']);
  const _norm = (a) => new Set((Array.isArray(a) ? a : []).map((h) => String(h || '').trim().replace(/^@/, '').toLowerCase()).filter(Boolean));
  const bl = _norm(_lists.zexBlackList), wl = _norm(_lists.zexWhiteList);
  for (const u of links || []) {
    const id = tgTweetId(u);
    if (!u || seen.has(id)) continue;
    if (own && tgLinkUser(u) === own) continue;   // skip my own posts
    if (bl.size && bl.has(tgLinkUser(u) || '')) continue;   // blacklisted account (links with a username; the rest are checked once the post opens)
    seen.add(id);
    items.push({ xUrl: u, username: '' });
  }
  // Whitelist: links of whitelisted accounts go first (stable — everything else keeps its order).
  if (wl.size) {
    const hot = items.filter((it) => wl.has(tgLinkUser(it.xUrl) || ''));
    if (hot.length && hot.length < items.length) { const rest = items.filter((it) => !wl.has(tgLinkUser(it.xUrl) || '')); items.length = 0; hot.concat(rest).forEach((it) => items.push(it)); }
  }
  if (!items.length) return { ok: false, reason: 'no_links' };
  // Resume: links this sweep already finished in an earlier (stopped / interrupted) run are skipped,
  // so a re-run of the same txt folder continues from the next link instead of starting over.
  const _sd = await chrome.storage.local.get(['zenTgSweepDone']);
  const doneMap = (_sd.zenTgSweepDone && typeof _sd.zenTgSweepDone === 'object') ? _sd.zenTgSweepDone : {};
  const total = items.length;
  let fresh = items.filter((it) => !doneMap[tgTweetId(it.xUrl)]);
  let resumed = total - fresh.length;
  if (!fresh.length) {
    // Every link in this list was already finished earlier → run the whole list again from the start.
    for (const it of items) delete doneMap[tgTweetId(it.xUrl)];
    await chrome.storage.local.set({ zenTgSweepDone: doneMap });
    fresh = items.slice(); resumed = 0;
  }
  items.length = 0; fresh.forEach((it) => items.push(it));
  // startSessionAutoMode drops items whose username equals myUsername (to skip
  // your own posts). Sweep links carry no username, so pass a value that can
  // never match and every link is kept.
  const res = await startSessionAutoMode(ZEN_TG_SWEEP_PATH, 'Telegram Sweep', await tgLikeOn(), '__zen_tg_no_filter__', items);
  if (res && res.ok) {
    await chrome.storage.local.set({ zenTgSweepArmed: false, zenTgSweepState: { phase: 'idle', collected: [] } });
    ztx({ type: 'job', name: 'TG SWEEP', src: 'telegram' });
  }
  if (res && res.ok) res.resumed = resumed;
  return res;
}

async function tgStatus() {
  const d = await chrome.storage.local.get(['zenTgActive', 'zenTgWidgetArmed', 'zenTgSweepArmed', 'zenTgLastRun']);
  const job = await getAutoJob(ZEN_TG_SWEEP_PATH);
  return { active: d.zenTgActive || null, armed: !!d.zenTgWidgetArmed, sweepArmed: !!d.zenTgSweepArmed, lastRun: d.zenTgLastRun || null, sweepJob: job };
}

// ══════════════════════════════════════════════════════════════
//  AUTO UNFOLLOW — background side. unfollow.js does the work on the
//  account's Following page; this only validates, opens the tab and keeps
//  the run flag. Storage: zenUnfRun, zenUnfCfg, zenUnfStats.
// ══════════════════════════════════════════════════════════════
const UNF_HARD_LIMIT = 2000;
async function unfStart(raw) {
  if (!(await tgSessionValid())) return { ok: false, reason: 'session' };
  const handle = await tgOwnHandle();
  if (!handle) return { ok: false, reason: 'no_handle' };
  const d = await chrome.storage.local.get(['zenUnfRun']);
  if (d.zenUnfRun) return { ok: false, reason: 'already_running' };
  const num = (v, def, lo, hi) => { v = Number(v); if (!isFinite(v)) v = def; return Math.min(hi, Math.max(lo, Math.floor(v))); };
  const c = raw || {};
  const cfg = {
    handle,
    mode: c.mode === 'all' ? 'all' : 'nonfollowers',
    limit: num(c.limit, 0, 0, UNF_HARD_LIMIT),
    minSec: num(c.minSec, 15, 1, 3600),
    maxSec: num(c.maxSec, 20, 1, 3600),
    breakEvery: num(c.breakEvery, 15, 0, 1000),
    breakSec: num(c.breakSec, 120, 0, 3600),
    tabId: null,
  };
  if (cfg.maxSec < cfg.minSec) { const t = cfg.minSec; cfg.minSec = cfg.maxSec; cfg.maxSec = t; }
  const tab = await chrome.tabs.create({ url: 'https://x.com/' + handle + '/following', active: true });
  cfg.tabId = tab.id;
  await chrome.storage.local.set({
    zenUnfCfg: cfg,
    zenUnfStats: { running: true, unfollowed: 0, skipped: 0, failed: 0, status: 'Opening your Following list…', ts: Date.now() },
    zenUnfRun: true,
  });
  return { ok: true };
}
// ── Following Analysis (Dashboard): scan my Following list into the shared People DB ──
async function zexPeopleStart() {
  if (!(await tgSessionValid())) return { ok: false, reason: 'session' };
  const handle = await tgOwnHandle();
  if (!handle) return { ok: false, reason: 'no_handle' };
  const d = await chrome.storage.local.get(['zexPeopleRun']);
  if (d.zexPeopleRun) return { ok: false, reason: 'already_running' };
  const tab = await chrome.tabs.create({ url: 'https://x.com/' + handle + '/following', active: true });
  await chrome.storage.local.set({
    zexPeopleCfg: { handle: String(handle).toLowerCase(), tabId: tab.id },
    zexPeopleScan: { running: true, found: 0, scored: 0, status: 'Opening your Following list…', ts: Date.now() },
    zexPeopleRun: true,
  });
  return { ok: true };
}
async function zexPeopleStop() {
  await chrome.storage.local.set({ zexPeopleRun: false });
  const d = await chrome.storage.local.get(['zexPeopleScan']);
  if (d.zexPeopleScan) await chrome.storage.local.set({ zexPeopleScan: Object.assign({}, d.zexPeopleScan, { running: false, status: 'Stopping…', ts: Date.now() }) });
  return { ok: true };
}
async function zexPeopleClaim(tabId) {
  const d = await chrome.storage.local.get(['zexPeopleRun', 'zexPeopleCfg']);
  if (d.zexPeopleRun && d.zexPeopleCfg && tabId != null && d.zexPeopleCfg.tabId === tabId) return { ok: true, cfg: d.zexPeopleCfg };
  return { ok: false };
}
// Shared People DB helpers for the Follow engine (same storage key as people_db.js)
async function zexPeopleIsFollowing(h) {
  try { const d = await chrome.storage.local.get(['zexPeople']); const m = d.zexPeople && d.zexPeople.m; const o = m && m[String(h).toLowerCase().replace(/^@/, '')]; return !!(o && o.f === 1); } catch (e) { return false; }
}
async function zexPeopleMarkFollowed(h) {
  try {
    h = String(h).toLowerCase().replace(/^@/, '');
    const d = await chrome.storage.local.get(['zexPeople']);
    const m = (d.zexPeople && d.zexPeople.m) || {};
    const o = m[h] || {}; o.f = 1; delete o.c; if (!o.src) o.src = 'FLW'; o.t = Date.now(); m[h] = o;
    await chrome.storage.local.set({ zexPeople: { v: 1, m } });
  } catch (e) {}
}
async function unfStop() {
  await chrome.storage.local.set({ zenUnfRun: false });
  const d = await chrome.storage.local.get(['zenUnfStats']);
  if (d.zenUnfStats) await chrome.storage.local.set({ zenUnfStats: Object.assign({}, d.zenUnfStats, { running: false, status: 'Stopped', ts: Date.now() }) });
  return { ok: true };
}
async function unfClaim(tabId) {
  const d = await chrome.storage.local.get(['zenUnfRun', 'zenUnfCfg']);
  if (d.zenUnfRun && d.zenUnfCfg && tabId != null && d.zenUnfCfg.tabId === tabId) return { ok: true, cfg: d.zenUnfCfg };
  return { ok: false };
}


// ══════════════════════════════════════════════════════════════
//  TAR ENGINE — Target Account List / Favourite (X) List
//  One engine, two sources: a manually-pasted Target Account List, or
//  a Favourite List sourced from an X List link/ID (members scraped by
//  content.js on that list's page). Same background job shape as the
//  Follow Engine: persists to chrome.storage.local, resumes after the
//  popup/tab/browser closes.
//
//  job = {
//    source: 'targets' | 'xlist',
//    xListLink: string|null,          // only when source === 'xlist'
//    queue: [username, ...],          // accounts to visit, in order
//    currentIndex: number,
//    accountsDone: [username, ...],   // fully processed this run (hit N or ran out of fresh posts)
//    accountsFailed: [username, ...], // profile didn't load / no posts at all
//    engagedTotal: number,            // total posts engaged across the whole run
//    tabId: number|null,
//    status: 'idle'|'navigating'|'working'|'paused'|'done'|'stopped',
//    postsPerAccount: number,         // N — fresh (not-yet-liked) posts to engage per account
//    engageMode: 'like'|'comment'|'both',
//    replyModel: 'model1'|'model2',
//    minGapMs, maxGapMs,              // gap between one account finishing and the next starting
//    startedAt: number
//  }
//
//  Resume vs fresh Start:
//   - tarEngineStart(queue, ...): ALWAYS a fresh recheck — every account in
//     the new queue is visited again from scratch (accountsDone reset for
//     accounts re-submitted), because "done" only ever meant "done as of
//     that run" — new posts may exist now.
//   - tarEngineResume(): continues the existing paused/stopped job exactly
//     at currentIndex, with its queue and progress untouched — for when a
//     run was stopped halfway and the person just wants to finish it.
// ══════════════════════════════════════════════════════════════

const TAR_STALL_MS = 60000; // a single account (profile load + scan + N engagements) gets this long before being skipped

async function getTarJob() {
  const d = await chrome.storage.local.get(['zTarJob']);
  return d.zTarJob || null;
}
async function setTarJob(job) {
  await chrome.storage.local.set({ zTarJob: job });
}

// Fresh run. usernames/settings replace the queue and progress markers;
// accountsDone for anyone in the NEW queue is cleared so they get rechecked.
async function tarEngineStart(usernames, opts) {
  opts = opts || {};
  const prev = await getTarJob();
  const clean = Array.from(new Set((usernames || []).map(u => String(u || '').trim().replace(/^@/, '')).filter(Boolean)));
  if (!clean.length) return { ok: false, reason: 'no_targets' };

  const job = {
    source: opts.source === 'xlist' ? 'xlist' : 'targets',
    xListLink: opts.xListLink || null,
    queue: clean,
    currentIndex: 0,
    accountsDone: (prev ? (prev.accountsDone || []) : []).filter(u => !clean.includes(u)),
    accountsFailed: [],
    engagedTotal: prev ? (prev.engagedTotal || 0) : 0,
    tabId: null, status: 'idle', startedAt: Date.now(),
    postsPerAccount: (typeof opts.postsPerAccount === 'number' && opts.postsPerAccount > 0) ? opts.postsPerAccount : ((prev && prev.postsPerAccount) || 2),
    engageMode: opts.engageMode || (prev && prev.engageMode) || 'like',
    replyModel: opts.replyModel || (prev && prev.replyModel) || 'model1',
    minGapMs: (typeof opts.minGapMs === 'number' && opts.minGapMs > 0) ? opts.minGapMs : ((prev && prev.minGapMs) || 90000),
    maxGapMs: (typeof opts.maxGapMs === 'number' && opts.maxGapMs > 0) ? opts.maxGapMs : ((prev && prev.maxGapMs) || 180000),
  };
  await setTarJob(job);
  tarEngineAdvance();
  return { ok: true, job };
}

// Continue an existing paused/stopped job from exactly where it left off —
// no requeue, no reset of progress.
async function tarEngineResume() {
  const job = await getTarJob();
  if (!job || !job.queue || job.currentIndex >= job.queue.length) return { ok: false, reason: 'nothing_to_resume' };
  job.status = 'idle';
  await setTarJob(job);
  tarEngineAdvance();
  return { ok: true, job };
}

async function tarEngineStop() {
  const job = await getTarJob();
  if (job) { job.status = 'stopped'; await setTarJob(job); }
  return { ok: true };
}

async function tarEngineAdvance() {
  const job = await getTarJob();
  if (!job || job.status === 'stopped') return;

  if (job.currentIndex >= job.queue.length) {
    job.status = 'done';
    await setTarJob(job);
    await bgNotify('✅ TAR Engine Complete', `Finished the list — ${job.engagedTotal || 0} posts engaged across ${(job.accountsDone || []).length} accounts.`);
    return;
  }

  const username = job.queue[job.currentIndex];
  const url = `https://x.com/${username}`;
  job.status = 'navigating';
  await setTarJob(job);

  try {
    if (job.tabId != null) {
      try {
        await chrome.tabs.get(job.tabId);
        await chrome.tabs.update(job.tabId, { url, active: false });
      } catch (e) {
        const tab = await chrome.tabs.create({ url, active: false });
        job.tabId = tab.id;
      }
    } else {
      const tab = await chrome.tabs.create({ url, active: false });
      job.tabId = tab.id;
    }
  } catch (e) {
    job.accountsFailed = (job.accountsFailed || []).concat([username]);
    job.currentIndex++;
    await setTarJob(job);
    setTimeout(tarEngineAdvance, 1000);
    return;
  }

  await setTarJob(job);
  await chrome.storage.local.set({
    zTarPending: {
      username, targetUrl: url, issuedAt: Date.now(),
      postsPerAccount: job.postsPerAccount, engageMode: job.engageMode, replyModel: job.replyModel,
    },
  });
}

// content.js reports the outcome for one account by writing zTarResult =
// { username, engagedCount, ok, ts }. ok=false only means the profile/scan
// itself failed (page didn't load, account suspended, etc) — an account
// with zero fresh posts to engage still reports ok=true, engagedCount:0.
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== 'local') return;
  if (changes.zTarResult) {
    const result = changes.zTarResult.newValue;
    if (!result || !result.username) return;
    const job = await getTarJob();
    if (!job || job.status === 'stopped') return;
    const current = job.queue[job.currentIndex];
    if (current !== result.username) return; // stale/duplicate report

    if (result.ok) {
      job.accountsDone = (job.accountsDone || []).concat([result.username]);
      job.engagedTotal = (job.engagedTotal || 0) + (result.engagedCount || 0);
    } else {
      job.accountsFailed = (job.accountsFailed || []).concat([result.username]);
    }
    job.currentIndex++;
    job.status = 'working';
    await setTarJob(job);
    const minGap = job.minGapMs || 90000;
    const maxGap = job.maxGapMs || 180000;
    const gap = minGap + Math.random() * Math.max(0, maxGap - minGap);
    setTimeout(tarEngineAdvance, gap);
  }
});

// Stall guard — if an account's tab never reports back, skip it after
// TAR_STALL_MS so the loop never gets permanently stuck.
setInterval(async () => {
  const job = await getTarJob();
  if (!job || job.status !== 'navigating') { /* also cover 'working' scans that hang mid-account */ }
  if (!job || (job.status !== 'navigating' && job.status !== 'working')) return;
  const pendingD = await chrome.storage.local.get(['zTarPending']);
  const pending = pendingD.zTarPending;
  if (pending && pending.username === job.queue[job.currentIndex] && Date.now() - (pending.issuedAt || 0) > TAR_STALL_MS) {
    job.accountsFailed = (job.accountsFailed || []).concat([job.queue[job.currentIndex]]);
    job.currentIndex++;
    job.status = 'working';
    await setTarJob(job);
    setTimeout(tarEngineAdvance, 1000);
  }
}, 10000);

// ── Favourite (X) List → member usernames ──────────────────────
// Opens the X List's page in a background tab; content.js (unfollow.js's
// generic profile-scraper pattern) scrolls it and reports member handles.
async function tarFetchXListMembers(listLink) {
  return new Promise(async (resolve) => {
    let settled = false;
    const finish = (usernames) => { if (settled) return; settled = true; resolve(usernames || []); };
    try {
      const tab = await chrome.tabs.create({ url: listLink, active: false });
      const listener = async (msg, sender) => {
        if (sender.tab && sender.tab.id === tab.id && msg && msg.type === 'zTarXListMembers') {
          chrome.runtime.onMessage.removeListener(listener);
          try { chrome.tabs.remove(tab.id); } catch (e) {}
          finish(msg.usernames);
        }
      };
      chrome.runtime.onMessage.addListener(listener);
      setTimeout(async () => {
        chrome.runtime.onMessage.removeListener(listener);
        try { chrome.tabs.remove(tab.id); } catch (e) {}
        finish([]);
      }, 25000);
    } catch (e) { finish([]); }
  });
}


// ── MESSAGE HANDLER — popup <-> background bridge for Auto Mode controls ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'sessAutoStart') {
    startSessionAutoMode(msg.sessionPath, msg.sessionLabel, msg.likeOn, msg.myUsername, msg.links, msg.engageEndTs)
      .then(sendResponse);
    return true; // async response
  }
  if (msg.type === 'sessAutoStop') {
    stopSessionAutoMode(msg.sessionPath).then(sendResponse);
    return true;
  }
  if (msg.type === 'sessAutoPause') {
    pauseSessionAutoMode(msg.sessionPath).then(sendResponse);
    return true;
  }
  if (msg.type === 'sessAutoResume') {
    resumeSessionAutoMode(msg.sessionPath).then(sendResponse);
    return true;
  }
  if (msg.type === 'sessAutoStatus') {
    getAutoJob(msg.sessionPath).then(job => sendResponse({ job }));
    return true;
  }


  // ── TAR Engine (Target Account List / Favourite X List) ──
  if (msg.type === 'tarStart')  { if (typeof zlimReset === 'function') zlimReset('comment'); tarEngineStart(msg.usernames, msg.opts || {}).then(sendResponse); return true; }
  if (msg.type === 'tarResume') { if (typeof zlimReset === 'function') zlimReset('comment'); tarEngineResume().then(sendResponse); return true; }
  if (msg.type === 'tarStop')   { tarEngineStop().then(sendResponse); return true; }
  if (msg.type === 'tarStatus') { getTarJob().then(job => sendResponse({ job })); return true; }
  if (msg.type === 'tarFetchXListMembers') { tarFetchXListMembers(msg.listLink).then(usernames => sendResponse({ usernames })); return true; }

  if (msg.type === 'followStart') {
    if (typeof zlimReset === 'function') zlimReset('follow');
    followEngineStart(msg.usernames, msg.minGapMs, msg.maxGapMs).then(sendResponse);
    return true;
  }
  if (msg.type === 'followStop') {
    followEngineStop().then(sendResponse);
    return true;
  }
  if (msg.type === 'followStatus') {
    getFollowJob().then(job => sendResponse({ job }));
    return true;
  }

  // ── Telegram Group Engage / Link Sweep ──
  if (msg.type === 'zenTgOpenEngage') { tgOpenEngagePanel().then(sendResponse); return true; }
  if (msg.type === 'zenTgOpenSweep')  { tgOpenSweepPanel().then(sendResponse); return true; }
  if (msg.type === 'zexHardRefresh') {
    const oldId = sender && sender.tab && sender.tab.id;
    if (msg.url && /^https:\/\/(x|twitter)\.com\//.test(msg.url)) {
      chrome.tabs.create({ url: msg.url, active: true }, (nt) => {
        if (chrome.runtime.lastError || !nt) { sendResponse({ ok: false }); return; }
        if (oldId != null && oldId !== nt.id) setTimeout(() => { chrome.tabs.remove(oldId, () => void chrome.runtime.lastError); }, 1500);
        sendResponse({ ok: true });
      });
    } else sendResponse({ ok: false });
    return true;
  }
  if (msg.type === 'zenTgStart')      { tgStart(msg.link, msg.endLink, msg.startId, msg.group).then(sendResponse); return true; }
  if (msg.type === 'zenTgStop')       { tgSerial(() => tgStop()).then(sendResponse); return true; }
  if (msg.type === 'zenTgReacted')    { tgSerial(() => tgReacted(msg.link, msg.skipped, msg.mid)).then(sendResponse); return true; }
  if (msg.type === 'unfStart') { unfStart(msg.cfg).then(sendResponse); return true; }
  if (msg.type === 'unfStop')  { unfStop().then(sendResponse); return true; }
  if (msg.type === 'zexPeopleStart') { zexPeopleStart().then(sendResponse); return true; }
  if (msg.type === 'zexPeopleStop')  { zexPeopleStop().then(sendResponse); return true; }
  if (msg.type === 'zexPeopleClaim') { zexPeopleClaim(sender && sender.tab ? sender.tab.id : null).then(sendResponse); return true; }
  if (msg.type === 'unfClaim') { unfClaim(sender && sender.tab ? sender.tab.id : null).then(sendResponse); return true; }
  if (msg.type === 'zenTgStartOwn')   { tgSerial(() => tgStartOwn(msg.link, msg.mid)).then(sendResponse); return true; }
  if (msg.type === 'zenTgOwnEnd')     { tgSerial(() => tgOwnEnd()).then(sendResponse); return true; }
  if (msg.type === 'zenTgNoLink')     { tgSerial(() => tgNoLinkFound(!!msg.failed, msg.link)).then(sendResponse); return true; }
  if (msg.type === 'zenTgSweepProgress') { tgSweepProgress(msg.collected, msg.phase).then(sendResponse); return true; }
  if (msg.type === 'zenTgSweepCancel')   { tgSweepCancel().then(sendResponse); return true; }
  if (msg.type === 'zexLogPush')         { zexLogPush(msg.lines); sendResponse({ ok: true }); return false; }
  if (msg.type === 'zexDayTick')         { zexDayTick(msg); sendResponse({ ok: true }); return false; }
  if (msg.type === 'zexErrFileAdd')      { zexErrFileAdd(msg.link); sendResponse({ ok: true }); return false; }
  if (msg.type === 'zexErrFileRemove')   { zexErrFileRemove(msg.link); sendResponse({ ok: true }); return false; }
  if (msg.type === 'zenTgSweepSend')     { if (typeof zlimReset === 'function') zlimReset('tgSweep'); tgSweepSend(msg.links, { retryIds: msg.retryIds }).then(sendResponse); return true; }
  if (msg.type === 'zenTgSweepDelayUpdate') {
    chrome.storage.local.set({ zenTgSweepDelayMin: msg.min, zenTgSweepDelayMax: msg.max });
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'zenTgStatus')        { tgStatus().then(sendResponse); return true; }

  if (msg.type === 'zenApplyProxy') {
    applyStoredProxyConfig();
    sendResponse({ ok: true });
    return true;
  }

  // ── CDP CLICK — Input.dispatchMouseEvent via chrome.debugger ──
  // content.js sends this when zen_cdp_click is ON.
  // Attaches debugger to the tab (if not already), fires a proper
  // OS-level mousePressed/mouseReleased/mouseMoved sequence, then
  // detaches cleanly. isTrusted: true — X.com cannot detect this.
  if (msg.type === '__CDP_CLICK__') {
    const { tabId, x, y, fromX, fromY } = msg;
    if (!tabId || x == null || y == null) { sendResponse({ ok: false, reason: 'bad_params' }); return true; }

    // ── Bezier curve helper ──
    // Generates intermediate points along a quadratic bezier curve from
    // (x0,y0) to (x1,y1) with a random control point for natural curvature.
    function bezierPoints(x0, y0, x1, y1, steps) {
      const cx = (x0 + x1) / 2 + (Math.random() * 80 - 40);
      const cy = (y0 + y1) / 2 + (Math.random() * 80 - 40);
      const pts = [];
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const bx = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * cx + t * t * x1;
        const by = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * cy + t * t * y1;
        pts.push({ x: Math.round(bx), y: Math.round(by) });
      }
      return pts;
    }

    // Per-tab last known cursor position (for bezier start point)
    if (!self._zenLastPos) self._zenLastPos = {};

    (async () => {
      try {
        // Attach (no-op if already attached)
        await new Promise((res, rej) => {
          chrome.debugger.attach({ tabId }, '1.3', () => {
            if (chrome.runtime.lastError &&
                !chrome.runtime.lastError.message.includes('already attached')) {
              console.warn('[ZenCDP][bg] debugger.attach failed', tabId, chrome.runtime.lastError.message);
              rej(chrome.runtime.lastError);
            } else { res(); }
          });
        });
        console.debug('[ZenCDP][bg] attached, dispatching click', { tabId, x, y, fromX, fromY });

        // Start point — prefer fromX/fromY sent by content.js, fall back
        // to last known position for this tab, then a random edge point.
        const startX = fromX ?? self._zenLastPos[tabId]?.x ?? Math.round(Math.random() * 400 + 200);
        const startY = fromY ?? self._zenLastPos[tabId]?.y ?? Math.round(Math.random() * 300 + 100);

        // How many intermediate steps? Scale with distance (8–20 points).
        const dist = Math.hypot(x - startX, y - startY);
        const steps = Math.min(20, Math.max(8, Math.round(dist / 40)));

        const path = bezierPoints(startX, startY, x, y, steps);

        // Fire intermediate mouseMoved events along the bezier path
        for (let i = 0; i < path.length - 1; i++) {
          const pt = path[i];
          await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
            type: 'mouseMoved', x: pt.x, y: pt.y,
            modifiers: 0, button: 'none', buttons: 0, clickCount: 0, deltaX: 0, deltaY: 0,
          });
          // Variable speed: faster at start/end, slower in middle (ease-in-out feel)
          const progress = i / (path.length - 1);
          const speedFactor = 1 - Math.sin(progress * Math.PI) * 0.5; // 0.5–1.0
          await new Promise(r => setTimeout(r, Math.round((8 + Math.random() * 10) * speedFactor)));
        }

        const base = { x, y, modifiers: 0, button: 'left', buttons: 1, clickCount: 1, deltaX: 0, deltaY: 0 };

        // Final arrival mouseMoved, then press + release
        await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { ...base, type: 'mouseMoved', button: 'none', buttons: 0 });
        await new Promise(r => setTimeout(r, 30 + Math.random() * 30));
        await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { ...base, type: 'mousePressed' });
        await new Promise(r => setTimeout(r, 40 + Math.random() * 40));
        await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { ...base, type: 'mouseReleased' });

        // Remember this position for the next click on this tab
        self._zenLastPos[tabId] = { x, y };

        console.debug('[ZenCDP][bg] click dispatched ok', { tabId, x, y });
        sendResponse({ ok: true });
      } catch (e) {
        console.warn('[ZenCDP][bg] click failed', { tabId, x, y }, e && e.message);
        sendResponse({ ok: false, reason: e.message });
      }
      // Detach after a short grace period so rapid successive clicks
      // don't suffer attach/detach overhead.
      if (self.ZexPlus) self.ZexPlus.scheduleDetach(tabId);   // ZEX+: shared per-tab detach timer (keeps focus/net emulation alive)
      else setTimeout(() => {
        chrome.debugger.detach({ tabId }, () => { chrome.runtime.lastError; /* suppress */ });
      }, 3000);
    })();
    return true; // async
  }

  // ── GET_TAB_ID — content.js needs its own tabId for CDP messages ──
  if (msg.type === '__GET_TAB_ID__') {
    sendResponse({ tabId: sender.tab ? sender.tab.id : null });
    return true;
  }

  // ── CDP Scroll (isTrusted: true mouseWheel) ───────────────────────
  if (msg.type === '__CDP_SCROLL__') {
    const { tabId, x, y, deltaY } = msg;
    if (!tabId) { sendResponse({ ok: false, reason: 'no_tabId' }); return true; }
    const target = { tabId };
    (async () => {
      try {
        await new Promise((res, rej) => {
          chrome.debugger.attach(target, '1.3', () => {
            if (chrome.runtime.lastError &&
                !chrome.runtime.lastError.message.includes('already attached')) {
              rej(chrome.runtime.lastError);
            } else { res(); }
          });
        });
        // Small natural mouseMoved before wheel — real mice do this
        await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
          type: 'mouseMoved', x, y, modifiers: 0,
          button: 'none', buttons: 0, clickCount: 0, deltaX: 0, deltaY: 0,
        });
        await new Promise(r => setTimeout(r, 20 + Math.random() * 30));
        // Fire wheel event in small chunks like a real scroll wheel
        const chunks = 3 + Math.floor(Math.random() * 3); // 3–5 ticks
        const perChunk = Math.round(deltaY / chunks);
        for (let i = 0; i < chunks; i++) {
          await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
            type: 'mouseWheel', x, y,
            deltaX: 0, deltaY: perChunk,
            modifiers: 0, pointerType: 'mouse',
          });
          await new Promise(r => setTimeout(r, 30 + Math.random() * 40));
        }
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, reason: e.message });
      }
      if (self.ZexPlus) self.ZexPlus.scheduleDetach(tabId);
      else setTimeout(() => {
        chrome.debugger.detach(target, () => { chrome.runtime.lastError; });
      }, 3000);
    })();
    return true;
  }
});


