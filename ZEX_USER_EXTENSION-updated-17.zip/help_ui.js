// Z EX — Help tab. Guides (title, text, optional image, optional video link) are written in the admin panel → Worker app-config "help_items".
// Text is always shown with textContent (never HTML). Images are fetched on demand (/v1/help-img) and kept in memory.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var imgCache = {};

  function call(path, body) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'zexpayCall', path: path, body: body, method: 'POST' }, function (res) {
          if (chrome.runtime.lastError || !res) return resolve({ ok: false });
          resolve(res);
        });
      } catch (e) { resolve({ ok: false }); }
    });
  }
  function safeUrl(u) { u = String(u || '').trim(); return /^https?:\/\/[^\s]+$/i.test(u) ? u : ''; }
  function openUrl(u) { try { chrome.tabs.create({ url: u }); } catch (e) { window.open(u, '_blank'); } }

  // ── link helpers: GitHub / Google Drive / YouTube links work as image or video sources ──
  function driveId(u) { var m = String(u).match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:[^#]*&)?id=)([\w-]{10,})/i); return m ? m[1] : ''; }
  function ytId(u) { var m = String(u).match(/(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{11})/i); return m ? m[1] : ''; }
  function ghRaw(u) {   // github.com/user/repo/blob/branch/file  →  raw.githubusercontent.com/user/repo/branch/file
    var m = String(u).match(/^https:\/\/github\.com\/([^\/]+)\/([^\/]+)\/(?:blob|raw)\/([^?#]+)/i);
    return m ? 'https://raw.githubusercontent.com/' + m[1] + '/' + m[2] + '/' + m[3] : u;
  }
  function imgSrc(u) { var d = driveId(u); return d ? 'https://drive.google.com/thumbnail?id=' + d + '&sz=w1200' : ghRaw(u); }
  // plain text → DOM with clickable links (never innerHTML)
  function linkify(text, el) {
    String(text).split(/(https?:\/\/[^\s<>"')]+)/g).forEach(function (part, i) {
      if (i % 2 === 1) {
        var url = part.replace(/[.,;:!?]+$/, ''), tail = part.slice(url.length);
        var a = document.createElement('a'); a.textContent = url; a.href = url; a.style.cssText = 'color:var(--blue,#3b82f6);text-decoration:underline;';
        a.addEventListener('click', function (e) { e.preventDefault(); openUrl(url); });
        el.appendChild(a); if (tail) el.appendChild(document.createTextNode(tail));
      } else if (part) el.appendChild(document.createTextNode(part));
    });
  }
  function openBtn(label, url) {
    var b = document.createElement('button'); b.type = 'button'; b.className = 'act-btn'; b.textContent = label; b.style.marginTop = '6px';
    b.addEventListener('click', function () { openUrl(url); });
    return b;
  }
  function linkImage(url) {
    var wrap = document.createElement('div');
    var im = document.createElement('img'); im.src = imgSrc(url); im.alt = '';
    im.style.cssText = 'max-width:100%;border-radius:10px;border:1px solid var(--border);display:block;margin:8px 0;cursor:zoom-in;';
    im.addEventListener('click', function () { openUrl(url); });
    im.addEventListener('error', function () { wrap.textContent = ''; wrap.appendChild(openBtn('🖼 Open image', url)); });
    wrap.appendChild(im); return wrap;
  }
  function videoBlock(url) {
    var wrap = document.createElement('div'), y = ytId(url), d = driveId(url), raw = ghRaw(url);
    if (/\.(mp4|webm|ogg|mov)(\?|#|$)/i.test(raw)) {
      var v = document.createElement('video'); v.controls = true; v.preload = 'none'; v.setAttribute('playsinline', ''); v.src = raw;
      v.style.cssText = 'max-width:100%;border-radius:10px;margin-top:8px;display:block;'; wrap.appendChild(v);
    } else if (y || d) {
      var f = document.createElement('iframe');
      f.src = y ? 'https://www.youtube-nocookie.com/embed/' + y : 'https://drive.google.com/file/d/' + d + '/preview';
      f.allow = 'autoplay; fullscreen; picture-in-picture'; f.setAttribute('allowfullscreen', ''); f.loading = 'lazy';
      f.style.cssText = 'width:100%;aspect-ratio:16/9;border:0;border-radius:10px;margin-top:8px;background:#000;'; wrap.appendChild(f);
    }
    wrap.appendChild(openBtn('▶ Open video in new tab', url));   // always: some links cannot be embedded
    return wrap;
  }

  function loadImage(it, box) {
    var key = it.id + ':' + (it.v || 0);
    function show(data) {
      var im = document.createElement('img'); im.src = data; im.alt = it.title || '';
      im.style.cssText = 'max-width:100%;border-radius:10px;border:1px solid var(--border);display:block;margin:8px 0;cursor:zoom-in;';
      im.addEventListener('click', function () { var w = window.open(); if (w) { w.document.write('<body style="margin:0;background:#000"><img src="' + data + '" style="max-width:100%;display:block;margin:auto">'); } });
      box.textContent = ''; box.appendChild(im);
    }
    if (imgCache[key]) return show(imgCache[key]);
    box.textContent = 'Loading image…'; box.style.cssText = 'font-size:11px;color:var(--dim);margin:8px 0;';
    call('/v1/help-img', { id: it.id }).then(function (r) {
      if (r.ok && r.data && r.data.data) { imgCache[key] = r.data.data; box.style.cssText = ''; show(r.data.data); }
      else box.textContent = '';
    });
  }

  function card(it) {
    var d = document.createElement('details'); d.className = 'act-card'; d.style.marginBottom = '8px';
    var s = document.createElement('summary'); s.style.cssText = 'cursor:pointer;font-size:13px;font-weight:700;list-style:none;';
    s.textContent = '▸ ' + (it.title || 'Guide');
    d.appendChild(s);
    var inner = document.createElement('div'); inner.style.marginTop = '8px';
    if (it.body) { var p = document.createElement('div'); linkify(it.body, p); p.style.cssText = 'font-size:12px;line-height:1.6;white-space:pre-wrap;word-break:break-word;color:var(--text);'; inner.appendChild(p); }
    var iu = safeUrl(it.imgUrl); if (iu) inner.appendChild(linkImage(iu));
    var imgBox = null;
    if (it.img) { imgBox = document.createElement('div'); inner.appendChild(imgBox); }
    var vu = safeUrl(it.video);
    if (vu) inner.appendChild(videoBlock(vu));
    d.appendChild(inner);
    var loaded = false;
    d.addEventListener('toggle', function () {
      s.textContent = (d.open ? '▾ ' : '▸ ') + (it.title || 'Guide');
      if (d.open && imgBox && !loaded) { loaded = true; loadImage(it, imgBox); }
    });
    return d;
  }

  function render(items) {
    var list = $('hlpList'), info = $('hlpInfo'); if (!list) return;
    list.textContent = '';
    var arr = (Array.isArray(items) ? items : []).filter(function (x) { return x && x.on !== false && x.id && (x.title || x.body || x.imgUrl || x.video || x.img); })
      .sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
    if (!arr.length) { if (info) info.textContent = 'No guides yet — check back soon.'; return; }
    if (info) info.textContent = 'Tap a topic to see how that feature works.';
    arr.forEach(function (it) { list.appendChild(card(it)); });
  }

  var lastSig = '';
  function load() {
    if (typeof zAppConfig !== 'function') return;
    try { chrome.storage.local.get(['zexHelpCache'], function (r) { if (r && r.zexHelpCache && !lastSig) render(r.zexHelpCache); }); } catch (e) {}
    zAppConfig(false).then(function (cfg) {
      if (!cfg) return;                                     // network error: keep what is shown
      var items = Array.isArray(cfg.help_items) ? cfg.help_items : [];
      var sig = JSON.stringify(items);
      if (sig === lastSig) return;
      lastSig = sig; render(items);
      try { chrome.storage.local.set({ zexHelpCache: items }); } catch (e) {}
    }).catch(function () {});
  }

  function init() {
    var btn = document.querySelector('.nav-tab[data-tabpanel="tabPanelHelp"]'); if (!btn) return;
    btn.addEventListener('click', load);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
