/* Z EX — Dashboard "Following Analysis" card (popup).
   Shows the linked X username; tap it (or Analyze) → background opens /<you>/following and people_scan.js saves everyone
   with their Wallchain score into the shared People DB (chrome.storage.local.zexPeople). Export / Import / Clear here. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  if (!$('pdCard') || typeof chrome === 'undefined' || !chrome.storage) return;
  var KEY = 'zexPeople', filter = 'following', people = {}, scan = null, handle = '';
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); };
  var SRC = { FOL: 'following list', FED: 'FED', SEA: 'SEA', COL: 'collect', SWP: 'sweep', TGE: 'telegram', FLW: 'follow engine' };
  function note(msg, cls) { var n = $('pdNote'); if (!n) return; n.textContent = msg || ''; n.className = 'sx-status' + (cls ? ' ' + cls : ''); if (msg) setTimeout(function () { if (n.textContent === msg) n.textContent = ''; }, 4000); }

  function paintTarget() {
    chrome.storage.local.get(['zenDeviceSession'], function (d) {
      var s = (d && d.zenDeviceSession) || {};
      handle = String(s.xHandle || '').replace(/^@/, '').trim();
      var el = $('pdTarget'); el.textContent = handle ? '@' + handle : 'No X account linked';
      el.classList.toggle('none', !handle);
    });
  }
  function paintStatus() {
    var b = $('pdScan'), st = $('pdStatus'), run = !!(scan && scan.running);
    b.textContent = run ? 'Stop analysis' : 'Analyze my following';
    st.textContent = scan && scan.status ? scan.status : '';
    st.className = 'sx-status' + (run ? '' : (scan && scan.done ? ' ok' : ''));
  }
  function stat(label, val) { return '<div class="zm-stat" style="flex:1;min-width:70px;"><b>' + val + '</b><span>' + label + '</span></div>'; }
  function render() {
    var n = 0, fo = 0, sc = 0, co = 0, rows = [];
    var q = ($('pdSearch').value || '').trim().toLowerCase().replace(/^@/, '');
    Object.keys(people).forEach(function (h) {
      var o = people[h]; n++;
      var isF = o.f === 1, isC = !isF && o.c === 1;
      if (isF) { fo++; if (o.s != null) sc++; } else if (isC) co++;
      if (filter === 'following' && !isF) return;
      if (filter === 'collected' && !isC) return;
      if (q && h.indexOf(q) < 0) return;
      rows.push({ h: h, o: o });
    });
    $('pdStats').innerHTML = stat('FOLLOWING', fo) + stat('WITH SCORE', sc) + stat('COLLECTED', co) + stat('TOTAL', n);
    rows.sort(function (a, b) { return (b.o.s == null ? -1 : b.o.s) - (a.o.s == null ? -1 : a.o.s) || (b.o.t || 0) - (a.o.t || 0); });
    var list = $('pdList'); list.textContent = '';
    if (!rows.length) { list.innerHTML = '<div style="font-size:11px;color:var(--dim);padding:8px 0;">' + (n ? 'Nothing here.' : 'Empty — tap Analyze to scan who you follow.') + '</div>'; }
    else {
      var html = rows.slice(0, 150).map(function (r) {
        return '<div class="pd-li"><a href="https://x.com/' + esc(r.h) + '" target="_blank" rel="noopener">@' + esc(r.h) + '</a><span>' + (r.o.s != null ? 'WC ' + r.o.s : 'no score') + ' · ' + esc(SRC[r.o.src] || r.o.src || '') + '</span></div>';
      }).join('');
      if (rows.length > 150) html += '<div style="font-size:11px;color:var(--dim);padding:6px 0;">+ ' + (rows.length - 150) + ' more (use search · Export has all)</div>';
      list.innerHTML = html;
    }
    document.querySelectorAll('#pdFilter .pd-f').forEach(function (b) { b.classList.toggle('active', b.dataset.f === filter); });
  }
  function load() {
    chrome.storage.local.get([KEY, 'zexPeopleScan'], function (d) {
      var st = d && d[KEY]; people = (st && st.m) || {}; scan = d && d.zexPeopleScan;
      paintStatus(); render();
    });
  }
  function startStop() {
    if (scan && scan.running) { chrome.runtime.sendMessage({ type: 'zexPeopleStop' }, function () { void chrome.runtime.lastError; }); return; }
    chrome.runtime.sendMessage({ type: 'zexPeopleStart' }, function (r) {
      void chrome.runtime.lastError;
      if (r && r.ok) return;
      var w = r && r.reason;
      note(w === 'session' ? 'Login to Z EX first' : w === 'no_handle' ? 'No X account linked' : w === 'already_running' ? 'Already running' : 'Could not start — try again', 'err');
    });
  }
  $('pdScan').addEventListener('click', startStop);
  $('pdTarget').addEventListener('click', function () { if (handle) startStop(); });
  $('pdSearch').addEventListener('input', render);
  $('pdFilter').addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('.pd-f'); if (b) { filter = b.dataset.f; render(); } });
  $('pdExport').addEventListener('click', function () {
    if (!window.ZexPeople) return;
    var obj = window.ZexPeople.export();
    if (!obj.count) { note('Nothing to export yet', 'err'); return; }
    var d = new Date(), p2 = function (x) { return String(x).padStart(2, '0'); };
    var name = 'zex-people-' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes()) + '.json';
    var url = URL.createObjectURL(new Blob([JSON.stringify(obj)], { type: 'application/json' }));
    var a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    note('Exported ' + obj.count + ' accounts', 'ok');
  });
  $('pdImport').addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
    var fr = new FileReader();
    fr.onload = function () {
      var obj = null; try { obj = JSON.parse(String(fr.result || '')); } catch (x) {}
      if (!obj || obj.kind !== 'people-db') { note('Not a ZEX people file', 'err'); return; }
      Promise.resolve(window.ZexPeople.importObj(obj)).then(function (r) { note(r && r.ok ? 'Imported · ' + r.added + ' new, ' + r.updated + ' updated' : 'Import failed', r && r.ok ? 'ok' : 'err'); });
    };
    fr.onerror = function () { note('Could not read the file', 'err'); };
    fr.readAsText(f);
  });
  $('pdClear').addEventListener('click', function () {
    if (confirm('Clear the whole People list (following + collected)? Engines will stop skipping those accounts.')) { window.ZexPeople.clear(); note('Cleared', 'ok'); }
  });
  chrome.storage.onChanged.addListener(function (c, a) {
    if (a !== 'local') return;
    if (c[KEY] || c.zexPeopleScan) { if (c[KEY]) people = (c[KEY].newValue && c[KEY].newValue.m) || {}; if (c.zexPeopleScan) scan = c.zexPeopleScan.newValue; paintStatus(); render(); }
    if (c.zenDeviceSession) paintTarget();
  });
  paintTarget(); load();
})();
