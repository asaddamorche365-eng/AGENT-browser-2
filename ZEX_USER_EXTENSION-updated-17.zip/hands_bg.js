/* Z EX — animated background manager.
   Plays the scenes registered in window.ZEX_SCENES (see /scenes/*.js) in random rotation —
   each ~12-15 s with a 1 s cross-fade, never the same scene twice in a row — on two canvases:
     login     → band above the login box (#zenHandsCanvas inside #loginPage), full alpha
     dashboard → centre of the screen, fixed behind the dashboard (#zenDashHands), alpha 0.5
   A scene is { name, init(ctx, W, H, S), draw(ctx, t, opts), resize(W, H) } and must be a pure
   function of t (both canvases share the scene objects). `opts` is one reused object:
     W,H canvas css size · S scale unit · cx,cy focal point · bot usable height · g pixel size
     ink / gold ("r,g,b") · i10 i26 i38 i55 i78 ready-made ink strokes · ia[0..40] / ga[0..40]
     ink / gold rgba strings by alpha (use U.q(a) as the index) */
(function () {
  'use strict';

  var FADE = 1;                    // cross-fade seconds
  var DUR_MIN = 12, DUR_MAX = 15;  // seconds per scene
  var FADE_IN = 1.2;               // first-load fade-in
  var MIN_DT = 19;                 // ms between frames → ~30 fps on 60 Hz screens, up to ~50 on faster ones
  var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  function mount(mode) {
    var isDash = mode === 'dash';
    var page = document.getElementById(isDash ? 'dashboard' : 'loginPage');
    var canvas = document.getElementById(isDash ? 'zenDashHands' : 'zenHandsCanvas');
    var scenes = window.ZEX_SCENES;
    if (!page || !canvas || !scenes || !scenes.length) return;
    var ctx = canvas.getContext('2d');
    var box = isDash ? null : page.querySelector('.login-box');
    function isVisible() { return isDash ? page.style.display === 'flex' : page.offsetParent !== null; }

    // ── shared options object (mutated in place, never re-created) ──
    var o = {
      W: 0, H: 0, S: 60, cx: 0, cy: 0, bot: 0, g: 2, dark: null,
      ink: '', gold: '', i10: '', i26: '', i38: '', i55: '', i78: '', ia: [], ga: []
    };
    function applyTheme(dark) {       // light mode + legacy dark mode (body.zex-legacy-dark), same colours as before
      o.dark = dark;
      o.ink = dark ? '235,235,235' : '23,24,26';
      o.gold = dark ? '250,204,21' : '202,138,4';
      o.i10 = 'rgba(' + o.ink + ',0.10)'; o.i26 = 'rgba(' + o.ink + ',0.26)'; o.i38 = 'rgba(' + o.ink + ',0.38)';
      o.i55 = 'rgba(' + o.ink + ',0.55)'; o.i78 = 'rgba(' + o.ink + ',0.78)';
      for (var k = 0; k <= 40; k++) {
        o.ia[k] = 'rgba(' + o.ink + ',' + (k / 40) + ')';
        o.ga[k] = 'rgba(' + o.gold + ',' + (k / 40) + ')';
      }
    }
    function legacyDark() { return !!(document.body && document.body.classList.contains('zex-legacy-dark')); }
    applyTheme(legacyDark());

    // ── layout ──
    var dpr = 1, inited = false, needLayout = true, dirty = true;
    function layout() {
      var W, H;
      if (isDash) { W = Math.max(1, window.innerWidth); H = Math.max(1, window.innerHeight); }
      else { var r = page.getBoundingClientRect(); W = Math.max(1, Math.round(r.width)); H = Math.max(1, Math.round(r.height)); }
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      o.W = W; o.H = H;
      if (isDash) {
        o.cx = W / 2; o.cy = H / 2; o.bot = H;
        o.S = Math.max(34, Math.min(W * 0.21, H * 0.17, 125));
      } else {
        var band = Math.max(130, box ? box.offsetTop : 170);   // the free band above the login box
        o.cx = W / 2; o.cy = band * 0.56; o.bot = band;
        o.S = Math.max(28, Math.min(W * 0.24, band * 0.56, 150));
      }
      o.g = Math.max(2, Math.round(o.S / 34));
      for (var i = 0; i < scenes.length; i++) {
        if (!inited && scenes[i].init) scenes[i].init(ctx, W, H, o.S);
        if (scenes[i].resize) scenes[i].resize(W, H);
      }
      inited = true; dirty = true;
    }

    // ── rotation state ──
    var cur = 0, next = -1, sceneT = 0, nextT = 0, dur = rndDur(), fadeIn = reduceMotion ? 1 : 0;
    function rndDur() { return DUR_MIN + Math.random() * (DUR_MAX - DUR_MIN); }
    function pick(excl) {
      var n = scenes.length, r;
      if (n < 2) return 0;
      do { r = (Math.random() * n) | 0; } while (r === excl);   // never the same scene twice in a row
      return r;
    }
    function ease(x) { return x * x * (3 - 2 * x); }
    function step(dt) {
      if (fadeIn < 1) fadeIn = Math.min(1, fadeIn + dt / FADE_IN);
      sceneT += dt;
      if (next < 0) {
        if (scenes.length > 1 && sceneT >= dur - FADE) { next = pick(cur); nextT = 0; }
      } else {
        nextT += dt;
        if (nextT >= FADE) { cur = next; sceneT = nextT; next = -1; dur = rndDur(); }
      }
    }

    function render() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, o.W, o.H);
      var dk = legacyDark(); if (dk !== o.dark) applyTheme(dk);
      var base = (isDash ? 0.5 : 1) * ease(fadeIn);
      if (next < 0) {
        ctx.globalAlpha = base;
        scenes[cur].draw(ctx, sceneT, o);
      } else {
        var f = ease(Math.min(1, nextT / FADE));
        ctx.globalAlpha = base * (1 - f); scenes[cur].draw(ctx, sceneT, o);
        ctx.globalAlpha = base * f;       scenes[next].draw(ctx, nextT, o);
      }
      ctx.globalAlpha = 1;
    }
    function renderStill() {          // prefers-reduced-motion: one static frame, no loop
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, o.W, o.H);
      var dk = legacyDark(); if (dk !== o.dark) applyTheme(dk);
      ctx.globalAlpha = isDash ? 0.5 : 1;
      scenes[0].draw(ctx, scenes[0].still || 2, o);
      ctx.globalAlpha = 1;
    }

    // ── loop: only runs while this canvas is visible and the tab is in the foreground ──
    var raf = 0, timer = 0, wasVis = false, last = 0, lastDraw = 0;
    function loop(now) {
      raf = 0; timer = 0;
      if (document.hidden) return;                       // visibilitychange restarts it
      if (now === undefined) now = performance.now();
      if (!isVisible()) { wasVis = false; timer = setTimeout(loop, 300); return; }   // cheap poll, no drawing
      if (!wasVis) { wasVis = true; needLayout = true; last = now; }
      if (needLayout) { layout(); needLayout = false; }
      if (reduceMotion) {
        if (dirty) { renderStill(); dirty = false; }
        timer = setTimeout(loop, 400);
        return;
      }
      if (now - lastDraw >= MIN_DT) {
        var dt = (now - last) / 1000; last = now; lastDraw = now;
        if (dt > 0.1 || dt < 0) dt = 0.1;                // a pause never skips a scene
        step(dt);
        render();
      }
      raf = requestAnimationFrame(loop);
    }
    function kick() { if (!raf && !timer && !document.hidden) raf = requestAnimationFrame(loop); }

    if (window.ResizeObserver && !isDash) new ResizeObserver(function () { needLayout = true; kick(); }).observe(page);
    window.addEventListener('resize', function () { needLayout = true; kick(); });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) {
        if (raf) { cancelAnimationFrame(raf); raf = 0; }
        if (timer) { clearTimeout(timer); timer = 0; }
        wasVis = false;
      } else kick();
    });
    kick();
  }

  mount('login');
  mount('dash');
})();
