// Z EX v4 - Content Script
// Multi-API: Gemini (free) → OpenRouter (free) → auto-fallback


// ═══ DEBUG LOG CAPTURE — every console line that starts with "[Z EX]" is kept (last 500, all tabs) so "Export debug log" (System tab) can save it ═══
(function zexLogCapture() {
  try {
    if (window.__zexLogCap) return; window.__zexLogCap = 1;
    let buf = [], timer = null;
    const flush = () => {
      timer = null;
      if (!buf.length) return;
      const lines = buf; buf = [];
      try { chrome.runtime.sendMessage({ type: 'zexLogPush', lines }, () => { void chrome.runtime.lastError; }); } catch (e) {}
    };
    const fmt = (v) => { try { if (typeof v === 'string') return v; if (v instanceof Error) return v.message; return JSON.stringify(v); } catch (e) { return String(v); } };
    ['log', 'info', 'warn', 'error'].forEach((lv) => {
      const orig = console[lv];
      console[lv] = function () {
        try {
          const a0 = arguments[0];
          if (typeof a0 === 'string' && a0.indexOf('[Z EX]') === 0) {
            const txt = Array.prototype.map.call(arguments, fmt).join(' ').slice(0, 320);
            buf.push({ t: Date.now(), l: lv, p: String(location.pathname || '').slice(0, 48), m: txt });
            if (buf.length > 40) buf.shift();
            if (!timer) timer = setTimeout(flush, 4000);
          }
        } catch (e) {}
        return orig.apply(this, arguments);
      };
    });
    window.addEventListener('pagehide', flush);
  } catch (e) {}
})();

// ═══ ZEX PIXEL FONT — used by the process log + agent dashboard ═══
(function zexInjectPixelFont() {
  try {
    if (document.getElementById('zex-pixel-font')) return;
    const st = document.createElement('style');
    st.id = 'zex-pixel-font';
    st.textContent = "@font-face{font-family:'ZexPixel';src:url('" + chrome.runtime.getURL('fonts/zex_pixel.ttf') + "') format('truetype');font-display:swap;}";
    (document.head || document.documentElement).appendChild(st);
  } catch (e) {}
})();

// ═══ ZEN CURSOR — Visible animated cursor overlay ════════════════
// Shows a real-looking mouse cursor on screen while auto mode runs.
// cursor moves smoothly to element before every realClick / scroll.
const ZenCursor = (() => {
  let el = null;           // the cursor div
  let curX = window.innerWidth / 2;
  let curY = window.innerHeight / 2;
  let raf = null;
  let visible = false;
  // custom image url (optional — user can set via ZenCursor.setImage(url))
  let customImg = null;
  let curSize = 28;        // px, user-adjustable (16–64)
  // animated skin (cursor_skins.js) — when set, replaces the arrow / custom image
  let skinId = '';
  let fx = null, fxCanvas = null, flipped = false;
  function _skinU() { return Math.max(1, Math.min(4, Math.round(curSize / 14))); }

  // Default SVG arrow — classic mouse pointer shape
  const DEFAULT_SVG = `
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 28 28">
      <filter id="zs" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="1" dy="1" stdDeviation="1.5" flood-opacity="0.5"/>
      </filter>
      <polygon filter="url(#zs)"
        points="4,2 4,22 9,17 13,26 16,25 12,16 19,16"
        fill="white" stroke="#222" stroke-width="1.2" stroke-linejoin="round"/>
    </svg>`;

  function _mount() {
    if (el) return;
    el = document.createElement('div');
    el.id = '__zen_cursor__';
    el.style.cssText = [
      'position:fixed',
      'top:0','left:0',
      'width:'+curSize+'px','height:'+curSize+'px',
      'z-index:2147483647',
      'pointer-events:none',
      'transform:translate(-2px,-2px)',
      'transition:none',
      'will-change:transform',
      'display:none',
    ].join(';');
    _applyImage();
    ZexShadow.mount(el);

    // Track real mouse position so cursor stays in sync when user moves mouse
    window.addEventListener('mousemove', (e) => {
      if (!visible) return;
      curX = e.clientX;
      curY = e.clientY;
      _renderPos(curX, curY);
    }, { passive: true });
  }

  function _applyImage() {
    if (!el) return;
    if (skinId && typeof ZexCursorFX !== 'undefined') {
      if (!fxCanvas) { fxCanvas = document.createElement('canvas'); fxCanvas.style.cssText = 'display:block;image-rendering:pixelated;'; }
      if (!fx) fx = ZexCursorFX.create(fxCanvas, { skin: skinId, u: _skinU(), bubble: true, arrow: true });
      fx.setSkin(skinId); fx.setScale(_skinU());
      el.style.backgroundImage = '';
      el.innerHTML = '';
      el.appendChild(fxCanvas);
      el.style.width = fx.width + 'px'; el.style.height = fx.height + 'px';
      el.style.transform = '';
      if (visible) fx.start();
      _renderPos(curX, curY);
      return;
    }
    if (fx) { fx.stop(); }
    el.style.width = curSize + 'px'; el.style.height = curSize + 'px';
    if (customImg) {
      el.style.backgroundImage = `url('${customImg}')`;
      el.style.backgroundSize = curSize + 'px ' + curSize + 'px';
      el.style.backgroundPosition = 'center';
      el.style.backgroundRepeat = 'no-repeat';
      el.innerHTML = '';
    } else {
      el.style.backgroundImage = '';
      el.innerHTML = DEFAULT_SVG;
    }
  }

  function _renderPos(x, y) {
    if (!el) return;
    if (skinId && fx) {
      // flip the bubble to the left when it would run off the right edge of the screen
      const f = (x + fx.width + 6) > window.innerWidth;
      if (f !== flipped) { flipped = f; fx.setFlip(f); }
      el.style.transform = `translate(${f ? x - fx.width + 1 : x}px,${y}px)`;
      return;
    }
    el.style.transform = `translate(${x - 2}px,${y - 2}px)`;
  }

  // Animate cursor from current position to (tx, ty) in ~ms duration
  function _animateTo(tx, ty, ms) {
    return new Promise((resolve) => {
      if (raf) cancelAnimationFrame(raf);
      const sx = curX, sy = curY;
      const start = performance.now();
      function step(now) {
        const t = Math.min((now - start) / ms, 1);
        // ease-out cubic
        const ease = 1 - Math.pow(1 - t, 3);
        curX = sx + (tx - sx) * ease;
        curY = sy + (ty - sy) * ease;
        _renderPos(curX, curY);
        if (t < 1) {
          raf = requestAnimationFrame(step);
        } else {
          curX = tx; curY = ty;
          resolve();
        }
      }
      raf = requestAnimationFrame(step);
    });
  }

  return {
    // Show cursor — call when any auto mode starts
    show() {
      _mount();
      visible = true;
      el.style.display = 'block';
      if (fx && skinId) { fx.setState('search', true); fx.start(); }
    },

    // Hide cursor — call when all auto modes stop
    hide() {
      visible = false;
      if (fx) fx.stop();
      if (el) el.style.display = 'none';
    },

    // Animated skin: set which built-in skin is used ('' = off) and what it is doing
    setSkin(id) {
      skinId = id || '';
      _mount();
      _applyImage();
    },
    setState(key) {
      if (fx && skinId) fx.setState(key);
    },

    // Move cursor to element center and wait
    async moveTo(targetEl, opts = {}) {
      if (!visible || !targetEl) return;
      const rect = targetEl.getBoundingClientRect();
      if (!rect.width && !rect.height) return;
      const tx = rect.left + rect.width  / 2 + (Math.random() * 6 - 3);
      const ty = rect.top  + rect.height / 2 + (Math.random() * 6 - 3);
      const dist = Math.hypot(tx - curX, ty - curY);
      // speed: ~600px/s — farther = slightly longer, min 80ms, max 500ms
      const ms = opts.ms || Math.max(80, Math.min(500, dist * 0.55));
      await _animateTo(tx, ty, ms);
      // tiny settling pause like a real hand
      await new Promise(r => setTimeout(r, 30 + Math.random() * 40));
    },

    // Move cursor to arbitrary screen coords (for scroll events)
    async moveToXY(x, y, ms = 200) {
      if (!visible) return;
      await _animateTo(x, y, ms);
    },

    // Set a custom cursor image URL (png/gif/webp)
    setImage(url) {
      customImg = url || null;
      _applyImage();
    },

    // Set cursor size in px (clamped 16–64)
    setSize(px) {
      curSize = Math.max(16, Math.min(64, parseInt(px, 10) || 28));
      if (skinId && fx) { _applyImage(); return; }
      if (el) {
        el.style.width = curSize + 'px';
        el.style.height = curSize + 'px';
        if (customImg) el.style.backgroundSize = curSize + 'px ' + curSize + 'px';
      }
    },

    // Is cursor currently visible?
    get active() { return visible; },
  };
})();

// ─── Auto Refresh hold ───────────────────────────────────────────
// true = every auto loop must NOT start a new post. Set when Auto Refresh
// fires (time up / goal reached) and kept until the refresh is finished and
// the feed has re-rendered, so the engine never works while the page reloads.
let zenRefreshHold = false;
try {
  const _t = Number(sessionStorage.getItem('zenArResume') || 0);
  if (_t && Date.now() - _t < 120000) zenRefreshHold = true; // page was just refreshed by Auto Refresh
} catch (e) {}

// ─── Auto-mode state watcher: show/hide cursor ───────────────────
// Polls every 300ms; shows cursor when any engine is running.
setInterval(() => {
  const anyRunning =
    (typeof repAutoRunning  !== 'undefined' && repAutoRunning)  ||
    (typeof feedAutoRunning !== 'undefined' && feedAutoRunning) ||
    (typeof searchAutoRunning !== 'undefined' && searchAutoRunning) ||
    (typeof givAutoRunning  !== 'undefined' && givAutoRunning) ||
    (typeof sessAutoRunningFor !== 'undefined' && !!sessAutoRunningFor);  // Telegram / Session engage runs
  if (anyRunning && !ZenCursor.active) ZenCursor.show();
  if (!anyRunning && ZenCursor.active) ZenCursor.hide();
  // Tell zex_noprompt.js (page world) that Z EX is driving this tab → no "Leave site?" prompt while automating.
  try {
    const _auto = anyRunning || window.__zexAutoFlag || (typeof tarRunningFor !== 'undefined' && !!tarRunningFor);
    const _h = document.documentElement;
    if (_h) { if (_auto) { if (!_h.hasAttribute('data-zex-auto')) _h.setAttribute('data-zex-auto', '1'); } else if (_h.hasAttribute('data-zex-auto')) _h.removeAttribute('data-zex-auto'); }
  } catch (e) {}
}, 300);

// ═══ REAL POINTER CLICK ══════════════════════════════════════════
// Replaces all .click() calls with actual mouse pointer events
// (pointerdown → mousedown → pointerup → mouseup → click)
// using the element's real center coordinates — same as a human click.
// ── CDP Click helper — asks background to fire Input.dispatchMouseEvent ──
// Resolved once on first call and cached for the page's lifetime.
// ── CDP mode cached (storage.get once, not per click) ────────────
let _zenCdpMode = false;
chrome.storage.local.get(['zen_cdp_click'], d => {
  _zenCdpMode = d.zen_cdp_click === true;
  _zenApplyCdpZoomGuard();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && 'zen_cdp_click' in changes) {
    _zenCdpMode = changes.zen_cdp_click.newValue === true;
    _zenApplyCdpZoomGuard();
  }
});

// ── CDP zoom guard ────────────────────────────────────────────────
// CDP's Input.dispatchMouseEvent fires at fixed CSS-pixel coordinates
// computed from getBoundingClientRect() at the moment of each click. If
// the page gets pinch-zoomed in between clicks — an accidental screen
// touch mid-reply is enough on mobile — every element's on-screen
// position shifts relative to those coordinates, and CDP has no concept
// of "the button" the way a real DOM click does: it just fires at a
// point, so once zoomed, clicks miss their targets until the user
// manually zooms back out to 1:1.
//
// The previous fix for this (repAutoSubmit) only forced scale=1 for a
// ~2 second window around one specific submit-button click, then
// restored the page's normal (pinch-enabled) viewport afterward — so
// the rest of any reply/comment flow, including while the reply box is
// open and being typed into, was still exposed to exactly this failure.
//
// Fix: for as long as zen_cdp_click is ON, keep the viewport locked to
// scale=1 continuously (not just around one click), and actively
// re-snap it if the user has already pinch-zoomed. Re-setting the
// SAME content string is a no-op in Chrome, so an interval alone won't
// undo an existing zoom — each snap below briefly appends a changed
// maximum-scale value and then reverts, which is what actually forces
// the browser back to 1:1 (see repAutoSubmit's original comment for
// the same trick used once instead of continuously).
let _zenCdpZoomInterval = null;
let _zenCdpOrigViewportContent = null;

function _zenSnapZoomTo1() {
  const meta = document.querySelector('meta[name="viewport"]');
  if (!meta) return;
  if (_zenCdpOrigViewportContent == null) {
    _zenCdpOrigViewportContent = meta.getAttribute('content') || '';
  }
  const locked = 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no';
  // Only touch the DOM if it isn't already exactly this value — but even
  // when it IS already this value, an existing pinch-zoom needs a
  // genuinely different string momentarily to force Chrome to re-read it,
  // so we toggle through a distinct intermediate value first.
  meta.setAttribute('content', locked + ', minimum-scale=1');
  meta.setAttribute('content', locked);
}

function _zenRestoreZoom() {
  const meta = document.querySelector('meta[name="viewport"]');
  if (meta && _zenCdpOrigViewportContent != null) {
    try { meta.setAttribute('content', _zenCdpOrigViewportContent); } catch (e) {}
  }
  _zenCdpOrigViewportContent = null;
}

function _zenApplyCdpZoomGuard() {
  if (_zenCdpMode) {
    if (_zenCdpZoomInterval) return; // already running
    _zenSnapZoomTo1();
    // Re-snap periodically — cheap (one attribute write, only when the
    // value actually needs correcting) and catches any zoom that snuck
    // in from a stray touch between polls.
    _zenCdpZoomInterval = setInterval(_zenSnapZoomTo1, 1000);
    console.debug('[ZenCDP] zoom guard engaged — viewport locked to scale=1 while CDP click is ON');
  } else if (_zenCdpZoomInterval) {
    clearInterval(_zenCdpZoomInterval);
    _zenCdpZoomInterval = null;
    _zenRestoreZoom();
    console.debug('[ZenCDP] zoom guard released — viewport restored');
  }
}

let _zenTabId = null;
async function _getTabId() {
  if (_zenTabId != null) return _zenTabId;
  try {
    const r = await chrome.runtime.sendMessage({ type: '__GET_TAB_ID__' });
    _zenTabId = (r && r.tabId) || null;
  } catch (e) { _zenTabId = null; }
  return _zenTabId;
}

// Tracks real mouse position on the page for CDP bezier path start point
let _zenCursorX = Math.round(window.innerWidth / 2);
let _zenCursorY = Math.round(window.innerHeight / 2);
document.addEventListener('mousemove', e => { _zenCursorX = Math.round(e.clientX); _zenCursorY = Math.round(e.clientY); }, { passive: true });

async function _cdpClick(el) {
  const tabId = await _getTabId();
  if (!tabId) {
    console.warn('[ZenCDP] no tabId from background — falling back to pointer click');
    await _pointerClick(el);
    return;
  }

  // ── Safe-zone guard ─────────────────────────────────────────────────────
  // CDP clicks land on whatever is physically at (x,y). Near the very bottom
  // of the screen that is X's bottom nav bar / floating Post button (Grok,
  // Notifications, Messages tabs), and near the top it is the sticky header.
  // So before clicking we make sure the target sits in the middle of the
  // screen (scroll it up a bit if needed), then confirm with elementFromPoint
  // that the click point really belongs to the target. If it doesn't, we skip
  // the CDP click and use the direct element click instead — never a stray tap.
  const inDialog = !!(el.closest && el.closest('[role="dialog"],[aria-modal="true"]'));
  const _zenSafe = () => {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const vh = window.innerHeight, vw = window.innerWidth;
    const topM = Math.max(90, vh * 0.12);
    const botM = inDialog ? 20 : Math.max(130, vh * 0.18);
    const cy = r.top + r.height / 2, cx = r.left + r.width / 2;
    if (r.left < 0 || r.right > vw) return false;
    return cy >= topM && cy <= vh - botM;
  };
  const _zenHitOk = () => {
    const r = el.getBoundingClientRect();
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return !!hit && (hit === el || el.contains(hit) || hit.contains(el));
  };
  let safe = true;
  try {
    for (let i = 0; i < 3 && !_zenSafe(); i++) {
      el.scrollIntoView({ behavior: 'instant', block: 'center', inline: 'nearest' });
      await new Promise(r => setTimeout(r, 200)); // let renderer settle
    }
    // Page couldn't scroll far enough (end of feed)? nudge window up a little.
    if (!_zenSafe() && !inDialog) {
      const r = el.getBoundingClientRect();
      const want = window.innerHeight * 0.45;
      window.scrollBy({ top: (r.top + r.height / 2) - want, behavior: 'instant' });
      await new Promise(r => setTimeout(r, 200));
    }
    safe = _zenSafe() && _zenHitOk();
    if (safe && ZenCursor.active) await ZenCursor.moveTo(el); // cursor follows after scroll
  } catch (e) { safe = true; }
  if (!safe) {
    console.debug('[ZenCDP] target not safely clickable (edge/overlay) — using direct element click');   // debug, not warn: it is a normal fallback, and warn made it pile up in chrome://extensions Errors
    await _pointerClick(el);
    return;
  }

  const rect = el.getBoundingClientRect();

  // ── NO devicePixelRatio multiplication ──────────────────────────────────
  // Per the CDP spec, Input.dispatchMouseEvent's x/y are "relative to the
  // main frame's viewport in CSS pixels" — the exact same units
  // getBoundingClientRect() already returns. There is no physical-pixel
  // conversion step; devicePixelRatio does not belong here at all.
  //
  // The previous code multiplied by dpr, which sent physical-pixel-scaled
  // coordinates into a CSS-pixel API. At dpr=1 (many desktop screens) the
  // multiplication is a no-op and the bug is invisible — which is why it
  // could pass earlier desktop testing. At dpr>1 (Retina/HiDPI desktop
  // displays, and effectively all mobile devices, dpr 2-4) the click
  // coordinates land far outside the target element, usually off the
  // visible page entirely. Input.dispatchMouseEvent still reports success
  // (Chrome does not error just because nothing was under the pointer), so
  // background.js's ok:true response suppressed the pointer-click fallback
  // even though the click hit nothing. That fully explains "toggle ON =
  // total silent failure on both desktop and mobile" without needing a
  // debugger-attach failure or infobar-driven layout shift — attach was
  // succeeding, and the rect was already read live/post-settle, so neither
  // of those was actually at fault.
  const dpr = window.devicePixelRatio || 1;
  const x = Math.round(rect.left + rect.width  / 2 + (Math.random() * 4 - 2));
  const y = Math.round(rect.top  + rect.height / 2 + (Math.random() * 4 - 2));
  const fx = Math.round(_zenCursorX);
  const fy = Math.round(_zenCursorY);

  console.debug('[ZenCDP] click target', {
    tag: el.tagName, testid: el.getAttribute && el.getAttribute('data-testid'),
    rect: { left: rect.left, top: rect.top, width: rect.width, height: rect.height },
    dpr, computed: { x, y }, from: { fx, fy },
    innerWidth: window.innerWidth, innerHeight: window.innerHeight,
  });

  try {
    // ZEX+ — touch-style tap (Input.dispatchTouchEvent) instead of the mouse path; falls back to the mouse click if it fails
    if (window.ZexPlus && ZexPlus.touchOn() && await ZexPlus.tapCdp(x, y)) { _zenCursorX = x; _zenCursorY = y; return; }
    const res = await chrome.runtime.sendMessage({ type: '__CDP_CLICK__', tabId, x, y, fromX: fx, fromY: fy });
    if (!res || !res.ok) {
      console.warn('[ZenCDP] background reported failure, falling back to pointer click', res && res.reason);
      await _pointerClick(el); // fallback if CDP fails
    } else {
      _zenCursorX = x;
      _zenCursorY = y;
    }
  } catch (e) {
    console.warn('[ZenCDP] sendMessage threw, falling back to pointer click', e && e.message);
    await _pointerClick(el); // fallback
  }
}

// Fires a touch sequence (touchstart/touchend) ahead of the mouse/pointer
// sequence below. Real mobile taps generate touch events first, and the
// browser only synthesizes compatibility mouse events afterward — some of
// X's mobile-web tap handlers (this reply icon among them, per reports of
// it not opening on non-desktop mobile web) listen for the touch events
// directly rather than relying on that compatibility layer. Wrapped in
// try/catch since TouchEvent/Touch support varies slightly by browser;
// harmless to skip if unsupported since the mouse sequence still follows.
function _dispatchTouchSequence(el, x, y) {
  try {
    const touchInit = {
      identifier: Date.now() % 100000,
      target: el,
      clientX: x, clientY: y,
      screenX: x + window.screenX, screenY: y + window.screenY,
      pageX: x + window.scrollX, pageY: y + window.scrollY,
      radiusX: 2.5, radiusY: 2.5, rotationAngle: 0, force: 1,
    };
    let touch;
    try { touch = new Touch(touchInit); } catch (e) { touch = touchInit; }
    const touches = [touch];
    el.dispatchEvent(new TouchEvent('touchstart', { touches, targetTouches: touches, changedTouches: touches, bubbles: true, cancelable: true }));
    el.dispatchEvent(new TouchEvent('touchend', { touches: [], targetTouches: [], changedTouches: touches, bubbles: true, cancelable: true }));
  } catch (e) {}
}

function _pointerClick(el) {
  const rect = el.getBoundingClientRect();
  const x = rect.left + rect.width  / 2 + (Math.random() * 4 - 2);
  const y = rect.top  + rect.height / 2 + (Math.random() * 4 - 2);
  _dispatchTouchSequence(el, x, y);
  const opts = {
    bubbles: true, cancelable: true, view: window,
    clientX: x, clientY: y,
    screenX: x + window.screenX,
    screenY: y + window.screenY,
    buttons: 1, button: 0,
    pointerId: 1, pointerType: 'mouse', isPrimary: true,
  };
  el.dispatchEvent(new PointerEvent('pointerover', opts));
  el.dispatchEvent(new PointerEvent('pointerenter', { ...opts, bubbles: false }));
  el.dispatchEvent(new MouseEvent('mouseover',  opts));
  el.dispatchEvent(new MouseEvent('mouseenter', { ...opts, bubbles: false }));
  el.dispatchEvent(new MouseEvent('mousemove',  opts));
  el.dispatchEvent(new PointerEvent('pointerdown', opts));
  el.dispatchEvent(new MouseEvent('mousedown',  opts));
  el.dispatchEvent(new PointerEvent('pointerup',   opts));
  el.dispatchEvent(new MouseEvent('mouseup',    opts));
  el.dispatchEvent(new MouseEvent('click',      opts));
}

async function realClick(el) {
  if (!el) return;

  // ── Animated skin: tell the cursor what this click is for ──
  if (ZenCursor.active) {
    try {
      const tid = (el.closest && el.closest('[data-testid]')) ? el.closest('[data-testid]').getAttribute('data-testid') : '';
      if (tid === 'like') ZenCursor.setState('like');
      else if (tid === 'reply') ZenCursor.setState('comment');
      else if (tid === 'tweetButton' || tid === 'tweetButtonInline') ZenCursor.setState('reply');
    } catch (e) {}
  }

  // ── Move visible cursor to element first (if auto mode is running) ──
  if (ZenCursor.active) {
    await ZenCursor.moveTo(el);
  }

  // ── Flash Lite: a person's finger rests on the button for a moment before pressing (like a bit longer: they glance first) ──
  if (zexLite()) {
    try {
      const _tt = el.closest && el.closest('[data-testid]'); const _id = _tt ? _tt.getAttribute('data-testid') : '';
      if (_id === 'like') await new Promise(r => setTimeout(r, 150 + Math.random() * 200));
      else if (_id === 'reply' || _id === 'tweetButton' || _id === 'tweetButtonInline') await new Promise(r => setTimeout(r, 90 + Math.random() * 170));
    } catch (e) {}
  }

  // ── CDP mode: isTrusted:true click via background debugger ──
  if (_zenCdpMode) {
    await _cdpClick(el);
  } else {
    _pointerClick(el);
  }
}

// ═══ AGENT STATUS TRACKER ════════════════════════════════════════
// Single source of truth for the floating agent dashboard. Every engine
// (SEA/search, FEED, REP) reports into this instead of the dashboard
// polling internals directly.
// Reply timing (History): box open -> generate -> send. Reset when the next box opens.
var _zexTim = { open: 0, gen0: 0 };

// ── Total error log (Agent dashboard + Support tab): every failed reply/step lands here ──
const ZEX_ERRLOG_KEY = 'zexErrLog', ZEX_ERRLOG_MAX = 150;
function zexErrLogPush(eng, msg) {
  try {
    chrome.storage.local.get([ZEX_ERRLOG_KEY], (d) => {
      const arr = Array.isArray(d && d[ZEX_ERRLOG_KEY]) ? d[ZEX_ERRLOG_KEY] : [];
      arr.unshift({ ts: Date.now(), eng: String(eng || ''), msg: String(msg || 'Unknown error').slice(0, 160) });
      chrome.storage.local.set({ [ZEX_ERRLOG_KEY]: arr.slice(0, ZEX_ERRLOG_MAX) });
    });
  } catch (e) {}
}
// Safety: 3x "Something went wrong" after Reply in ONE session (all engines together, not only in a row) -> stop everything.
function zexSafetyHit(eng) {
  try {
    chrome.runtime.sendMessage({ type: 'zexSafetyHit', eng: eng || '' }, (r) => {
      void chrome.runtime.lastError;
      if (r && r.stop) zexSafetyStopAll(r.n);
    });
  } catch (e) {}
}
const ZEX_ENG_KEYS = {
  SEA: { eng: 'zenSearchEngineOn', auto: 'zenSearchAutoMode', cur: () => searchAutoModeOn },
  FED: { eng: 'zenFeedEngineOn',   auto: 'zenFeedAutoMode',   cur: () => feedAutoModeOn },
  REP: { eng: 'zenRepEngineOn',    auto: 'zenAutoRepMode',    cur: () => repAutoModeOn },
  GIV: { eng: 'zenGivEngineOn',    auto: 'zenGivAutoMode',    cur: () => givAutoModeOn },
};
async function zexSafetyStopAll(n) {
  try {
    const bm = (m) => new Promise((res) => { try { chrome.runtime.sendMessage(m, (r) => { void chrome.runtime.lastError; res(r || null); }); } catch (e) { res(null); } });
    const rec = Object.assign({}, (typeof ZexAgentBg !== 'undefined' && ZexAgentBg.resume) || {});
    const upd = { zexSafetyStop: { ts: Date.now(), n: n || 3 } };
    Object.keys(ZEX_ENG_KEYS).forEach((k) => {
      const K = ZEX_ENG_KEYS[k]; rec[k] = { auto: !!K.cur(), ts: Date.now() };
      upd[K.eng] = false; upd[K.auto] = false;
    });
    upd.zenAgentResume = rec; upd.zenSearchCollectOn = false;
    await new Promise((r) => chrome.storage.local.set(upd, r));
    await bm({ type: 'tarStop' }); await bm({ type: 'zenTgStop' }); await bm({ type: 'sessAutoPause', sessionPath: 'telegram_sweep' });
    zexErrLogPush('SAFETY', 'Auto stop: ' + (n || 3) + 'x "Something went wrong" in one session');
    showToast('System auto stopped for safety reasons, take some break buddy', 'warn');
  } catch (e) { console.warn('[Z EX] safety stop failed', e); }
}

const ZenAgentStatus = {
  startedAt: null,            // Date.now() when any engine last turned on
  state: 'idle',               // 'idle' | 'writing' | 'sending' | 'waiting'
  currentModel: null,          // last model string actually used for a call
  currentProvider: null,       // 'Gemini' | 'OpenAI' | 'DeepSeek' | 'Groq' | 'OpenRouter'
  repliesCompleted: 0,         // successful sends this session
  activeModes: [],
  // Persistent counters (survive tab reloads): total / success / failed / posted / drafted, per engine
  stats: { ok: 0, fail: 0, posted: 0, drafted: 0, by: {}, lastError: '', lastErrorTs: 0, lastOkTs: 0, since: Date.now() },
  listeners: [],
};
chrome.storage.local.get(['zenAgentStats'], (d) => {
  if (d && d.zenAgentStats && typeof d.zenAgentStats === 'object') {
    ZenAgentStatus.stats = Object.assign(ZenAgentStatus.stats, d.zenAgentStats);
    zenAgentEmit();
  }
});
ZenAgentStatus.typeMode = { on: false, style: 'style' };
chrome.storage.local.get(['zen_type_mode', 'zen_type_style'], (d) => {
  d = d || {};
  ZenAgentStatus.typeMode = { on: d.zen_type_mode === true, style: d.zen_type_style === 'live' ? 'live' : 'style' };
});
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local') return;
  if ('zen_type_mode' in ch) ZenAgentStatus.typeMode.on = ch.zen_type_mode.newValue === true;
  if ('zen_type_style' in ch) ZenAgentStatus.typeMode.style = ch.zen_type_style.newValue === 'live' ? 'live' : 'style';
  zenAgentEmit();
});
// Auto-reset (background alarm) or another tab changed the counters → adopt them, so this tab does not write old numbers back.
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local' || !ch.zenAgentStats) return;
  const nv = ch.zenAgentStats.newValue;
  if (!nv || typeof nv !== 'object') return;
  const cur = ZenAgentStatus.stats || {};
  if ((Number(nv.since) || 0) > (Number(cur.since) || 0)) {
    ZenAgentStatus.stats = Object.assign({ ok: 0, fail: 0, posted: 0, drafted: 0, by: {}, lastError: '', lastErrorTs: 0, lastOkTs: 0 }, nv);
    zenAgentEmit();
  }
});
function zenAgentSaveStats() { try { chrome.storage.local.set({ zenAgentStats: ZenAgentStatus.stats }); } catch (e) {} }
// engine: 'SEA'|'FED'|'REP'|'GIV'|'TAR'|'MAN'  ok: reply made  posted: actually submitted (auto)
function zexTgRunNow() { return typeof window.__zexSessPath === 'string' && window.__zexSessPath.indexOf('telegram_') === 0; }
function zenAgentRecord(engine, ok, posted, errMsg) {
  try { console.log('[Z EX] Post result', engine, ok ? (posted ? 'POSTED' : 'drafted') : 'FAILED ' + String(errMsg || '').slice(0, 60), _zenCurSid || '-', location.pathname.slice(0, 30)); } catch (e) {}
  try { _zenCurSid = ''; } catch (e) {}   // post finished (done or failed) — the stuck watchdog has nothing left to skip
  const s = ZenAgentStatus.stats;
  const b = s.by[engine] || (s.by[engine] = { ok: 0, fail: 0 });
  if (ok) { s.ok++; b.ok++; s.lastOkTs = Date.now(); if (posted) s.posted++; else s.drafted++; }
  else {
    s.fail++; b.fail++; s.lastError = String(errMsg || 'Unknown error').slice(0, 90); s.lastErrorTs = Date.now();
    zexErrLogPush(engine, errMsg);
    if (/X error after Reply|something went wrong/i.test(String(errMsg || ''))) zexSafetyHit(engine);
  }
  zenAgentSaveStats();
  zenAgentEmit();
  try { chrome.runtime.sendMessage({ type: 'zexDayTick', eng: engine, ok: !!ok, posted: !!posted, err: ok ? '' : String(errMsg || '') }, () => { void chrome.runtime.lastError; }); } catch (e) {}   // Daily Summary
  // Auto-Stop Limits: every successful reply from an engine run counts toward the shared Comment limit.
  // (MAN = a reply the user triggered by hand, not an engine run.)
  if (ok && engine !== 'MAN' && engine !== 'TG') {
    try { chrome.runtime.sendMessage({ type: 'zenLimitTick', kind: 'comment', engine: engine }, () => { void chrome.runtime.lastError; }); } catch (e) {}
  }
}
function zenAgentResetStats() {
  ZenAgentStatus.stats = { ok: 0, fail: 0, posted: 0, drafted: 0, by: {}, lastError: '', lastErrorTs: 0, lastOkTs: 0, since: Date.now() };
  zenAgentSaveStats(); zenAgentEmit();
}

function zenAgentEmit() {
  ZenAgentStatus.listeners.forEach((fn) => { try { fn(ZenAgentStatus); } catch (e) {} });
}

function zenAgentSetState(state, extra) {
  ZenAgentStatus.state = state;
  try {
    if (state === 'writing') ZenCursor.setState('type');
    else if (state === 'sending') ZenCursor.setState('reply');
    else if (state === 'idle') ZenCursor.setState('rest');
  } catch (e) {}
  if (extra && extra.model) {
    ZenAgentStatus.currentModel = extra.model;
    if (extra.provider) ZenAgentStatus.currentProvider = extra.provider;
  }
  zenAgentEmit();
}

function zenAgentMarkEngineOn() {
  if (!ZenAgentStatus.startedAt) ZenAgentStatus.startedAt = Date.now();
  zenAgentEmit();
}

function zenAgentMarkEngineOff() {
  // Only go fully idle/reset the timer once every engine is off — callers
  // check their own combined engine state before calling this.
  ZenAgentStatus.startedAt = null;
  ZenAgentStatus.state = 'idle';
  zenAgentEmit();
}

function zenAgentReplyCompleted() {
  ZenAgentStatus.repliesCompleted++;
  try { ZenCursor.setState('done'); } catch (e) {}
  zenAgentEmit();
}

// ── Extension-context-invalidated guard ─────────────────────────
// This content script keeps running on an open X tab across extension
// reloads/updates during dev (and rare auto-updates in production). Once
// invalidated, any chrome.* call throws "Extension context invalidated" —
// left uncaught, some browsers (Mises included) treat that as a crash and
// disable the extension. This swallows just that one error class and lets
// the recurring scan loops below notice and stop themselves quietly.
function extContextAlive() {
  try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
}
window.addEventListener('error', (e) => {
  const msg = (e && e.message) || (e && e.error && e.error.message) || '';
  if (msg.includes('Extension context invalidated')) e.preventDefault();
});
window.addEventListener('unhandledrejection', (e) => {
  const msg = (e && e.reason && (e.reason.message || String(e.reason))) || '';
  if (msg.includes('Extension context invalidated')) e.preventDefault();
});

// ── Storage-result safety net ────────────────────────────────────
// Some browsers (Mises included) can invoke chrome.storage.local.get's
// callback with `undefined` instead of `{}` when the requested key has
// no stored value yet — real Chrome never does this. Every call site in
// this file assumes it always gets an object back (e.g. `d.someKey`),
// so without this guard a fresh install/empty key throws
// "Cannot read properties of undefined" and can crash the content
// script's engines. This wraps the API once, here, so every existing
// call site downstream is protected without needing to be touched
// individually.
if (chrome && chrome.storage && chrome.storage.local && !chrome.storage.local.__zenSafeGetWrapped) {
  const _zenOrigGet = chrome.storage.local.get.bind(chrome.storage.local);
  chrome.storage.local.get = function (a, b) {
    if (typeof a === 'function') return _zenOrigGet(function (res) { a(res || {}); });
    if (typeof b === 'function') return _zenOrigGet(a, function (res) { b(res || {}); });
    return _zenOrigGet(a, b);
  };
  chrome.storage.local.__zenSafeGetWrapped = true;
}

const TONES = ['Smart', 'Funny', 'Professional', 'Supportive', 'Witty', 'Curious', 'Short', 'Human', 'Alpha', 'Positive', 'PositiveQuestion', 'Helpful', 'Custom', 'Auto'];

// Auto tone randomly cycles Smart, Witty, Human, Alpha, Curious, Positive, PositiveQuestion, Helpful — never repeats same twice in a row
const AUTO_POOL = ['Smart', 'Witty', 'Human', 'Alpha', 'Curious', 'Positive', 'PositiveQuestion', 'Helpful'];
let lastAutoTone = null;

function resolveAutoTone() {
  const available = AUTO_POOL.filter(t => t !== lastAutoTone);
  const chosen = available[Math.floor(Math.random() * available.length)];
  lastAutoTone = chosen;
  return chosen;
}

// ─── Simple tweet-text hash for reply dedup ───────────────────
function tweetHash(str) {
  let h = 0;
  const s = str.slice(0, 120);
  for (let i = 0; i < s.length; i++) {
    h = Math.imul(31, h) + s.charCodeAt(i) | 0;
  }
  return 'zrh_' + Math.abs(h);
}

let selectedTone = 'Smart';
let isGenerating = false;

chrome.storage.local.get(['defaultTone'], (d) => {
  if (d.defaultTone) selectedTone = d.defaultTone;
});

// ─── Own account detection ─────────────────────────────────────
// Uses the X username the person verified inside the extension's own
// login flow (zenDeviceSession.xHandle) — this is the account-ownership
// check the popup already performs (it opens the profile and confirms
// "Edit profile" is present), so it's far more reliable than scraping
// X's DOM for a logged-in-account indicator, which varies across the
// mobile web layout / Kiwi Browser and isn't always present.
let _zenOwnHandle = null;

function refreshOwnHandle() {
  chrome.storage.local.get(['zenDeviceSession'], (d) => {
    const h = d.zenDeviceSession && d.zenDeviceSession.xHandle;
    _zenOwnHandle = h ? String(h).replace(/^@/, '').toLowerCase() : null;
  });
}
refreshOwnHandle();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.zenDeviceSession) refreshOwnHandle();
});

function detectOwnHandle() {
  return _zenOwnHandle;
}

// Returns the lowercase handle (no @) of the article's author, or null.
function getArticleAuthorHandle(article) {
  if (!article) return null;
  try {
    const userNameBlock = article.querySelector('[data-testid="User-Name"]');
    if (userNameBlock) {
      const links = userNameBlock.querySelectorAll('a[href^="/"]');
      for (const a of links) {
        const href = a.getAttribute('href') || '';
        const m = href.match(/^\/([A-Za-z0-9_]+)$/);
        if (m) return m[1].toLowerCase();
      }
    }
  } catch (e) {}
  return null;
}

// ── Promoted / Ad post detection ────────────────────────────────
// X marks promoted posts with a small "Ad" (or "Promoted") label in the
// post header, next to the "..." menu. Localised labels are covered too.
// Engines never inject their button on these, so auto modes skip them.
const ZEN_AD_LABELS = new Set([
  'ad', 'ads', 'promoted', 'sponsored', 'promoted by', 'anzeige', 'gesponsert', 'werbung',
  'publicidad', 'promocionado', 'anuncio', 'publicité', 'sponsorisé', 'promu',
  'annuncio', 'sponsorizzato', 'promovido', 'patrocinado', 'anúncio', 'реклама',
  'reklam', 'reklame', 'iklan', 'quảng cáo', 'إعلان', 'विज्ञापन', 'বিজ্ঞাপন',
  '広告', 'プロモーション', '광고', '推广', '廣告', '推廣'
]);
function isAdArticle(article) {
  try {
    if (!article) return false;
    if (article.dataset && article.dataset.zenAd === '1') return true;
    const nodes = article.querySelectorAll('span, div');
    for (const n of nodes) {
      if (n.children.length > 0) continue;
      const t = (n.textContent || '').trim().toLowerCase();
      if (!t || t.length > 20 || !ZEN_AD_LABELS.has(t)) continue;
      // the tweet's own text / quoted post can legitimately say "Ad" — ignore those
      if (n.closest('[data-testid="tweetText"], [data-testid="card.layoutLarge.detail"]')) continue;
      if (article.dataset) article.dataset.zenAd = '1';
      return true;
    }
  } catch (e) {}
  return false;
}

function isOwnArticle(article) {
  const own = detectOwnHandle();
  if (!own) return false; // can't confirm — don't block replies on uncertainty
  const author = getArticleAuthorHandle(article);
  return !!author && author === own;
}

// ─── Persistent "already replied" tracking ──────────────────────
// Keyed by tweet status ID. Populated only once a reply is confirmed
// actually POSTED (see watchForPostSuccess), so a merely-drafted-but-
// not-sent reply never hides the button.
let _zenRepliedIds = new Set();
let _zenRepliedBy = {};   // statusId -> { eng, ts } — which engine engaged the post first (shared by ALL engines)
// Wallchain score for a post/author (wc_score.js). null when no badge was seen.
function zexWcFor(sid, author) {
  try {
    if (typeof window.zexWcScore !== 'function') return null;
    var v = sid ? window.zexWcScore(String(sid)) : null;
    if (v == null && author) v = window.zexWcScore(String(author));
    return v == null ? null : v;
  } catch (e) { return null; }
}
// ── Wallchain score options (settings: window.zexWcCfg(), written by the popup) ──
// 'ok' = show/run · 'skip' = score outside the range · 'wait' = badge not seen yet (retry on the next scan)
function zexWcGate(article, key) {
  try {
    const c = window.zexWcCfg && window.zexWcCfg()[key];
    if (!c || !c.on) return 'ok';
    const s = window.zexWcScore(article);
    if (s == null) return 'wait';
    return window.zexWcIn(s, c) ? 'ok' : 'skip';
  } catch (e) { return 'ok'; }
}
function zexWcFollowCfg(eng) {
  try { const c = window.zexWcCfg()[eng + 'Follow']; return c && c.on ? c : null; } catch (e) { return null; }
}
const _zexWcSleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── People DB (people_db.js): one shared list of usernames + Wallchain score, used by every engine ──
// Already-followed accounts (my Following scan, Follow engine, Follow-by-score) are never opened / followed / collected again.
function zexIsFollowed(h) { try { return !!(window.ZexPeople && window.ZexPeople.isFollowing(h)); } catch (e) { return false; } }
let _zexPoolQ = [], _zexPoolT = null;
function zexPoolAdd(h) {
  _zexPoolQ.push(String(h).toLowerCase());
  if (_zexPoolT) return;
  _zexPoolT = setTimeout(() => {
    _zexPoolT = null; const q = _zexPoolQ; _zexPoolQ = [];
    try {
      chrome.storage.local.get(['zexWcFollowPool'], (d) => {
        const pool = Array.isArray(d && d.zexWcFollowPool) ? d.zexWcFollowPool : [];
        const have = new Set(pool);
        q.forEach((x) => { if (!have.has(x)) { have.add(x); pool.push(x); } });
        chrome.storage.local.set({ zexWcFollowPool: pool.slice(-2000) });
      });
    } catch (e) {}
  }, 1200);
}
// One post: author's score in range + not followed → saved to the People DB (and the Follow pool when new).
// returns 'added' | 'known' | 'following' | 'out' | 'noscore' | null
function zexPeopleCollectArticle(a, c, src) {
  try {
    const hd = getArticleAuthorHandle(a); if (!hd || !window.ZexPeople) return null;
    const s = window.zexWcScore(a);
    if (s == null) return 'noscore';
    if (!window.zexWcIn(s, c)) return 'out';
    if (window.ZexPeople.isFollowing(hd)) return 'following';
    const isNew = !window.ZexPeople.has(hd);
    window.ZexPeople.add(hd, { s: s, c: 1, src: src });
    if (isNew) zexPoolAdd(hd);
    return isNew ? 'added' : 'known';
  } catch (e) { return null; }
}
// "Collect username by Wallchain while engaging" — FED (home feed) and SEA (search): runs beside the engine, manual or auto.
let _zexColAdded = 0, _zexColToastTs = 0;
setInterval(() => {
  try {
    if (document.hidden || !window.zexWcCfg || !window.ZexPeople) return;
    const all = window.zexWcCfg();
    let c = null, src = '';
    if (feedEngineOn && isHomeFeedUrl(location.href) && all.feedCollect && all.feedCollect.on) { c = all.feedCollect; src = 'FED'; }
    else if (searchEngineOn && isSearchUrl(location.href) && all.searchCollect && all.searchCollect.on) { c = all.searchCollect; src = 'SEA'; }
    if (!c) return;
    for (const a of document.querySelectorAll('article[data-testid="tweet"]')) {
      if (isAdArticle(a) || isOwnArticle(a)) continue;
      if (zexPeopleCollectArticle(a, c, src) === 'added') _zexColAdded++;
    }
    if (_zexColAdded >= 5 || (_zexColAdded > 0 && Date.now() - _zexColToastTs > 30000)) {
      showToast('Collected ' + _zexColAdded + ' username' + (_zexColAdded > 1 ? 's' : '') + ' by Wallchain score', 'success');
      _zexColAdded = 0; _zexColToastTs = Date.now();
    }
  } catch (e) {}
}, 2500);
// Saved list for Follow By Wallchain Score: zexWcFollowLog[handle] = { r: 'new' | 'already', eng, s: score, t: time }.
// Anyone in this list is skipped next time (profile is not opened again). Shown in the Follow card in the popup.
async function zexWcLogFollow(h, r, eng, sc) {
  try {
    const d = await getStorage(['zexWcFollowLog']);
    const log = d.zexWcFollowLog || {};
    log[h] = { r: r, eng: eng, s: sc, t: Date.now() };
    const ks = Object.keys(log);
    if (ks.length > 3000) ks.sort((x, y) => (log[x].t || 0) - (log[y].t || 0)).slice(0, ks.length - 3000).forEach((k) => delete log[k]);
    chrome.storage.local.set({ zexWcFollowLog: log });
  } catch (e) {}
}

// Follow By Wallchain Score (Feed / Search auto loops).
// Finds a post whose author's score is in range → opens that profile → Follow → goes back → loop carries on.
// Returns true when it did something (loop should re-check the page), 'limit' when the max is reached in follow-only mode, else false.
async function zexWcFollowStep(eng, urlOk) {
  const c = zexWcFollowCfg(eng);
  if (!c) return false;
  const st = await getStorage(['zexWcFollowed', 'zexWcFollowStat', 'zexWcFollowLog']);
  const stat = st.zexWcFollowStat || {}, done = st.zexWcFollowed || {}, flog = st.zexWcFollowLog || {};   // flog = saved @names (new follow / already followed) — never opened again
  const lim = Math.max(0, Number(c.limit) || 0);
  if (lim > 0 && (stat[eng] || 0) >= lim) return c.only ? 'limit' : false;

  let pick = null, h = null, sc = null;
  for (const a of document.querySelectorAll('article[data-testid="tweet"]')) {
    if (isAdArticle(a) || isOwnArticle(a)) continue;
    const hd = getArticleAuthorHandle(a);
    if (!hd || done[hd] || flog[hd] || zexIsFollowed(hd)) continue;
    const s = window.zexWcScore(a);
    if (s == null || !window.zexWcIn(s, c)) continue;
    pick = a; h = hd; sc = s; break;
  }
  if (!pick) return false;

  done[h] = Date.now();                       // mark first — a failed try is never repeated for the same account
  const ks = Object.keys(done);
  if (ks.length > 3000) ks.sort((x, y) => done[x] - done[y]).slice(0, ks.length - 3000).forEach((k) => delete done[k]);
  try { chrome.storage.local.set({ zexWcFollowed: done }); } catch (e) {}

  const link = Array.from(pick.querySelectorAll('[data-testid="User-Name"] a[href^="/"]'))
    .find((a) => (a.getAttribute('href') || '').toLowerCase() === '/' + h);
  if (!link) return true;
  const backUrl = location.href;
  await zenWaitForVisible();
  await ensureInViewport(pick, { margin: 40, settle: 200 });
  if (ZenCursor.active) await ZenCursor.moveTo(link);
  await realClick(link);

  let onProfile = false;
  for (let i = 0; i < 20 && !onProfile; i++) { await _zexWcSleep(400); onProfile = location.pathname.toLowerCase() === '/' + h; }
  if (onProfile) {
    await _zexWcSleep(1700 + Math.random() * 900);
    let result = 'fail';
    if (followAlreadyDoneOrUnavailable()) result = 'already';
    else {
      let btn = null;
      for (let i = 0; i < 10 && !btn; i++) { btn = followFindButton(); if (!btn) await _zexWcSleep(400); }
      if (btn) {
        await realClick(btn);
        for (let i = 0; i < 10; i++) {
          await _zexWcSleep(300);
          const nb = followFindButton();
          if ((nb && (nb.textContent || '').trim().toLowerCase() === 'following') || followAlreadyDoneOrUnavailable()) { result = 'followed'; break; }
        }
      }
    }
    if (result === 'followed') {
      stat[eng] = (stat[eng] || 0) + 1;
      try { chrome.storage.local.set({ zexWcFollowStat: stat }); } catch (e) {}
      showToast('Followed @' + h + ' · WC ' + sc + (lim ? ' · ' + stat[eng] + '/' + lim : ''), 'success');
    }
    if (result === 'followed' || result === 'already') { await zexWcLogFollow(h, result === 'followed' ? 'new' : 'already', eng, sc); try { window.ZexPeople && window.ZexPeople.add(h, { s: sc, f: 1, src: eng === 'feed' ? 'FED' : 'SEA' }); } catch (e) {} }
    try { if (typeof zexT === 'function') zexT('wc_visit', { eng: eng === 'feed' ? 'FED' : 'SEA', h: '@' + h, wc: sc, why: result }); } catch (e) {}   // workflow map: every profile it opens
    await _zexWcSleep(600 + Math.random() * 600);
  }
  // back to the timeline / results
  try { history.back(); } catch (e) {}
  let back = false;
  for (let i = 0; i < 20 && !back; i++) { await _zexWcSleep(400); back = urlOk(location.href); }
  if (!back) { location.href = backUrl; await _zexWcSleep(4000); }
  await _zexWcSleep(1200 + Math.random() * 800);
  return true;
}

// Telegram Engage / Sweep: on the opened X post, commenters (visible replies) whose score is in range
// are saved to the Follow pool (zexWcFollowPool) — moved into the Follow list from the popup later.
async function zexWcTgCollect(sessionPath) {
  try {
    const key = sessionPath === 'telegram_sweep' ? 'tgSweep' : 'tgEngage';
    const c = window.zexWcCfg && window.zexWcCfg()[key];
    if (!c || !c.on) return;
    const own = String((await zenTgOwnHandle()) || '').toLowerCase();
    const found = new Set(), foundScore = {};
    for (let round = 0; round < 4; round++) {
      const arts = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
      const mainH = arts.length ? getArticleAuthorHandle(arts[0]) : null;
      arts.slice(1).forEach((a) => {
        const hd = getArticleAuthorHandle(a);
        if (!hd || hd === own || hd === mainH) return;
        const s = window.zexWcScore(a);
        if (s != null && window.zexWcIn(s, c)) { found.add(hd); foundScore[hd] = s; }
      });
      await _zexWcSleep(1100);
    }
    if (!found.size) return;
    const d = await getStorage(['zexWcFollowPool', 'zFollowJob']);
    const pool = Array.isArray(d.zexWcFollowPool) ? d.zexWcFollowPool : [];
    const have = new Set(pool.concat((d.zFollowJob && d.zFollowJob.followed) || []).map((x) => String(x).toLowerCase()));
    let added = 0;
    found.forEach((h) => {
      if (zexIsFollowed(h)) return;                       // already in my Following list → skip
      const isNew = !(window.ZexPeople && window.ZexPeople.has(h));
      try { window.ZexPeople && window.ZexPeople.add(h, { s: foundScore[h], c: 1, src: key === 'tgSweep' ? 'SWP' : 'TGE' }); } catch (e) {}
      if (!have.has(h)) { pool.push(h); added++; }
    });
    if (added) { chrome.storage.local.set({ zexWcFollowPool: pool.slice(-2000) }); showToast('Saved ' + added + ' commenter' + (added > 1 ? 's' : '') + ' to Follow list (Wallchain)', 'success'); }
  } catch (e) {}
}

let _zenIdsReady = false;         // true once the persisted replied/history lists are loaded (until then hasAlreadyReplied() can't be trusted)
let _zenHistoryIds = new Set();   // status IDs of every link saved in Reply History — a saved link = already engaged
function zenHistoryIdSet(hist) {
  const out = new Set();
  if (Array.isArray(hist)) for (const h of hist) { const id = h && repStatusIdSafe(h.link); if (id) out.add(id); }
  return out;
}
chrome.storage.local.get(['zenRepliedStatusIds', 'zenRepliedBy', 'zenReplyHistory'], (d) => {
  if (Array.isArray(d.zenRepliedStatusIds)) _zenRepliedIds = new Set(d.zenRepliedStatusIds);
  if (d.zenRepliedBy && typeof d.zenRepliedBy === 'object') _zenRepliedBy = d.zenRepliedBy;
  _zenHistoryIds = zenHistoryIdSet(d.zenReplyHistory);
  // "Ready" = old lists AND the shared link database (ZexDB) are both loaded.
  Promise.resolve(typeof ZexDB !== 'undefined' ? ZexDB.ready : null).then(() => {
    _zenIdsReady = true;
    try { if (typeof tryInject === 'function') tryInject(); } catch (e) {}   // re-scan: posts seen before the list was ready
  });
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.zenReplyHistory) _zenHistoryIds = zenHistoryIdSet(changes.zenReplyHistory.newValue);
  if (changes.zenRepliedStatusIds) {
    _zenRepliedIds = new Set(Array.isArray(changes.zenRepliedStatusIds.newValue) ? changes.zenRepliedStatusIds.newValue : []);
  }
  if (changes.zenRepliedBy) {
    const v = changes.zenRepliedBy.newValue;
    _zenRepliedBy = (v && typeof v === 'object') ? v : {};
  }
});

// Normalises any engine label (REP/FED/SEA/GIV/TAR, 'tg', 'get', 'FED-GIV'…) to one display tag.
function zenEngTag(raw) {
  const u = String(raw || '').trim().toUpperCase();
  if (u === 'TG') return 'TG';
  if (u === 'SESS') return 'SESS';
  if (u === 'FED' || u === 'FED-GIV') return 'FED';
  if (u === 'REP' || u === 'SEA' || u === 'GIV' || u === 'TAR') return u;
  if (u === 'GET' || u === 'MANUAL') return 'MANUAL';
  return '';
}

function markStatusIdReplied(statusId, eng) {
  if (!statusId) return;
  try { chrome.runtime.sendMessage({ type: 'zexErrFileRemove', link: 'https://x.com/i/status/' + statusId }, () => { void chrome.runtime.lastError; }); } catch (e) {}   // commented now → leaves the Sweep Error file
  const tag = zenEngTag(eng);
  try { if (typeof ZexDB !== 'undefined') ZexDB.set(statusId, 'd', tag); } catch (e) {}
  const isNew = !_zenRepliedIds.has(statusId);
  const needBy = !!tag && !(_zenRepliedBy[statusId] && _zenRepliedBy[statusId].eng);   // first engine wins
  if (!isNew && !needBy) return;
  const upd = {};
  if (isNew) {
    _zenRepliedIds.add(statusId);
    upd.zenRepliedStatusIds = Array.from(_zenRepliedIds).slice(-2000);
  }
  if (needBy) {
    _zenRepliedBy[statusId] = { eng: tag, ts: Date.now() };
    const keys = Object.keys(_zenRepliedBy);
    if (keys.length > 2000) {
      keys.sort((a, b) => ((_zenRepliedBy[a] || {}).ts || 0) - ((_zenRepliedBy[b] || {}).ts || 0))
          .slice(0, keys.length - 2000).forEach((k) => delete _zenRepliedBy[k]);
    }
    upd.zenRepliedBy = _zenRepliedBy;
  }
  chrome.storage.local.set(upd);
}

// The post is known as engaged only from the OLD lists (replied IDs / Reply History) → copy it into the link DB,
// so the Link Checker and every engine see it as DONE from now on.
function zexBackfillDone(sid) {
  try {
    if (!sid || typeof ZexDB === 'undefined' || ZexDB.has(sid)) return;
    const m = _zenRepliedBy[sid];
    ZexDB.set(sid, 'd', (m && m.eng) || '');
  } catch (e) {}
}

function hasAlreadyReplied(statusId) {
  // Shared link database (ZexDB, no size limit) is searched first: found -> skip, not found -> work as normal.
  return !!statusId && ((typeof ZexDB !== 'undefined' && ZexDB.has(statusId)) || _zenRepliedIds.has(statusId) || _zenHistoryIds.has(statusId));
}

// Last-moment guard for every engine's click handler: true = abort (list not loaded yet, or the post was
// already engaged). Removes the engine button so the auto loop moves on instead of retrying it.
function zenAlreadyGuard(article, eng, btn, sid) {
  if (!_zenIdsReady) return true;
  if (sid === undefined) sid = articleStatusId(article);
  if (zexBlockedArticle(article)) { zexLogBlocked(sid, eng, zenArticleLink(article), getArticleAuthorHandle(article)); try { if (btn) btn.remove(); } catch (e) {} return true; }
  if (sid && hasAlreadyReplied(sid)) {
    zexBackfillDone(sid);
    zenLogSkip(sid, eng, zenArticleLink(article), getArticleAuthorHandle(article));
    try { if (btn) btn.remove(); } catch (e) {}
    return true;
  }
  return false;
}
async function zenWaitIdsReady(maxMs) {
  const t0 = Date.now();
  while (!_zenIdsReady && Date.now() - t0 < (maxMs || 5000)) await new Promise((r) => setTimeout(r, 100));
}

// ─── Account lists (Keywords tab): BLACKLIST = never engage that account · WHITELIST = Sweep opens these first ───
// Storage: zexBlackList / zexWhiteList = ['handle', …] (lowercase, no @). Engines skip a blacklisted author's posts and note it in History.
let _zexBL = new Set();
function _zexHandles(a) { return new Set((Array.isArray(a) ? a : []).map((h) => String(h || '').trim().replace(/^@/, '').toLowerCase()).filter(Boolean)); }
try {
  chrome.storage.local.get(['zexBlackList'], (d) => { _zexBL = _zexHandles(d && d.zexBlackList); });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.zexBlackList) _zexBL = _zexHandles(ch.zexBlackList.newValue); });
} catch (e) {}
function zexBlockedArticle(article) {
  try { if (!_zexBL.size || !article) return false; const h = getArticleAuthorHandle(article); return !!h && _zexBL.has(h); } catch (e) { return false; }
}
const _zexBlkLogged = new Set();
function zexLogBlocked(sid, eng, link, author) {
  try {
    if (!sid) return;
    const cur = zenEngTag(eng) || '';
    const key = sid + '|' + cur;
    if (_zexBlkLogged.has(key)) return;
    _zexBlkLogged.add(key);
    chrome.storage.local.get(['zenSkipLog'], (d) => {
      const log = Array.isArray(d.zenSkipLog) ? d.zenSkipLog : [];
      if (log.some((x) => x && x.sid === sid && x.reason === 'blacklist')) return;
      log.unshift({ sid, link: link || ('https://x.com/i/status/' + sid), author: author || '', by: '', cur, reason: 'blacklist', prevReply: '', ts: Date.now() });
      chrome.storage.local.set({ zenSkipLog: log.slice(0, 300) });
    });
  } catch (e) {}
}

// An engine met a post some engine already engaged → skip it and note it in History
// ("Already engaged by <engine>"). Logged once per post per engine (zenSkipLog, capped).
const _zenSkipLogged = new Set();
function zenLogSkip(sid, curEng, link, author) {
  try {
    if (!sid) return;
    const cur = zenEngTag(curEng);
    const key = sid + '|' + cur;
    if (_zenSkipLogged.has(key)) return;
    _zenSkipLogged.add(key);
    const meta = _zenRepliedBy[sid] || null;
    const db = (typeof ZexDB !== 'undefined') ? ZexDB.get(sid) : null;   // why the link database holds this ID
    // The same engine seeing the post it finished a moment ago is not a skip.
    if (meta && meta.eng === cur && Date.now() - (meta.ts || 0) < 30 * 60 * 1000) return;
    chrome.storage.local.get(['zenReplyHistory', 'zenSkipLog'], (d) => {
      const hist = Array.isArray(d.zenReplyHistory) ? d.zenReplyHistory : [];
      const log = Array.isArray(d.zenSkipLog) ? d.zenSkipLog : [];
      if (log.some((x) => x && x.sid === sid && x.cur === cur)) return;
      const prev = hist.find((h) => h && repStatusIdSafe(h.link) === sid);
      let by = (meta && meta.eng) || '';
      if (!by && prev) by = zenEngTag(prev.eng || prev.src || prev.tone);
      if (!by && db && db.code === 'd') by = zenEngTag(db.eng);
      const _why = db && db.code === 'o' ? 'comment_off' : db && db.code === 'b' ? 'commented_before' : undefined;
      log.unshift({
        sid, link: link || (prev && prev.link) || '', author: author || (prev && prev.author) || '',
        by, cur, reason: _why, prevReply: prev ? (prev.reply || '') : '', ts: Date.now(),
        wc: zexWcFor(sid, author) == null ? undefined : zexWcFor(sid, author),
      });
      chrome.storage.local.set({ zenSkipLog: log.slice(0, 300) });
    });
  } catch (e) {}
}

function articleStatusId(article) {
  if (!article) return null;
  const link = article.querySelector('a[href*="/status/"]');
  return link ? repStatusIdSafe(link.href) : null;
}


// ─── Comment-off (replies restricted) detection ─────────────────
// X shows a "Who can reply?" dialog when you tap Reply on a post whose author
// limited replies, and a "Only some accounts can reply" banner on the post page.
// Either one means the comment cannot be done → skip, and save it to History.
const ZEN_COMMENT_OFF_MSG = "Comment couldn't be done — comments are turned off for this post.";
let _zenCommentOffIds = new Set();
chrome.storage.local.get(['zenSkipLog'], (d) => {
  if (Array.isArray(d.zenSkipLog)) for (const x of d.zenSkipLog) if (x && x.reason === 'comment_off' && x.sid) _zenCommentOffIds.add(x.sid);
});
function zenIsCommentOff(sid) {
  if (!sid) return false;
  if (_zenCommentOffIds.has(sid)) return true;
  try { const e = typeof ZexDB !== 'undefined' ? ZexDB.get(sid) : null; return !!(e && e.code === 'o'); } catch (e) { return false; }
}

function zenReplyOffDialogEl() {
  const dlgs = document.querySelectorAll('[role="dialog"], [aria-modal="true"], [data-testid="sheetDialog"]');
  for (const d of dlgs) {
    if (/who can reply\?/i.test(d.innerText || '')) return d;
  }
  return null;
}
// Banner shown on the post page instead of the reply box (no composer present).
function zenReplyOffBannerPresent() {
  if (document.querySelector('[data-testid="tweetTextarea_0"]')) return false;
  const nodes = document.querySelectorAll('main [role="presentation"], main div[dir="ltr"], main span');
  for (const n of nodes) {
    if (n.children.length > 3) continue;
    const t = (n.textContent || '').trim();
    if (t.length < 80 && /^only (some accounts|people[^.]{0,60}|accounts[^.]{0,60}) can reply\.?$/i.test(t)) return true;
  }
  return false;
}
function zenDismissReplyOffDialog() {
  try {
    const d = zenReplyOffDialogEl();
    if (!d) return;
    const btns = d.querySelectorAll('button, [role="button"]');
    for (const b of btns) { if (/^got it$/i.test((b.innerText || '').trim())) { b.click(); return; } }
    const x = d.querySelector('[aria-label="Close"], [data-testid="app-bar-close"]');
    if (x) { x.click(); return; }
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
  } catch (e) {}
}
function zenLogCommentOff(sid, eng, link, author) {
  try {
    const cur = zenEngTag(eng) || '';
    window.__zenReplyOff = { sid: sid || '', ts: Date.now() };
    if (!sid) return;
    _zenCommentOffIds.add(sid);
    try { if (typeof ZexDB !== 'undefined') ZexDB.set(sid, 'o', cur); } catch (e) {}
    chrome.storage.local.get(['zenSkipLog'], (d) => {
      const log = Array.isArray(d.zenSkipLog) ? d.zenSkipLog : [];
      if (log.some((x) => x && x.sid === sid && x.reason === 'comment_off')) return;
      log.unshift({ sid, link: link || ('https://x.com/i/status/' + sid), author: author || '', by: '', cur,
        reason: 'comment_off', prevReply: '', ts: Date.now() });
      chrome.storage.local.set({ zenSkipLog: log.slice(0, 300) });
    });
  } catch (e) {}
}
// ─── System failure / undetected skip → History (FAILED filter) ─────────
// Any post the engine could not finish for its own reasons (error, GET Reply never showed,
// stuck, Telegram link failed) is saved with its link so it can be checked by hand.
// Not logged: comment-off (has its own card) and posts some engine already engaged.
function zenLogFail(sid, eng, link, author, reason) {
  try {
    if (!sid) return;
    if (zenIsCommentOff(sid)) return;
    if (hasAlreadyReplied(sid)) return;
    const cur = zenEngTag(eng) || '';
    const why = reason || 'failed';
    // Every engine's uncompleted link also goes to the Sweep "⚠ Error file" so it can be retried later.
    try { chrome.runtime.sendMessage({ type: 'zexErrFileAdd', link: link || ('https://x.com/i/status/' + sid) }, () => { void chrome.runtime.lastError; }); } catch (e) {}
    chrome.storage.local.get(['zenSkipLog'], (d) => {
      const log = Array.isArray(d.zenSkipLog) ? d.zenSkipLog : [];
      if (log.some((x) => x && x.sid === sid && (x.reason === 'comment_off' || (x.reason === why && x.cur === cur)))) return;
      log.unshift({ sid, link: link || ('https://x.com/i/status/' + sid), author: author || '', by: '', cur,
        reason: why, prevReply: '', ts: Date.now() });
      chrome.storage.local.set({ zenSkipLog: log.slice(0, 300) });
    });
  } catch (e) {}
}
// Error text for callers when repOpenReplyBox returned null.
function zenNoBoxMsg() {
  const r = window.__zenReplyOff;
  return (r && Date.now() - r.ts < 20000) ? ZEN_COMMENT_OFF_MSG : 'Could not open reply box for this post';
}
function zenHandleReplyOff(article, opts) {
  const link = (opts && opts.link) || zenArticleLink(article) || '';
  const sid = repStatusIdSafe(link) || articleStatusId(article) || repStatusIdSafe(location.href) || '';
  const author = (article && getArticleAuthorHandle(article)) || '';
  zenDismissReplyOffDialog();
  zenLogCommentOff(sid, opts && opts.eng, link, author);
  console.warn('[Z EX] Comment is off for this post — skipped.', sid);
}

// Same regex as repStatusId but usable before that function is defined further down.
function repStatusIdSafe(url) {
  if (!url) return null;
  const m = String(url).match(/\/status\/(\d+)/);
  return m ? m[1] : null;
}

// ─── DOM-based "already replied" detection ──────────────────────
// Covers replies made before this session (e.g. manually, or before the
// extension was installed/updated) that were never posted through the
// extension's own tracking. X nests a reply directly under the comment
// it answers as the very next article in that thread — so if that next
// article's author is you, this comment already has your reply.
function threadAlreadyHasOwnReply(article) {
  const own = detectOwnHandle();
  if (!own) return false; // can't confirm — don't hide a button on uncertainty
  try {
    const allArticles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
    const idx = allArticles.indexOf(article);
    if (idx === -1) return false;
    // Check the next couple of articles — the direct reply is normally
    // immediately after, but a "Show more replies" divider or a second
    // reply to the same comment can shift it by one.
    for (let i = idx + 1; i < Math.min(idx + 3, allArticles.length); i++) {
      const next = allArticles[i];
      // Stop scanning once we hit a reply that has its own separate
      // reply-thread line (i.e. a new top-level comment, not a nested one).
      const author = getArticleAuthorHandle(next);
      if (author === own) return true;
    }
  } catch (e) {}
  return false;
}

// ─── Observer ─────────────────────────────────────────────────
// Single timer-debounced MutationObserver. The observer is the only
// injection trigger — no stray setTimeouts that could race with it.
// tryInject is re-entrant-safe via the _zenInjecting guard and the
// DOM-level '.zen-injected' marker.

let injectTimer = null;
let _zenInjecting = false;
let _zenInjectStart = 0;      // when the current tryInject run began (a crashed run can never lock injection forever)
let _zenInjectFirstMut = 0;   // first un-injected mutation — caps how long the debounce may keep postponing

// Debounce with a ceiling: on a busy feed X mutates the DOM non-stop, a plain debounce
// never fires and the GET Reply widget never gets injected. After 1.2s we inject regardless.
const observer = new MutationObserver(() => {
  const now = Date.now();
  if (!_zenInjectFirstMut) _zenInjectFirstMut = now;
  clearTimeout(injectTimer);
  const wait = (now - _zenInjectFirstMut >= 1200) ? 0 : 300;
  injectTimer = setTimeout(() => { _zenInjectFirstMut = 0; tryInject(); }, wait);
});
observer.observe(document.body, { childList: true, subtree: true });

// Two deferred boots cover slow-loading compose boxes without creating
// a race: both converge on the same dedup guard so only one widget
// ever gets attached per toolbar.
setTimeout(tryInject, 800);
setTimeout(tryInject, 2000);

function tryInject() {
  // A run that crashed (or hung) used to leave _zenInjecting = true for good → GET Reply never
  // appeared again until a page reload. Now the flag always resets, and a stale one is ignored after 3s.
  if (_zenInjecting && Date.now() - _zenInjectStart < 3000) return;
  _zenInjecting = true;
  _zenInjectStart = Date.now();
  try { _zenTryInjectBody(); }
  catch (e) { console.warn('[Z EX] GET Reply inject error (recovered)', e); }
  finally { _zenInjecting = false; }
}
function _zenTryInjectBody() {

  // Per-call dedup sets — reset each run so removed+re-added nodes
  // get a fresh widget after a navigation (SPA route change).
  const seenEditors  = new Set();
  const seenToolbars = new Set();

  // Walks up from the compose textarea to find the article of the tweet/comment
  // being replied to — same ancestor-walk pattern used by getTweetText/getTweetLink.
  function findArticleForTextarea(ce) {
    let el = ce;
    for (let i = 0; i < 30; i++) {
      el = el.parentElement;
      if (!el) break;
      const tweets = el.querySelectorAll('[data-testid="tweetText"]');
      if (tweets.length > 0) {
        const article = tweets[tweets.length - 1].closest('article');
        if (article) return article;
      }
    }
    const modal = document.querySelector('[aria-modal="true"], [data-testid="sheetDialog"]');
    if (modal) {
      const tweets = modal.querySelectorAll('[data-testid="tweetText"]');
      if (tweets.length > 0) {
        const article = tweets[tweets.length - 1].closest('article');
        if (article) return article;
      }
    }
    return null;
  }

  function injectFor(ce) {
    if (!ce || seenEditors.has(ce)) return;
    if (!_zenIdsReady) return;   // replied/History list not loaded yet — retried when it is
    seenEditors.add(ce);

    const toolbar = findToolbar(ce);
    if (!toolbar) return;

    // Guard 1 — same toolbar already processed this run
    if (seenToolbars.has(toolbar)) return;
    seenToolbars.add(toolbar);

    // Guard 2 — widget already live in DOM (prevents duplicate on re-observe)
    if (toolbar.querySelector('.zen-injected')) return;

    // Guard 3 — never offer "GET Reply" under your own post/comment.
    const article = findArticleForTextarea(ce);
    if (article && isOwnArticle(article)) return;

    // Guard 4 — never offer "GET Reply" if you've already posted a reply
    // to this exact tweet/comment (tracked persistently once a reply is
    // confirmed sent, or detected directly from X's own thread DOM for
    // replies made before this session).
    if (article) {
      const sid = articleStatusId(article);
      if (hasAlreadyReplied(sid)) return;
      if (threadAlreadyHasOwnReply(article)) {
        if (sid) markStatusIdReplied(sid);
        return;
      }
    }

    const widget = buildWidget(ce);
    toolbar.appendChild(widget);

    // ── Cleanup when this reply box closes ──────────────────────────
    // On some mobile web builds, closing a reply/comment sheet doesn't
    // actually remove its DOM subtree — X keeps a shell mounted and just
    // reuses/hides it, or leaves the old one in place while mounting a
    // fresh sheet for the next box the user opens. Guard 2 above only
    // stops a SECOND widget from being appended into the SAME toolbar
    // node — it does nothing if that toolbar node itself lingers on
    // screen after the user closes the box. That's what made an old
    // "Smart / GET Reply" widget stay visible after opening a second,
    // different reply box (each with its own widget) instead of the
    // first one disappearing when its box closed.
    // Fix: once the editor this widget belongs to is no longer in the
    // document (or has genuinely become invisible), remove the widget
    // itself rather than relying on X to remove its container for us.
    (function watchForClose() {
      let attempts = 0;
      const maxAttempts = 1200; // ~10 minutes ceiling so this can't run forever
      const poll = setInterval(() => {
        attempts++;
        // Two ways a box can "close" on X's mobile web: the sheet subtree
        // is actually removed from the document, OR it's kept mounted but
        // hidden (display:none/visibility toggle on an ancestor) instead
        // of removed — offsetParent becomes null in that second case even
        // though document.body.contains() would still say true. Skip the
        // visibility check for the first couple of ticks so it can't
        // false-trigger before the freshly-appended widget's first layout.
        const removed = !document.body.contains(ce) || !document.body.contains(toolbar);
        const hiddenInPlace = !removed && attempts > 2 && toolbar.offsetParent === null;
        if (removed || hiddenInPlace || attempts >= maxAttempts) {
          clearInterval(poll);
          try { widget.remove(); } catch (e) {}
        }
      }, 500);
    })();
  }

  // Primary: tweetTextarea_0 wrapper -> drill to real editable node
  // (contenteditable on desktop/Lexical, or a plain <textarea> on X's
  // non-desktop mobile web)
  document.querySelectorAll('[data-testid="tweetTextarea_0"]').forEach(wrapper => {
    const ce = _zenResolveEditor(wrapper);
    injectFor(ce);
  });

  // Fallback: root-level compose boxes that skip the tweetTextarea_0 wrapper
  document.querySelectorAll('[data-testid="tweetTextarea_0root"] [contenteditable="true"], [data-testid="tweetTextarea_0root"] textarea').forEach(ce => {
    injectFor(ce);
  });

  // Fallback: mobile bottom sheet (non-desktop web reply modal) — scan
  // directly for a <textarea> in case it isn't wrapped in a testid the
  // selectors above already cover.
  const mobileSheet = document.querySelector('[aria-modal="true"][role="dialog"], [data-testid="sheetDialog"]');
  if (mobileSheet) {
    mobileSheet.querySelectorAll('textarea').forEach(ta => injectFor(ta));
  }

  _zenInjecting = false;
}

// ─── Find toolbar ─────────────────────────────────────────────
function findToolbar(ta) {
  let el = ta;
  for (let i = 0; i < 25; i++) {
    el = el.parentElement;
    if (!el) break;
    const tb = el.querySelector('[data-testid="toolBar"]') ||
               el.querySelector('[role="toolbar"]') ||
               el.querySelector('[data-testid="attachments"]') ||
               el.querySelector('div[style*="justify-content: space-between"]');
    if (tb) {
      let wrap = tb.querySelector('.zen-wrap');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.className = 'zen-wrap';
        wrap.style.cssText = 'display:flex;align-items:center;gap:4px;margin-left:4px;flex-shrink:0;';
        tb.appendChild(wrap);
      }
      return wrap;
    }
  }

  // Modal composer toolbar
  const modal = document.querySelector('[aria-labelledby="modal-header"]');
  if (modal) {
    const bars = modal.querySelectorAll('[role="toolbar"], [data-testid="toolBar"]');
    if (bars.length > 0) {
      const tb = bars[bars.length - 1];
      let wrap = tb.querySelector('.zen-wrap');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.className = 'zen-wrap';
        wrap.style.cssText = 'display:flex;align-items:center;gap:4px;margin-left:4px;flex-shrink:0;';
        tb.appendChild(wrap);
      }
      return wrap;
    }
  }

  // ── x.com/compose/ full-page (non-desktop/mobile mode) ─────────────────
  // On this page X does NOT render [data-testid="toolBar"] or [role="toolbar"].
  // Instead the action bar is a row of icon buttons directly inside the form.
  // We find the bottom action row (the div that holds GIF, emoji, etc.) and
  // append our widget there, OR fall back to injecting a floating bar anchored
  // just above the page bottom so it's always reachable.
  if (/\/compose\//.test(location.pathname)) {
    // Try: find the icon-button row that contains the GIF / emoji icons
    const composeToolbarCandidates = [
      document.querySelector('[data-testid="gifButton"]'),
      document.querySelector('[aria-label="Add GIF"]'),
      document.querySelector('[aria-label="Emoji"]'),
      document.querySelector('[aria-label="Add emoji"]'),
      document.querySelector('[data-testid="scheduleButton"]'),
    ].filter(Boolean);

    for (const anchor of composeToolbarCandidates) {
      // Walk up to the row that directly contains all action buttons
      let row = anchor.parentElement;
      for (let d = 0; d < 6 && row; d++) {
        if (row.children.length >= 3) break; // found the row
        row = row.parentElement;
      }
      if (row) {
        let wrap = row.querySelector('.zen-wrap');
        if (!wrap) {
          wrap = document.createElement('div');
          wrap.className = 'zen-wrap';
          wrap.style.cssText = 'display:inline-flex;align-items:center;gap:4px;margin-left:auto;flex-shrink:0;';
          row.appendChild(wrap);
        }
        return wrap;
      }
    }

    // Hard fallback: inject a fixed bottom bar so GET Reply is always accessible
    // even if X's compose toolbar changes its structure.
    let floatingBar = ZexShadow.$('#zen-compose-floating-bar');
    if (!floatingBar) {
      floatingBar = document.createElement('div');
      floatingBar.id = 'zen-compose-floating-bar';
      floatingBar.style.cssText = [
        'position:fixed', 'bottom:80px', 'right:12px', 'z-index:9999',
        'display:flex', 'align-items:center', 'gap:4px',
        'background:rgba(0,0,0,0.82)', 'padding:5px 8px',
        'border-radius:20px', 'box-shadow:0 2px 12px rgba(0,0,0,0.5)',
      ].join(';');
      ZexShadow.mount(floatingBar);
    }
    return floatingBar;
  }

  return null;
}

// ─── Build Widget ─────────────────────────────────────────────
function buildWidget(textarea) {
  const container = document.createElement('div');
  container.className = 'zen-injected';
  container.style.cssText = 'display:inline-flex;align-items:center;gap:3px;';

  const toneBtn = document.createElement('button');
  toneBtn.className = 'zen-tone-btn';
  toneBtn.innerHTML = `<span class="zen-tone-label">${selectedTone}</span> ▾`;
  toneBtn.title = 'Select tone';

  const replyBtn = document.createElement('button');
  replyBtn.className = 'zen-reply-btn';
  replyBtn.innerHTML = 'GET Reply';
  replyBtn.title = 'Generate AI Reply';

  const trainBtn = document.createElement('button');
  trainBtn.className = 'zen-train-btn';
  trainBtn.innerHTML = '🎓';
  trainBtn.title = 'Type your OWN reply above, then tap this to save it as a training example';

  container.appendChild(toneBtn);
  container.appendChild(replyBtn);
  container.appendChild(trainBtn);

  let dropdown = null;
  toneBtn.addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    if (dropdown) { dropdown.remove(); dropdown = null; return; }
    dropdown = buildToneDropdown(toneBtn, (tone) => {
      selectedTone = tone;
      toneBtn.innerHTML = `<span class="zen-tone-label">${tone}</span> ▾`;
      chrome.storage.local.set({ defaultTone: tone });
      dropdown.remove(); dropdown = null;
    });
    ZexShadow.mount(dropdown);
  });

  document.addEventListener('click', () => {
    if (dropdown) { dropdown.remove(); dropdown = null; }
  });

  // ── GET Reply click ──────────────────────────────────────────
  replyBtn.addEventListener('click', async (e) => {
    e.preventDefault(); e.stopPropagation();
    const cfg = await getStorage(['bigReplyConfig', 'bigReplyMode']);
    const bigOn = cfg.bigReplyMode === true;
    await handleGetReply(textarea, replyBtn, bigOn);
  });

  // ── Train click — saves the user's own hand-typed reply as an example ──
  trainBtn.addEventListener('click', async (e) => {
    e.preventDefault(); e.stopPropagation();
    await handleTrainFromPost(textarea, trainBtn);
  });

  return container;
}

// ─── Train-on-this-post ──────────────────────────────────────────
// Lets the user write their OWN reply in the normal compose box (instead
// of generating one), then save {post, myReply} straight into whichever
// style pool is currently active (a named trained style, or Default) —
// no separate popup needed, no AI reply required first.
async function handleTrainFromPost(textarea, btn) {
  // Re-resolve the live editor the same way handleGetReply does, in case
  // the reference has gone stale (e.g. on the /compose/ page).
  if (/\/compose\//.test(location.pathname)) {
    const liveWrapper = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (liveWrapper) {
      const liveEditor = _zenResolveEditor(liveWrapper);
      if (liveEditor) textarea = liveEditor;
    }
  }

  const ed = _zenResolveEditor(textarea);
  if (!ed) { showToast('Could not find the reply box', 'error'); return; }

  const myReply = (ed.tagName === 'TEXTAREA' ? (ed.value || '') : (ed.innerText || '')).trim();
  const PLACEHOLDERS = ['Post your reply', "What is happening?!", "What's happening?", 'Add another Tweet'];
  const isPlaceholder = !myReply || PLACEHOLDERS.some(p => myReply === p || myReply.startsWith(p + '\n'));
  if (isPlaceholder) {
    showToast('Type your own reply first, then tap 🎓 Train', 'warn');
    return;
  }

  const tweetText = getTweetText(textarea);
  if (!tweetText) { showToast('Could not read the original post text', 'error'); return; }

  const original = btn.innerHTML;
  btn.disabled = true;
  try {
    const saved = await _ragSaveExample(tweetText, myReply);
    showToast(`Saved to "${saved.name}" style ✓`, 'success');
    btn.innerHTML = '✓';
  } catch (e) {
    showToast('Could not save training example', 'error');
  } finally {
    setTimeout(() => { btn.innerHTML = original; btn.disabled = false; }, 1200);
  }
}


// ─── Firebase API Key Sync (Admin → Storage) ──────────────────
// Called before every reply generation to ensure admin-assigned keys are fresh
async function syncAdminApiKey(email) {
  // AI keys stay in the Worker; the Worker enforces the API lock (returns API_LOCKED on generate).
  return { locked: false };
}


let clickTimestamps = [];
let lastActiveSentAt = 0;
async function trackActivity(email) {
  const now = Date.now();
  clickTimestamps.push(now);
  // Keep last 10 clicks
  clickTimestamps = clickTimestamps.filter(t => now - t < 30000);
  const isRapid = clickTimestamps.length >= 3; // 3+ clicks in 30s = Working
  if (now - lastActiveSentAt < 5 * 60 * 1000) return;   // S4b: Worker profile, throttled (was a Firebase write per click)
  lastActiveSentAt = now;
  try { await zenServerCall('/v1/profile', { patch: { lastActive: now, rapidClicks: isRapid ? 1 : 0 } }); } catch (e) {}
}

// ─── ZEXPAY guard (credits / activation) ────────────────────────
// The Worker is the real gate (it re-checks everything on /v1/generate). This just blocks early with a clear message
// using the cached /v1/me (kept fresh by the popup and by every generate response).
async function zpGetMeCached(force) {
  try {
    const st = await new Promise(r => chrome.storage.local.get(['zexpayMe'], r));
    const c = st && st.zexpayMe;
    if (!force && c && (Date.now() - (c.t || 0)) < 60000) return c;
  } catch (e) {}
  try {
    const me = await zenServerCall('/v1/me');
    const c = Object.assign({}, me, { t: Date.now() });
    try { chrome.storage.local.set({ zexpayMe: c }); } catch (e) {}
    return c;
  } catch (e) { return null; }   // network error → fail open here; the Worker still enforces on generate
}
function zpCachePatch(patch) {
  try {
    chrome.storage.local.get(['zexpayMe'], (st) => {
      const c = Object.assign({}, (st && st.zexpayMe) || {}, patch, { t: Date.now() });
      chrome.storage.local.set({ zexpayMe: c });
    });
  } catch (e) {}
}
async function checkAndIncrementReplyCount(email) {
  const me = await zpGetMeCached(false);
  if (me) {
    if (me.api_locked) return { allowed: false, reason: 'Contact Admin' };
    if (me.lock_reason === 'not_approved') return { allowed: false, reason: 'Access not active — contact admin.' };
    if (me.lock_reason === 'expired') return { allowed: false, reason: 'Access expired — contact admin.' };
    if (me.lock_reason === 'needs_first_payment') return { allowed: false, reason: 'Activate your account with the first payment (ZEXPAY tab).' };
    if (me.lock_reason === 'no_credits' || (typeof me.credits === 'number' && me.credits < (me.cost_per_comment || 2))) {
      return { allowed: false, reason: 'No credits left — open the ZEXPAY tab to top up.' };
    }
  }
  // stats-only Firebase bookkeeping (replyCount / daily) was dropped in S4b: nothing stores it any more.
  return { allowed: true };
}

// ─── Shared Reply Handler ──────────────────────────────────────

// Engines (FED / SEA / TAR) call GET Reply for the real work and then record the result
// themselves. This wrapper tells handleGetReply not to ALSO record it as a MAN reply.
async function zenEngineGetReply(editor, btn, big) {
  window.__zenEngGet = true;
  try { return await handleGetReply(editor, btn, big); }
  finally { window.__zenEngGet = false; }
}

async function handleGetReply(textarea, btn, isBigMode) {
    if (isGenerating) return;
    try { _zexTim.gen0 = Date.now(); } catch (e) {}

    // ── On x.com/compose/ page: resolve the live editor fresh ──────────────
    // The textarea reference passed from buildWidget may be stale if X
    // re-mounted its React tree (happens on compose page navigation).
    // Always re-query the real contenteditable on this page type.
    if (/\/compose\//.test(location.pathname)) {
      const liveWrapper = document.querySelector('[data-testid="tweetTextarea_0"]');
      if (liveWrapper) {
        const liveEditor = _zenResolveEditor(liveWrapper);
        if (liveEditor && liveEditor !== textarea) textarea = liveEditor;
      }
    }

    // Internet check
    if (!navigator.onLine) {
      showToast('No internet connection!', 'error');
      return;
    }

    const { zenDeviceSession } = await getStorage(['zenDeviceSession']);
    if (!zenDeviceSession || Date.now() >= zenDeviceSession.expiresAt) {
      showToast('Session expired! Open Z EX and login again.', 'warn');
      return;
    }

    // Sync admin API keys from Firebase (ensures admin-assigned keys are always fresh)
    const syncResult = await syncAdminApiKey(zenDeviceSession.email);
    if (syncResult && syncResult.locked) {
      showToast('Contact Admin', 'error');
      return;
    }

    // Reply limit + API lock check
    const limitCheck = await checkAndIncrementReplyCount(zenDeviceSession.email);
    if (!limitCheck.allowed) {
      if (limitCheck.reason === 'Contact Admin') {
        showToast('Contact Admin', 'error');
      } else {
        showToast('' + limitCheck.reason, 'error');
      }
      return;
    }

    // Track activity
    trackActivity(zenDeviceSession.email);

    const grammarKeys = TONES.map(t => 'useGrammar_' + t);
    const storage = await getStorage(['zexProcLog', 'replyStyle', 'smartSwitch', 'zenRagMode', 'useProjectNameGlobal', 'bigReplyConfig', 'customTonePrompt', 'customToneWords', ...grammarKeys]);
    const smartSwitch = storage.smartSwitch !== false;

    let tweetText = getTweetText(textarea);
    if (!tweetText) tweetText = 'Write a good engaging reply for this tweet.';

    // ── Keyword Reply Check ──────────────────────────────────
    const isKeyword = await checkKeywordMatch(tweetText, textarea);
    if (isKeyword) {
      const authorName = extractAuthorFirstName(textarea);
      const shortReply = buildShortReply(tweetText, authorName);
      try { await insertReply(textarea, shortReply); } catch(e) { return; }
      showToast('Keyword reply!', 'success');
      chrome.storage.local.get(['zenReplyCount'], (d) => {
        chrome.storage.local.set({ zenReplyCount: (d.zenReplyCount || 0) + 1 });
      });

      // Track this reply too, so it shows up in History (with a real link)
      // once it's actually posted — this branch used to skip tracking entirely.
      const tweetLink = getTweetLink(textarea);
      pendingReplyMap.set(textarea, { tweetLink, tweetAuthor: authorName || (zenGetReplyTarget() || {}).author || '', replyText: shortReply, tone: 'Keyword', ts: Date.now() });
      armPostWatcher(textarea);
      trackGetReplyClick(tweetLink, authorName || '');
      return;
    }

    // Resolve effective tone
    let effectiveTone = selectedTone === 'Auto' ? resolveAutoTone() : selectedTone;

    // Big mode uses saved config tone
    if (isBigMode && storage.bigReplyConfig) {
      effectiveTone = storage.bigReplyConfig.tone || effectiveTone;
    }

    if (selectedTone === 'Auto' && !isBigMode) {
      showToast(`Auto → ${effectiveTone}`, 'info');
    }

    // Load previous replies for this tweet (dedup)
    const hashKey = tweetHash(tweetText);
    const prevData = await getStorage([hashKey]);
    const prevReplies = prevData[hashKey] || [];

    isGenerating = true;
    btn.innerHTML = '<span class="zen-spin"></span>';
    btn.disabled = true;

    const procPanel = storage.zexProcLog !== true ? null : createProcessPanel(btn);
    logProcess(procPanel, 'NEURAL LINK ESTABLISHED');
    logProcess(procPanel, 'TONE LOCK: ' + effectiveTone.toUpperCase());
    zenAgentSetState('writing');

    try {
      const toneGrammarKey = 'useGrammar_' + effectiveTone;
      const useGrammar = storage[toneGrammarKey] !== false;
      const useProjectName = storage.useProjectNameGlobal !== false;
      const bigReplyWords = isBigMode ? (storage.bigReplyConfig?.words || '') : null;
      const customPrompt = effectiveTone === 'Custom' ? (storage.customTonePrompt || '') : null;
      const customWords = effectiveTone === 'Custom' ? (storage.customToneWords || '') : null;

      // ── ZEN RAG: pick style examples (sent to the Worker, which builds the prompt) ──
      // 'random' (default): 3 random examples from the pool — no embeddings, cheapest.
      // 'smart' (storage zenRagMode): top-3 most similar (Worker embeddings, keyword fallback).
      let ragExamples = [];
      const ragMode = storage.zenRagMode === 'smart' ? 'smart' : 'random';
      const activePool = await _ragActiveExamples();
      const rawExamples = activePool.examples;
      if (rawExamples.length > 0 && effectiveTone !== 'Custom') {
        try {
          logProcess(procPanel, 'RAG → SEARCHING STYLE EXAMPLES');
          if (ragMode === 'smart') {
            // Cache embeddings in background (doesn't block reply) — write
            // back to whichever pool (named style or Default) this came from.
            _ragCacheExampleEmbeddings(rawExamples, (updated) => {
              if (activePool.styleId) {
                chrome.storage.local.get(['zenTrainedStyles'], d => {
                  const styles = d.zenTrainedStyles || [];
                  const idx = styles.findIndex(s => s.id === activePool.styleId);
                  if (idx === -1) return;
                  const next = styles.slice();
                  next[idx] = { ...styles[idx], examples: updated };
                  chrome.storage.local.set({ zenTrainedStyles: next });
                });
              } else {
                chrome.storage.local.set({ zenStyleExamples: updated });
              }
            }).catch(() => {});
            ragExamples = await findSimilarExamples(tweetText, rawExamples, 3);
          } else {
            ragExamples = rawExamples.slice().sort(() => Math.random() - 0.5).slice(0, 3);
          }
          if (ragExamples.length > 0) logProcess(procPanel, `RAG → ${ragExamples.length} EXAMPLE(S) MATCHED ✓`);
        } catch (e) {
          ragExamples = []; // RAG failed silently — continue with normal prompt
        }
      }

      const liveEditor = (await zenLiveEnabled()) ? textarea : null; // box is already open → stream straight into it
      const reply = await zenLiveGenerate(liveEditor, () => generateReplyWithFallback(
        tweetText, effectiveTone, storage.replyStyle || '',
        smartSwitch, useGrammar, useProjectName, prevReplies, bigReplyWords,
        customPrompt, customWords,
        (line) => { logProcess(procPanel, line); zenAgentTrackStepLine(line); },
        ragExamples, ragMode, zenArticleForEditor(textarea)
      ));

      logProcess(procPanel, 'REPLY SYNTHESIZED ✓');
      removeProcessPanel(procPanel, 900);
      zenAgentSetState('sending');

      try {
        await insertReply(textarea, reply);
      } catch(e) {
        logProcess(procPanel, 'BLOCKED — UNSAFE OUTPUT');
        removeProcessPanel(procPanel, 1600);
        zenAgentSetState('waiting');
        return;
      }

      // ── Track this reply so we can log it to History once it's actually posted ──
      const tweetLink = getTweetLink(textarea);
      const tweetAuthor = extractAuthorFirstName(textarea) || (zenGetReplyTarget() || {}).author || '';
      const _fc = (zenFeedReplyCtx && Date.now() - zenFeedReplyCtx.ts < 120000) ? zenFeedReplyCtx : null;
      pendingReplyMap.set(textarea, { tweetLink, tweetAuthor, replyText: reply, tone: effectiveTone, ...(_fc ? { engine: 'FED', kw: _fc.kw } : {}), ts: Date.now() });
      armPostWatcher(textarea);
      trackGetReplyClick(tweetLink, tweetAuthor);

      const updatedPrev = [...prevReplies, reply].slice(-5);
      chrome.storage.local.set({ [hashKey]: updatedPrev });

      chrome.storage.local.get(['zenReplyCount'], (d) => {
        chrome.storage.local.set({ zenReplyCount: (d.zenReplyCount || 0) + 1 });
      });
      zenAgentReplyCompleted();
      if (!window.__zenEngGet && !zexTgRunNow()) zenAgentRecord('MAN', true, false);   // engine runs (FED/SEA/TAR) record themselves — don't count the same reply twice
      zenAgentSetState('waiting');
      showToast('Reply generated!', 'success');

      // ── ZEN RAG: Thumbs up/down feedback ──────────────────────
      // Show a small inline feedback bar — thumbs up auto-saves this
      // tweet+reply pair into style examples for future matching.
      _ragShowFeedback(textarea, tweetText, reply);
    } catch (err) {
      logProcess(procPanel, 'SEQUENCE FAILED ✗');
      removeProcessPanel(procPanel, 1600);
      zenAgentSetState('waiting');
      if (!window.__zenEngGet && !zexTgRunNow()) zenAgentRecord('MAN', false, false, err && err.message);
      showToast('' + (err.message || 'All APIs failed. Check keys.'), 'error');
    } finally {
      isGenerating = false;
      btn.innerHTML = isBigMode ? 'Big Reply' : 'GET Reply';
      btn.disabled = false;
    }
}

// Parse a process-panel step line for provider/model info so the dashboard
// can show "which API is running" without duplicating the fallback logic.
function zenAgentTrackStepLine(line) {
  if (!line) return;
  const m = line.match(/QUERYING\s*→\s*(.+)/i);
  if (m) {
    const label = m[1].trim();
    let provider = 'Unknown';
    if (/deepseek/i.test(label)) provider = 'DeepSeek';
    else if (/groq/i.test(label)) provider = 'Groq';
    else if (/gemini/i.test(label)) provider = 'Gemini';
    else if (/openai|gpt/i.test(label)) provider = 'OpenAI';
    else if (/openrouter/i.test(label)) provider = 'OpenRouter';
    zenAgentSetState('writing', { model: label, provider });
  }
}








// ─── Extract clean project name from tweet ───────────────────
// ─── Keyword Reply System ──────────────────────────────────────
const AUTO_KEYWORDS = ['gm', 'gn', 'hhm', 'gmm', 'gnnn', 'gmmm', 'happy mutant monday', 'happy mutant', 'good morning', 'good night', 'morning', 'night'];

const GM_REPLIES = ['Gmm {name}', 'Gm {name}', 'Gmmm {name}', 'morning {name}', 'morning legend {name}', 'Gm boss', 'Gm fam', 'Gm ser', 'gm gm', 'rise n grind {name}', 'morning vibes {name}', 'Gm Gm {name}'];
const GN_REPLIES = ['Gn {name}', 'Gnnn {name}', 'sleep well {name}', 'Gn fam', 'rest up {name}', 'Gn ser', 'gn gn', 'night {name}', 'sweet dreams {name}'];
const HHM_REPLIES = ['HHM {name}', 'HHM ser', 'happy mutant {name}', 'HHM fam', 'mutant monday {name}', 'hhm hhm', 'Mutants stay wild {name}'];
const GENERIC_SHORT_REPLIES = ['Gm {name}', 'letsgooo {name}', 'based {name}', 'fr {name}', 'say less {name}', 'W {name}', 'real one {name}', 'facts {name}', 'this {name}', 'always {name}'];

function extractAuthorFirstName(textarea) {
  try {
    let el = textarea;
    for (let i = 0; i < 30; i++) {
      el = el.parentElement;
      if (!el) break;
      const nameEl = el.querySelector('[data-testid="User-Name"] span, [data-testid="UserName"] span');
      if (nameEl) {
        const raw = nameEl.innerText.trim().split(/\s+/)[0].replace(/[^a-zA-Z0-9]/g, '');
        return raw.length > 1 ? raw : null;
      }
    }
    const modal = document.querySelector('[aria-modal="true"], [data-testid="sheetDialog"]');
    if (modal) {
      const nameEl = modal.querySelector('[data-testid="User-Name"] span, [data-testid="UserName"] span');
      if (nameEl) {
        const raw = nameEl.innerText.trim().split(/\s+/)[0].replace(/[^a-zA-Z0-9]/g, '');
        return raw.length > 1 ? raw : null;
      }
    }
  } catch(e) {}
  return null;
}



function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function buildShortReply(tweetText, authorName) {
  const t = tweetText.toLowerCase().trim();
  const name = authorName || '';
  let pool;
  if (/\bgn\b|good night|gnnn|sleep well/.test(t)) {
    pool = GN_REPLIES;
  } else if (/hhm|happy mutant/.test(t)) {
    pool = HHM_REPLIES;
  } else if (/\bgm\b|good morning|gmm|morning/.test(t)) {
    pool = GM_REPLIES;
  } else {
    pool = GENERIC_SHORT_REPLIES;
  }
  let reply = pickRandom(pool);
  reply = reply.replace('{name}', name).trim();
  // Clean up trailing space if no name
  return reply.replace(/\s+/g, ' ').trim();
}

async function checkKeywordMatch(tweetText, textarea) {
  const storage = await getStorage(['autoKeyword', 'customKeyword', 'keywordBox']);
  const autoOn = storage.autoKeyword !== false;
  const customOn = storage.customKeyword !== false;
  const t = tweetText.toLowerCase().trim();
  // Only match if tweet is short (keyword-type posts are short)
  if (tweetText.length > 120) return false;

  if (autoOn) {
    const matched = AUTO_KEYWORDS.some(kw => t === kw || t.startsWith(kw + ' ') || t.endsWith(' ' + kw) || t.includes(' ' + kw + ' '));
    if (matched) return true;
  }

  if (customOn && storage.keywordBox) {
    const customKws = storage.keywordBox.split(',').map(k => k.trim().toLowerCase()).filter(Boolean);
    const matched = customKws.some(kw => t === kw || t.includes(kw));
    if (matched) return true;
  }
  return false;
}



// ─── Prompt Builder ───────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════
// ─── ZEN RAG — Style Examples + Semantic Similarity System ────
// ═══════════════════════════════════════════════════════════════
// Storage key: 'zenStyleExamples' → [{tweet, myReply, embedding?}]
// This is the original, unnamed "Default" example pool — kept exactly as
// before for anyone who never creates a named style (fully backward
// compatible).
//
// Storage key: 'zenTrainedStyles' → [{id, name, examples: [{tweet, myReply, embedding?}]}]
// Named styles the user trains separately from "Default", so a trained
// voice can be given its own name and selected on its own — it no longer
// has to ride along with whichever tone chip happens to be selected.
//
// Storage key: 'zenActiveStyleId' → null (= Default pool) | a zenTrainedStyles id
// Set from the popup's "Trained Styles" chip row; read here so RAG
// matching and every "save this as an example" action (the 👍 feedback
// bar, the on-post Train button, the popup's Save Example button) all
// read from and write to the same currently-selected pool.
//
// Embedding: OpenAI text-embedding-3-small (cached in storage)

// Resolves which example pool is active right now.
// Returns { styleId: null|string, examples: [...] }
async function _ragActiveExamples() {
  const d = await getStorage(['zenActiveStyleId', 'zenTrainedStyles', 'zenStyleExamples']);
  const activeId = d.zenActiveStyleId || null;
  if (activeId) {
    const st = (d.zenTrainedStyles || []).find(s => s.id === activeId);
    if (st) return { styleId: activeId, examples: st.examples || [] };
  }
  return { styleId: null, examples: d.zenStyleExamples || [] };
}

// Appends one {tweet, myReply} example into whichever pool is active
// (a named trained style, or the Default pool), capped at 50.
async function _ragSaveExample(tweet, myReply) {
  const d = await getStorage(['zenActiveStyleId', 'zenTrainedStyles', 'zenStyleExamples']);
  const activeId = d.zenActiveStyleId || null;
  if (activeId) {
    const styles = d.zenTrainedStyles || [];
    const idx = styles.findIndex(s => s.id === activeId);
    if (idx !== -1) {
      const arr = [...(styles[idx].examples || []), { tweet, myReply }];
      if (arr.length > 50) arr.splice(0, arr.length - 50);
      const updated = styles.slice();
      updated[idx] = { ...styles[idx], examples: arr };
      await new Promise(res => chrome.storage.local.set({ zenTrainedStyles: updated }, res));
      return { styleId: activeId, name: styles[idx].name };
    }
  }
  const arr = [...(d.zenStyleExamples || []), { tweet, myReply }];
  if (arr.length > 50) arr.splice(0, arr.length - 50);
  await new Promise(res => chrome.storage.local.set({ zenStyleExamples: arr }, res));
  return { styleId: null, name: 'Default' };
}

// ═══════════════════════════════════════════════════════════════
// ZEX SERVER CLIENT — AI generation runs in the Worker (ZEXPAY). The extension
// sends only tweet text + tone/style/flags; keys and prompts never live here.
// ═══════════════════════════════════════════════════════════════
const ZEX_SERVER_MSG = {
  NO_CREDITS: 'No credits left — top up to continue.',
  NEEDS_FIRST_PAYMENT: 'Activate your account with the first payment.',
  X_NOT_VERIFIED: 'Verify your X account in the ZEX popup first.',
  NOT_APPROVED: 'Access not active — contact admin.',
  EXPIRED: 'Access expired — contact admin.',
  API_LOCKED: 'Contact Admin',
  NO_API_KEY: 'API not connected — contact admin.',
  DAILY_LIMIT: 'Daily limit reached.',
  RATE_LIMIT: 'Too fast — wait a few seconds and try again.',
  NO_AUTH: 'Please sign in again.',
  NETWORK: 'Network error — try again.',
  // M4b: server codes that used to show up raw
  NO_TOKEN: 'Please sign in again.',
  BAD_TOKEN: 'Please sign in again.',
  TOKEN_EXPIRED: 'Please sign in again.',
  NO_EMAIL: 'Please sign in again.',
  EMAIL_NOT_VERIFIED: 'Verify your email, then sign in again.',
  BUSY: 'ZEX is busy — try again in a moment.',
  BUSY_TRY_LATER: 'ZEX is busy — try again in a moment.',
  APPROVAL_CHECK_FAILED: 'ZEX is busy — try again in a moment.',
  JWKS_FETCH_FAILED: 'ZEX is busy — try again in a moment.',
  SERVER_ERROR: 'ZEX server error — try again.',
  EMPTY_TWEET: 'Could not read the post text — try again.',
  EMPTY_COMMENT: 'Could not read the comment text — try again.',
  BAD_ENGINE: 'Request error — try again.',
  BAD_JSON: 'Request error — try again.',
};
function zenServerCall(path, body) {
  return new Promise((resolve, reject) => {
    const fail = (code, msg, data) => { const e = new Error(ZEX_SERVER_MSG[code] || msg || code); e.code = code; e.data = data || null; reject(e); };
    try {
      chrome.runtime.sendMessage({ type: 'zexpayCall', path, body }, (res) => {
        if (chrome.runtime.lastError || !res) return fail('NETWORK');
        if (res.ok) {
          try { if (path === '/v1/generate' && res.data && typeof res.data.credits === 'number') zpCachePatch({ credits: res.data.credits, low: res.data.credits < 100, lock_reason: res.data.credits < 2 ? 'no_credits' : null, locked: res.data.credits < 2 }); } catch (e) {}
          return resolve(res.data);
        }
        try {
          if (path === '/v1/generate') {
            if (res.error === 'NO_CREDITS') zpCachePatch({ credits: 0, lock_reason: 'no_credits', locked: true });
            else if (res.error === 'NEEDS_FIRST_PAYMENT') zpCachePatch({ activated: false, needs_first_payment: true, lock_reason: 'needs_first_payment', locked: true });
          }
        } catch (e) {}
        if (res.error === 'AI_FAILED') return fail('AI_FAILED', 'AI failed: ' + (res.message || 'try again') + ' (credits refunded)', res.data);
        fail(res.error || 'ERR', res.message, res.data);
      });
    } catch (e) { fail('NETWORK'); }
  });
}
async function zenServerGenerate(payload) {
  const r = await zenServerCall('/v1/generate', payload);
  return r;
}
// ── M3b2: post images → Worker (URLs only; the Worker enforces the global switch, allowlist and model vision) ──
// Up to 2 photos of the target post (tweetPhoto + pbs.twimg.com/media only → no avatars / emoji / card thumbs / video / GIF), upgraded to name=large.
function zenGetPostImages(article) {
  const out = [];
  try {
    if (!article || !article.querySelectorAll) return out;
    const imgs = article.querySelectorAll('[data-testid="tweetPhoto"] img[src*="pbs.twimg.com/media"]');
    for (const im of imgs) {
      let u; try { u = new URL(im.currentSrc || im.src); } catch (e) { continue; }
      if (u.protocol !== 'https:' || u.hostname !== 'pbs.twimg.com' || u.pathname.indexOf('/media/') !== 0) continue;
      u.searchParams.set('name', 'large');
      const s = u.toString();
      if (s.length <= 300 && out.indexOf(s) < 0) out.push(s);
      if (out.length >= 2) break;
    }
  } catch (e) {}
  return out;
}
// Same walk-up as getTweetText(): the article of the post the reply box belongs to (null → text only).
function zenArticleForEditor(replyTextarea) {
  try {
    let el = replyTextarea;
    for (let i = 0; i < 30; i++) {
      el = el && el.parentElement;
      if (!el) break;
      const tweets = el.querySelectorAll('[data-testid="tweetText"]');
      if (tweets.length > 0) return tweets[tweets.length - 1].closest('article');
    }
    const modal = document.querySelector('[aria-modal="true"], [data-testid="sheetDialog"]');
    if (modal) { const t = modal.querySelectorAll('[data-testid="tweetText"]'); if (t.length > 0) return t[t.length - 1].closest('article'); }
  } catch (e) {}
  return null;
}
// Honours the popup toggle (zenReadImages, default ON) and the cached /v1/me (global switch OFF, or no vision-capable model → skip the work).
async function zenImagesFor(article) {
  try {
    const d = await new Promise(r => chrome.storage.local.get(['zenReadImages'], r));
    if (d && d.zenReadImages === false) return [];
    const me = await zpGetMeCached(false);
    if (me && (me.vision_enabled === false || me.vision === false)) return [];
    return zenGetPostImages(article);
  } catch (e) { return []; }
}
// ── M4b: quoted-post text + image alt text → small extra context (<=300 chars total, nothing when empty) ──
// Appended to payload.tweet inside zenWithImages(), so reply / rep / feed / giv all get it without touching any call site.
// Text only (no image bytes): not tied to the image switches. Dropped if it would push the tweet past the Worker's 1500-char clip.
const ZEN_CTX_QUOTE_MAX = 200, ZEN_CTX_ALT_MAX = 100, ZEN_CTX_TWEET_MAX = 1500;
const ZEN_CTX_GENERIC_ALT = /^(image|images|photo|picture|gif|embedded video|video)$/i;   // X's default alt when the author wrote none
function zenCtxClean(v, max) {
  const t = String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  return t.length > max ? t.slice(0, max - 1).trimEnd() + '…' : t;
}
function zenGetPostContext(article, baseText) {
  const out = { quote: '', alt: '' };
  try {
    if (!article || !article.querySelectorAll) return out;
    const base = String(baseText || '').replace(/\s+/g, ' ').trim().toLowerCase();
    // quoted post = a tweetText that sits inside a role=link card nested in the article
    for (const n of article.querySelectorAll('[data-testid="tweetText"]')) {
      const card = n.closest('[role="link"]');
      if (!card || card === article || !article.contains(card)) continue;
      const q = zenCtxClean(n.innerText || n.textContent, ZEN_CTX_QUOTE_MAX);
      if (q.length < 3) continue;
      if (base && base.indexOf(q.toLowerCase().slice(0, 40)) >= 0) break;   // already part of the text we send (getTweetText can pick the quoted text itself)
      out.quote = q; break;
    }
    const alts = [];
    for (const im of article.querySelectorAll('[data-testid="tweetPhoto"] img')) {
      const a = zenCtxClean(im.getAttribute('alt'), ZEN_CTX_ALT_MAX);
      if (a.length < 4 || ZEN_CTX_GENERIC_ALT.test(a) || alts.indexOf(a) >= 0) continue;
      alts.push(a); if (alts.length >= 2) break;
    }
    out.alt = zenCtxClean(alts.join(' | '), ZEN_CTX_ALT_MAX);
  } catch (e) {}
  return out;
}
function zenContextSuffix(article, baseText) {
  const c = zenGetPostContext(article, baseText), parts = [];
  if (c.quote) parts.push('[Quoted post: ' + c.quote + ']');
  if (c.alt) parts.push('[Image description: ' + c.alt + ']');
  return parts.length ? '\n\n' + parts.join('\n') : '';
}
async function zenWithImages(payload, article) {
  const imgs = await zenImagesFor(article);
  if (imgs.length) payload.images = imgs;
  try {   // M4b
    const suf = zenContextSuffix(article, payload.tweet), cur = String(payload.tweet || '');
    if (suf && cur.length + suf.length <= ZEN_CTX_TWEET_MAX) payload.tweet = cur + suf;
  } catch (e) {}
  return payload;
}
// AI generation can legitimately take 20s+ (fallback model, slow API). Keep the stuck watchdog fed while it
// runs — but only for 30s, so a truly hung AI call still gets caught.
function zexAiBeat() {
  const t0 = Date.now();
  zenProgress();
  const id = setInterval(() => { if (Date.now() - t0 < 30000) zenProgress(); else clearInterval(id); }, 2000);
  return () => clearInterval(id);
}
async function generateReplyWithFallback(...a) { const stop = zexAiBeat(); try { return await _generateReplyWithFallbackRaw(...a); } finally { stop(); } }
async function repGenerateReplyWithFallback(...a) { const stop = zexAiBeat(); try { return await _repGenerateReplyWithFallbackRaw(...a); } finally { stop(); } }

async function _generateReplyWithFallbackRaw(tweetText, tone, style, smartSwitch, useGrammar, useProjectName, prevReplies, bigReplyWords, customPrompt, customWords, onStep, ragExamples, ragMode, article) {
  const step = typeof onStep === 'function' ? onStep : () => {};
  step('SCANNING TWEET CONTEXT');
  const ex = (ragExamples || []).map(e => ({ tweet: e.tweet, myReply: e.myReply }));
  if (ex.length) step('RAG STYLE MATCHED ✓');
  step('QUERYING → ZEX SERVER');
  const r = await zenServerGenerate(await zenWithImages({
    engine: 'reply', tweet: tweetText, tone, style, use_grammar: useGrammar, use_project_name: useProjectName,
    prev_replies: prevReplies || [], big_reply_words: bigReplyWords || '', custom_prompt: customPrompt || '', custom_words: customWords || '',
    smart_switch: smartSwitch === true, rag_examples: ex, rag_mode: ragMode === 'smart' ? 'smart' : 'random',
  }, article));
  step('ZEX SERVER OK ✓');
  return r.reply;
}
async function feedGenerateReplyWithFallback(postText, smartSwitch, article) {
  const r = await zenServerGenerate(await zenWithImages({ engine: 'feed', tweet: postText, smart_switch: smartSwitch === true }, article));
  return r.reply;
}
async function _repGenerateReplyWithFallbackRaw(postText, commentText, smartSwitch, article) {
  const r = await zenServerGenerate(await zenWithImages({ engine: 'rep', tweet: postText, comment: commentText, smart_switch: smartSwitch === true }, article));
  return r.reply;
}
// Giveaway yes/no check. Fails closed (false) on any error, like before.
async function givClassifyWithFallback(postText, smartSwitch, article) {
  try {
    const r = await zenServerGenerate(await zenWithImages({ engine: 'giv', tweet: postText, smart_switch: smartSwitch === true }, article));
    return r.answer === true;
  } catch (e) { return false; }
}

const _ragEmbedCache = new Map(); // in-memory: text → float[]

let _ragEmbedDownUntil = 0;   // Worker has no embedding key → skip embedding calls for a while (keyword fallback)
async function _ragEmbedBatch(texts) {
  if (Date.now() < _ragEmbedDownUntil) throw new Error('Embeddings unavailable');
  try {
    const r = await zenServerCall('/v1/embed', { texts: texts.map(t => String(t).slice(0, 512)) });
    if (!r || !Array.isArray(r.embeddings) || r.embeddings.length !== texts.length) throw new Error('No embedding returned');
    return r.embeddings;
  } catch (e) {
    if (e && (e.code === 'EMBED_UNAVAILABLE' || e.code === 'DAILY_LIMIT')) _ragEmbedDownUntil = Date.now() + 10 * 60 * 1000;
    throw e;
  }
}
async function _ragGetEmbedding(text) {
  const key = text.slice(0, 200);
  if (_ragEmbedCache.has(key)) return _ragEmbedCache.get(key);
  const vec = (await _ragEmbedBatch([text]))[0];
  _ragEmbedCache.set(key, vec);
  return vec;
}

function _ragCosineSim(a, b) {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na  += a[i] * a[i];
    nb  += b[i] * b[i];
  }
  return na && nb ? dot / (Math.sqrt(na) * Math.sqrt(nb)) : 0;
}

// Keyword fallback when no API key — simple word overlap score
function _ragKeywordSim(a, b) {
  const tok = s => new Set(s.toLowerCase().match(/\b\w{3,}\b/g) || []);
  const sa = tok(a), sb = tok(b);
  let inter = 0;
  for (const w of sa) if (sb.has(w)) inter++;
  return inter / Math.max(sa.size + sb.size - inter, 1);
}

// ── Find top-N similar style examples for a given tweet ─────────
async function findSimilarExamples(newTweetText, savedExamples, topN = 3) {
  if (!savedExamples || savedExamples.length === 0) return [];

  let useEmbedding = Date.now() >= _ragEmbedDownUntil;
  let newVec = null;

  if (useEmbedding) {
    try {
      newVec = await _ragGetEmbedding(newTweetText);
    } catch (e) {
      useEmbedding = false; // fall back to keyword
    }
  }

  const scored = await Promise.all(savedExamples.map(async (ex) => {
    let score = 0;
    if (useEmbedding) {
      try {
        // Use cached embedding if stored, else fetch
        let exVec = ex.embedding || null;
        if (!exVec) {
          exVec = await _ragGetEmbedding(ex.tweet);
        }
        score = _ragCosineSim(newVec, exVec);
      } catch (e) {
        score = _ragKeywordSim(newTweetText, ex.tweet);
      }
    } else {
      score = _ragKeywordSim(newTweetText, ex.tweet);
    }
    return { ...ex, _score: score };
  }));

  return scored
    .sort((a, b) => b._score - a._score)
    .slice(0, topN)
    .filter(ex => ex._score > 0.05); // ignore totally unrelated examples
}

// ── Compute + cache embeddings for all saved examples ────────────
// writeBack(updatedExamples) persists them to wherever they came from —
// the caller passes a closure scoped to the active pool.
async function _ragCacheExampleEmbeddings(examples, writeBack) {
  if (!examples.length || Date.now() < _ragEmbedDownUntil) return examples;
  const updated = [...examples];
  const need = [];
  for (let i = 0; i < updated.length; i++) if (!updated[i].embedding) need.push(i);
  let changed = false;
  for (let s = 0; s < need.length; s += 20) {
    const idx = need.slice(s, s + 20);
    try {
      const vecs = await _ragEmbedBatch(idx.map(i => updated[i].tweet));
      idx.forEach((i, k) => { updated[i] = { ...updated[i], embedding: vecs[k] }; });
      changed = true;
    } catch (e) { break; /* retry next time */ }
  }
  if (changed && typeof writeBack === 'function') writeBack(updated);
  return updated;
}


// ═══════════════════════════════════════════════════════════════
// ── Thumbs up/down feedback bar ─────────────────────────────────
function _ragShowFeedback(textarea, tweetText, reply) {
  // ── Auto-save to Recent Replies (always, regardless of 👍/👎) ──
  // Capped at 30 — oldest dropped. User reviews in Style tab later.
  chrome.storage.local.get(['zenRecentReplies'], d => {
    const arr = [
      { tweet: tweetText, myReply: reply, ts: Date.now() },
      ...(d.zenRecentReplies || []),
    ].slice(0, 30);
    chrome.storage.local.set({ zenRecentReplies: arr });
  });

  // Remove any previous feedback bar
  ZexShadow.$$('.__zen_rag_fb__').forEach(el => el.remove());

  const bar = document.createElement('div');
  bar.className = '__zen_rag_fb__';
  bar.style.cssText = [
    'position:fixed', 'bottom:90px', 'right:14px',
    'z-index:2147483646',
    'background:#1a1a1a', 'color:#fff',
    'padding:7px 12px', 'border-radius:20px',
    'font-size:12px', 'display:flex', 'align-items:center', 'gap:8px',
    'box-shadow:0 2px 12px rgba(0,0,0,.4)',
    'font-family:system-ui,sans-serif',
    'opacity:0', 'transition:opacity .2s',
  ].join(';');

  bar.innerHTML = `
    <span style="opacity:.7;font-size:11px;">Good reply?</span>
    <button id="__rag_up__" title="Save as style example" style="background:none;border:none;cursor:pointer;font-size:16px;padding:0;line-height:1;">👍</button>
    <button id="__rag_dn__" title="Dismiss" style="background:none;border:none;cursor:pointer;font-size:16px;padding:0;line-height:1;">👎</button>`;

  ZexShadow.mount(bar);
  requestAnimationFrame(() => { bar.style.opacity = '1'; });

  const dismiss = () => {
    bar.style.opacity = '0';
    setTimeout(() => bar.remove(), 200);
  };

  bar.querySelector('#__rag_up__').addEventListener('click', async () => {
    // Remove from recent (promoted to saved examples) regardless of which
    // pool it lands in.
    chrome.storage.local.get(['zenRecentReplies'], d => {
      const recent = (d.zenRecentReplies || []).filter(
        r => !(r.tweet === tweetText && r.myReply === reply)
      );
      chrome.storage.local.set({ zenRecentReplies: recent });
    });
    const saved = await _ragSaveExample(tweetText, reply);
    showToast(`Saved to "${saved.name}" style ✓`, 'success');
    dismiss();
  });

  bar.querySelector('#__rag_dn__').addEventListener('click', dismiss);

  // Auto-dismiss after 6s
  setTimeout(dismiss, 6000);
}

// END ZEN RAG
// ═══════════════════════════════════════════════════════════════


// ─── Tone Dropdown ────────────────────────────────────────────
// ─── AI Process Readout (sci-fi style, shows real generation steps) ──
function createProcessPanel(anchor) {
  const rect = anchor.getBoundingClientRect();
  const panel = document.createElement('div');
  panel.className = 'zen-proc-panel';
  panel.style.cssText = `
    position:fixed;top:${rect.bottom + 6}px;left:${rect.left}px;
    min-width:210px;max-width:250px;
    background:#17181a;border:1px solid rgba(234,179,8,0.3);border-radius:9px;
    padding:8px 10px;z-index:9999999;overflow:hidden;
    box-shadow:0 8px 26px rgba(0,0,0,0.65),0 0 18px rgba(234,179,8,0.14);
    font-family:'ZexPixel','Courier New',monospace;font-size:12px;line-height:1.5;
    color:#facc15;pointer-events:none;
  `;

  const rain = document.createElement('canvas');
  rain.className = 'zen-proc-rain';
  rain.style.cssText = `
    position:absolute;inset:0;width:100%;height:100%;
    opacity:0.22;pointer-events:none;z-index:0;
  `;
  panel.appendChild(rain);

  const logLayer = document.createElement('div');
  logLayer.className = 'zen-proc-loglayer';
  logLayer.style.cssText = 'position:relative;z-index:1;';
  panel.appendChild(logLayer);
  panel._logLayer = logLayer;

  ZexShadow.mount(panel);
  panel._queue = Promise.resolve();
  startProcRain(panel, rain);
  return panel;
}

function startProcRain(panel, canvas) {
  const ctx = canvas.getContext('2d');
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let w, h, cols, drops;

  function size() {
    const r = panel.getBoundingClientRect();
    w = canvas.width = Math.max(1, Math.round(r.width));
    h = canvas.height = Math.max(1, Math.round(r.height));
    cols = Math.max(1, Math.floor(w / 12));
    drops = new Array(cols).fill(0).map(() => Math.random() * -20);
  }
  size();

  ctx.font = '11px monospace';
  // Low-power: ~14 fps (was a 60 fps loop), nothing drawn while the tab is hidden or the panel is collapsed.
  let tm = 0, gone = 0;
  function draw() {
    tm = 0;
    if (!panel.isConnected) return;
    if (document.hidden) return;                                   // visibilitychange restarts it
    if (!canvas.isConnected) { if (++gone > 20) return; tm = setTimeout(draw, 500); return; }
    gone = 0;
    if (!canvas.getClientRects().length) { tm = setTimeout(draw, 500); return; }   // collapsed / display:none → no drawing
    ctx.fillStyle = 'rgba(23,24,26,0.25)';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#eab308';
    for (let i = 0; i < cols; i++) {
      const ch = chars[Math.floor(Math.random() * chars.length)];
      ctx.fillText(ch, i * 12, drops[i] * 12);
      if (drops[i] * 12 > h && Math.random() > 0.975) drops[i] = 0;
      drops[i]++;
    }
    tm = setTimeout(draw, 70);
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden && !tm && panel.isConnected) draw(); });
  tm = setTimeout(draw, 70);
}

const ZEN_SCRAMBLE_CHARS = '!<>-_\\/[]{}—=+*^?#';

function typeProcessLine(panel, text) {
  return new Promise((resolve) => {
    if (!panel || !panel.isConnected) { resolve(); return; }
    const layer = panel._logLayer || panel;
    const line = document.createElement('div');
    line.style.cssText = 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
    layer.appendChild(line);
    while (layer.children.length > 6) layer.removeChild(layer.firstChild);

    const full = '▸ ' + text;
    const length = full.length;
    const queue = [];
    for (let i = 0; i < length; i++) {
      const start = Math.floor(Math.random() * 12);
      const end = start + Math.floor(Math.random() * 14) + 4;
      queue.push({ to: full[i], start, end, char: '' });
    }

    let frame = 0;
    const timer = setInterval(() => {
      if (!panel.isConnected) { clearInterval(timer); resolve(); return; }
      let output = '';
      let complete = 0;
      for (let i = 0; i < length; i++) {
        const q = queue[i];
        if (frame >= q.end) {
          complete++;
          output += q.to;
        } else if (frame >= q.start) {
          if (!q.char || Math.random() < 0.28) {
            q.char = ZEN_SCRAMBLE_CHARS[Math.floor(Math.random() * ZEN_SCRAMBLE_CHARS.length)];
          }
          output += `<span class="zen-proc-dud">${q.char}</span>`;
        } else {
          output += ' ';
        }
      }
      line.innerHTML = output;
      frame++;
      if (complete === length) {
        clearInterval(timer);
        line.innerHTML = full; // settle to clean final text
        resolve();
      }
    }, 28);
  });
}

function logProcess(panel, text) {
  if (!panel) return;
  panel._queue = (panel._queue || Promise.resolve()).then(() => typeProcessLine(panel, text));
}

function removeProcessPanel(panel, delay) {
  if (!panel) return;
  (panel._queue || Promise.resolve()).then(() => {
    setTimeout(() => {
      if (!panel.isConnected) return;
      panel.style.transition = 'opacity .35s';
      panel.style.opacity = '0';
      setTimeout(() => panel.remove(), 350);
    }, delay || 900);
  });
}

function buildToneDropdown(anchor, onSelect) {
  const rect = anchor.getBoundingClientRect();
  const dd = document.createElement('div');
  dd.style.cssText = `
    position:fixed;top:${rect.bottom + 6}px;left:${rect.left}px;
    background:#0d1220;border:1px solid rgba(0,170,255,0.3);border-radius:10px;
    padding:6px;z-index:9999999;
    box-shadow:0 8px 30px rgba(0,0,0,0.7),0 0 20px rgba(0,100,255,0.15);
    display:grid;grid-template-columns:1fr 1fr;gap:4px;min-width:200px;
    font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  `;
  TONES.forEach(tone => {
    const item = document.createElement('button');
    const isActive = tone === selectedTone;
    const isAuto = tone === 'Auto';
    item.style.cssText = `
      background:${isActive ? 'rgba(0,170,255,0.15)' : isAuto ? 'rgba(0,255,150,0.05)' : 'transparent'};
      border:1px solid ${isActive ? 'rgba(0,170,255,0.5)' : isAuto ? 'rgba(0,255,150,0.3)' : 'transparent'};
      border-radius:7px;color:${isActive ? '#00aaff' : isAuto ? '#00ffaa' : '#aac4dd'};
      font-size:12px;font-weight:600;padding:8px 10px;cursor:pointer;
      display:flex;align-items:center;gap:6px;transition:all 0.15s;width:100%;text-align:left;
    `;
    item.innerHTML = tone;
    item.addEventListener('mouseover', () => { if (!isActive) item.style.background = 'rgba(255,255,255,0.05)'; });
    item.addEventListener('mouseout', () => { if (!isActive) item.style.background = isAuto ? 'rgba(0,255,150,0.05)' : 'transparent'; });
    item.addEventListener('click', (e) => { e.stopPropagation(); onSelect(tone); });
    dd.appendChild(item);
  });
  return dd;
}

// ─── Get Tweet Text ───────────────────────────────────────────
function getTweetText(replyTextarea) {
  // Walk up ancestors first — works for inline reply boxes
  let el = replyTextarea;
  for (let i = 0; i < 30; i++) {
    el = el.parentElement;
    if (!el) break;
    const tweets = el.querySelectorAll('[data-testid="tweetText"]');
    if (tweets.length > 0) return tweets[tweets.length - 1].innerText.trim();
  }

  // Modal / sheet dialog composer
  const modal = document.querySelector('[aria-modal="true"], [data-testid="sheetDialog"]');
  if (modal) {
    const tweets = modal.querySelectorAll('[data-testid="tweetText"]');
    if (tweets.length > 0) return tweets[tweets.length - 1].innerText.trim();
  }

  // ── x.com/compose/ full-page (mobile non-desktop mode) ─────────────────
  // On this page the original tweet is NOT rendered as [data-testid="tweetText"].
  // Instead X renders a quoted tweet block whose text lives in a plain <span>
  // or <div> inside a styled card above the composer. We try several selectors
  // that match the compose-reply preview block in current X markup.
  const composePage = /\/compose\//.test(location.pathname);
  if (composePage) {
    // Selector 1: any article element visible on the compose page
    const article = document.querySelector('article[data-testid="tweet"]');
    if (article) {
      const t = article.querySelector('[data-testid="tweetText"]');
      if (t) return t.innerText.trim();
      // Fallback: collect all readable text from the article block
      const raw = (article.innerText || '').trim();
      if (raw.length > 10) return raw;
    }

    // Selector 2: the "replying to" quoted preview block — X wraps it in a
    // div with role="group" or a generic card div; grab all visible text.
    const previewBlocks = document.querySelectorAll(
      '[data-testid="reply-preview"], ' +
      '[data-testid="tweet-text-show-more-link"],' +
      'div[role="group"] [lang],' +
      'div[dir="auto"][lang]'
    );
    for (const pb of previewBlocks) {
      const txt = (pb.innerText || '').trim();
      if (txt.length > 10 && !/^@/.test(txt)) return txt;
    }

    // Selector 3: last resort — largest visible text block on the compose page
    // that isn't the composer itself (which is [contenteditable="true"])
    const spans = document.querySelectorAll('span[dir="auto"], div[dir="auto"]');
    let best = '';
    for (const s of spans) {
      if (s.querySelector('[contenteditable]')) continue; // skip the editor itself
      if (s.closest('[contenteditable]')) continue;
      const txt = (s.innerText || '').trim();
      if (txt.length > best.length && txt.length > 20) best = txt;
    }
    if (best) return best;
  }

  // Global fallback — any tweetText in the document
  const all = document.querySelectorAll('[data-testid="tweetText"]');
  for (let i = all.length - 1; i >= 0; i--) {
    const t = all[i].innerText.trim();
    if (t.length > 5) return t;
  }
  return null;
}

// ─── Paste Reply ──────────────────────────────────────────────
// X (Twitter) uses DraftJS with a contenteditable div. The problem:
//
//   execCommand('insertText') after selectNodeContents leaves a ghost
//   layer because DraftJS maintains its OWN internal EditorState tree
//   that does NOT update from DOM mutations — it only updates from
//   specific synthetic events it handles internally.
//
// The ONLY reliable method that works on Kiwi/mobile Chrome is:
//
//   1. Focus the editor
//   2. Ctrl+A to select all (via KeyboardEvent) so DraftJS clears its state
//   3. Use the Clipboard API / execCommand('paste') with a DataTransfer
//      OR fall back to insertText on the empty selection
//   4. Fire the full event chain DraftJS expects: keydown → input → keyup
//
// We use a THREE-STEP approach:
//   Step A: Clear via Ctrl+A + Delete keystrokes (DraftJS handles these natively)
//   Step B: Insert via execCommand('insertText') into the now-empty editor
//   Step C: Dispatch a 'change'-like input event chain to unlock the Reply button
//
// The key fix over the previous version: we do NOT use execCommand('delete')
// because that bypasses DraftJS state. Instead we simulate real keyboard
// events (keydown/keyup for Ctrl+A then Delete) that DraftJS intercepts.

// ─── Paste Reply ──────────────────────────────────────────────
// THE PROBLEM (confirmed from screenshots):
//   Every prior approach appended text rather than replacing it.
//   execCommand('insertText') on Kiwi/Android Chrome inserts at caret
//   position WITHOUT clearing existing content, even after Ctrl+A.
//   DraftJS maintains its own EditorState that ignores DOM range ops.
//
// THE SOLUTION — synthetic paste event injection:
//   X/DraftJS has a 'paste' handler that:
//     1. Takes text/plain from ClipboardData
//     2. REPLACES the current DraftJS selection with pasted content
//     3. Updates EditorState correctly (Reply button activates)
//
//   We:
//     A. Select all content inside editor (DOM level)
//     B. Fire a 'paste' event with a custom DataTransfer containing our text
//     C. DraftJS paste handler catches it, replaces selection, updates state
//
//   This is the same path as a real Ctrl+V paste — DraftJS handles
//   clearing + inserting in one atomic operation internally.

let _zenPasteInProgress = false;

// ─── Output Safety Filter ────────────────────────────────────────
function isReplyTextSafe(text, opts) {
  const allowLinks = !!(opts && opts.allowLinks);
  if (typeof text !== 'string') return false;
  const trimmed = text.trim();
  if (!trimmed) return false;
  if (trimmed.replace(/\s/g, '').length < 2) return false;
  if (allowLinks) return true;
  const linkPattern = /(https?:\/\/|www\.)\S+|\b[a-z0-9-]+\.(com|net|org|io|xyz|gg|co|link|shop|app|info|biz|me|to|gl|ru)\b/i;
  if (linkPattern.test(trimmed)) return false;
  return true;
}

// ─── Resolve wrapper -> real editable node ─────────────────────────
// X's reply compose wrapper contains either a Lexical/DraftJS
// contenteditable div (desktop web, and mobile web when "Desktop site"
// is requested) OR, in X's non-desktop mobile web experience, a plain
// <textarea> element instead — same UI, completely different DOM.
// Every place that used to hardcode
// `wrapper.querySelector('[contenteditable="true"]') || wrapper` now
// goes through here, so a textarea-based compose box resolves to the
// textarea itself instead of silently falling back to the outer wrapper
// div (which is what used to make injection silently no-op on mobile
// with "Desktop site" off: events dispatched to the wrapper never
// reached the real <textarea> living inside it).
function _zenResolveEditor(wrapper) {
  if (!wrapper) return wrapper;
  if (wrapper.tagName === 'TEXTAREA' || wrapper.getAttribute?.('contenteditable') === 'true') return wrapper;
  return wrapper.querySelector?.('[contenteditable="true"]') || wrapper.querySelector?.('textarea') || wrapper;
}

// ─── Path D — plain <textarea> injection (X's non-desktop mobile web) ──
// When "Desktop site" is off, X serves a simpler mobile experience whose
// reply box is a real <textarea>, not a Lexical/DraftJS contenteditable
// div. None of Paths A-C apply — a textarea has no beforeinput/paste
// handling to hook into, and synthetic KeyboardEvents don't reliably
// drive real text edits on mobile Chrome. Whatever framework backs this
// textarea (React or otherwise) only picks up a script-driven value
// change through its own tracked native setter, so we call that setter
// directly and then dispatch a real 'input' event — the standard way to
// make a framework-controlled <textarea> notice the change.
function _zenInjectIntoTextarea(textarea, text) {
  try {
    textarea.focus();
    try { textarea.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch(e) {}

    const proto = Object.getPrototypeOf(textarea);
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set
      || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;

    if (setter) {
      setter.call(textarea, text);
    } else {
      textarea.value = text; // last resort — won't notify a framework listener, but keeps the box non-empty
    }

    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
    try { textarea.setSelectionRange(text.length, text.length); } catch(e) {}

    return (textarea.value || '').trim().length > 0;
  } catch(e) {
    return false;
  }
}

// ─── Editor type detection ────────────────────────────────────────
// Desktop x.com uses DraftJS. Mobile x.com/compose/ uses Lexical.
// They respond to different event paths — we detect which one we have
// so we can pick the right injection strategy without trial-and-error.
function _zenEditorType(editor) {
  // Lexical stores its state on the DOM node's __lexicalEditor property
  if (editor.__lexicalEditor || editor._lexicalEditor) return 'lexical';
  // Walk up a few levels — Lexical root wrapper carries the ref
  let el = editor;
  for (let i = 0; i < 6; i++) {
    el = el.parentElement;
    if (!el) break;
    if (el.__lexicalEditor || el._lexicalEditor) return 'lexical';
  }
  // compose/ path always uses Lexical in current X builds
  if (/\/compose\//.test(location.pathname)) return 'lexical';
  return 'draftjs';
}

// ─── Core text injection — three paths tried in order ─────────────
// Path A (Lexical): InputEvent with inputType:'insertText' — the only
//   path Lexical actually handles from script; it updates its own tree
//   and marks the editor dirty, which enables the Reply/Post button.
// Path B (DraftJS/universal): ClipboardEvent paste — DraftJS paste
//   handler replaces selection with text/plain data, updates EditorState.
// Path C (last resort): execCommand('insertText') — works in some
//   Chromium builds even when A and B don't fire the right handlers.
async function _zenInjectText(editor, text) {
  // ── Resolve to the real editable node (contenteditable OR textarea) ──
  editor = _zenResolveEditor(editor);
  if (!editor) return false;

  // ── PATH D — plain <textarea> (X's non-desktop mobile web) ─────
  if (editor.tagName === 'TEXTAREA') {
    return _zenInjectIntoTextarea(editor, text);
  }

  // ── ZEX+ — trusted Input.insertText through CDP (old paths below stay as the fallback) ──
  try { if (window.ZexPlus && ZexPlus.keyOn() && await ZexPlus.typeCdp(editor, text, null)) return true; } catch (e) {}

  const editorType = _zenEditorType(editor);

  // ── Focus + bring into view ───────────────────────────────────
  editor.focus();
  try { editor.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch(e) {}
  await new Promise(r => setTimeout(r, 40));

  // ── Select all existing content ───────────────────────────────
  // Both DraftJS and Lexical respect a DOM selectAll before the event.
  try {
    const sel = window.getSelection();
    if (sel) {
      const range = document.createRange();
      range.selectNodeContents(editor);
      sel.removeAllRanges();
      sel.addRange(range);
    }
  } catch(e) {}

  // ── PATH A — Lexical: InputEvent insertText ───────────────────
  if (editorType === 'lexical') {
    let worked = false;
    try {
      // Lexical listens for 'beforeinput' with inputType='insertText'.
      // This is the canonical path — it replaces selection + updates state.
      const beforeInput = new InputEvent('beforeinput', {
        inputType: 'insertText',
        data: text,
        bubbles: true,
        cancelable: true,
      });
      editor.dispatchEvent(beforeInput);
      await new Promise(r => setTimeout(r, 30));

      // Follow with 'input' so React/Lexical re-renders
      const inputEv = new InputEvent('input', {
        inputType: 'insertText',
        data: text,
        bubbles: true,
      });
      editor.dispatchEvent(inputEv);
      await new Promise(r => setTimeout(r, 60));

      const inner = (editor.innerText || '').trim();
      if (inner && inner !== 'Post your reply' && inner !== 'What is happening?!') {
        worked = true;
      }
    } catch(e) {}

    if (worked) {
      _zenMoveCursorToEnd(editor);
      return true;
    }

    // Lexical fallback: execCommand — works in Kiwi/Chrome on Android
    // because their execCommand implementation fires 'beforeinput' internally.
    // Uses execCommand('selectAll') rather than synthetic ctrl+A/Delete
    // KeyboardEvents — mobile Chrome doesn't reliably act on synthetic
    // keyboard events for real text editing, but execCommand is a direct
    // semantic command the browser executes itself.
    try {
      editor.focus();
      document.execCommand('selectAll', false);
      await new Promise(r => setTimeout(r, 20));
      document.execCommand('delete', false);
      await new Promise(r => setTimeout(r, 20));

      document.execCommand('insertText', false, text);
      await new Promise(r => setTimeout(r, 60));

      const inner2 = (editor.innerText || '').trim();
      if (inner2 && inner2 !== 'Post your reply') {
        _zenMoveCursorToEnd(editor);
        return true;
      }
    } catch(e) {}

    // Lexical last-ditch: directly mutate the DOM + fire full event chain
    // Lexical will re-reconcile from its virtual tree, but the button should
    // at minimum activate after we trigger its onChange handler.
    try {
      editor.innerHTML = '';
      document.execCommand('insertText', false, text);
      ['input','compositionend'].forEach(evName => {
        editor.dispatchEvent(new Event(evName, { bubbles: true }));
      });
      await new Promise(r => setTimeout(r, 80));
      _zenMoveCursorToEnd(editor);
      return true;
    } catch(e) {}

    return false;
  }

  // ── PATH B — DraftJS: ClipboardEvent paste ────────────────────
  try {
    let dt;
    try {
      dt = new DataTransfer();
      dt.setData('text/plain', text);
    } catch(e) {
      dt = { getData: (type) => type === 'text/plain' ? text : '', types: ['text/plain'] };
    }

    const pasteEvent = new ClipboardEvent('paste', {
      clipboardData: dt,
      bubbles: true,
      cancelable: true,
    });

    if (!pasteEvent.clipboardData || !pasteEvent.clipboardData.getData('text/plain')) {
      Object.defineProperty(pasteEvent, 'clipboardData', { get: () => dt, configurable: true });
    }

    editor.dispatchEvent(pasteEvent);
    await new Promise(r => setTimeout(r, 150));

    const inner = (editor.innerText || '').trim();
    if (inner && inner !== 'Post your reply') {
      _zenMoveCursorToEnd(editor);
      return true;
    }
  } catch(e) {}

  // ── PATH C — Last resort: execCommand insertText ───────────────
  try {
    document.execCommand('delete', false);
    await new Promise(r => setTimeout(r, 30));
    document.execCommand('insertText', false, text);
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    await new Promise(r => setTimeout(r, 80));
    const inner = (editor.innerText || '').trim();
    if (inner) {
      _zenMoveCursorToEnd(editor);
      return true;
    }
  } catch(e) {}

  return false;
}

function _zenMoveCursorToEnd(editor) {
  try {
    editor.focus();
    const s = window.getSelection();
    if (s) {
      const r = document.createRange();
      r.selectNodeContents(editor);
      r.collapse(false);
      s.removeAllRanges();
      s.addRange(r);
    }
  } catch(e) {}
}

async function pasteReply(editor, text, opts) {
  if (!editor) return false;

  if (!isReplyTextSafe(text, opts)) {
    console.warn('[Z EX] Blocked reply before paste — empty or link-like output:', text);
    try { showToast('Reply blocked — empty or link-like output', 'warn'); } catch (e) {}
    return false;
  }

  if (_zenPasteInProgress) return false;
  _zenPasteInProgress = true;

  try {
    // Previously this fired _zenInjectText without awaiting it, then
    // returned true immediately — so insertReply() (below) reported
    // success back to its caller before the text had actually landed in
    // the DOM. On a slow connection this is exactly the kind of gap that
    // lets an auto-mode loop's isEditorEmpty() check run before injection
    // finishes, producing a false "No reply was drafted" even though a
    // reply WAS generated and WAS being inserted. Awaiting here closes
    // that gap — pasteReply (and therefore insertReply) now only resolve
    // once the text is genuinely in the editor.
    await _zenInjectText(editor, text);
  } finally {
    _zenPasteInProgress = false;
  }

  return true;
}

// ─── Human Typing Simulation ────────────────────────────────────
// Used when zen_type_mode is ON.
//
// Root cause of "toggle does nothing, still pastes instantly" on BOTH
// desktop and mobile: X's reply/compose editor (the [data-testid=
// "tweetTextarea_0"] box) is Lexical on every surface today, including
// the desktop modal/inline reply box — not just the /compose/ page as
// the old comment here assumed. _zenEditorType()'s check for
// editor.__lexicalEditor is correct (that's Lexical's real internal
// field, set on the exact root contenteditable node), but whichever way
// it resolved, this function used to route ANY 'lexical' result straight
// to _zenInjectText() — the same one-shot instant-injection function
// pasteReply() effectively uses. So on any surface detected as Lexical
// (which in practice is all of them now), Human Typing Mode silently
// took the instant path — no per-character delay ever happened, even
// though the toggle was correctly read and correctly true.
//
// Fix: give Lexical its own real char-by-char path (Path A below) using
// the same 'beforeinput'/insertText event Lexical's reconciler listens
// for in _zenInjectText — just fired once per character with a delay
// between each, instead of once for the whole string. DraftJS keeps the
// execCommand loop, which already works for that editor type. Plain
// <textarea> (non-desktop mobile web without "Desktop site" on) still
// has no native way to simulate incremental typing on a framework-bound
// textarea, so it keeps the one-shot injection — same as before.
// ─── Human typing rhythm ────────────────────────────────────────
// Builds a per-character delay list that feels like a real person typing:
// uneven speed, quick bursts inside familiar stretches, a beat at the start
// of each word, longer stops after commas / sentence ends / new lines, and a
// short "thinking" pause before the first key. The whole run is scaled so it
// never takes longer than ~9s — it's a visual style only, so auto mode isn't
// slowed down much and the reply text itself is never changed.
function _zenHumanDelays(text) {
  if (zexFlash() && !zexLite()) return Array.from({ length: text.length }, () => 2);   // Flash: type as fast as the editor keeps up (Lite: human rhythm, squeezed)
  const arr = [];
  let burst = 0;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i], prev = i ? text[i - 1] : '';
    let d = 45 + Math.random() * 65;
    if (burst > 0) { d *= 0.55; burst--; }
    else if (Math.random() < 0.12) burst = 2 + Math.floor(Math.random() * 4);
    if (prev === ' ') d += 30 + Math.random() * 90;
    if (/[,;:]/.test(prev)) d += 120 + Math.random() * 180;
    if (/[.!?]/.test(prev)) d += 250 + Math.random() * 450;
    if (prev === '\n') d += 300 + Math.random() * 400;
    if (ch >= 'A' && ch <= 'Z' && prev === ' ') d += 40;
    arr.push(d);
  }
  const total = arr.reduce((a, b) => a + b, 0) || 1;
  const _lt = zexLite();
  const cap = _lt ? Math.max(900, Math.min(2000, text.length * 18)) : Math.max(3000, Math.min(9000, text.length * 45));   // Lite: whole reply typed in ~1-2s, still uneven
  const scale = Math.min(1, cap / total);
  return arr.map((d) => Math.max(_lt ? 7 : 18, d * scale));
}
const _zenSleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function typeReply(editor, text) {
  if (!editor) return false;
  if (!text || !text.trim()) return false;

  // Resolve to real editable node (contenteditable OR textarea)
  editor = _zenResolveEditor(editor);
  if (!editor) return false;

  // Plain <textarea> (X's non-desktop mobile web): type into it one character
  // at a time through the native value setter + input event, so React sees
  // every keystroke. If the final value doesn't match, fall back to one-shot.
  if (editor.tagName === 'TEXTAREA') {
    try {
      editor.focus();
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
      if (setter) {
        setter.call(editor, ''); editor.dispatchEvent(new Event('input', { bubbles: true }));
        const delays = _zenHumanDelays(text);
        await _zenSleep(zexFx(250 + Math.random() * 350, 0));
        let typed = '';
        for (let i = 0; i < text.length; i++) {
          typed += text[i];
          setter.call(editor, typed);
          editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text[i] }));
          try { editor.setSelectionRange(typed.length, typed.length); } catch (e) {}
          await _zenSleep(delays[i]);
        }
        editor.dispatchEvent(new Event('change', { bubbles: true }));
        if ((editor.value || '') === text) return true;
      }
    } catch (e) { console.warn('[ZenType] textarea typing failed, one-shot fallback', e && e.message); }
    return _zenInjectIntoTextarea(editor, text);
  }

  // ── ZEX+ — trusted keystrokes through CDP (Input.dispatchKeyEvent, keyDown/keyUp per character) ──
  try {
    if (window.ZexPlus && ZexPlus.keyOn()) {
      const _zpFast = zexFlash() && !zexLite();
      if (!_zpFast) await _zenSleep(zexFx(250 + Math.random() * 350, 0));
      if (await ZexPlus.typeCdp(editor, text, _zpFast ? null : _zenHumanDelays(text))) return true;
    }
  } catch (e) {}

  const editorType = _zenEditorType(editor);
  console.debug('[ZenType] editor type detected', { editorType, testid: editor.getAttribute?.('data-testid'), path: location.pathname });

  editor.focus();
  try {
    const sel = window.getSelection();
    if (sel) {
      const range = document.createRange();
      range.selectNodeContents(editor);
      sel.removeAllRanges();
      sel.addRange(range);
    }
  } catch (e) {}

  if (editorType === 'lexical') {
    // ── Lexical char-by-char, mobile-safe ───────────────────────────
    // The previous attempt here used execCommand('delete')/execCommand
    // ('insertText') per character, and a synthetic InputEvent as a
    // first try. Both are exactly the mechanism this codebase already
    // found unreliable on Kiwi/mobile Chrome (see the "Paste Reply"
    // notes above _zenPasteInProgress): execCommand('insertText') on
    // Kiwi/Android inserts at the caret WITHOUT properly replacing the
    // current selection, even right after a selectAll. That's exactly
    // consistent with "works on desktop, still pastes instantly on
    // mobile" — the per-char attempts produced no visible change on
    // mobile, so this function fell through to the _zenInjectText
    // one-shot fallback every single time, which looks identical to
    // OFF mode even though the toggle and this function's logic were
    // both otherwise correct.
    //
    // Fix: use the mechanism this codebase already proved works on
    // Kiwi/mobile for one-shot injection — a synthetic 'paste'
    // ClipboardEvent, which Lexical/DraftJS's own paste handler
    // consumes to replace the current selection and update internal
    // state correctly — but fire it ONCE PER CHARACTER with a human
    // typing delay between each, instead of once with the whole
    // string. Collapsing the selection to the end after each paste
    // (via _zenMoveCursorToEnd) makes the next paste append rather
    // than re-replacing the whole box.
    function pasteChar(ch) {
      let dt;
      try {
        dt = new DataTransfer();
        dt.setData('text/plain', ch);
      } catch (e) {
        dt = { getData: (type) => (type === 'text/plain' ? ch : ''), types: ['text/plain'] };
      }
      const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
      if (!ev.clipboardData || !ev.clipboardData.getData('text/plain')) {
        Object.defineProperty(ev, 'clipboardData', { get: () => dt, configurable: true });
      }
      editor.dispatchEvent(ev);
    }

    const delays = _zenHumanDelays(text);
    await _zenSleep(zexFx(250 + Math.random() * 350, 0)); // brief "thinking" beat before the first key
    for (let i = 0; i < text.length; i++) {
      try { pasteChar(text[i]); } catch (e) { console.warn('[ZenType] lexical paste-per-char threw', e && e.message); }
      _zenMoveCursorToEnd(editor);
      await _zenSleep(delays[i]);
    }

    const inner = (editor.innerText || '').trim();
    if (inner && inner !== 'Post your reply' && inner !== 'What is happening?!') {
      console.debug('[ZenType] lexical paste-per-char succeeded', { length: inner.length });
      _zenMoveCursorToEnd(editor);
      return true;
    }

    console.warn('[ZenType] lexical paste-per-char produced no visible text — falling back to one-shot injection');
    return await _zenInjectText(editor, text);
  }

  // ── DraftJS path: character-by-character typing simulation ─────────
  try {
    document.execCommand('delete', false);
  } catch (e) {}
  await new Promise(r => setTimeout(r, 60));

  const dDelays = _zenHumanDelays(text);
  await _zenSleep(zexFx(250 + Math.random() * 350, 0));
  for (let i = 0; i < text.length; i++) {
    document.execCommand('insertText', false, text[i]);
    await _zenSleep(dDelays[i]);
  }

  const draftInner = (editor.innerText || '').trim();
  if (draftInner) {
    console.debug('[ZenType] draftjs char-by-char succeeded', { length: draftInner.length });
    return true;
  }
  console.warn('[ZenType] draftjs char-by-char produced no visible text — falling back to one-shot injection');
  return await _zenInjectText(editor, text);
}

// ═══ LIVE WRITING (true streaming) ═══════════════════════════════
// Mode "Live": the reply box is opened BEFORE the API call and the model's
// tokens are written into it while they arrive (SSE streaming), like watching
// someone write live. Mode "Style" (default) keeps the old behaviour: generate
// first, then type it out.
//
// How it hooks in: while a live session is armed, this content script's own
// fetch() to the AI providers is transparently switched to streaming; tokens
// go to a paced char queue that types into the editor; the caller still gets a
// normal JSON-shaped Response, so all existing parsing/fallback code is
// untouched. When the final (cleaned) reply reaches insertReply(), the box is
// reconciled: identical → nothing more to do, different → replaced.
let _zenLive = null;       // armed session (streaming allowed)
let _zenLiveLast = null;   // last finished session, for reconciliation
const _zenNativeFetch = window.fetch.bind(window);

async function zenLiveEnabled() {
  const d = await new Promise((r) => chrome.storage.local.get(['zen_type_mode', 'zen_type_style'], r));
  return !!d && d.zen_type_mode === true && d.zen_type_style === 'live';
}

function _zenEditorText(editor) {
  if (!editor) return '';
  return (editor.tagName === 'TEXTAREA' ? editor.value : editor.innerText) || '';
}

function _zenMakeCharWriter(rawEditor) {
  const editor = _zenResolveEditor(rawEditor);
  if (!editor) return null;
  const isTA = editor.tagName === 'TEXTAREA';
  const type = isTA ? 'textarea' : _zenEditorType(editor);
  let typed = '';
  const taSet = (v) => {
    const s = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    if (s) s.call(editor, v); else editor.value = v;
  };
  const selectAll = () => {
    try {
      editor.focus();
      const sel = window.getSelection();
      if (sel) { const r = document.createRange(); r.selectNodeContents(editor); sel.removeAllRanges(); sel.addRange(r); }
    } catch (e) {}
  };
  return {
    editor, type,
    prepare() { // put the box in a clean, focused state
      typed = '';
      if (isTA) { editor.focus(); taSet(''); editor.dispatchEvent(new Event('input', { bubbles: true })); return; }
      selectAll();
      if (type !== 'lexical') { try { document.execCommand('delete', false); } catch (e) {} }
    },
    async write(ch) {
      if (!isTA && window.ZexPlus && ZexPlus.keyOn() && await ZexPlus.typeCdp(editor, ch, [0], { live: true })) return;   // ZEX+ trusted keystroke
      if (isTA) {
        typed += ch; taSet(typed);
        editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ch }));
        try { editor.setSelectionRange(typed.length, typed.length); } catch (e) {}
      } else if (type === 'lexical') {
        let dt;
        try { dt = new DataTransfer(); dt.setData('text/plain', ch); }
        catch (e) { dt = { getData: (t) => (t === 'text/plain' ? ch : ''), types: ['text/plain'] }; }
        const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
        if (!ev.clipboardData || !ev.clipboardData.getData('text/plain')) {
          Object.defineProperty(ev, 'clipboardData', { get: () => dt, configurable: true });
        }
        editor.dispatchEvent(ev);
        _zenMoveCursorToEnd(editor);
      } else {
        document.execCommand('insertText', false, ch);
      }
    },
    clear() { // wipe whatever is in the box
      typed = '';
      if (isTA) { taSet(''); editor.dispatchEvent(new Event('input', { bubbles: true })); return; }
      selectAll();
      try { document.execCommand('delete', false); } catch (e) {}
      try { editor.dispatchEvent(new InputEvent('beforeinput', { inputType: 'deleteContentBackward', bubbles: true, cancelable: true })); } catch (e) {}
    },
  };
}

function zenLiveArm(editor) {
  const cw = _zenMakeCharWriter(editor);
  if (!cw) return null;
  const st = {
    editor: cw.editor, cw, queue: [], written: '', prepared: false,
    leading: true, pumping: null,
    push(text) {
      for (const ch of text) {
        if (st.leading) { if (/\s/.test(ch) || ch === '"' || ch === "'") continue; st.leading = false; } // mirror trim + leading-quote strip
        st.queue.push(ch);
      }
      if (!st.pumping && st.queue.length) st.pumping = st._pump();
    },
    async _pump() {
      try {
        if (!st.prepared) { cw.prepare(); st.prepared = true; }
        while (st.queue.length) {
          const ch = st.queue.shift();
          try { await cw.write(ch); st.written += ch; } catch (e) {}
          const backlog = st.queue.length;
          let d = backlog > 60 ? 5 : backlog > 25 ? 12 : 22 + Math.random() * 40;   // keeps up with fast models
          if (backlog < 12 && /[,.!?]/.test(ch)) d += 60 + Math.random() * 90;
          await _zenSleep(d);
        }
      } finally { st.pumping = null; }
    },
    async finish() { while (st.pumping) await st.pumping; },
    async reset() { // a provider failed mid-way and the next one starts fresh
      st.queue = []; await st.finish();
      if (st.written) cw.clear();
      st.written = ''; st.leading = true; st.prepared = false;
    },
  };
  _zenLive = st;
  _zenLiveLast = null;
  return st;
}

function zenLiveDisarm() { if (_zenLive) { _zenLiveLast = _zenLive; } _zenLive = null; }

async function zenLiveGenerate(editor, genFn) {
  const st = editor ? zenLiveArm(editor) : null;
  try { return await genFn(); }
  catch (e) {
    if (st) { st.queue = []; await st.finish(); try { st.cw.clear(); } catch (_) {} _zenLiveLast = null; }
    throw e;
  } finally { zenLiveDisarm(); }
}

async function _zenStreamFetch(kind, url, init, live) {
  const body = JSON.parse(init.body);
  let sUrl = url;
  if (kind === 'openai') body.stream = true;
  else sUrl = url.replace(':generateContent', ':streamGenerateContent') + (url.includes('?') ? '&' : '?') + 'alt=sse';

  const resp = await _zenNativeFetch(sUrl, { ...init, body: JSON.stringify(body) });
  if (!resp.ok) {
    if ([401, 403, 429].includes(resp.status) || resp.status >= 500) return resp; // real error — caller handles it
    return _zenNativeFetch(url, init); // model may not support streaming → normal request
  }
  if (!resp.body) return _zenNativeFetch(url, init);

  await live.reset();
  const reader = resp.body.getReader();
  const dec = new TextDecoder();
  let buf = '', full = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let nl;
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (!line.startsWith('data:')) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === '[DONE]') continue;
      let j; try { j = JSON.parse(payload); } catch (e) { continue; }
      if (j && j.error) throw new Error(j.error.message || 'Stream error');
      let piece = '';
      if (kind === 'openai') piece = (j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content) || '';
      else {
        const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
        for (const p of parts) if (p && typeof p.text === 'string' && !p.thought) piece += p.text;
      }
      if (piece) { full += piece; live.push(piece); }
    }
  }
  const synth = kind === 'openai'
    ? { choices: [{ message: { role: 'assistant', content: full }, finish_reason: 'stop' }] }
    : { candidates: [{ content: { role: 'model', parts: [{ text: full }] }, finishReason: 'STOP' }] };
  return new Response(JSON.stringify(synth), { status: 200, headers: { 'Content-Type': 'application/json' } });
}

window.fetch = function (input, init) {
  try {
    const live = _zenLive;
    if (live && init && init.method === 'POST' && typeof init.body === 'string') {
      const url = typeof input === 'string' ? input : ((input && input.url) || '');
      let kind = null;
      if (/^https:\/\/generativelanguage\.googleapis\.com\/.+:generateContent/.test(url)) kind = 'gemini';
      else if (/chat\/completions/.test(url) && /^https:\/\/(api\.openai\.com|api\.deepseek\.com|api\.groq\.com|openrouter\.ai)\//.test(url)) kind = 'openai';
      if (kind) {
        let b = {}; try { b = JSON.parse(init.body); } catch (e) {}
        const maxTok = b.max_tokens || (b.generationConfig && b.generationConfig.maxOutputTokens) || 0;
        if (maxTok >= 30) return _zenStreamFetch(kind, url, init, live); // skips tiny classifier calls (max_tokens 5)
      }
    }
  } catch (e) {}
  return _zenNativeFetch(input, init);
};

// Helper — wraps pasteReply + typeReply with zen_type_mode check.
// Use this everywhere instead of calling pasteReply() directly.
async function insertReply(editor, text, opts) {
  ZenCursor.setState('type');
  const _r = await _insertReplyCore(editor, text, opts);
  ZenCursor.setState('typed');
  return _r;
}
async function _insertReplyCore(editor, text, opts) {
  // ── Live session reconciliation ──
  const live = _zenLiveLast;
  if (live && live.written && _zenResolveEditor(editor) === live.editor) {
    _zenLiveLast = null;
    await live.finish();
    if (!isReplyTextSafe(text, opts)) {
      try { live.cw.clear(); } catch (e) {}
      try { showToast('Reply blocked — empty or link-like output', 'warn'); } catch (e) {}
      throw new Error('Reply blocked — unsafe output');
    }
    if (_zenEditorText(live.editor).trim() === String(text).trim()) return true; // already exactly what we want
    live.cw.prepare();                       // select all → replace with the final cleaned text
    const okr = await pasteReply(editor, text, opts);
    if (!okr) throw new Error('Reply blocked — unsafe output');
    return true;
  }
  const d = await new Promise(r => chrome.storage.local.get(['zen_type_mode'], r));
  if (d.zen_type_mode === true || zexLite()) {   // Flash Lite always types (squeezed human rhythm) instead of pasting
    const ok = await typeReply(editor, text);
    if (!ok) throw new Error('Typing failed — editor not found or text empty');
    return true;
  }
  const ok = await pasteReply(editor, text, opts);
  if (!ok) throw new Error('Reply blocked — unsafe output');
  return true;
}

// ─── Reply History Tracking ─────────────────────────────────────
// Tracks whether a generated reply was actually POSTED (not just pasted),
// and if so, logs {link, author, reply, tone, ts} to chrome.storage.local
// so the popup's History tab can show real posted-reply history.

const pendingReplyMap = new WeakMap();   // textarea -> pending reply data
const trackedSubmitBtns = new WeakSet(); // avoid attaching duplicate click listeners

function isValidStatusUrl(url) {
  // A real tweet permalink always contains /status/<digits>. Anything else
  // (home timeline, notifications tab, a profile page, etc.) is NOT a link
  // we should ever save as "View Tweet" — that's what made old saved links
  // sometimes point nowhere useful.
  return typeof url === 'string' && /\/status\/\d+/.test(url);
}

// ─── Reply-target hint ─────────────────────────────────────────
// On mobile web, tapping a tweet's reply icon navigates to x.com/compose/,
// which UNMOUNTS the original tweet — so getTweetLink() can't find it in the
// DOM any more and history saved "Link unavailable". We remember the target
// at the moment the reply icon is used (by an engine, by a Telegram/session
// run, or by the person tapping it) and getTweetLink() falls back to it.
const ZEN_TARGET_TTL = 10 * 60 * 1000;
let _zenReplyTarget = null;        // { url, author, ts }
let _zenTargetLockUntil = 0;       // engine/session-set targets are not overwritten by passive taps

function zenNormalizeStatusUrl(u) {
  try {
    const m = String(u || '').match(/^(https?:\/\/[^\/?#]+\/[^\/?#]+\/status\/\d+)/i);
    if (m) return m[1];
    return isValidStatusUrl(u) ? String(u) : null;
  } catch (e) { return null; }
}
function zenArticleLink(article) {
  try {
    if (!article) return null;
    // The timestamp anchor is the tweet's own permalink (first status link can be a quoted/other post).
    const t = article.querySelector('a[href*="/status/"] time');
    const a = (t && t.closest('a')) || article.querySelector('a[href*="/status/"]');
    return a ? zenNormalizeStatusUrl(a.href) : null;
  } catch (e) { return null; }
}
function zenSetReplyTarget(url, author, lockMs) {
  const n = zenNormalizeStatusUrl(url);
  if (!n) return;
  _zenReplyTarget = { url: n, author: author || '', ts: Date.now() };
  if (lockMs) _zenTargetLockUntil = Date.now() + lockMs;
  try { sessionStorage.setItem('zenReplyTarget', JSON.stringify(_zenReplyTarget)); } catch (e) {}
}
function zenGetReplyTarget() {
  let t = _zenReplyTarget;
  if (!t) { try { t = JSON.parse(sessionStorage.getItem('zenReplyTarget') || 'null'); } catch (e) { t = null; } }
  return (t && t.url && Date.now() - (t.ts || 0) <= ZEN_TARGET_TTL) ? t : null;
}
function zenClearReplyTarget() {
  _zenReplyTarget = null; _zenTargetLockUntil = 0;
  try { sessionStorage.removeItem('zenReplyTarget'); } catch (e) {}
}
// Passive capture: the person taps a tweet's reply icon themselves.
document.addEventListener('click', (e) => {
  try {
    if (Date.now() < _zenTargetLockUntil) return;
    const icon = e.target && e.target.closest && e.target.closest('[data-testid="reply"]');
    if (!icon) return;
    const article = icon.closest('article');
    const url = zenArticleLink(article);
    if (url) zenSetReplyTarget(url, getArticleAuthorHandle(article) || '');
  } catch (err) {}
}, true);

function getTweetLink(replyTextarea) {
  try {
    let el = replyTextarea;
    for (let i = 0; i < 30; i++) {
      el = el.parentElement;
      if (!el) break;
      const tweets = el.querySelectorAll('[data-testid="tweetText"]');
      if (tweets.length > 0) {
        const article = tweets[tweets.length - 1].closest('article');
        if (article) {
          const link = article.querySelector('a[href*="/status/"]');
          if (link && link.href && isValidStatusUrl(link.href)) return link.href;
        }
      }
    }
    const modal = document.querySelector('[aria-modal="true"], [data-testid="sheetDialog"]');
    if (modal) {
      const tweets = modal.querySelectorAll('[data-testid="tweetText"]');
      if (tweets.length > 0) {
        const article = tweets[tweets.length - 1].closest('article');
        if (article) {
          const link = article.querySelector('a[href*="/status/"]');
          if (link && link.href && isValidStatusUrl(link.href)) return link.href;
        }
      }
    }
    // Full-page compose (mobile): the tweet is unmounted — use the remembered reply target.
    if (/\/compose\//.test(location.pathname)) {
      const h = zenGetReplyTarget();
      if (h) return h.url;
    }
    if (isValidStatusUrl(location.href)) return location.href;
    const h2 = zenGetReplyTarget();
    if (h2) return h2.url;
  } catch (e) {}
  return null; // no reliable tweet link found — caller decides what to do
}

function findSubmitButton(textarea) {
  // Walk up from textarea first — most reliable when multiple composers on page
  let el = textarea;
  for (let i = 0; i < 25; i++) {
    el = el.parentElement;
    if (!el) break;
    const btn = el.querySelector('[data-testid="tweetButtonInline"]') || el.querySelector('[data-testid="tweetButton"]');
    if (btn) return btn;
  }
  // Modal dialog
  const modal = document.querySelector('[aria-labelledby="modal-header"]');
  if (modal) {
    const btn = modal.querySelector('[data-testid="tweetButton"]') || modal.querySelector('[data-testid="tweetButtonInline"]');
    if (btn) return btn;
  }
  // x.com/compose/ full-page (mobile) — Reply button is in the top bar as
  // a plain <a> or <div> with role="button" labelled "Reply", OR as the
  // standard tweetButton but outside any modal/article ancestor.
  const topbarReply =
    document.querySelector('[data-testid="tweetButton"]') ||
    document.querySelector('[data-testid="tweetButtonInline"]');
  if (topbarReply) return topbarReply;

  // Last resort — find any button whose visible text is "Reply" or "Post"
  // (X changes label depending on compose context)
  const allBtns = document.querySelectorAll('button, [role="button"]');
  for (const b of allBtns) {
    const txt = (b.textContent || b.innerText || '').trim().toLowerCase();
    if (txt === 'reply' || txt === 'post') return b;
  }
  return null;
}

function isEditorEmpty(textarea) {
  try {
    const ed = _zenResolveEditor(textarea);
    if (!ed) return true;
    const text = (ed.tagName === 'TEXTAREA' ? (ed.value || '') : (ed.innerText || '')).trim();
    if (!text) return true;
    // Lexical on x.com/compose/ renders placeholder as real DOM text —
    // treat these as "empty" so engines don't mistake placeholder for reply.
    const PLACEHOLDERS = ['Post your reply', "What is happening?!", "What's happening?", 'Add another Tweet'];
    if (PLACEHOLDERS.some(p => text === p || text.startsWith(p + '\n'))) return true;
    return false;
  } catch (e) { return true; }
}

function armPostWatcher(textarea) {
  const submitBtn = findSubmitButton(textarea);
  if (!submitBtn || trackedSubmitBtns.has(submitBtn)) return;
  trackedSubmitBtns.add(submitBtn);
  submitBtn.addEventListener('click', () => {
    const pending = pendingReplyMap.get(textarea);
    if (!pending) return;
    // Fresh capture right at click time — DOM is still fully intact here,
    // so if the earlier capture (at generation time) missed or went stale,
    // this is the best chance to grab the real link before the composer closes.
    const freshLink = getTweetLink(textarea);
    if (freshLink) pending.tweetLink = freshLink;
    watchForPostSuccess(textarea, pending);
  });
}

function watchForPostSuccess(textarea, pending) {
  const start = Date.now();
  const maxWait = 6000;
  const timer = setInterval(() => {
    const elapsed = Date.now() - start;
    const stillConnected = document.contains(textarea);
    const cleared = !stillConnected || isEditorEmpty(textarea);
    if (cleared) {
      clearInterval(timer);
      saveReplyHistory(pending);
      return;
    }
    if (elapsed >= maxWait) clearInterval(timer); // couldn't confirm — don't log a false entry
  }, 400);
}

// ── POST TAGS (keyword / project) ─────────────────────────────────────────
// zenPostTags = { [statusId]: { t: ['polymarket', '@proj', '$tick'], ts } }
// Written when a post is seen by SEA / Link Collect / FED, read when the reply
// is saved so History + Dashboard show which keyword/project the comment belongs to.
const ZEX_TAG_KEY = 'zenPostTags';
let _zexTagChain = Promise.resolve();
function zexNormTag(k) { return String(k || '').trim().toLowerCase().slice(0, 40); }
function zexIsProjTag(k) { return /^[@$]/.test(String(k || '')); }
function zexMergeTags(a, b) {
  const out = [];
  (a || []).concat(b || []).forEach((k) => { k = zexNormTag(k); if (k && out.indexOf(k) < 0) out.push(k); });
  return out;
}
// Project mentions inside a post: $TICKERS first, then @handles (max 3).
function zexProjectTags(text) {
  const t = String(text || '');
  return zexMergeTags(t.match(/\$[A-Za-z][A-Za-z0-9]{1,14}\b/g) || [], t.match(/@[A-Za-z0-9_]{2,15}/g) || []).slice(0, 3);
}
// Which project / keyword this post belongs to. Items are strings or {name, alias:[...]}.
// Several projects in one post: only the one mentioned FIRST in the post text is tagged.
function zexKwMatch(items, article) {
  const list = [];
  (items || []).forEach((it) => {
    if (!it) return;
    const name = zexNormTag(typeof it === 'string' ? it : it.name);
    if (!name) return;
    const terms = [name].concat(typeof it === 'string' ? [] : (it.alias || []).map(zexNormTag)).filter(Boolean);
    if (!list.some((p) => p.name === name)) list.push({ name: name, terms: terms });
  });
  if (!list.length) return [];
  const te = article.querySelector('[data-testid="tweetText"]');
  const pick = (text) => {
    let best = null, bestAt = Infinity;
    list.forEach((p) => p.terms.forEach((t) => { const at = text.indexOf(t); if (at >= 0 && at < bestAt) { bestAt = at; best = p.name; } }));
    return best;
  };
  let hit = pick((te ? te.innerText : '').toLowerCase());
  if (!hit) hit = pick(String(article.innerText || '').toLowerCase());
  if (!hit && list.length === 1) hit = list[0].name;
  return hit ? [hit] : [];
}
function zexSeaKwTags(article) {
  return new Promise((res) => {
    try {
      // Manual search on X: the project name comes from the search itself (start of the query), no saved keyword needed.
      if (isSearchUrl(location.href)) {
        const qk = zexQueryProjects(location.href);
        if (qk.length) { res(zexKwMatch(qk, article)); return; }
      }
      chrome.storage.local.get(['zenSearchKeywords'], (d) => { try { res(zexKwMatch(d && d.zenSearchKeywords, article)); } catch (e) { res([]); } });
    } catch (e) { res([]); }
  });
}
function zexTagPost(sid, tags) {
  tags = zexMergeTags(tags, []);
  if (!sid || !tags.length) return Promise.resolve();
  _zexTagChain = _zexTagChain.then(() => new Promise((res) => {
    try {
      chrome.storage.local.get([ZEX_TAG_KEY], (d) => {
        try {
          const m = (d && d[ZEX_TAG_KEY] && typeof d[ZEX_TAG_KEY] === 'object') ? d[ZEX_TAG_KEY] : {};
          const old = m[sid] && Array.isArray(m[sid].t) ? m[sid].t : [];
          m[sid] = { t: zexMergeTags(old, tags).slice(0, 8), ts: Date.now() };
          const ids = Object.keys(m);
          if (ids.length > 5000) ids.sort((x, y) => (m[x].ts || 0) - (m[y].ts || 0)).slice(0, ids.length - 5000).forEach((k) => delete m[k]);
          chrome.storage.local.set({ [ZEX_TAG_KEY]: m }, () => res());
        } catch (e) { res(); }
      });
    } catch (e) { res(); }
  })).catch(() => {});
  return _zexTagChain;
}

// ── POST AGE LIMIT (Search engine + Link Collect only) ────────────────────
// zenSearchAgeFilter = { on, mode:'age'|'dates', minSec, maxSec, dates:['YYYY-MM-DD'], tFrom, tTo }
// Verdict per post: 'ok' (inside window) | 'skip' (outside, keep scrolling) | 'old' (older than the window = end of useful results).
let zexAgeCfg = null;
const zexAgeOldIds = new Set();      // distinct posts seen that are older than the window (this search)
try {
  chrome.storage.local.get(['zenSearchAgeFilter'], (d) => { zexAgeCfg = (d && d.zenSearchAgeFilter) || null; });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && ch.zenSearchAgeFilter) { zexAgeCfg = ch.zenSearchAgeFilter.newValue || null; zexAgeOldIds.clear(); }
  });
} catch (e) {}
function zexAgeActive() {
  const c = zexAgeCfg;
  if (!c || c.on !== true) return false;
  if (c.mode === 'dates') return Array.isArray(c.dates) && c.dates.length > 0;
  return (c.maxSec || 0) > (c.minSec || 0);
}
function zexPostTs(article) {
  try {
    const t = article.querySelector('time[datetime]');
    const ms = t ? Date.parse(t.getAttribute('datetime')) : NaN;
    return isFinite(ms) ? ms : null;
  } catch (e) { return null; }
}
function zexLocalDayKey(ms) {
  const d = new Date(ms), p = (x) => String(x).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}
function zexHM(s) { const m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '')); return m ? (+m[1]) * 60 + (+m[2]) : null; }
function zexAgeVerdict(article) {
  if (!zexAgeActive()) return 'ok';
  const ts = zexPostTs(article);
  if (ts == null) return 'ok';           // no time on the card: can't judge, leave it alone
  const c = zexAgeCfg;
  if (c.mode === 'dates') {
    const dates = c.dates.slice().sort();
    const first = dates[0].split('-');
    const earliest = new Date(+first[0], +first[1] - 1, +first[2]).getTime();
    if (ts < earliest) return 'old';
    if (dates.indexOf(zexLocalDayKey(ts)) < 0) return 'skip';
    const f = zexHM(c.tFrom), t = zexHM(c.tTo);
    if (f != null || t != null) {
      const d = new Date(ts), mins = d.getHours() * 60 + d.getMinutes();
      const a = f != null ? f : 0, b = t != null ? t : 24 * 60 - 1;
      const inside = a <= b ? (mins >= a && mins <= b) : (mins >= a || mins <= b);
      if (!inside) return 'skip';
    }
    return 'ok';
  }
  const age = (Date.now() - ts) / 1000;
  if (age > c.maxSec) return 'old';
  if (age < (c.minSec || 0)) return 'skip';
  return 'ok';
}
// SEA / Collect: this many older posts seen (and nothing eligible on screen) = stop.
const ZEX_AGE_OLD_STOP = 4;

// Which Daily-Activity bucket a confirmed reply belongs to:
// 'tg' (Telegram engage run), 'tar' (Target Account List run), REP/FED/SEA/GIV engines, else 'get' (manual GET Reply).
function zenDashSource(t) {
  t = String(t || '').toUpperCase();
  if (typeof window.__zexSessPath === 'string' && window.__zexSessPath.indexOf('telegram_') === 0) return 'tg';
  if (typeof tarRunningFor !== 'undefined' && tarRunningFor) return 'tar';
  if (t === 'TAR') return 'tar';
  if (t === 'FED-GIV') return 'FED';
  if (t === 'REP' || t === 'FED' || t === 'SEA' || t === 'GIV') return t;
  return 'get';
}

// Dashboard + goal-based auto-refresh counters. Bumped once per CONFIRMED post.
// Engine is identified by the reply's tone tag (REP / FED / SEA / GIV; FED-GIV = feed engine).
function zenBumpDashCounters(tone, kw) {
  try {
    const src = zenDashSource(tone);
    const extra = (src === 'tg' || src === 'tar' || src === 'get') ? src : null; // not an engine — never feeds engine counters
    const t = extra ? '' : src;
    const key = t === 'REP' ? 'zenRepCount'
              : (t === 'FED' || t === 'FED-GIV') ? 'zenFedCount'
              : t === 'SEA' ? 'zenSeaCount'
              : t === 'GIV' ? 'zenGivCount' : null;
    chrome.storage.local.get(['zenTodayReplies', 'zenTodayDate', 'zenDailyLog', 'zexDayStartMin'].concat(key ? [key] : []), (d) => {
      // custom day start (minutes after midnight, default 0): 06:00 -> a day runs 06:00 to 06:00
      const dayN = new Date(Date.now() - (Number(d.zexDayStartMin) || 0) * 60000);
      const today = dayN.toDateString();
      const upd = {
        zenTodayDate: today,
        zenTodayReplies: (d.zenTodayDate === today ? (d.zenTodayReplies || 0) : 0) + 1,
      };
      if (key) upd[key] = (d[key] || 0) + 1;

      // Permanent per-day log (survives the 300-entry reply-history cap).
      // Day key is local YYYY-MM-DD. Feed posts are split into keyword-matched
      // vs normal feed, plus a per-keyword tally.
      const n = dayN, pad = (x) => String(x).padStart(2, '0');
      const day = n.getFullYear() + '-' + pad(n.getMonth() + 1) + '-' + pad(n.getDate());
      const log = (d.zenDailyLog && typeof d.zenDailyLog === 'object') ? d.zenDailyLog : {};
      const e = log[day] || { total: 0, rep: 0, fed: 0, sea: 0, giv: 0, fedKw: 0, fedNormal: 0, tg: 0, get: 0, tar: 0, kw: {} };
      e.total++;
      if (extra) e[extra] = (e[extra] || 0) + 1;
      else if (t === 'REP') e.rep++;
      else if (t === 'SEA') e.sea++;
      else if (t === 'GIV') e.giv++;
      else if (t === 'FED' || t === 'FED-GIV') {
        e.fed++;
        const list = Array.isArray(kw) ? kw : [];
        if (list.some((k) => !zexIsProjTag(k))) e.fedKw++; else e.fedNormal++;
      }
      { // keyword / project tag tally (any engine: FED, SEA, Collect->Sweep, ...)
        const list = Array.isArray(kw) ? kw : [];
        if (list.length) {
          if (!e.kw || typeof e.kw !== 'object') e.kw = {};
          list.forEach((k) => { k = zexNormTag(k); if (k) e.kw[k] = (e.kw[k] || 0) + 1; });
        }
      }
      log[day] = e;
      const days = Object.keys(log).sort();
      if (days.length > 400) days.slice(0, days.length - 400).forEach((k) => delete log[k]);
      upd.zenDailyLog = log;

      chrome.storage.local.set(upd);
    });
  } catch (e) {}
}

function saveReplyHistory(entry) {
  try {
    if (entry && !(Array.isArray(entry.kw) && entry.kw.length)) {
      const _tsid = repStatusIdSafe(entry.tweetLink || (isValidStatusUrl(location.href) ? location.href : null));
      if (_tsid) {
        let _done = false;
        const _go = (tags) => { if (_done) return; _done = true; if (tags && tags.length) entry.kw = tags.slice(); _saveReplyHistoryCore(entry); };
        setTimeout(() => _go(null), 1500);
        chrome.storage.local.get([ZEX_TAG_KEY], (d) => {
          const r = d && d[ZEX_TAG_KEY] && d[ZEX_TAG_KEY][_tsid];
          _go(r && Array.isArray(r.t) ? r.t : null);
        });
        return;
      }
    }
  } catch (e) {}
  _saveReplyHistoryCore(entry);
}

function _saveReplyHistoryCore(entry) {
  zenBumpDashCounters(entry && (entry.engine || entry.tone), entry && entry.kw);
  // Workflow map: confirmed comment (engine + auto/manual + who)
  try {
    if (typeof zexT === 'function') {
      const _zt = String((entry && (entry.engine || entry.tone)) || '').toUpperCase();
      const _tgRun = typeof window.__zexSessPath === 'string' && window.__zexSessPath.indexOf('telegram_') === 0;
      const _ze = _tgRun ? 'TG' : _zt === 'FED-GIV' ? 'FED' : (['REP', 'FED', 'SEA', 'GIV', 'TAR'].indexOf(_zt) >= 0 ? _zt : 'MAN');
      const _za = (repAutoRunning || feedAutoRunning || searchAutoRunning || givAutoRunning || sessAutoRunningFor) ? 'auto' : 'manual';
      zexT('comment', { eng: _ze, mode: _za, h: entry && entry.tweetAuthor, link: entry && entry.tweetLink, wc: zexWcFor(repStatusIdSafe(entry && entry.tweetLink), entry && entry.tweetAuthor) });
    }
  } catch (e) {}
  zenClearReplyTarget();
  // How long this reply took: box open -> generate -> send (o / g / s) and the total (t), in ms.
  let _dur;
  try {
    const now = Date.now(), T = _zexTim, fresh = (v) => v && now - v < 5 * 60 * 1000;
    const t0 = fresh(T.open) ? T.open : (fresh(T.gen0) ? T.gen0 : 0);
    if (t0) {
      _dur = { t: now - t0 };
      if (fresh(T.open) && T.gen0 >= T.open) _dur.o = T.gen0 - T.open;
      if (fresh(T.gen0) && entry && entry.ts >= T.gen0) { _dur.g = entry.ts - T.gen0; _dur.s = Math.max(0, now - entry.ts); }
    }
    T.open = 0; T.gen0 = 0;
  } catch (e) {}
  chrome.storage.local.get(['zenReplyHistory'], (d) => {
    const hist = Array.isArray(d.zenReplyHistory) ? d.zenReplyHistory : [];
    // Last-resort attempt: if both earlier captures failed but we happen to
    // still be sitting on the tweet's own permalink page, use that instead
    // of saving a broken/blank link.
    let link = entry.tweetLink;
    if (!link && isValidStatusUrl(location.href)) link = location.href;
    hist.unshift({
      link: link || '',
      author: entry.tweetAuthor,
      reply: entry.replyText,
      tone: entry.tone,
      eng: entry.engine || undefined,
      src: (function () { const x = zenDashSource(entry.engine || entry.tone); return (x === 'tg' || x === 'tar' || x === 'get') ? x : undefined; })(),
      kw: Array.isArray(entry.kw) && entry.kw.length ? entry.kw : undefined,
      wc: zexWcFor(repStatusIdSafe(link), entry.tweetAuthor) == null ? undefined : zexWcFor(repStatusIdSafe(link), entry.tweetAuthor),
      dur: _dur,
      ts: entry.ts
    });
    chrome.storage.local.set({ zenReplyHistory: hist.slice(0, 300) });
  });
  // Confirmed real post — remember this tweet/comment as already-replied-to
  // so GET Reply / REP buttons never show up on it again.
  const sid = repStatusIdSafe(entry.tweetLink || (isValidStatusUrl(location.href) ? location.href : null));
  if (sid) markStatusIdReplied(sid, zenDashSource(entry.engine || entry.tone));
}

// ─── GET Reply Click Tracking (per post) ───────────────────────
// Every time a reply is generated for a post, bump that post's counter —
// regardless of whether the reply actually gets posted. Lets the popup show
// "this post: generated N times" under Total Reply Activity.
function trackGetReplyClick(tweetLink, tweetAuthor) {
  if (!tweetLink) return;
  chrome.storage.local.get(['zenGetReplyClicks'], (d) => {
    const map = (d.zenGetReplyClicks && typeof d.zenGetReplyClicks === 'object') ? d.zenGetReplyClicks : {};
    const existing = map[tweetLink] || { count: 0, author: '', firstTs: Date.now() };
    existing.count += 1;
    existing.author = tweetAuthor || existing.author || '';
    existing.lastTs = Date.now();
    map[tweetLink] = existing;
    chrome.storage.local.set({ zenGetReplyClicks: map });
  });
}

// ─── Toast ────────────────────────────────────────────────────
let toastTimer;
function showToast(msg, type = 'info') {
  let t = ZexShadow.$('#zen-toast');
  if (!t) { t = document.createElement('div'); t.id = 'zen-toast'; ZexShadow.mount(t); }
  const colors = { success: '#00ff64', error: '#ff4444', warn: '#ffaa00', info: '#00aaff' };
  t.style.cssText = `
    position:fixed;bottom:24px;left:50%;transform:translateX(-50%);
    background:#0d1220;border:1px solid ${colors[type]};color:${colors[type]};
    font-family:-apple-system,sans-serif;font-size:13px;font-weight:600;
    padding:10px 20px;border-radius:30px;z-index:9999999;
    box-shadow:0 4px 24px rgba(0,0,0,0.6);white-space:nowrap;
    pointer-events:none;transition:opacity 0.3s;opacity:1;
  `;
  t.textContent = msg;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.style.opacity = '0'; }, 3000);
}

function getStorage(keys) {
  if (!extContextAlive()) return Promise.resolve({});
  return new Promise(resolve => {
    try {
      chrome.storage.local.get(keys, (result) => {
        if (chrome.runtime.lastError) { resolve({}); return; }
        resolve(result || {});
      });
    } catch (e) { resolve({}); }
  });
}

// ═══════════════════════════════════════════════════════════════
// ═══ COMMENT REP ENGINE ══════════════════════════════════════════
// Reply Your Own Post Comment
//
// Engine: Post context + Comment = Reply (always short).
//
// This is a fully separate feature from the GET Reply widget above.
// It now activates automatically on ANY tweet/status page (no longer
// gated behind the popup's "Open" link flow) and re-checks whenever
// the SPA navigates to a new status URL.
// ═══════════════════════════════════════════════════════════════

function repStatusId(url) {
  if (!url) return null;
  const m = String(url).match(/\/status\/(\d+)/);
  return m ? m[1] : null;
}

let repModeActive = false;
let repEngineOn = false;     // master toggle — loaded from storage below (default OFF when never set)
chrome.storage.local.get(['zenRepEngineOn'], (d) => {
  repEngineOn = d.zenRepEngineOn === true;
  if (typeof repTryActivate === 'function') repTryActivate();
  if (typeof zenAgentRefreshEngineState === 'function') zenAgentRefreshEngineState();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.zenRepEngineOn) return;
  repEngineOn = changes.zenRepEngineOn.newValue === true;
  if (!repEngineOn) {
    repStopEngine();
    showToast('REP engine OFF', 'success');
  } else {
    repTryActivate();
  }
  if (typeof zenAgentRefreshEngineState === 'function') zenAgentRefreshEngineState();
});
function repStopEngine() {
  repModeActive = false;
  repOriginStatusId = null;
  if (repScanTimer) { clearInterval(repScanTimer); repScanTimer = null; }
  document.querySelectorAll('.zen-rep-btn').forEach((b) => b.remove());
  repDoneArticles = new WeakSet(); // so buttons come back when the engine is turned ON again
}
let repOriginStatusId = null;
let repPostText = '';
let repPostArticle = null;   // M3b2: main post article (image source for REP)
let repScanTimer = null;
let repDoneArticles = new WeakSet();
const repBusyArticles = new WeakSet();
let repLastEditor = null;

// Comments are tracked by their own tweet-status id (not just DOM node
// identity) because the full-page compose flow used by some mobile
// browsers unmounts and remounts the whole comment list on the way
// back — a plain WeakSet keyed on the old node would forget a comment
// was already replied to and let it get redrafted.
const repProcessedIds = new Set();
function repCommentId(article) {
  const link = article.querySelector('a[href*="/status/"]');
  return link ? repStatusId(link.href) : null;
}

// ═══ AUTO MODE ═════════════════════════════════════════════
// When ON, the engine walks through a post's comments by itself, running
// the exact same draft flow a manual REP tap would (generate + paste into
// that comment's own reply box) — and then submits it through X's own
// Reply/Post button itself, with no manual tap needed. That's what lets
// the loop actually continue on its own to the next comment. After
// submitting, the loop waits until that box closes (confirming the post
// went through) before moving to the next comment. Turning the toggle off
// in the popup stops it before its next step.
// ═══════════════════════════════════════════════════════════════

let repAutoModeOn = false;
let repAutoRunning = false;
const repAutoSkipped = new WeakSet();
const REP_AUTO_MAX_PER_RUN = 40; // circuit breaker against any runaway loop

// ── Percentage-based selection ──────────────────────────────────
// User picks e.g. 50% in the Activity tab. Rather than rolling an
// independent coin-flip per comment (which only converges to the target
// percentage on average, not exactly), we count the actual eligible pool
// and pick that exact share of it at random — "20 comments, 50% → exactly
// 10, chosen randomly" — matching what was asked for.
//
// X lazy-loads comments as you scroll, so the pool isn't fixed up front.
// We handle that by re-running selection every scan: any newly-discovered
// eligible comments get folded into the pool, target count is recomputed
// from the new total, and additional random picks are added (never
// removing ones already selected) until the selected count matches the
// rounded percentage of the current total.
let repAutoPercentage = 100;
const repAutoSelected = new WeakSet();      // articles chosen to receive a reply
const repAutoPoolSeen = [];                 // ordered list of all eligible articles seen so far (this page)

chrome.storage.local.get(['zenRepAutoPercentage'], (d) => {
  const v = Number(d.zenRepAutoPercentage);
  repAutoPercentage = (Number.isFinite(v) && v >= 1 && v <= 100) ? v : 100;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.zenRepAutoPercentage) return;
  const v = Number(changes.zenRepAutoPercentage.newValue);
  repAutoPercentage = (Number.isFinite(v) && v >= 1 && v <= 100) ? v : 100;
});

// Resets the selection pool — called whenever the REP engine (re)activates
// on a post, so a new post always starts counting from zero.
function repResetAutoPool() {
  repAutoPoolSeen.length = 0;
}

// Call once per scan pass with the currently-visible eligible articles
// (live REP button, not already done/busy/skipped). Grows the pool with
// any not seen before, then tops up the selected set to match the
// current target count (Math.round(total * percentage / 100)).
function repUpdateAutoSelection(eligibleArticles) {
  eligibleArticles.forEach((a) => {
    if (!repAutoPoolSeen.includes(a)) repAutoPoolSeen.push(a);
  });

  if (repAutoPercentage >= 100) {
    // Fast path — everything eligible gets selected, no randomness needed.
    repAutoPoolSeen.forEach((a) => repAutoSelected.add(a));
    return;
  }

  const targetCount = Math.round(repAutoPoolSeen.length * repAutoPercentage / 100);
  const currentlySelected = repAutoPoolSeen.filter((a) => repAutoSelected.has(a));
  const need = targetCount - currentlySelected.length;
  if (need <= 0) return;

  // Randomly add `need` more from the not-yet-selected pool.
  const unselected = repAutoPoolSeen.filter((a) => !repAutoSelected.has(a));
  for (let i = unselected.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [unselected[i], unselected[j]] = [unselected[j], unselected[i]];
  }
  unselected.slice(0, need).forEach((a) => repAutoSelected.add(a));
}


function repTryActivate() {
  if (!repEngineOn) { if (repModeActive || repScanTimer) repStopEngine(); return; }
  const sid = repStatusId(location.href);
  if (!sid) return;              // not a status/post page — nothing to do
  if (repModeActive && repOriginStatusId === sid) return; // already running here

  repModeActive = true;
  repOriginStatusId = sid;
  repResetAutoPool(); // fresh percentage pool for this post
  repWaitForMainPost();
}

// Initial boot for a hard page load / extension (re)start.
repTryActivate();

// X is a single-page app — clicking into a different post doesn't reload
// the content script, so watch for URL changes and re-arm the engine.
let _repLastHref = location.href;
setInterval(() => {
  if (location.href === _repLastHref) return;
  _repLastHref = location.href;
  repTryActivate();
  feedTryActivate();
  searchTryActivate();
}, 800);

function repWaitForMainPost(attempt) {
  attempt = attempt || 0;
  const firstArticle = document.querySelector('article[data-testid="tweet"]');
  const firstText = firstArticle ? firstArticle.querySelector('[data-testid="tweetText"]') : null;

  if (firstArticle && firstText) {
    repPostText = firstText.innerText.trim();
    repPostArticle = firstArticle;
    if (!repEngineOn) return;
    showToast('REP engine ON — REP buttons will appear on comments', 'success');
    repScanTimer = setInterval(repScanComments, 1200);
    repScanComments();
    return;
  }
  if (attempt > 25) return; // ~15s — page never rendered, give up quietly
  setTimeout(() => repWaitForMainPost(attempt + 1), 600);
}

function repScanComments() {
  if (!repModeActive) return;
  if (!repEngineOn) { repStopEngine(); return; }
  if (!extContextAlive()) { clearInterval(repScanTimer); repModeActive = false; return; }

  // Guard against SPA navigation away from the opened post — engine
  // must never carry over to whatever the user browses to next.
  if (repStatusId(location.href) !== repOriginStatusId) {
    clearInterval(repScanTimer);
    repModeActive = false;
    return;
  }

  const articles = document.querySelectorAll('article[data-testid="tweet"]');
  if (articles.length < 2) return;
  // Index 0 is the main post itself — never a comment.
  for (let i = 1; i < articles.length; i++) {
    repInjectButton(articles[i]);
  }

  if (repAutoModeOn) repAutoLoop();
}

function repInjectButton(article) {
  if (isAdArticle(article)) return; // skip promoted posts
  if (repDoneArticles.has(article)) return;
  if (article.querySelector('.zen-rep-btn')) { repDoneArticles.add(article); return; }

  const actionBar = article.querySelector('[role="group"]');
  if (!actionBar) return; // not fully rendered yet — retry on next scan

  const commentTextEl = article.querySelector('[data-testid="tweetText"]');
  if (!commentTextEl || !commentTextEl.innerText.trim()) { repDoneArticles.add(article); return; } // text-less comment, nothing to reply from

  // Never show REP on your own comments under your own post.
  if (isOwnArticle(article)) { repDoneArticles.add(article); return; }

  // Reply By Wallchain Score — score outside the range = no REP button on this comment.
  { const g = zexWcGate(article, 'rep'); if (g === 'wait') return; if (g === 'skip') { repDoneArticles.add(article); return; } }

  if (!_zenIdsReady) return;   // replied/History list not loaded yet — retry on the next scan
  repDoneArticles.add(article);

  const cid = repCommentId(article);
  const sessionDone = cid && repProcessedIds.has(cid);
  if (zexBlockedArticle(article)) { zexLogBlocked(cid, 'REP', zenArticleLink(article), getArticleAuthorHandle(article)); return; }
  let persistedDone = hasAlreadyReplied(cid);

  // Not in our own persisted log yet — check X's own DOM in case this
  // comment already has your reply from before this session (manual
  // reply, or replied before the extension tracked it).
  if (!persistedDone && !sessionDone && threadAlreadyHasOwnReply(article)) {
    persistedDone = true;
    if (cid) markStatusIdReplied(cid);
  }

  const alreadyDone = sessionDone || persistedDone;

  // Already replied to this exact comment in a previous session — skip
  // showing any button at all rather than a disabled DONE placeholder.
  if (persistedDone && !sessionDone) { zenLogSkip(cid, 'REP', zenArticleLink(article), getArticleAuthorHandle(article)); return; }

  const btn = document.createElement('button');
  btn.className = 'zen-rep-btn';
  btn.type = 'button';

  if (alreadyDone) {
    btn.textContent = 'DONE';
    btn.classList.add('zen-rep-done');
    btn.disabled = true;
    btn.title = 'Already drafted this session';
  } else {
    btn.textContent = 'REP';
    btn.title = 'Generate a short reply for this comment';
    btn.addEventListener('click', async (e) => {
      e.preventDefault(); e.stopPropagation();
      await repHandleClick(article, commentTextEl, btn);
    });
  }

  actionBar.appendChild(btn);
}

async function repHandleClick(article, commentTextEl, btn) {
  if (repBusyArticles.has(article)) return;
  if (zenAlreadyGuard(article, 'REP', btn, repCommentId(article))) return;

  if (!navigator.onLine) { showToast('No internet connection!', 'error'); return; }

  const { zenDeviceSession } = await getStorage(['zenDeviceSession']);
  if (!zenDeviceSession || Date.now() >= zenDeviceSession.expiresAt) {
    showToast('Session expired! Open Z EX and login again.', 'warn');
    return;
  }

  const syncResult = await syncAdminApiKey(zenDeviceSession.email);
  if (syncResult && syncResult.locked) { showToast('Contact Admin', 'error'); return; }

  const limitCheck = await checkAndIncrementReplyCount(zenDeviceSession.email);
  if (!limitCheck.allowed) {
    showToast('' + (limitCheck.reason === 'Contact Admin' ? 'Contact Admin' : limitCheck.reason), 'error');
    return;
  }
  trackActivity(zenDeviceSession.email);

  const storage = await getStorage(['smartSwitch']);
  const smartSwitch = storage.smartSwitch !== false;

  const commentText = commentTextEl.innerText.trim();

  repBusyArticles.add(article);
  const originalHTML = btn.innerHTML;
  btn.innerHTML = '<span class="zen-spin"></span>';
  btn.disabled = true;

  try {
    let editor = null;
    if (await zenLiveEnabled()) { // Live: open the box first, then stream into it
      editor = await repOpenReplyBox(article, { eng: 'REP' });
      if (!editor) throw new Error(zenNoBoxMsg());
      repLastEditor = editor;
    }
    const reply = await zenLiveGenerate(editor, () => repGenerateReplyWithFallback(
      repPostText, commentText, smartSwitch, repPostArticle
    ));

    if (!editor) {
      editor = await repOpenReplyBox(article, { eng: 'REP' });
      if (!editor) throw new Error(zenNoBoxMsg());
      repLastEditor = editor;
    }

    await insertReply(editor, reply);

    // Track actual posting (not just drafting) so this comment is
    // remembered as already-replied-to even after a reload/new session.
    const cidForWatch = repCommentId(article);
    pendingReplyMap.set(editor, { tweetLink: cidForWatch ? `https://x.com/i/status/${cidForWatch}` : null, tweetAuthor: getArticleAuthorHandle(article) || '', replyText: reply, tone: 'REP', ts: Date.now() });
    armPostWatcher(editor);

    let autoPosted = false;
    if (repAutoModeOn) {
      // Auto Mode means no manual review — submit through X's own button
      // right away so the box actually closes and repWaitForClose lets the
      // loop move on to the next comment by itself.
      autoPosted = await repAutoSubmit(editor);
    }

    btn.textContent = 'DONE';
    btn.classList.add('zen-rep-done');
    btn.disabled = true;
    showToast(autoPosted ? 'Reply posted' : 'Reply drafted — review & tap Reply', 'success');
    zenAgentRecord('REP', true, !!autoPosted);

    const cid = repCommentId(article);
    if (cid) repProcessedIds.add(cid);

    chrome.storage.local.get(['zenRepDraftCount'], (d) => {
      chrome.storage.local.set({ zenRepDraftCount: (d.zenRepDraftCount || 0) + 1 });
    });
  } catch (err) {
    zenAgentRecord('REP', false, false, err && err.message);
    showToast('' + (err.message || 'Reply failed'), 'error');
    btn.innerHTML = originalHTML;
    btn.disabled = false;
  } finally {
    repBusyArticles.delete(article);
  }
}

// Auto Mode only — waits for X's own Reply/Post button on this editor to
// become enabled (it's disabled while empty, briefly after paste too), then
// waits a random human-like beat before actually clicking it.
// Mobile/zoom fix: Reply button may be below the fold or offset by zoom.
// We scroll it into view AND reset viewport scale before firing the click.

// ─── "Something went wrong" after Reply → Back → Discard → next post ───
const ZEN_POST_ERR_MSG = 'X error after Reply ("Something went wrong") — draft discarded, moving to next post.';
function zenPostErrorShowing() {
  const sel = '[role="alert"], [data-testid="toast"], [data-testid="error-detail"], main div, [role="dialog"] div';
  const nodes = document.querySelectorAll(sel);
  for (const n of nodes) {
    if (n.children.length > 4) continue;
    const t = (n.textContent || '').trim();
    if (t.length < 160 && /something went wrong/i.test(t)) return true;
  }
  return false;
}
async function zenWaitPostError(editor, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (zenPostErrorShowing()) return true;
    // Posted fine: the compose screen is gone / the editor was removed.
    if (!/\/compose\//.test(location.pathname) && editor && !document.body.contains(editor)) return false;
    await new Promise(r => setTimeout(r, 250));
  }
  return zenPostErrorShowing();
}
function zenFindByText(root, re, selector) {
  const els = (root || document).querySelectorAll(selector || 'button, [role="button"]');
  for (const e of els) if (re.test((e.innerText || e.textContent || '').trim())) return e;
  return null;
}
async function zenRecoverPostError() {
  try {
    // 1) Back arrow (top-left of the compose screen)
    const back = document.querySelector('[data-testid="app-bar-back"], [aria-label="Back"], [data-testid="app-bar-close"], [aria-label="Close"]');
    if (back) { if (ZenCursor.active) { try { await ZenCursor.moveTo(back); } catch (e) {} } await realClick(back); }
    // 2) "Save post?" dialog → Discard
    for (let i = 0; i < 20; i++) {
      await new Promise(r => setTimeout(r, 250));
      const dlg = document.querySelector('[role="alertdialog"], [data-testid="confirmationSheetDialog"], [role="dialog"], [aria-modal="true"]');
      const disc = zenFindByText(dlg || document, /^discard$/i);
      if (disc) { await realClick(disc); break; }
      if (!/\/compose\//.test(location.pathname)) break;   // already left the compose screen
    }
    await new Promise(r => setTimeout(r, 700));
  } catch (e) { console.warn('[Z EX] zenRecoverPostError failed', e); }
}


// ═══ EXTRA SAFETY 1 / 2 ═══════════════════════════════════════════════════════
// ES1: "Something went wrong" after Reply → click Reply a 2nd time. If it fails again AND X shows
//      "This request looks like it might be automated…" → discard, reload, Home → scroll → like 2-3 → Profile → scroll → back to the page.
// ES2: draw by % → open the post itself first (click inside the post), then open the comment box from there.
let zexEs1On = false, zexEs2On = false, zexEs2Pct = 30;
try {
  chrome.storage.local.get(['zexEs1On', 'zexEs2On', 'zexEs2Pct'], (d) => {
    d = d || {}; zexEs1On = d.zexEs1On === true; zexEs2On = d.zexEs2On === true;
    if (typeof d.zexEs2Pct === 'number') zexEs2Pct = d.zexEs2Pct;
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.zexEs1On) zexEs1On = ch.zexEs1On.newValue === true;
    if (ch.zexEs2On) zexEs2On = ch.zexEs2On.newValue === true;
    if (ch.zexEs2Pct) zexEs2Pct = typeof ch.zexEs2Pct.newValue === 'number' ? ch.zexEs2Pct.newValue : 30;
  });
} catch (e) {}
const ZEX_ES1_KEY = 'zexEs1Job';
const _esSleep = (ms) => new Promise((r) => setTimeout(r, ms));
const _esRnd = (a, b) => a + Math.random() * (b - a);
function zexAutomatedShowing() {
  try { return /might be automated/i.test(document.body.innerText || ''); } catch (e) { return false; }
}
async function zexEsScroll(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    window.scrollBy({ top: _esRnd(250, 520), behavior: 'smooth' });
    zenProgress();
    await _esSleep(_esRnd(700, 1300));
  }
}
async function zexEsLikeSome(n) {
  let done = 0;
  for (let t = 0; t < 10 && done < n; t++) {
    const btns = [...document.querySelectorAll('article [data-testid="like"]')].filter((b) => {
      const r = b.getBoundingClientRect();
      return r.width > 0 && r.top > 90 && r.bottom < window.innerHeight - 70;
    });
    if (btns.length) {
      await realClick(btns[Math.floor(Math.random() * btns.length)]);
      done++; await _esSleep(_esRnd(1500, 3000));
    }
    window.scrollBy({ top: _esRnd(300, 600), behavior: 'smooth' });
    await _esSleep(_esRnd(1200, 2200));
  }
}
async function zexEsWaitFor(fn, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) { try { const v = fn(); if (v) return v; } catch (e) {} try { zenProgress(); } catch (e) {} await _esSleep(300); }
  return null;
}
function zexEsFindProfileLink() {
  return document.querySelector('a[data-testid="AppTabBar_Profile_Link"]') ||
    [...document.querySelectorAll('a[role="link"]')].find((a) => /^profile$/i.test((a.innerText || '').trim()));
}
async function zexEs1Routine(job) {
  window.__zexEs1Busy = true;
  try {
    showToast('Extra Safety 1 — cooling down like a normal user…', 'info');
    await zexEsWaitFor(() => document.querySelector('article'), 15000);
    await _esSleep(_esRnd(1500, 2500));
    // Home icon → Home feed → scroll → like 2-3 posts
    const home = document.querySelector('a[data-testid="AppTabBar_Home_Link"], a[href="/home"]');
    if (home) { await realClick(home); await zexEsWaitFor(() => /\/home/.test(location.pathname) && document.querySelector('article'), 10000); }
    await _esSleep(_esRnd(1500, 2500));
    await zexEsScroll(_esRnd(5000, 8000));
    await zexEsLikeSome(2 + Math.floor(Math.random() * 2));
    // Profile → scroll 3-4s
    let prof = zexEsFindProfileLink();
    if (!prof) {
      const av = document.querySelector('[data-testid="DashButton_ProfileIcon_Link"], [aria-label="Account menu"]');
      if (av) { await realClick(av); prof = await zexEsWaitFor(zexEsFindProfileLink, 4000); }
    }
    if (prof) {
      await realClick(prof);
      await zexEsWaitFor(() => document.querySelector('[data-testid="UserName"], [data-testid="primaryColumn"] article'), 10000);
      await _esSleep(_esRnd(1000, 1800));
      await zexEsScroll(_esRnd(3000, 4000));
    }
  } catch (e) { console.warn('[Z EX] ES1 routine error', e); }
  // Back to the saved page; engines resume after it renders (same as Auto Refresh).
  try { sessionStorage.removeItem(ZEX_ES1_KEY); sessionStorage.setItem('zenArResume', String(Date.now())); } catch (e) {}
  location.href = (job && job.url) || 'https://x.com/home';
}
async function zexEs1Handle(editor) {
  window.__zexEs1Busy = true;
  let leaving = false;
  try {
    showToast('Extra Safety 1 — error, trying Reply once more…', 'warn');
    await _esSleep(_esRnd(1800, 3200));
    const btn = findSubmitButton(editor);
    if (!btn || btn.disabled || btn.getAttribute('aria-disabled') === 'true') return 'fail';
    await realClick(btn);
    if (!(await zenWaitPostError(editor, 5000))) return 'ok';
    await _esSleep(600);
    if (!zexAutomatedShowing()) return 'fail';
    try { zexErrLogPush('ES1', 'Automated-request block — running cool-down routine'); } catch (e) {}
    const url = _zenGoodUrl || 'https://x.com/home';
    try { zenSkipStuckPost(); } catch (e) {}
    await zenRecoverPostError();
    try { sessionStorage.setItem(ZEX_ES1_KEY, JSON.stringify({ ts: Date.now(), url })); } catch (e) {}
    leaving = true;
    location.href = url;           // fresh page, then zexEs1Routine runs
    return 'routine';
  } finally { if (!leaving) window.__zexEs1Busy = false; }
}
try {
  if (sessionStorage.getItem(ZEX_ES1_KEY)) { window.__zexEs1Busy = true; zenRefreshHold = true; }
} catch (e) {}
setTimeout(() => {
  try {
    const raw = sessionStorage.getItem(ZEX_ES1_KEY); if (!raw) return;
    const job = JSON.parse(raw);
    if (!job || Date.now() - job.ts > 240000) { sessionStorage.removeItem(ZEX_ES1_KEY); window.__zexEs1Busy = false; zenRefreshHold = false; return; }
    zexEs1Routine(job);
  } catch (e) {}
}, 2500);

// ES2 ───────────────────────────────────────────────────────────────────────
function zexEs2Roll() {
  const c = Math.min(100, Math.max(0, Math.round(Number(zexEs2Pct)) || 0));
  if (c >= 100) return true; if (c <= 0) return false;
  const g = _zexGcd(c, 100); let size = 100 / g, yes = c / g;
  const k = Math.max(1, Math.ceil(20 / size)); size *= k; yes *= k;
  const sk = 'zexEs2Deck:' + c; let deck = [];
  try { deck = JSON.parse(sessionStorage.getItem(sk) || '[]'); } catch (e) {}
  if (!Array.isArray(deck) || !deck.length) {
    deck = []; for (let n = 0; n < size; n++) deck.push(n < yes ? 1 : 0);
    for (let n = deck.length - 1; n > 0; n--) { const r = Math.floor(Math.random() * (n + 1)); const t = deck[n]; deck[n] = deck[r]; deck[r] = t; }
  }
  const v = deck.pop() === 1;
  try { sessionStorage.setItem(sk, JSON.stringify(deck)); } catch (e) {}
  console.log('[Z EX] ES2 draw (' + c + '%): ' + (v ? 'OPEN POST' : 'direct') + ' — ' + deck.length + ' cards left');
  return v;
}
const _esStatusId = () => { const m = location.pathname.match(/\/status\/(\d+)/); return m ? m[1] : ''; };
function zexEs2Abort() { window.__zexEs2Back = null; }
// Returns: the article on the opened post page | null (comment the normal way) | 'off' (comments are off, nothing more to do)
async function zexEs2Enter(article, opts) {
  if (!zexEs2Roll()) return null;
  const sid = articleStatusId(article), listUrl = location.href;
  if (!sid) return null;
  // No coordinates: a floating/popup window offsets and scales screen coordinates, so a tap aimed at the text
  // could land on an image or a neighbouring post. We click this post's own permalink (time link) directly.
  const exact = new RegExp('/status/' + sid + '$');
  const links = [...article.querySelectorAll('a[href*="/status/' + sid + '"]')].filter((x) => exact.test((x.getAttribute('href') || '').split('?')[0]));
  const link = links.find((x) => x.querySelector('time')) || links[0];
  if (!link) return null;
  // Guard the lost-page / stuck watchers for the whole detour.
  window.__zexEs2Back = { url: listUrl, sid, ts: Date.now(), seenCompose: false, t0: 0 };
  try { link.click(); } catch (e) { zexEs2Abort(); return null; }
  const landed = await zexEsWaitFor(() => _esStatusId() !== '' && !/\/compose\//.test(location.pathname), 6000);
  if (!landed) { zexEs2Abort(); return null; }
  if (_esStatusId() !== sid) {                     // wrong post opened → step back out, comment the normal way
    console.warn('[Z EX] ES2: opened', _esStatusId(), 'but wanted', sid, '— going back');
    zexEs2Abort(); history.back();
    await zexEsWaitFor(() => _esStatusId() === '', 5000); await _esSleep(800);
    return null;
  }
  const art = await zexEsWaitFor(() => {
    const a = [...document.querySelectorAll('article[data-testid="tweet"]')].find((x) => articleStatusId(x) === sid);
    return a && a.querySelector('[data-testid="reply"]') ? a : null;
  }, 8000);
  if (!art) { zexEs2Abort(); history.back(); await zexEsWaitFor(() => _esStatusId() === '', 5000); await _esSleep(800); return null; }
  await _esSleep(_esRnd(1500, 3500));
  if (zenReplyOffBannerPresent()) {                // "who can reply" limited → same handling as the normal path, then leave
    try { zenHandleReplyOff(art, opts); } catch (e) {}
    zexEs2Abort(); history.back(); await zexEsWaitFor(() => _esStatusId() === '', 5000); await _esSleep(600);
    return 'off';
  }
  return art;
}
// Called when the reply flow is over (posted, failed or discarded): leave the post page and wait until the list is back,
// so the engine never carries on (like / reply / scroll) while it is still inside the post.
async function zexEs2Return() {
  const b = window.__zexEs2Back; if (!b) return;
  try {
    const t0 = Date.now();
    while (/\/compose\//.test(location.pathname) && Date.now() - t0 < 8000) { try { zenProgress(); } catch (e) {} await _esSleep(250); }
    await _esSleep(_esRnd(1200, 2200));
    if (_esStatusId()) {
      history.back();
      await zexEsWaitFor(() => _esStatusId() === '' && !/\/compose\//.test(location.pathname), 8000);
      if (_esStatusId()) { location.href = b.url; await _esSleep(1500); }   // last resort: reload the list page
    }
    await zexEsWaitFor(() => document.querySelector('article'), 8000);
    await _esSleep(_esRnd(700, 1400));
  } catch (e) {} finally { window.__zexEs2Back = null; }
}
// Safety net: a post page with no reply flow running for 40s (reply icon missing, compose never opened…) → leave it.
setInterval(() => {
  try {
    const b = window.__zexEs2Back; if (!b) return;
    if (Date.now() - b.ts > 240000) { window.__zexEs2Back = null; return; }
    if (/\/compose\//.test(location.pathname)) { b.seenCompose = true; b.ts2 = Date.now(); return; }
    if (_esStatusId() && Date.now() - (b.ts2 || b.ts) > 40000) { window.__zexEs2Back = null; history.back(); }
  } catch (e) {}
}, 2000);

// ─── Lost-page recovery (misclick / stuck → go back automatically) ───────────
// A misclick can drop an auto engine on a profile, a photo viewer, another post, a list…
// where it has nothing to do and would wait forever. If an auto engine (REP / FED / SEA / GIV)
// was working a moment ago and the tab is now on a page it can't use, we go back by ourselves:
//   1) X's own Back arrow  2) history.back()  3) jump straight to the last good page.
let _zenGoodUrl = '';            // last page where an auto engine had real work to do
let _zenLastEngineTs = 0;        // last time an engine acted (loop tick / reply-box open)
let _zenLostSince = 0;
let _zenErrSeen = 0;      // when the "Something went wrong" banner first showed on the compose page
let _zenRecoverStep = 0;
let _zenRecovering = false;
let _zenProgressTs = Date.now();   // last time any auto loop made real progress (stuck-watchdog heartbeat)
let _zenLoopEpoch = 0;             // bumped on stuck-recovery so an orphaned (hung) loop can't run alongside the new one
function zenProgress() { _zenProgressTs = Date.now(); }
function zenMarkEngineActivity() { _zenLastEngineTs = Date.now(); _zenProgressTs = Date.now(); }

function zenAutoEngineWantsThisPage() {
  const url = location.href;
  if (repEngineOn && repAutoModeOn && repStatusId(url)) return true;
  if ((feedEngineOn || givEngineOn) && (feedAutoModeOn || givAutoModeOn) && isHomeFeedUrl(url)) return true;
  if ((searchEngineOn || givEngineOn) && (searchAutoModeOn || givAutoModeOn) && isSearchUrl(url)) return true;
  return false;
}
function zenAnyAutoOn() {
  return (repEngineOn && repAutoModeOn) || (feedEngineOn && feedAutoModeOn) || (searchEngineOn && searchAutoModeOn) || (givEngineOn && givAutoModeOn);
}
async function zenOtherFlowOwnsTab() {
  if (sessAutoRunningFor || tarRunningFor || followRunningFor) return true;
  try {
    const d = await getStorage(['zSessAutoPending', 'zTarPending', 'zTarJob', 'zFollowJob']);
    const pend = d.zSessAutoPending;
    if (pend && Date.now() - (pend.issuedAt || 0) < 150000) return true;
    if (d.zTarPending || (d.zTarJob && d.zTarJob.status && d.zTarJob.status !== 'done' && d.zTarJob.status !== 'stopped')) return true;
    if (d.zFollowJob && d.zFollowJob.status && d.zFollowJob.status !== 'done' && d.zFollowJob.status !== 'stopped') return true;
  } catch (e) {}
  return false;
}
async function zenGoBackOnce() {
  // Compose screen: Back arrow (+ Discard on the "Save post?" sheet).
  if (/\/compose\//.test(location.pathname)) { await zenRecoverPostError(); return; }
  // Photo / video viewer or any page with X's own Back arrow.
  const back = document.querySelector('[data-testid="app-bar-back"], [aria-label="Back"]');
  if (back) { try { if (ZenCursor.active) await ZenCursor.moveTo(back); } catch (e) {} await realClick(back); return; }
  const closeBtn = document.querySelector('[data-testid="Close"], [aria-label="Close"]');
  if (closeBtn && /\/photo\/|\/video\//.test(location.pathname)) { await realClick(closeBtn); return; }
  history.back();
}
// ═══ HARD REFRESH ═══════════════════════════════════════════════════════════
// Lost-page recovery could not get out of a wrong page (e.g. a post opened in this tab with nothing to go back to)
// → open the Search page in a NEW tab and close this one. Toggle: popup → Hard Refresh.
let zexHardRefreshOn = false;
try {
  chrome.storage.local.get(['zexHardRefreshOn'], (d) => { zexHardRefreshOn = !!(d && d.zexHardRefreshOn === true); });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.zexHardRefreshOn) zexHardRefreshOn = ch.zexHardRefreshOn.newValue === true; });
} catch (e) {}
async function zexHardRefresh(why) {
  try {
    // cap: max 3 per 30 min, so it can never spawn tabs forever
    const now = Date.now();
    const d = await getStorage(['zexHardRefreshLog', 'zenSearchKeywords', 'zenSearchFilters', 'zenSearchResultType', 'zenSearchRawOn', 'zenSearchRawQuery']);
    const log = (Array.isArray(d.zexHardRefreshLog) ? d.zexHardRefreshLog : []).filter((t) => now - t < 1800000);
    if (log.length >= 3) { showToast('Hard Refresh limit reached (3 / 30 min)', 'warn'); return false; }
    let url = '';
    if (searchEngineOn || givEngineOn) {
      const raw = d.zenSearchRawOn === true && typeof d.zenSearchRawQuery === 'string' ? d.zenSearchRawQuery.replace(/\s+/g, ' ').trim() : '';
      try { if (window.__zexBuildSearchUrl) url = window.__zexBuildSearchUrl(d.zenSearchKeywords || [], d.zenSearchFilters || {}, d.zenSearchResultType || 'top', raw) || ''; } catch (e) {}
    }
    if (!url) url = _zenGoodUrl || 'https://x.com/home';
    log.push(now);
    await new Promise((r) => chrome.storage.local.set({ zexHardRefreshLog: log }, r));
    try { if (typeof zexT === 'function') zexT('lost', { why: 'hard', h: location.pathname.slice(0, 60) }); } catch (e) {}
    showToast('Hard Refresh — opening a fresh tab…', 'warn');
    await new Promise((r) => setTimeout(r, 600));
    chrome.runtime.sendMessage({ type: 'zexHardRefresh', url });
    return true;
  } catch (e) { return false; }
}

async function zenLostPageTick() {
  try {
    if (_zenRecovering || !extContextAlive()) return;
    if (!/^(x|twitter)\.com$/.test(location.hostname.replace(/^www\./, ''))) return;
    if (!zenAnyAutoOn() || zenRefreshHold || window.__zexPvNav || window.__zexEs1Busy || (window.__zexEs2Back && Date.now() - window.__zexEs2Back.ts < 240000)) { _zenLostSince = 0; return; }   // PvNav: our own Profile Visit

    if (zenAutoEngineWantsThisPage()) {          // on a usable page → remember it, all good
      _zenGoodUrl = location.href; _zenLostSince = 0; _zenRecoverStep = 0; return;
    }
    // Only react if an engine was actually working right before (so a user browsing on purpose isn't dragged back).
    if (!zenStuckLoopsRunning() && Date.now() - Math.max(_zenLastEngineTs, _zenProgressTs) > 120000 && !_zenLostSince) return;   // a loop that is switched on but sitting on a wrong page also counts (it used to stay lost for minutes)   // delay / AI heartbeats (zenProgress) also mean "an engine is working"
    {
      const _errNow = zenPostErrorShowing();
      if (!_errNow) _zenErrSeen = 0; else if (!_zenErrSeen) _zenErrSeen = Date.now();
      // normal reply flow gets 60s; once "Something went wrong" is on screen we go back after 20s
      // The reply box is a /compose/ URL (X puts the search/feed page behind it) — that is NOT a wrong page while the engine is alive.
      // Before: only reply-box-open counted as activity, so a slow AI / long delay / slow network passed 60s and got "Wrong page — going back" (post discarded).
      // Now: any heartbeat counts, and a real reply box that is up gets 150s. True hangs are still caught earlier by the stuck watchdog (20s).
      const _zenAlive = Date.now() - Math.max(_zenLastEngineTs, _zenProgressTs);
      const _zenBoxUp = !!document.querySelector('[data-testid="tweetTextarea_0"]');
      if (/\/compose\//.test(location.pathname) && (_errNow ? Date.now() - _zenErrSeen < 20000 : _zenAlive < (_zenBoxUp ? 150000 : 60000))) return;
    }
    if (await zenOtherFlowOwnsTab()) { _zenLostSince = 0; return; }

    if (!_zenLostSince) { _zenLostSince = Date.now(); return; }
    if (Date.now() - _zenLostSince < 7000) return;   // grace: pages/animations still settling

    _zenRecovering = true;
    try {
      _zenRecoverStep++;
      // On /home (or the bare site) with a known good page, Back leads nowhere useful → return to the good page right away (was: ~4 min of steps).
      if (_zenGoodUrl && /^\/(home)?\/?$/.test(location.pathname) && !document.querySelector('[data-testid="app-bar-back"]') && _zenRecoverStep < 3) _zenRecoverStep = 3;
      console.warn('[Z EX] Lost page — going back. step', _zenRecoverStep, location.href, '| loops running:', zenStuckLoopsRunning(), '| good page:', _zenGoodUrl ? _zenGoodUrl.slice(0, 60) : '-', '| idle s:', Math.round((Date.now() - Math.max(_zenLastEngineTs, _zenProgressTs)) / 1000));
      if (_zenRecoverStep <= 2) {
        showToast('Wrong page — going back…', 'warn');
        if (_zenRecoverStep === 1) { try { if (typeof zexT === 'function') zexT('lost', { why: 'back', h: location.pathname.slice(0, 60) }); } catch (e) {} }
        await zenGoBackOnce();
      } else if (_zenGoodUrl && _zenRecoverStep <= 4) {
        showToast('Still lost — returning to the last page…', 'warn');
        if (_zenRecoverStep === 3) { try { if (typeof zexT === 'function') zexT('lost', { why: 'return', h: location.pathname.slice(0, 60) }); } catch (e) {} }
        location.href = _zenGoodUrl;
      } else {
        // Nothing worked. Hard Refresh ON → new tab with the Search page, this tab closes. Otherwise give up quietly.
        if (zexHardRefreshOn && await zexHardRefresh('lost-page loop')) { _zenRecoverStep = 0; _zenLostSince = Date.now() + 60000; return; }
        _zenRecoverStep = 0; _zenLostSince = 0;
      }
      _zenLostSince = Date.now();   // wait another grace period before judging the result
    } finally { _zenRecovering = false; }
  } catch (e) {}
}
setInterval(zenLostPageTick, 2000);

// ─── Stuck watchdog (engine hung mid-post → recover, then run again) ──────────
// Catches the case the Lost-page recovery can't: we ARE on the right page but an auto loop
// stopped making progress (reply box never opened, GET Reply never appeared, a promise never
// resolved, a stale reply sheet is blocking, …). Every real step calls zenProgress() /
// zenMarkEngineActivity(); if a loop is "running" but silent for zenStuckLimit() (20s × network factor) we:
//   1st/2nd time → SOFT : close any leftover reply sheet, drop the hung run, restart the loops.
//   repeats soon → HARD : reload the page (engines resume by themselves, same as Auto Refresh).
// Hard reloads are capped so it can never reload-loop forever.
// Not counted as stuck: tab hidden, offline (waits for the connection), and any delay the engine itself chose.
const ZEN_STUCK_BASE_MS = 20000;     // GOOD network: 20s with no progress = stuck (was 60s). Slow network → more patience (zenStuckLimit): FAIR 30s · SLOW 40s · POOR 60s
// Delay system: a wait the engine chose on purpose (reply gap, like→comment gap, custom seconds)
// is never "stuck", however long it is. zenDelayWait() registers it here so the watchdog can read it.
let _zenDelayUntil = 0;
let _zenDelayLabel = '';
function zenDelayActive() { return Date.now() < _zenDelayUntil; }
function zenDelayLeftMs() { return Math.max(0, _zenDelayUntil - Date.now()); }
function zenDelayWait(ms, label) {
  ms = Math.max(0, Math.round(ms));
  const end = Date.now() + ms;
  if (end + 3000 > _zenDelayUntil) { _zenDelayUntil = end + 3000; _zenDelayLabel = label || 'DELAY'; }   // +3s grace after it ends
  zenProgress();
  return new Promise((resolve) => {
    (function slice() {
      const left = end - Date.now();
      if (left <= 0) { zenProgress(); if (Date.now() >= _zenDelayUntil - 2500) { _zenDelayUntil = 0; _zenDelayLabel = ''; } resolve(); return; }
      zenProgress();                                   // heartbeat while waiting
      setTimeout(slice, Math.min(1000, left));
    })();
  });
}
// Stuck limit follows the network: GOOD 1x · FAIR 1.5x · SLOW 2x · POOR 3x (OFFLINE = paused, see zenStuckTick).
function zenStuckLimit() {
  let m = 1;
  try { if (window.ZexNet) m = ZexNet.stuckMult(); } catch (e) {}
  return Math.round(ZEN_STUCK_BASE_MS * m);
}
const ZEN_STUCK_SOFT_WINDOW = 600000; // 2 soft fixes within 10 min → next one is a hard reload
const ZEN_STUCK_MAX_RELOADS = 3;      // max hard reloads per 30 min
let _zenStuckFixing = false;
let _zenStuckSoftTimes = [];

// ─── Post skip list ──────────────────────────────────────────────────────────
// A post an engine could not finish (no GET Reply / stuck mid-post / failed) goes on this list by
// STATUS ID (not by DOM node — X re-mounts nodes, and a reload wipes them), so every engine's
// next pass leaves it alone instead of getting stuck on it again. Kept in sessionStorage so it
// survives the watchdog's page reload. Entries expire after 30 min.
const ZEN_SKIP_TTL = 30 * 60 * 1000;
const _zenSkipSids = new Map();   // sid -> ts
try {
  const o = JSON.parse(sessionStorage.getItem('zenSkipSids') || '{}');
  const t0 = Date.now();
  Object.keys(o).forEach((k) => { if (t0 - o[k] < ZEN_SKIP_TTL) _zenSkipSids.set(k, o[k]); });
} catch (e) {}
function zenSkipSave() {
  try {
    const o = {}; _zenSkipSids.forEach((v, k) => { o[k] = v; });
    sessionStorage.setItem('zenSkipSids', JSON.stringify(o));
  } catch (e) {}
}
function zenSkipSidOf(article) {
  try { return articleStatusId(article) || repCommentId(article) || ''; } catch (e) { return ''; }
}
function zenPostSkipped(article) {
  const sid = zenSkipSidOf(article);
  if (!sid || !_zenSkipSids.has(sid)) return false;
  if (Date.now() - _zenSkipSids.get(sid) > ZEN_SKIP_TTL) { _zenSkipSids.delete(sid); return false; }
  return true;
}
function zenRefindArticle(sid) {
  if (!sid) return null;
  return Array.from(document.querySelectorAll('article[data-testid="tweet"]')).find((a) => zenSkipSidOf(a) === sid) || null;
}
function zenSkipErr(msg) { const e = new Error(msg); e.zenSkipped = true; return e; }
function zenSkipSid(sid, eng, why, author) {
  if (!sid) return;
  const fresh = !_zenSkipSids.has(sid);
  _zenSkipSids.set(sid, Date.now());
  zenSkipSave();
  if (fresh) {
    try { if (typeof zexT === 'function') zexT('skip', { eng: eng || '', why: why || '', link: 'https://x.com/i/status/' + sid, h: author || '' }); } catch (e) {}
    if (why === 'failed' || why === 'no_get_reply' || why === 'stuck') {
      // The user pressed Stop mid-post → that is not a system failure.
      const e = zenEngTag(eng);
      const stopped = (e === 'REP' && !repAutoModeOn) || (e === 'FED' && !feedAutoModeOn) || (e === 'SEA' && !searchAutoModeOn) || (e === 'GIV' && !givAutoModeOn);
      if (!stopped || why === 'stuck') zenLogFail(sid, eng, 'https://x.com/i/status/' + sid, author || '', why);
    }
  }
}
function zenSkipPost(article, eng, why) {
  let au = ''; try { au = getArticleAuthorHandle(article) || ''; } catch (e) {}
  zenSkipSid(zenSkipSidOf(article), eng, why, au);
}
// Which post an engine is working on right now (set when its reply box opens, cleared when it finishes).
let _zenCurSid = '', _zenCurTs = 0, _zenCurEng = '';
function zenSetCurrentPost(article, eng) {
  const sid = zenSkipSidOf(article);
  if (!sid) return;
  _zenCurSid = sid; _zenCurTs = Date.now(); _zenCurEng = eng || '';
  try { console.log('[Z EX] Post start', eng || '-', sid, location.pathname.slice(0, 30)); } catch (e) {}
}
// Watchdog: the engine hung on this post → leave it out of the restarted run.
function zenSkipStuckPost() {
  if (_zenCurSid && Date.now() - _zenCurTs < 5 * 60 * 1000) {
    const sid = _zenCurSid, eng = _zenCurEng;
    _zenCurSid = '';
    zenSkipSid(sid, eng, 'stuck');
    return sid;
  }
  return '';
}

function zenStuckLoopsRunning() {
  return !!(repAutoRunning || feedAutoRunning || searchAutoRunning || givAutoRunning);
}
function zenStuckRestartLoops() {
  try {
    if (repAutoModeOn)    repAutoLoop();
    if (feedAutoModeOn)   feedAutoLoop();
    if (searchAutoModeOn) searchAutoLoop();
    if (givAutoModeOn)    givAutoLoop();
  } catch (e) {}
}
async function zenStuckCloseComposer() {
  try {
    const hasComposer = document.querySelector('[data-testid="tweetTextarea_0"]') ||
                        /\/compose\//.test(location.pathname);
    if (hasComposer) await zenRecoverPostError();   // Back/Close + "Discard" on the Save-post sheet
  } catch (e) {}
}
function zenStuckHardReload(why) {
  let log = [];
  try { log = JSON.parse(sessionStorage.getItem('zenStuckReloads') || '[]'); } catch (e) {}
  const now = Date.now();
  log = log.filter(t => now - t < 1800000);
  if (log.length >= ZEN_STUCK_MAX_RELOADS) {
    showToast('Engine keeps getting stuck — please check the page manually', 'error');
    zenProgress();   // don't re-fire every tick
    return;
  }
  log.push(now);
  try { sessionStorage.setItem('zenStuckReloads', JSON.stringify(log)); } catch (e) {}
  showToast('Engine stuck — reloading page to restart…', 'warn');
  console.warn('[Z EX] Stuck watchdog: hard reload —', why);
  try { sessionStorage.setItem('zenArResume', String(now)); } catch (e) {}   // engines wait for the feed to render, then resume
  setTimeout(() => { location.reload(); }, 800);
}
async function zenStuckTick() {
  try {
    if (_zenStuckFixing || !extContextAlive()) return;
    if (!/^(x|twitter)\.com$/.test(location.hostname.replace(/^www\./, ''))) return;
    if (document.hidden || zenRefreshHold || window.__zexPvNav || window.__zexEs1Busy || window.__zexEs2Back) { zenProgress(); return; }   // waiting for the tab / own Profile Visit is normal, not stuck
    if (!zenStuckLoopsRunning()) { zenProgress(); return; }
    try { if (window.ZexNet && ZexNet.isOffline()) { zenProgress(); return; } } catch (e) {}   // no internet = wait, don't "fix"
    if (zenDelayActive()) { zenProgress(); return; }                                          // our own delay system is waiting
    if (Date.now() - _zenProgressTs < zenStuckLimit()) return;

    _zenStuckFixing = true;
    const now = Date.now();
    _zenStuckSoftTimes = _zenStuckSoftTimes.filter(t => now - t < ZEN_STUCK_SOFT_WINDOW);
    console.warn('[Z EX] Stuck watchdog: no progress for', Math.round((now - _zenProgressTs) / 1000), 's — recovering. soft fixes so far:', _zenStuckSoftTimes.length);
    const _stuckNet = (() => { try { return window.ZexNet ? ZexNet.label() : ''; } catch (e) { return ''; } })();
    const _stuckSkipped = zenSkipStuckPost();   // the post it hung on is skipped, so the restart doesn't walk into it again

    if (_zenStuckSoftTimes.length >= 2) {
      try { if (typeof zexT === 'function') zexT('stuck', { why: 'hard', n: _zenStuckSoftTimes.length, name: _stuckNet }); } catch (e) {}
      zenStuckHardReload('repeated stuck');
      return;
    }
    try { if (typeof zexT === 'function') zexT('stuck', { why: 'soft', n: _zenStuckSoftTimes.length + 1, name: _stuckNet }); } catch (e) {}
    // SOFT recovery
    _zenStuckSoftTimes.push(now);
    showToast(_stuckSkipped ? 'Engine was stuck — skipping this post, restarting…' : 'Engine was stuck — restarting…', 'warn');
    _zenLoopEpoch++;                                  // orphan the hung run(s)
    repAutoRunning = feedAutoRunning = searchAutoRunning = givAutoRunning = false;
    try { ZenCursor.setState('rest'); } catch (e) {}
    await zenStuckCloseComposer();
    zenProgress();
    setTimeout(zenStuckRestartLoops, 1500);
  } catch (e) {
    console.warn('[Z EX] stuck watchdog error', e);
  } finally {
    _zenStuckFixing = false;
  }
}
setInterval(zenStuckTick, 5000);

// Network changes → workflow map (only while an auto engine is on, and only on a real change).
try {
  if (window.ZexNet) {
    ZexNet.subscribe((st, prev) => {
      if (!prev || prev === st.q) return;
      if (!zenAnyAutoOn()) return;
      const bad = (q) => q === 'slow' || q === 'poor';
      let why = '';
      if (st.q === 'offline') why = 'offline';
      else if (prev === 'offline') why = 'online';
      else if (bad(st.q) && !bad(prev)) why = 'slow';
      else if (!bad(st.q) && bad(prev)) why = 'recovered';
      if (!why) return;
      try { if (typeof zexT === 'function') zexT('net', { why, name: ZexNet.label(), n: st.ms || 0 }); } catch (e) {}
    });
  }
} catch (e) {}

function repAutoSubmit(editor, pauseOverrideMs) {
  return new Promise((resolve, reject) => {
    let attempts = 0;
    const maxAttempts = 25; // ~7.5s — extra time for paste+DraftJS reconcile
    const poll = setInterval(() => {
      attempts++;
      const btn = findSubmitButton(editor);
      const disabled = !btn || btn.disabled || btn.getAttribute('aria-disabled') === 'true';
      if (btn && !disabled) {
        clearInterval(poll);

        // ── Scroll fix ──────────────────────────────────────────────────
        // Viewport scale=1 locking is now handled globally and continuously
        // by _zenApplyCdpZoomGuard() for as long as zen_cdp_click is ON
        // (see its definition near _zenCdpMode) — this used to lock/restore
        // the viewport here too, just for a ~2s window around this one
        // click, which left the rest of the reply flow (typing, opening
        // the box) still exposed to a mid-flow pinch zoom breaking CDP
        // click coordinates. Only the scroll-into-view responsibility
        // stays local to this function.
        try { btn.scrollIntoView({ behavior: 'instant', block: 'center', inline: 'nearest' }); } catch (e) {}

        const pause = (typeof pauseOverrideMs === 'number' && pauseOverrideMs >= 0)
          ? pauseOverrideMs
          : (zexAdvComment() ? Math.round(zexRndRange(zexAdvComment().gen) * 1000) : 2000 + Math.random() * 1000); // default random 2.0–3.0s pause (Advanced: Timing page)
        const _pauseMs = zexFlash() ? Math.max(300, pause) : pause;   // Flash: tiny floor so the editor state is committed before the click
        setTimeout(() => {
          (async () => {
            await realClick(btn);
            // X sometimes answers with "Something went wrong…" instead of posting.
            if (await zenWaitPostError(editor, 4000)) {
              if (zexEs1On) {
                const _es = await zexEs1Handle(editor);
                if (_es === 'ok') { await zexEs2Return(); resolve(true); return; }
                if (_es === 'routine') return;   // page is reloading into the cool-down routine
              }
              await zenRecoverPostError();
              await zexEs2Return();
              reject(new Error(ZEN_POST_ERR_MSG));
              return;
            }
            await zexEs2Return();
            resolve(true);
          })();
        }, _pauseMs);
        return;
      }
      if (attempts >= maxAttempts) { clearInterval(poll); resolve(false); }
    }, 300);
  });
}

// ─── ensureInViewport ──────────────────────────────────────────
// Scrolls an element smoothly into the visible viewport and waits until
// it is actually rendered/visible there before returning. This is the
// core fix for the "DOM has 100 posts but phone screen shows 2-3" problem:
// X uses virtual/windowed rendering so off-screen articles are in the DOM
// but their inner buttons (reply icon, like, etc.) are not yet painted or
// hit-testable. Trying to click them before they're on-screen silently
// fails — no compose box opens, no error, just nothing.
//
// Called before EVERY reply-icon or button click in all three auto engines
// (REP, FEED, SEA). The article must be visible first; then its buttons work.
async function ensureInViewport(el, opts) {
  if (!el) return;
  opts = opts || {};
  const margin = opts.margin || 80; // px from edge counts as "in view"
  const maxWait = opts.maxWait || 1800; // ms to wait for it to appear
  const settle = zexFx(opts.settle || 180, 110);   // ms to let rendering settle after scroll (Flash: shorter, but never below 110ms so X can paint the buttons)

  const rect = el.getBoundingClientRect();
  const inView =
    rect.top    >= -margin &&
    rect.bottom <= window.innerHeight + margin &&
    rect.left   >= -margin &&
    rect.right  <= window.innerWidth  + margin &&
    rect.width  > 0 && rect.height > 0;

  if (inView) {
    // Already in viewport — small settle pause so any lazy-render
    // finishes painting before we fire the click.
    await new Promise(r => setTimeout(r, settle));
    return;
  }

  // Scroll the element to center of viewport.
  el.scrollIntoView({ behavior: (zexFlash() && !zexLite()) ? 'instant' : 'smooth', block: 'center', inline: 'nearest' });   // Lite: smooth = human

  // Move ZenCursor toward element so it visually tracks the scroll.
  if (ZenCursor.active) {
    await ZenCursor.moveToXY(
      window.innerWidth / 2,
      window.innerHeight / 2,
      zexFx(Math.min(400, maxWait * 0.4), 60)
    );
  }

  // Wait until the element is genuinely inside the viewport (or timeout).
  const start = Date.now();
  await new Promise(r => {
    const poll = setInterval(() => {
      const r2 = el.getBoundingClientRect();
      const now =
        r2.top    >= -margin &&
        r2.bottom <= window.innerHeight + margin &&
        r2.width  > 0 && r2.height > 0;
      if (now || Date.now() - start >= maxWait) {
        clearInterval(poll);
        r();
      }
    }, 60);
  });

  // Extra settle so X's virtual-scroll renderer finishes painting
  // the element's inner DOM (buttons, text nodes, action bar).
  await new Promise(r => setTimeout(r, settle + ((zexFlash() && !zexLite()) ? 0 : Math.random() * 80)));
}

// ─── repOpenReplyBox ──────────────────────────────────────────────
// Clicks the reply icon on an article, then returns the live contenteditable
// composer node. Handles three structural scenarios X uses:
//
//   A) Modal composer     — desktop / desktop-mode mobile
//      reply icon click → <div aria-modal> appears with tweetTextarea_0
//
//   B) Inline composer    — some desktop page layouts
//      reply icon click → composer expands inline under the article
//
//   C) Full-page compose  — NON-desktop mobile (x.com/compose/ navigation)
//      reply icon click → browser navigates to x.com/compose/
//      original article is UNMOUNTED, modal/inline searches find nothing
//      composer is found at top-level [data-testid="tweetTextarea_0"]
//
// We detect C by watching for the URL to change to /compose/ within a
// short window after the click. If that happens we wait for the compose
// page's own editor to render, then return it. Otherwise we keep polling
// for the modal/inline editor as before.

async function repOpenReplyBox(article, opts) {
  zenMarkEngineActivity();
  try { _zexTim.open = Date.now(); _zexTim.gen0 = 0; } catch (e) {}
  try { zenSetCurrentPost(article, opts && opts.eng); } catch (e) {}
  // ── Bring article into viewport first ────────────────────────────
  await ensureInViewport(article, { margin: 60, settle: 220 });

  // Comment already known to be off (or the banner is showing) → don't even try.
  if (zenIsCommentOff(articleStatusId(article)) || zenReplyOffBannerPresent()) { zenHandleReplyOff(article, opts); return null; }

  let _viaEs2 = false;
  if (zexEs2On && opts && (opts.eng === 'FED' || opts.eng === 'SEA' || opts.eng === 'GIV') && !_esStatusId()) {
    try {
      const _sid0 = articleStatusId(article);
      const _na = await zexEs2Enter(article, opts);
      if (_na === 'off') return null;
      if (_na) { article = _na; _viaEs2 = true; }
      else if (!article.isConnected && _sid0) {          // we stepped back out → the feed re-rendered, find this post again
        const _re = await zexEsWaitFor(() => [...document.querySelectorAll('article[data-testid="tweet"]')].find((x) => articleStatusId(x) === _sid0), 5000);
        if (_re) { article = _re; await ensureInViewport(article, { margin: 60, settle: 220 }); }
      }
    } catch (e) { console.warn('[Z EX] ES2 failed', e); zexEs2Abort(); }
  }
  const replyIcon = article.querySelector('[data-testid="reply"]');
  if (!replyIcon) {
    console.warn('[Z EX] repOpenReplyBox: no [data-testid="reply"] icon found on this article — nothing to click.');
    return null;
  }

  if (ZenCursor.active) await ZenCursor.moveTo(replyIcon);

  // Remember which tweet this reply is for (see reply-target hint above).
  const _tgtLink = (opts && opts.link) || zenArticleLink(article);
  if (_tgtLink) zenSetReplyTarget(_tgtLink, getArticleAuthorHandle(article) || '', 30000);

  const urlBefore = location.href;
  if (_viaEs2) { try { _pointerClick(replyIcon); } catch (e) { await realClick(replyIcon); } }   // post page: element-level click, never a coordinate tap
  else await realClick(replyIcon);

  // ── Wait briefly to detect navigation to /compose/ ───────────────
  // If X navigates to the compose page we switch to the compose-page
  // editor wait path instead of looking for a modal that will never appear.
  const COMPOSE_DETECT_MS = 1500;
  const composeDetected = await new Promise(resolve => {
    const deadline = Date.now() + COMPOSE_DETECT_MS;
    const tick = setInterval(() => {
      if (/\/compose\//.test(location.pathname)) {
        clearInterval(tick);
        resolve(true);
      } else if (Date.now() >= deadline) {
        clearInterval(tick);
        resolve(false);
      }
    }, 60);
  });

  if (composeDetected) {
    // ── Scenario C: x.com/compose/ full-page editor ─────────────────
    // Wait for the Lexical editor inside the compose page to mount.
    // The page navigation + React hydration can take much longer than a
    // few seconds on a slow connection, so this window is generous.
    const MAX_WAIT = 10000;
    const start = Date.now();
    return await new Promise(resolve => {
      const poll = setInterval(() => {
        const wrapper = document.querySelector('[data-testid="tweetTextarea_0"]');
        if (wrapper) {
          const editor = _zenResolveEditor(wrapper);
          clearInterval(poll);
          // Small settle so Lexical finishes hydrating its tree
          setTimeout(() => resolve(editor), 300);
          return;
        }
        if (Date.now() - start >= MAX_WAIT) {
          clearInterval(poll);
          console.warn('[Z EX] repOpenReplyBox: timed out waiting for compose-page editor.', { url: location.href });
          resolve(null);
        }
      }, 150);
    });
  }

  // ── Did the click navigate us to a different page (e.g. the tweet's own
  // status page) without opening a sheet directly? Some non-desktop mobile
  // web builds land there first and need a second tap on that page before
  // the reply sheet actually opens. We detect this and retry once.
  const navigatedAway = location.href !== urlBefore && !document.body.contains(article);
  let retriedClick = false;

  // ── Scenarios A / B: modal or inline editor ───────────────────────
  return await new Promise(resolve => {
    let attempts = 0;
    const maxAttempts = 30; // ~9s — generous for slow connections

    const poll = setInterval(() => {
      attempts++;
      let editor = null;

      // 0) "Who can reply?" dialog → comments are off for this post
      if (zenReplyOffDialogEl()) { clearInterval(poll); zenHandleReplyOff(article, opts); resolve(null); return; }

      // A) Modal dialog composer
      const modal = document.querySelector('[aria-modal="true"][role="dialog"], [data-testid="sheetDialog"]');
      if (modal) {
        const wrapper = modal.querySelector('[data-testid="tweetTextarea_0"]');
        editor = _zenResolveEditor(wrapper);
      }

      // B) Inline composer expanding under this article
      if (!editor && article.parentElement) {
        const wrapper = article.parentElement.querySelector('[data-testid="tweetTextarea_0"]');
        editor = _zenResolveEditor(wrapper);
      }

      // C-late) Compose page finished navigating but our URL check window closed
      // before we detected it — catch it here so nothing falls through.
      if (!editor && /\/compose\//.test(location.pathname)) {
        const wrapper = document.querySelector('[data-testid="tweetTextarea_0"]');
        editor = _zenResolveEditor(wrapper);
      }

      // D) Any tweetTextarea_0 on page (last resort)
      if (!editor) {
        const wrapper = document.querySelector('[data-testid="tweetTextarea_0"]');
        editor = _zenResolveEditor(wrapper);
      }

      // E) We landed on a different page than expected and still see
      // nothing after ~1.5s — try tapping a reply icon on this new page
      // once, in case the sheet needs that second tap here.
      if (!editor && navigatedAway && !retriedClick && attempts >= 5) {
        retriedClick = true;
        const icon2 = document.querySelector('[data-testid="reply"]');
        if (icon2) {
          console.warn('[Z EX] repOpenReplyBox: navigated away with no sheet open — retrying reply click on the new page.');
          realClick(icon2);
        }
      }

      if (editor) { clearInterval(poll); resolve(editor); return; }
      if (attempts >= maxAttempts) {
        clearInterval(poll);
        if (/\/compose\//.test(location.pathname)) { zenRecoverPostError(); }   // stuck on an empty compose page → back out
        console.warn('[Z EX] repOpenReplyBox: timed out waiting for reply box.', {
          url: location.href,
          navigatedAway,
          retriedClick,
          anyDialog: !!document.querySelector('[role="dialog"], [aria-modal="true"], [data-testid="sheetDialog"]'),
          anyTweetTextarea: !!document.querySelector('[data-testid="tweetTextarea_0"]'),
        });
        resolve(null);
      }
    }, 300);
  });
}

// ── Speed control ────────────────────────────────────────────────
// Normal = current human-like pacing. Fast = shorter gaps. Custom = a
// person-chosen fixed number of seconds between replies.
let repAutoSpeedMode = 'normal';   // 'normal' | 'fast' | 'custom'
let repAutoCustomSeconds = 5;

chrome.storage.local.get(['zenRepSpeedMode', 'zenRepCustomSeconds'], (d) => {
  if (d.zenRepSpeedMode === 'fast' || d.zenRepSpeedMode === 'custom' || d.zenRepSpeedMode === 'normal') {
    repAutoSpeedMode = d.zenRepSpeedMode;
  }
  const s = Number(d.zenRepCustomSeconds);
  if (Number.isFinite(s) && s >= 1 && s <= 120) repAutoCustomSeconds = s;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.zenRepSpeedMode) {
    const v = changes.zenRepSpeedMode.newValue;
    if (v === 'fast' || v === 'custom' || v === 'normal') repAutoSpeedMode = v;
  }
  if (changes.zenRepCustomSeconds) {
    const s = Number(changes.zenRepCustomSeconds.newValue);
    if (Number.isFinite(s) && s >= 1 && s <= 120) repAutoCustomSeconds = s;
  }
});

// Returns the gap (ms) to wait before starting the NEXT reply.
function repNextDelayMs() {
  if (repAutoSpeedMode === 'fast') return 2000 + Math.random() * 1500;     // ~2–3.5s (was 0.5–1s — too fast, bot-like)
  if (repAutoSpeedMode === 'custom') return repAutoCustomSeconds * 1000;    // fixed, as chosen
  return 4000 + Math.random() * 3000;                                      // normal ~4–7s (was 1.5–3s)
}

// ── Like → comment delay (shared by FED, Search, GIV) ───────────────
// zenLikeDelay = [minSec, maxSec]. After a like lands, wait a random time in
// this range before opening the reply box. [0, 0] = comment right away (old behaviour).
let zenLikeDelayRange = [0, 0];
function zenLikeDelayNorm(v) {
  let a = 0, b = 0;
  if (Array.isArray(v)) { a = Number(v[0]); b = Number(v[1]); }
  if (!isFinite(a) || a < 0) a = 0;
  if (!isFinite(b) || b < 0) b = 0;
  if (b < a) { const x = a; a = b; b = x; }
  return [Math.min(a, 120), Math.min(b, 120)];
}
chrome.storage.local.get(['zenLikeDelay'], (d) => { zenLikeDelayRange = zenLikeDelayNorm(d.zenLikeDelay); });
chrome.storage.onChanged.addListener((c, area) => {
  if (area === 'local' && c.zenLikeDelay) zenLikeDelayRange = zenLikeDelayNorm(c.zenLikeDelay.newValue);
});
function zenWaitAfterLike() {
  const adv = zexAdvComment();   // Timing page (Advanced) replaces the old like→comment box
  if (adv) {
    const ms = Math.round(zexRndRange(adv.like) * 1000);
    return ms > 0 ? zenDelayWait(ms, 'LIKE → COMMENT') : Promise.resolve();
  }
  const a = zenLikeDelayRange[0], b = zenLikeDelayRange[1];
  if (b <= 0) return Promise.resolve();
  return zenDelayWait(Math.round((a + Math.random() * (b - a)) * 1000), 'LIKE → COMMENT');
}

// ── Timing page (Advanced) — resolved numbers saved by the popup (zexTimingResolved) ──
// Classic mode: zexAdvComment() is null and every engine behaves exactly as before.
let zexTimingRes = null;
chrome.storage.local.get(['zexTimingResolved'], (d) => { zexTimingRes = d.zexTimingResolved || null; });
chrome.storage.onChanged.addListener((c, area) => {
  if (area === 'local' && c.zexTimingResolved) zexTimingRes = c.zexTimingResolved.newValue || null;
});
function zexAdvComment() { return (zexTimingRes && zexTimingRes.ui === 'advanced' && zexTimingRes.comment) || null; }
// Flash (Timing page): max-speed mode. True only for the engine that is running now (Telegram runs use the tg group).
function zexFlash() {
  const r = zexTimingRes;
  if (!r || r.ui !== 'advanced') return false;
  const p = window.__zexSessPath;
  const g = (typeof p === 'string' && p.indexOf('telegram_') === 0) ? r.tg : r.comment;
  return !!(g && g.flash);
}
// Flash Lite (Timing page): Flash-style speed (~15-20% slower) + human feel. zexFlash() is also true in Lite, so every Flash shortcut
// still applies; the places that matter for "looks human" (scroll, typing, hover before click) check zexLite() first.
function zexLite() {
  const r = zexTimingRes;
  if (!r || r.ui !== 'advanced') return false;
  const p = window.__zexSessPath;
  const g = (typeof p === 'string' && p.indexOf('telegram_') === 0) ? r.tg : r.comment;
  return !!(g && g.lite);
}
// Shrinks a fixed internal wait in Flash mode (floor = min ms), unchanged otherwise. Lite keeps 40% (Flash 20%).
function zexFx(ms, min) { return zexLite() ? Math.max(min || 0, Math.round(ms * 0.4)) : (zexFlash() ? Math.max(min || 0, Math.round(ms * 0.2)) : ms); }
function zexRndRange(r) {
  const a = Number(r && r[0]) || 0, b = Number(r && r[1]) || 0;
  return Math.min(a, b) + Math.random() * Math.abs(b - a);
}
let zexPaceCycleStart = 0;   // when the current post's cycle began (end of the previous pace wait)
let zexPaceCount = 0;        // replies finished — drives "break after every N"
// Everything that happens after a reply lands: "after clicking Reply" wait, optional break, then the gap before the next post.
// Custom mode has a target time per post: the gap is whatever is left of it after the real work, so the whole post lands near the target.
async function repPaceWait() {
  const adv = zexAdvComment();
  if (!adv) return repSleep(repNextDelayMs());
  const postMs = Math.round(zexRndRange(adv.post) * 1000);
  if (postMs > 0) await zenDelayWait(postMs, 'AFTER REPLY');
  zexPaceCount++;
  if (adv.breakEvery > 0 && zexPaceCount % adv.breakEvery === 0) {
    await zenDelayWait(Math.round(zexRndRange(adv.breakLen) * 1000), 'BREAK · ' + zexPaceCount + ' replies');
    zexPaceCycleStart = Date.now();
    return;
  }
  let gapMs;
  if (adv.target) {
    const T = adv.target * 1000 * (0.85 + Math.random() * 0.3);
    const elapsed = zexPaceCycleStart ? Date.now() - zexPaceCycleStart : 0;
    gapMs = Math.max(zexFlash() ? 300 : 2000, T - elapsed);   // Flash Lite: small floor, the stopwatch (12.5s/post) only fills what is left
  } else {
    gapMs = zexRndRange(adv.next) * 1000;
  }
  await zenDelayWait(gapMs, 'NEXT POST');
  zexPaceCycleStart = Date.now();
}

chrome.storage.local.get(['zenAutoRepMode'], (d) => {
  repAutoModeOn = d.zenAutoRepMode === true;
  if (repAutoModeOn) repAutoLoop();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.zenAutoRepMode) return;
  repAutoModeOn = changes.zenAutoRepMode.newValue === true;
  if (repAutoModeOn) repAutoLoop();
});

function repSleep(ms) {
  if (zexLite()) ms = Math.max(220, ms * 0.45);   // Flash Lite: shrink, but a bit less than Flash
  else if (zexFlash()) ms = Math.max(150, ms * 0.3);   // Flash: page-render waits and gaps shrink too
  // Add ±20% random jitter to every delay — fixed intervals are detectable
  const jitter = ms * 0.2;
  const actual = ms + (Math.random() * jitter * 2 - jitter);
  return zenDelayWait(actual, 'REPLY GAP');   // delay system: heartbeat + visible to the stuck watchdog
}

// ── Tab visibility pause ─────────────────────────────────────────
// X.com flags automation when the tab is hidden (user switched away).
// All engines check this before each action via zenWaitForVisible().
async function zenWaitForVisible() {
  if (!document.hidden) return;
  await new Promise(resolve => {
    const handler = () => {
      if (!document.hidden) {
        document.removeEventListener('visibilitychange', handler);
        resolve();
      }
    };
    document.addEventListener('visibilitychange', handler);
  });
  // Extra settle after tab becomes visible — let X.com re-render
  await new Promise(r => setTimeout(r, zexFx(300 + Math.random() * 200, 40)));
}

// ── CDP Scroll helper ────────────────────────────────────────────
// Uses chrome.debugger mouseWheel (isTrusted:true) when CDP mode ON,
// falls back to window.scrollBy otherwise.
async function zenScroll(deltaY) {
  ZenCursor.setState('scroll');
  if (_zenCdpMode) {
    try {
      const tabId = await _getTabId();
      if (tabId) {
        const x = Math.round(window.innerWidth  / 2 + (Math.random() * 40 - 20));
        const y = Math.round(window.innerHeight * 0.6 + (Math.random() * 40 - 20));
        const res = await chrome.runtime.sendMessage({
          type: '__CDP_SCROLL__', tabId, x, y, deltaY,
        });
        if (res?.ok) return;
      }
    } catch (e) { /* fallthrough */ }
  }
  // Fallback
  window.scrollBy({ top: deltaY, behavior: (zexFlash() && !zexLite()) ? 'instant' : 'smooth' });
}


// ═══ WAIT FOR MORE POSTS (v14.9.31) ═════════════════════════════════════════
// After a scroll: wait until NEW posts really show up (never scroll again on top of a loading spinner).
// If X shows "Something went wrong. Try reloading." — its Retry button does not work — do a FULL page reload instead.
function zexPostIds() {
  const ids = new Set();
  document.querySelectorAll('article[data-testid="tweet"] a[href*="/status/"]').forEach((a) => {
    const m = (a.getAttribute('href') || '').match(/\/status\/(\d+)/);
    if (m) ids.add(m[1]);
  });
  return ids;
}
function zexTimelineError() {
  const col = document.querySelector('[data-testid="primaryColumn"]') || document.body;
  const btns = col.querySelectorAll('button, [role="button"]');
  for (const b of btns) {
    if (/^\s*retry\s*$/i.test(b.innerText || '')) return true;
  }
  return false;
}
function zexTimelineLoading() {
  const col = document.querySelector('[data-testid="primaryColumn"]') || document.body;
  return !!col.querySelector('[role="progressbar"]');
}
async function zexReloadForError(why) {
  try {
    // cap: max 3 reloads / 10 min so it can never loop forever
    const now = Date.now();
    let log = [];
    try { log = JSON.parse(sessionStorage.getItem('zexLoadReloadLog') || '[]').filter((t) => now - t < 600000); } catch (e) {}
    if (log.length >= 3) { showToast('Feed keeps failing - reload limit reached (3 / 10 min)', 'warn'); return false; }
    log.push(now);
    try { sessionStorage.setItem('zexLoadReloadLog', JSON.stringify(log)); } catch (e) {}
    try { sessionStorage.setItem('zenArResume', String(now)); } catch (e) {}   // engines wait for the feed to render, then resume
    zenRefreshHold = true;
    showToast('Feed failed to load (' + (why || 'error') + ') - refreshing page…', 'warn');
    await new Promise((r) => setTimeout(r, 800));
    location.reload();
    return true;
  } catch (e) { return false; }
}
// prevIds = zexPostIds() taken BEFORE the scroll. Returns 'ok' | 'reload' | 'timeout' | 'hold'.
async function zexWaitMorePosts(prevIds, maxMs) {
  maxMs = maxMs || 30000;
  const t0 = Date.now();
  let errSince = 0;
  while (Date.now() - t0 < maxMs) {
    if (zenRefreshHold) return 'hold';
    if (document.hidden) { await new Promise((r) => setTimeout(r, 500)); continue; }
    const cur = zexPostIds();
    for (const id of cur) { if (!prevIds.has(id)) return 'ok'; }
    if (zexTimelineError()) {
      if (!errSince) errSince = Date.now();
      if (Date.now() - errSince > 1500) { await zexReloadForError('Something went wrong'); return 'reload'; }
    } else { errSince = 0; }
    await new Promise((r) => setTimeout(r, 400));
  }
  // Timed out: still spinning = keep waiting a bit more via the caller; stuck without spinner = reload
  if (zexTimelineError() || !zexTimelineLoading()) {
    // no new posts, no spinner: probably the real end of results -> let the caller's streak counter decide
    if (zexTimelineError()) { await zexReloadForError('no response'); return 'reload'; }
    return 'timeout';
  }
  await zexReloadForError('stuck loading');
  return 'reload';
}

// Slow, eased, human-like scroll: many small steps instead of one big jump.
// ~2.5 ms per px (1000px ≈ 2.5s), slow-fast-slow, with a little jitter.
async function zenSmoothScroll(totalPx) {
  ZenCursor.setState('scroll');
  const _fl = zexFlash(), _lt = zexLite();
  // Lite: eased human scroll, ~0.8 ms/px (Flash 0.35, normal 2.5) in 9+ small steps
  const dur = _lt ? Math.min(1100, Math.max(450, Math.abs(totalPx) * 0.8)) : (_fl ? Math.min(450, Math.max(180, Math.abs(totalPx) * 0.35)) : Math.min(6000, Math.max(1200, Math.abs(totalPx) * 2.5)));
  const steps = Math.max(_lt ? 9 : (_fl ? 4 : 12), Math.round(dur / (_zenCdpMode ? 90 : 40)));
  let done = 0;
  for (let i = 1; i <= steps; i++) {
    if (document.hidden || zenRefreshHold) break;
    const t = i / steps;
    const eased = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; // easeInOutQuad
    const target = totalPx * eased;
    const delta = target - done;
    done = target;
    if (Math.abs(delta) >= 0.5) {
      if (_zenCdpMode) await zenScroll(delta);
      else window.scrollBy({ top: delta, behavior: 'instant' });
    }
    await new Promise(r => setTimeout(r, Math.round((dur / steps) * (0.8 + Math.random() * 0.4))));
  }
  // Lite: sometimes a person scrolls a touch too far and eases back a little
  if (_lt && Math.random() < 0.18 && !document.hidden && !zenRefreshHold) {
    await new Promise(r => setTimeout(r, 140 + Math.random() * 160));
    const nudge = -Math.sign(totalPx || 1) * (20 + Math.random() * 45);
    try { if (_zenCdpMode) await zenScroll(nudge); else window.scrollBy({ top: nudge, behavior: 'smooth' }); } catch (e) {}
  }
}

// Resolves once the given editor node leaves the document — covers the
// modal-closed, inline-box-closed, and navigated-back-from-full-page
// cases in one check, without caring which one actually happened.
function repWaitForClose(editor) {
  return new Promise((resolve) => {
    if (!editor) { resolve(); return; }
    let attempts = 0;
    const maxAttempts = 400; // ~200s ceiling so a stuck tab can't hang the loop forever
    const poll = setInterval(() => {
      attempts++;
      zenProgress();
      if (!document.body.contains(editor) || attempts >= maxAttempts) {
        clearInterval(poll);
        resolve();
      }
    }, 500);
  });
}

async function repAutoLoop() {
  zenMarkEngineActivity();
  if (repAutoRunning) return;
  repAutoRunning = true;
  const _ep = _zenLoopEpoch;   // stuck-watchdog: this run is orphaned if the epoch changes
  let processed = 0;
  try {
    while (_ep === _zenLoopEpoch && repAutoModeOn && repModeActive && !zenRefreshHold && processed < REP_AUTO_MAX_PER_RUN) {
      const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]')).slice(1);

      const eligible = articles.filter((a) => {
        const btn = a.querySelector('.zen-rep-btn');
        return btn && !btn.disabled && !repAutoSkipped.has(a) && !repBusyArticles.has(a) && !zenPostSkipped(a);
      });
      repUpdateAutoSelection(eligible);

      const target = eligible.find((a) => repAutoSelected.has(a));
      if (!target) {
        // Human-like: brief pause before giving up — real users don't instantly stop
        await repSleep(800 + Math.random() * 600);
        break;
      }

      const btn = target.querySelector('.zen-rep-btn');
      const commentTextEl = target.querySelector('[data-testid="tweetText"]');
      if (!commentTextEl) { repAutoSkipped.add(target); continue; }

      // ── Pause if tab is hidden — X.com flags background automation ──
      await zenWaitForVisible();
      // ── Bring article into viewport first (virtual scroll fix) ──
      await ensureInViewport(target, { margin: 40, settle: 200 });
      ZenCursor.setState('found');
      // Move ZenCursor to the button for visual feedback
      if (ZenCursor.active && btn) await ZenCursor.moveTo(btn);

      repLastEditor = null;
      let repRetried = false;
      try {
        await repHandleClick(target, commentTextEl, btn);
      } catch (err) {
        if (!repRetried) {
          repRetried = true;
          // 1 retry after short pause — CDP glitch or transient DOM issue
          await repSleep(800 + Math.random() * 400);
          try {
            await repHandleClick(target, commentTextEl, btn);
          } catch (err2) {
            repAutoSkipped.add(target);
            showToast('' + (err2?.message || 'Reply failed — skipping post'), 'error');
          }
        }
      }
      processed++;

      if (!btn.classList.contains('zen-rep-done')) {
        // Generation or paste failed — don't retry it forever in this pass.
        repAutoSkipped.add(target);
        zenSkipPost(target, 'REP', 'failed');   // by status id — survives X re-mounting the row
        await zenStuckCloseComposer();                 // never leave a half-open reply sheet blocking the next post
        await repSleep(1200);
        continue;
      }

      await repWaitForClose(repLastEditor);
      ZenCursor.setState('rest');
      await repPaceWait(); // pacing gap before the next one (Classic: chosen speed mode · Advanced: Timing page)
    }
  } finally {
    if (_ep === _zenLoopEpoch) repAutoRunning = false;
  }
}







// ═══ FEED ENGINE ══════════════════════════════════════════════
// Reply Your Feed (x.com/home)
//
// Same engine as the Comment REP engine, applied to posts in your home
// timeline instead of comments under one of your own posts. Shares the
// same "already replied" tracking and own-post detection so a post never
// gets double-handled by either engine.
// ═══════════════════════════════════════════════════════════════

function isHomeFeedUrl(url) {
  try {
    const u = new URL(url);
    return /^(x\.com|twitter\.com)$/.test(u.hostname.replace(/^www\./, '')) && (u.pathname === '/home' || u.pathname === '/');
  } catch (e) { return false; }
}

let feedEngineOn = false;     // master toggle — set from the popup
let feedModeActive = false;   // currently running on this tab right now
let feedScanTimer = null;
// ── Random Like % — DRAW SYSTEM (FED / SEA / Telegram) ───────────────────
// Every post gets one draw: YES (like) or NO. The draws come from a shuffled "deck":
// at 40% the deck has 8 YES + 12 NO cards (20 cards), shuffled. Each post takes the next
// card; when the deck is empty a fresh shuffled deck is made. So there is no counting of
// posts — the run can go on forever — and the win rate stays true to the % in every
// block of cards (no 10 NO in a row / no over-liking). Instant: no network / async work.
// Deck is kept in sessionStorage so a page refresh / stuck-restart doesn't reset it.
const _zexLikeRolls = new WeakMap();   // one draw per post (a retry / 2nd code path reuses it)
function _zexGcd(a, b) { while (b) { const t = a % b; a = b; b = t; } return a; }
function zexLikeRoll(article, pct, key) {
  try {
    if (article && _zexLikeRolls.has(article)) return _zexLikeRolls.get(article);
    const p = Math.round(Number(pct));
    const c = isFinite(p) ? Math.min(100, Math.max(0, p)) : 100;
    let v;
    if (c >= 100) v = true;
    else if (c <= 0) v = false;
    else {
      const g = _zexGcd(c, 100);
      let size = 100 / g, yes = c / g;
      const k = Math.max(1, Math.ceil(20 / size)); size *= k; yes *= k;   // ≥ 20 cards per deck when possible
      const sk = 'zexLikeDeck:' + (key || 'X') + ':' + c;
      let deck = [];
      try { deck = JSON.parse(sessionStorage.getItem(sk) || '[]'); } catch (e) {}
      if (!Array.isArray(deck) || !deck.length) {
        deck = []; for (let n = 0; n < size; n++) deck.push(n < yes ? 1 : 0);
        for (let n = deck.length - 1; n > 0; n--) { const r = Math.floor(Math.random() * (n + 1)); const t = deck[n]; deck[n] = deck[r]; deck[r] = t; }
      }
      v = deck.pop() === 1;
      try { sessionStorage.setItem(sk, JSON.stringify(deck)); } catch (e) {}
      console.log('[Z EX] Like draw (' + (key || '') + ' ' + c + '%): ' + (v ? 'YES' : 'NO') + ' — ' + deck.length + ' cards left in deck');
    }
    if (article) _zexLikeRolls.set(article, v);
    return v;
  } catch (e) { return true; }
}

let feedLikeOn = false;
let feedLikePct = 100;   // Random Like % (zenFeedLikePct)
let feedAutoModeOn = false;
let feedTargetFilterOn = false;   // target post filter toggle
let feedTargetKeywords = [];      // keywords: OR-match against post text
let feedAutoRunning = false;
const feedDoneArticles = new WeakSet();
const feedBusyArticles = new WeakSet();
const feedAutoSkipped = new WeakSet();
let feedLastEditor = null;
const FEED_AUTO_MAX_PER_RUN = 40; // circuit breaker against any runaway loop

chrome.storage.local.get(['zenFeedEngineOn', 'zenFeedLikeOn', 'zenFeedLikePct', 'zenFeedAutoMode', 'zenFeedTargetFilterOn', 'zenFeedTargetKeywords'], (d) => {
  feedEngineOn = d.zenFeedEngineOn === true;
  feedLikeOn = d.zenFeedLikeOn === true;
  if (typeof d.zenFeedLikePct === 'number') feedLikePct = d.zenFeedLikePct;
  feedAutoModeOn = d.zenFeedAutoMode === true;
  feedTargetFilterOn = d.zenFeedTargetFilterOn === true;
  feedTargetKeywords = d.zenFeedTargetKeywords || [];
  feedTryActivate();
  if (feedAutoModeOn) feedAutoLoop();
  zenAgentRefreshEngineState();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.zenFeedEngineOn) {
    feedEngineOn = changes.zenFeedEngineOn.newValue === true;
    feedTryActivate();
    zenAgentRefreshEngineState();
  }
  if (changes.zenFeedLikeOn) feedLikeOn = changes.zenFeedLikeOn.newValue === true;
  if (changes.zenFeedLikePct) feedLikePct = typeof changes.zenFeedLikePct.newValue === 'number' ? changes.zenFeedLikePct.newValue : 100;
  if (changes.zenFeedAutoMode) {
    feedAutoModeOn = changes.zenFeedAutoMode.newValue === true;
    if (feedAutoModeOn) feedAutoLoop();
  }
  if (changes.zenFeedTargetFilterOn !== undefined) feedTargetFilterOn = changes.zenFeedTargetFilterOn.newValue === true;
  if (changes.zenFeedTargetKeywords !== undefined) feedTargetKeywords = changes.zenFeedTargetKeywords.newValue || [];
});

function feedTryActivate() {
  if (window.__zexPvNav) return;   // Profile Visit in progress
  if (!feedEngineOn || !isHomeFeedUrl(location.href)) {
    feedModeActive = false;
    if (feedScanTimer) { clearInterval(feedScanTimer); feedScanTimer = null; }
    return;
  }
  if (feedModeActive) return; // already running here
  feedModeActive = true;
  showToast('FEED engine ON — FED buttons will appear on your timeline', 'success');
  feedScanTimer = setInterval(feedScanPosts, 1200);
  feedScanPosts();
}

// Reuses the exact same URL-watch interval the Comment engine set up.
feedTryActivate();

function feedScanPosts() {
  if (!feedModeActive) return;
  if (window.__zexPvNav) return;   // Profile Visit in progress
  if (!extContextAlive()) { feedModeActive = false; clearInterval(feedScanTimer); feedScanTimer = null; return; }
  if (!feedEngineOn || !isHomeFeedUrl(location.href)) {
    feedModeActive = false;
    clearInterval(feedScanTimer);
    feedScanTimer = null;
    return;
  }

  const articles = document.querySelectorAll('article[data-testid="tweet"]');
  articles.forEach((a) => feedInjectButton(a));
  articles.forEach((a) => givInjectButton(a));

  if (feedAutoModeOn) feedAutoLoop();
  if (givAutoModeOn) givAutoLoop();
}

function feedIsAlreadyLiked(article) {
  return !!article.querySelector('[data-testid="unlike"]');
}

// ── Target Post Filter ─────────────────────────────────────────────
// Returns true when the post should be engaged (filter off, no keywords
// defined, or post text contains at least one keyword — OR logic,
// case-insensitive). False = skip this post entirely.
function feedMatchesTarget(postText) {
  if (!feedTargetFilterOn || feedTargetKeywords.length === 0) return true;
  const text = postText.toLowerCase();
  return feedTargetKeywords.some(kw => kw && text.includes(kw.toLowerCase()));
}

// Set while a FED Model 2 reply is being drafted so the shared GET Reply
// pipeline can tag that reply as FED (+ matched keywords) for the dashboard.
let zenFeedReplyCtx = null;

// Which of the target keywords this post matched (empty = normal feed post,
// i.e. filter off or no keyword hit). Used only for dashboard stats.
function feedMatchedKeywords(postText) {
  const text = String(postText || '').toLowerCase();
  let out = [];
  if (feedTargetFilterOn && feedTargetKeywords.length > 0) {
    out = feedTargetKeywords
      .filter(kw => kw && text.includes(String(kw).toLowerCase()))
      .map(kw => String(kw).trim().toLowerCase().slice(0, 40));
  }
  // Project tag: $TICKER / @project mentioned inside the post
  return zexMergeTags(out, zexProjectTags(postText));
}

function feedInjectButton(article) {
  if (isAdArticle(article)) return; // skip promoted posts
  if (feedDoneArticles.has(article)) return;
  if (article.querySelector('.zen-fed-btn')) { feedDoneArticles.add(article); return; }

  const actionBar = article.querySelector('[role="group"]');
  if (!actionBar) return; // not fully rendered yet — retry on next scan

  const postTextEl = article.querySelector('[data-testid="tweetText"]');
  if (!postTextEl || !postTextEl.innerText.trim()) { feedDoneArticles.add(article); return; } // text-less post, nothing to reply from

  // Never show FED on your own posts.
  if (isOwnArticle(article)) { feedDoneArticles.add(article); return; }

  // Engage By Wallchain Score — score outside the range = no FED button on this post.
  { const g = zexWcGate(article, 'feedEngage'); if (g === 'wait') return; if (g === 'skip') { feedDoneArticles.add(article); return; } }

  // Target post filter — skip posts that don't match any keyword.
  if (!feedMatchesTarget(postTextEl.innerText || '')) { feedDoneArticles.add(article); return; }

  if (!_zenIdsReady) return;   // replied/History list not loaded yet — retry on the next scan
  feedDoneArticles.add(article);

  // "Already engaged" is decided by History (same link saved) + the shared list — not by a Like.
  // Never show FED on a post already replied to (shared tracking with the Comment engine).
  const sid = articleStatusId(article);
  if (zexBlockedArticle(article)) { zexLogBlocked(sid, 'FED', zenArticleLink(article), getArticleAuthorHandle(article)); return; }
  if (hasAlreadyReplied(sid)) { zenLogSkip(sid, 'FED', zenArticleLink(article), getArticleAuthorHandle(article)); return; }
  if (zenIsCommentOff(sid)) return; // comment off — already saved in History

  const btn = document.createElement('button');
  btn.className = 'zen-rep-btn zen-fed-btn';
  btn.type = 'button';
  btn.textContent = 'FED';
  btn.title = 'Generate a short reply for this post';
  btn.addEventListener('click', async (e) => {
    e.preventDefault(); e.stopPropagation();
    await feedHandleClick(article, postTextEl, btn);
  });

  actionBar.appendChild(btn);
}

async function feedHandleClick(article, postTextEl, btn) {
  if (feedBusyArticles.has(article)) return;
  if (zenAlreadyGuard(article, 'FED', btn)) return;

  const { zenFeedPromptModel } = await getStorage(['zenFeedPromptModel']);
  const useModel2 = zenFeedPromptModel === 'model2';

  // ── Model 2: just open this post's real reply box and let the GET Reply
  // widget (which auto-injects into any open reply box) do everything —
  // Tone, Custom Tone, Big Reply, Project Name, Keywords, session/limit
  // checks, history — all handled by that one existing engine. Nothing
  // duplicated here.
  if (useModel2) {
    await feedHandleClickModel2(article, btn);
    return;
  }

  // ── Model 1: quick, feed-only, always short — ignores tone/keyword/project settings.
  if (!navigator.onLine) { showToast('No internet connection!', 'error'); return; }

  const { zenDeviceSession } = await getStorage(['zenDeviceSession']);
  if (!zenDeviceSession || Date.now() >= zenDeviceSession.expiresAt) {
    showToast('Session expired! Open Z EX and login again.', 'warn');
    return;
  }

  const syncResult = await syncAdminApiKey(zenDeviceSession.email);
  if (syncResult && syncResult.locked) { showToast('Contact Admin', 'error'); return; }

  const limitCheck = await checkAndIncrementReplyCount(zenDeviceSession.email);
  if (!limitCheck.allowed) {
    showToast('' + (limitCheck.reason === 'Contact Admin' ? 'Contact Admin' : limitCheck.reason), 'error');
    return;
  }
  trackActivity(zenDeviceSession.email);

  const storage = await getStorage(['smartSwitch']);
  const smartSwitch = storage.smartSwitch !== false;

  const postText = postTextEl.innerText.trim();

  feedBusyArticles.add(article);
  const originalHTML = btn.innerHTML;
  btn.innerHTML = '<span class="zen-spin"></span>';
  btn.disabled = true;

  try {
    // Auto Wallet Detect: if ON and a wallet address is saved, check this
    // post against the same keyword (+ optional AI verify) logic the GIV
    // engine uses. On a match, paste the wallet reply template instead of
    // generating a normal AI reply — with no wallet saved, falls through
    // to the normal AI reply below exactly as if this were off.
    const { zenFeedGivDetectOn } = await getStorage(['zenFeedGivDetectOn']);
    if (zenFeedGivDetectOn === true && givWalletAddress && givPostMatches(postText)) {
      let isGiveaway = true;
      if (givAiVerifyOn) {
        isGiveaway = await givClassifyWithFallback(
          postText, smartSwitch, article
        );
      }
      if (isGiveaway) {
        const walletReply = givReplyTemplate.replace(/\{wallet\}/gi, givWalletAddress);

        if (feedLikeOn && !feedIsAlreadyLiked(article) && zexLikeRoll(article, feedLikePct, 'FED')) {
          try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
        }

        const editor = await repOpenReplyBox(article, { eng: 'FED' });
        if (!editor) throw new Error(zenNoBoxMsg());
        feedLastEditor = editor;

        await insertReply(editor, walletReply, { allowLinks: true });

        const sidForWatch = articleStatusId(article);
        pendingReplyMap.set(editor, { tweetLink: sidForWatch ? `https://x.com/i/status/${sidForWatch}` : null, tweetAuthor: getArticleAuthorHandle(article) || '', replyText: walletReply, tone: 'FED-GIV', kw: feedMatchedKeywords(postText), ts: Date.now() });
        armPostWatcher(editor);

        let autoPostedWallet = false;
        if (feedAutoModeOn) {
          autoPostedWallet = await repAutoSubmit(editor);
        }

        btn.textContent = 'DONE';
        btn.classList.add('zen-rep-done');
        btn.disabled = true;
        showToast(autoPostedWallet ? 'Wallet reply posted' : 'Wallet reply drafted — review & tap Reply', 'success');
        zenAgentRecord('FED', true, !!autoPostedWallet);

        if (sidForWatch) markStatusIdReplied(sidForWatch, 'FED');

        chrome.storage.local.get(['zenFeedDraftCount'], (d) => {
          chrome.storage.local.set({ zenFeedDraftCount: (d.zenFeedDraftCount || 0) + 1 });
        });
        feedBusyArticles.delete(article);
        return;
      }
    }

    let editor = null;
    const feedLive = await zenLiveEnabled();
    if (feedLive) { // Live: like → open box → stream into it
      if (feedLikeOn && !feedIsAlreadyLiked(article) && zexLikeRoll(article, feedLikePct, 'FED')) {
        try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
      }
      editor = await repOpenReplyBox(article, { eng: 'FED' });
      if (!editor) throw new Error(zenNoBoxMsg());
      feedLastEditor = editor;
    }
    const reply = await zenLiveGenerate(editor, () => feedGenerateReplyWithFallback(
      postText, smartSwitch, article
    ));

    if (!editor) {
      // Like first if enabled — independent of whether the reply itself succeeds later.
      if (feedLikeOn && !feedIsAlreadyLiked(article) && zexLikeRoll(article, feedLikePct, 'FED')) {
        try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
      }
      editor = await repOpenReplyBox(article, { eng: 'FED' });
      if (!editor) throw new Error(zenNoBoxMsg());
      feedLastEditor = editor;
    }

    await insertReply(editor, reply);

    // Shared tracking with the Comment engine — a post replied to via FED
    // will never show a REP button for it either, and vice versa.
    const sidForWatch = articleStatusId(article);
    pendingReplyMap.set(editor, { tweetLink: sidForWatch ? `https://x.com/i/status/${sidForWatch}` : null, tweetAuthor: getArticleAuthorHandle(article) || '', replyText: reply, tone: 'FED', kw: feedMatchedKeywords(postText), ts: Date.now() });
    armPostWatcher(editor);

    let autoPosted = false;
    if (feedAutoModeOn) {
      autoPosted = await repAutoSubmit(editor);
    }

    btn.textContent = 'DONE';
    btn.classList.add('zen-rep-done');
    btn.disabled = true;
    showToast(autoPosted ? 'Reply posted' : 'Reply drafted — review & tap Reply', 'success');
    zenAgentRecord('FED', true, !!autoPosted);

    if (sidForWatch) markStatusIdReplied(sidForWatch, 'FED');

    chrome.storage.local.get(['zenFeedDraftCount'], (d) => {
      chrome.storage.local.set({ zenFeedDraftCount: (d.zenFeedDraftCount || 0) + 1 });
    });
  } catch (err) {
    zenAgentRecord('FED', false, false, err && err.message);
    showToast('' + (err.message || 'Reply failed'), 'error');
    btn.innerHTML = originalHTML;
    btn.disabled = false;
  } finally {
    feedBusyArticles.delete(article);
  }
}

// ── Model 2 handler — opens the reply box, waits for the real GET Reply
// widget to auto-inject into its toolbar (the same MutationObserver that
// injects it on every other reply box on X), then invokes that exact
// engine directly. Session/limit checks, Tone, Custom Tone, Big Reply,
// Project Name, Keywords, and history — all come from that one place.
async function feedHandleClickModel2(article, btn) {
  feedBusyArticles.add(article);
  const originalHTML = btn.innerHTML;
  btn.innerHTML = '<span class="zen-spin"></span>';
  btn.disabled = true;

  try {
    const postTextEl2 = article.querySelector('[data-testid="tweetText"]');
    const postText2 = postTextEl2 ? postTextEl2.innerText.trim() : '';

    // Auto Wallet Detect (Model 2 path) — same check as Model 1: on a
    // giveaway match with a wallet saved, paste the wallet template
    // directly and skip the normal GET Reply widget entirely.
    const { zenFeedGivDetectOn: detectOn2 } = await getStorage(['zenFeedGivDetectOn']);
    if (detectOn2 === true && givWalletAddress && givPostMatches(postText2)) {
      let isGiveaway2 = true;
      if (givAiVerifyOn) {
        const storage2 = await getStorage(['smartSwitch']);
        isGiveaway2 = await givClassifyWithFallback(postText2, storage2.smartSwitch !== false, article);
      }
      if (isGiveaway2) {
        const walletReply2 = givReplyTemplate.replace(/\{wallet\}/gi, givWalletAddress);

        if (feedLikeOn && !feedIsAlreadyLiked(article) && zexLikeRoll(article, feedLikePct, 'FED')) {
          try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
        }

        const editor2 = await repOpenReplyBox(article, { eng: 'FED' });
        if (!editor2) throw new Error(zenNoBoxMsg());
        feedLastEditor = editor2;

        await insertReply(editor2, walletReply2, { allowLinks: true });

        const sidForWatch2 = articleStatusId(article);
        pendingReplyMap.set(editor2, { tweetLink: sidForWatch2 ? `https://x.com/i/status/${sidForWatch2}` : null, tweetAuthor: getArticleAuthorHandle(article) || '', replyText: walletReply2, tone: 'FED-GIV', kw: feedMatchedKeywords(postText2), ts: Date.now() });
        armPostWatcher(editor2);

        let autoPostedWallet2 = false;
        if (feedAutoModeOn) {
          autoPostedWallet2 = await repAutoSubmit(editor2);
        }

        btn.textContent = 'DONE';
        btn.classList.add('zen-rep-done');
        btn.disabled = true;
        showToast(autoPostedWallet2 ? 'Wallet reply posted' : 'Wallet reply drafted — review & tap Reply', 'success');
        zenAgentRecord('FED', true, !!autoPostedWallet2);

        if (sidForWatch2) markStatusIdReplied(sidForWatch2, 'FED');

        chrome.storage.local.get(['zenFeedDraftCount'], (d) => {
          chrome.storage.local.set({ zenFeedDraftCount: (d.zenFeedDraftCount || 0) + 1 });
        });
        feedBusyArticles.delete(article);
        return;
      }
    }

    // Like BEFORE opening the reply box: on mobile web, opening the reply
    // box can navigate to a dedicated compose page and unmount this
    // article's DOM node entirely, so clicking Like on it afterward would
    // silently do nothing.
    if (feedLikeOn && !feedIsAlreadyLiked(article) && zexLikeRoll(article, feedLikePct, 'FED')) {
      try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
    }

    let editor = await repOpenReplyBox(article, { eng: 'FED' });
    if (!editor) throw new Error(zenNoBoxMsg());
    feedLastEditor = editor;

    const _got = await zenAcquireGetReply(article, editor, 'FED');
    if (!_got) throw zenSkipErr('GET Reply did not appear — post skipped');
    const replyBtn = _got.replyBtn;
    editor = _got.editor;
    feedLastEditor = editor;

    const cfg = await getStorage(['bigReplyConfig', 'bigReplyMode']);
    const bigOn = cfg.bigReplyMode === true;
    zenFeedReplyCtx = { kw: feedMatchedKeywords(postText2), ts: Date.now() };
    try { await zenEngineGetReply(editor, replyBtn, bigOn); } finally { zenFeedReplyCtx = null; }

    if (isEditorEmpty(editor)) {
      throw new Error('No reply was drafted — check session, API key, or reply limit');
    }

    let autoPosted = false;
    if (feedAutoModeOn) {
      autoPosted = await repAutoSubmit(editor);
    }

    btn.textContent = 'DONE';
    btn.classList.add('zen-rep-done');
    btn.disabled = true;
    showToast(autoPosted ? 'Reply posted' : 'Reply drafted — review & tap Reply', 'success');
    zenAgentRecord('FED', true, !!autoPosted);

    const sid = articleStatusId(article);
    if (sid) markStatusIdReplied(sid, 'FED');

    chrome.storage.local.get(['zenFeedDraftCount'], (d) => {
      chrome.storage.local.set({ zenFeedDraftCount: (d.zenFeedDraftCount || 0) + 1 });
    });
  } catch (err) {
    zenAgentRecord('FED', false, false, err && err.message);
    showToast('' + (err.message || 'Reply failed'), 'error');
    btn.innerHTML = originalHTML;
    btn.disabled = false;
  } finally {
    feedBusyArticles.delete(article);
  }
}

// Polls the reply box's toolbar for the GET Reply widget that the main
// MutationObserver auto-injects into every open reply box on X.
// On compose pages the editor reference may be stale after navigation —
// we re-query the live editor each tick so we don't wait forever on
// a detached node.
function feedWaitForGetReplyButton(editor, maxWaitMs) {
  maxWaitMs = maxWaitMs || 8000;
  return new Promise((resolve) => {
    const start = Date.now();
    let lastForce = 0;
    const poll = setInterval(() => {
      zenProgress();   // heartbeat: a bounded wait is not "stuck"
      // Always re-resolve the live editor if ours was detached (compose page / X re-mounted the sheet)
      let liveEditor = editor;
      if (/\/compose\//.test(location.pathname) || !editor || !document.body.contains(editor)) {
        const wrapper = document.querySelector('[data-testid="tweetTextarea_0"]');
        if (wrapper) liveEditor = _zenResolveEditor(wrapper);
      }

      const toolbar = liveEditor ? findToolbar(liveEditor) : null;
      const replyBtn = toolbar ? toolbar.querySelector('.zen-reply-btn') : null;
      if (replyBtn) { clearInterval(poll); resolve(replyBtn); return; }

      // Also check the floating bar injected for compose pages
      const floatingBar = ZexShadow.$('#zen-compose-floating-bar');
      const floatingBtn = floatingBar ? floatingBar.querySelector('.zen-reply-btn') : null;
      if (floatingBtn) { clearInterval(poll); resolve(floatingBtn); return; }

      // Not there yet → don't just wait for the MutationObserver (it can miss / get starved):
      // push the injector ourselves about once a second.
      const now = Date.now();
      if (now - lastForce >= 1000) { lastForce = now; try { tryInject(); } catch (e) {} }

      if (now - start >= maxWaitMs) { clearInterval(poll); resolve(null); }
    }, 250);
  });
}

// ─── GET Reply: wait → retry (close + reopen the reply box) → skip the post ──────────
// Sometimes the GET Reply widget never shows up (X re-mounted the sheet, injector starved, …).
// Instead of hanging until the stuck watchdog fires, the engine itself:
//   try 1: wait for the button (force-injecting it)   → try 2 / 3: close the sheet, reopen it, wait again
//   still nothing → close the sheet, put the post on the skip list and move on to the next post.
// Returns { replyBtn, editor } (editor may be a freshly reopened one) or null (post skipped, composer closed).
const ZEN_GETREPLY_TRIES = 3;
async function zenAcquireGetReply(article, editor, eng, firstWaitMs) {
  const sid = zenSkipSidOf(article);
  let art = article, ed = editor;
  for (let attempt = 1; attempt <= ZEN_GETREPLY_TRIES; attempt++) {
    zenMarkEngineActivity();
    const btn = await feedWaitForGetReplyButton(ed, attempt === 1 ? (firstWaitMs || 8000) : 6000);
    if (btn) return { replyBtn: btn, editor: ed };
    // Legit reasons for "no button": we already replied / it's our own post → retrying is pointless
    if (sid && hasAlreadyReplied(sid)) break;
    console.warn('[Z EX] GET Reply did not appear — attempt', attempt, '/', ZEN_GETREPLY_TRIES, eng || '');
    if (attempt >= ZEN_GETREPLY_TRIES) break;
    showToast('GET Reply missing — retrying (' + attempt + '/' + (ZEN_GETREPLY_TRIES - 1) + ')…', 'warn');
    await zenStuckCloseComposer();
    await repSleep(900 + Math.random() * 500);
    if (!document.body.contains(art) && sid) { const a2 = zenRefindArticle(sid); if (a2) art = a2; }
    if (!document.body.contains(art)) break;
    ed = await repOpenReplyBox(art, { eng: eng });
    if (!ed) break;
  }
  await zenStuckCloseComposer();
  zenSkipPost(art, eng, 'no_get_reply');
  return null;
}

// ═══ PROFILE VISIT (FED + SEA only) ══════════════════════════
// FED and SEA have their own settings and their own block counter. Posts are counted in blocks (default 20). In every block 5-6 random posts are picked;
// for those posts the engine clicks the author's profile (same tab, like a human), scrolls
// a little, goes Back and carries on. The visit happens right BEFORE or right AFTER the
// reply (random). Nothing is engaged on the profile.
// window.__zexPvNav is a property (not a let) because feedTryActivate() runs at load time.
const _pvSt = { FED: { idx: 0, plan: null, lastKey: '' }, SEA: { idx: 0, plan: null, lastKey: '' } };   // per-engine block state
const _pvOwn = () => { try { return (detectOwnHandle() || '').toLowerCase(); } catch (e) { return ''; } };
function _pvPostKey(art) {
  try { const a = art.querySelector('a[href*="/status/"]'); const m = a && (a.getAttribute('href') || '').match(/status\/(\d+)/); return m ? m[1] : ''; } catch (e) { return ''; }
}
// zenProfVisit = { fed:{on,every,min,max,sec}, sea:{...} } (older flat shape is still understood)
async function _pvCfg(eng) {
  const d = await new Promise((r) => chrome.storage.local.get(['zenProfVisit'], r));
  const v = d.zenProfVisit || {};
  const key = eng === 'FED' ? 'fed' : 'sea';
  let c;
  if (v[key] && typeof v[key] === 'object') c = Object.assign({ on: false }, v[key]);
  else c = Object.assign({}, v, { on: v[key] !== undefined ? !!v[key] : v.on === true });
  c = Object.assign({ every: 20, min: 5, max: 6, sec: 8 }, c);
  c.every = Math.max(1, c.every | 0); c.min = Math.max(1, c.min | 0); c.max = Math.max(c.min, c.max | 0); c.sec = Math.max(3, +c.sec || 8);
  return c;
}
function _pvMakePlan(c) {
  const n = Math.min(c.every, c.min + Math.floor(Math.random() * (c.max - c.min + 1)));
  const idx = Array.from({ length: c.every }, (_, i) => i);
  for (let i = idx.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
  const plan = new Map();
  idx.slice(0, n).forEach((i) => plan.set(i, Math.random() < 0.5 ? 'before' : 'after'));
  return plan;
}
async function _pvWaitFor(fn, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) { try { if (fn()) return true; } catch (e) {} await new Promise((r) => setTimeout(r, 200)); }
  return false;
}
// Click the author's profile link inside the post, scroll, go Back. Returns true when the visit happened.
async function _pvVisit(art, handle, c) {
  if (window.__zexPvNav) return false;
  const origHref = location.href;
  const want = '/' + handle.toLowerCase();
  const onProfile = () => location.pathname.toLowerCase().replace(/\/+$/, '') === want;
  let link = null;
  try {
    const sels = ['[data-testid="User-Name"] a[href]', '[data-testid="Tweet-User-Avatar"] a[href]'];
    for (const sel of sels) {
      for (const el of art.querySelectorAll(sel)) { if ((el.getAttribute('href') || '').toLowerCase().replace(/\/+$/, '') === want) { link = el; break; } }
      if (link) break;
    }
  } catch (e) {}
  if (!link) return false;
  window.__zexPvNav = true;
  let went = false;
  try {
    zenMarkEngineActivity();
    showToast('Profile visit — @' + handle, 'info');
    await zenWaitForVisible();
    await ensureInViewport(art, { margin: 40, settle: 200 });
    try { if (ZenCursor.active) await ZenCursor.moveTo(link); } catch (e) {}
    await realClick(link);
    went = await _pvWaitFor(onProfile, 8000);
    if (went) {
      await _pvWaitFor(() => document.querySelector('[data-testid="UserName"], [data-testid="primaryColumn"] article'), 6000);
      await repSleep(900);
      const end = Date.now() + Math.round(c.sec * 1000 * (0.8 + Math.random() * 0.5));
      while (Date.now() < end && onProfile()) {
        zenMarkEngineActivity();
        if (Math.random() < 0.8) await zenSmoothScroll(160 + Math.random() * 360);
        else window.scrollBy({ top: -(80 + Math.random() * 160), behavior: 'smooth' });
        await repSleep(600 + Math.random() * 900);
      }
    }
  } catch (e) {
    console.warn('[Z EX] profile visit error', e);
  }
  // ── back to where we were ──
  try {
    if (location.href !== origHref) {
      history.back();
      let back = await _pvWaitFor(() => location.href === origHref, 6000);
      if (!back) {
        const bb = document.querySelector('[data-testid="app-bar-back"], [aria-label="Back"]');
        if (bb) { await realClick(bb); back = await _pvWaitFor(() => location.href === origHref, 5000); }
      }
      if (!back) { try { history.pushState(null, '', origHref); window.dispatchEvent(new PopStateEvent('popstate')); } catch (e) {} await new Promise((r) => setTimeout(r, 800)); }
    }
    await _pvWaitFor(() => document.querySelector('article[data-testid="tweet"]'), 8000);
    await repSleep(900);
  } catch (e) {}
  window.__zexPvNav = false;
  zenMarkEngineActivity();
  return went;
}
// Called once per targeted post, before the reply.
// Returns { lost, after } — lost: the post element went away (re-find it), after: context for zexPvAfter.
async function zexPvBefore(art, eng) {
  const none = { lost: false, after: null };
  try {
    const c = await _pvCfg(eng);
    if (!c.on) return none;
    const st = _pvSt[eng] || _pvSt.SEA;
    const key = _pvPostKey(art);
    if (key && key === st.lastKey) return none;     // this post was already counted (re-found after a visit)
    st.lastKey = key;
    if (!st.plan || st.idx >= c.every) { st.plan = _pvMakePlan(c); st.idx = 0; }
    const when = st.plan.get(st.idx);
    st.idx++;
    if (!when) return none;
    const h = getArticleAuthorHandle(art);
    if (!h || h === _pvOwn()) return none;
    if (when === 'before') {
      await _pvVisit(art, h, c);
      return { lost: !document.body.contains(art), after: null };
    }
    return { lost: false, after: { art, handle: h, cfg: c } };
  } catch (e) { console.warn('[Z EX] profile visit error', e); return none; }
}
async function zexPvAfter(pv) {
  const ctx = pv && pv.after;
  if (!ctx) return;
  try {
    // the reply is done and the composer closed; use the post if it is still on screen
    let art = document.body.contains(ctx.art) ? ctx.art : null;
    if (!art) {
      for (const x of document.querySelectorAll('article[data-testid="tweet"]')) { if (getArticleAuthorHandle(x) === ctx.handle) { art = x; break; } }
    }
    if (art) await _pvVisit(art, ctx.handle, ctx.cfg);
  } catch (e) { console.warn('[Z EX] profile visit error', e); }
}

async function feedAutoLoop() {
  zenMarkEngineActivity();
  if (feedAutoRunning) return;
  feedAutoRunning = true;
  const _ep = _zenLoopEpoch;   // stuck-watchdog: this run is orphaned if the epoch changes
  let processed = 0;
  let noNewTargetStreak = 0;
  try {
    while (_ep === _zenLoopEpoch && feedAutoModeOn && feedModeActive && !zenRefreshHold && processed < FEED_AUTO_MAX_PER_RUN) {
      { // Follow By Wallchain Score — runs between replies, never in the middle of one
        const fs = await zexWcFollowStep('feed', isHomeFeedUrl);
        if (fs === 'limit') { showToast('Follow by Wallchain Score — limit reached', 'success'); try { chrome.storage.local.set({ zenFeedAutoMode: false }); } catch (e) {} break; }
        if (fs) { await repSleep(1200); continue; }
      }
      const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
      const _wcOnlyF = !!(zexWcFollowCfg('feed') || {}).only;

      const target = articles.find((a) => {
        const btn = a.querySelector('.zen-fed-btn');
        if (_wcOnlyF) return false;   // follow-only: no replies
        if (!btn || btn.disabled || feedAutoSkipped.has(a) || feedBusyArticles.has(a) || zenPostSkipped(a)) return false;
        const te = a.querySelector('[data-testid="tweetText"]');
        return feedMatchesTarget(te ? te.innerText : '');
      });
      if (!target) {
        // Nothing eligible in view (no keyword match / already liked or
        // replied) — scroll down to load more posts and keep looking.
        noNewTargetStreak++;
        ZenCursor.setState('search');
        if (noNewTargetStreak > 8) { await repSleep(3000); break; } // scan timer restarts the loop
        await zenWaitForVisible();
        if (ZenCursor.active) {
          await ZenCursor.moveToXY(
            window.innerWidth / 2 + (Math.random() * 60 - 30),
            window.innerHeight * 0.75,
            180
          );
        }
        const _ids0 = zexPostIds();
        await zenSmoothScroll(window.innerHeight * 1.0);
        const _wl = await zexWaitMorePosts(_ids0);   // wait for real new posts; error -> full reload
        if (_wl === 'reload' || _wl === 'hold') break;
        await repSleep(1500); // give X time to render the next batch; scan injects FED buttons
        continue;
      }
      noNewTargetStreak = 0;

      const btn = target.querySelector('.zen-fed-btn');
      const postTextEl = target.querySelector('[data-testid="tweetText"]');
      if (!postTextEl) { feedAutoSkipped.add(target); continue; }

      const _pv = await zexPvBefore(target, 'FED');   // Profile Visit: may visit the author's profile before replying
      if (_pv.lost) continue;                  // page re-rendered after the visit → pick the post again
      // ── Pause if tab is hidden — X.com flags background automation ──
      await zenWaitForVisible();
      // ── Bring article into viewport first (virtual scroll fix) ──
      // Off-screen articles are in the DOM but X hasn't rendered their
      // inner buttons yet — ensureInViewport scrolls + waits until the
      // article is actually painted before we touch anything inside it.
      await ensureInViewport(target, { margin: 40, settle: 200 });
      ZenCursor.setState('found');
      // Move ZenCursor to the button for visual feedback
      if (ZenCursor.active && btn) await ZenCursor.moveTo(btn);

      feedLastEditor = null;
      try {
        await feedHandleClick(target, postTextEl, btn);
      } catch (err) {
        // 1 retry after short pause
        await repSleep(800 + Math.random() * 400);
        try {
          await feedHandleClick(target, postTextEl, btn);
        } catch (err2) {
          feedAutoSkipped.add(target);
          showToast('' + (err2?.message || 'Reply failed — skipping post'), 'error');
        }
      }
      processed++;

      if (!btn.classList.contains('zen-rep-done')) {
        feedAutoSkipped.add(target);
        zenSkipPost(target, 'FED', 'failed');   // by status id — survives X re-mounting the row
        await zenStuckCloseComposer();                 // never leave a half-open reply sheet blocking the next post
        await repSleep(1200);
        continue;
      }

      await repWaitForClose(feedLastEditor);
      ZenCursor.setState('rest');
      await zexPvAfter(_pv);
      await repPaceWait(); // same pacing preference as the Comment engine
    }
  } finally {
    if (_ep === _zenLoopEpoch) feedAutoRunning = false;
  }
}

// ═══ SEA ENGINE ══════════════════════════════════════════════
// Reply From Search (x.com/search)
//
// Exact clone of the FEED engine (Model 1 quick / Model 2 full, Like
// Posts, Auto Mode), just scoped to search-result pages instead of the
// home timeline. Shares the same "already replied" tracking as
// REP/FEED so a post never gets double-handled by any engine.
// ═══════════════════════════════════════════════════════════════

function isSearchUrl(url) {
  try {
    const u = new URL(url);
    return /^(x\.com|twitter\.com)$/.test(u.hostname.replace(/^www\./, '')) && u.pathname === '/search';
  } catch (e) { return false; }
}

let searchEngineOn = false;    // master toggle — set from the popup / floating button
let searchModeActive = false;  // currently running on this tab right now
let searchScanTimer = null;
let searchLikeOn = false;
let searchLikePct = 100; // Random Like % (zenSearchLikePct)
let searchAutoModeOn = false;
let searchAutoRunning = false;
const searchDoneArticles = new WeakSet();
const searchBusyArticles = new WeakSet();
const searchAutoSkipped = new WeakSet();
let searchLastEditor = null;
const SEARCH_AUTO_MAX_PER_RUN = 40; // circuit breaker against any runaway loop

chrome.storage.local.get(['zenSearchEngineOn', 'zenSearchLikeOn', 'zenSearchLikePct', 'zenSearchAutoMode'], (d) => {
  searchEngineOn = d.zenSearchEngineOn === true;
  searchLikeOn = d.zenSearchLikeOn === true;
  if (typeof d.zenSearchLikePct === 'number') searchLikePct = d.zenSearchLikePct;
  searchAutoModeOn = d.zenSearchAutoMode === true;
  searchTryActivate();
  if (searchAutoModeOn) searchAutoLoop();
  zenAgentRefreshEngineState();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.zenSearchEngineOn) {
    searchEngineOn = changes.zenSearchEngineOn.newValue === true;
    searchTryActivate();
    zenAgentRefreshEngineState();
  }
  if (changes.zenSearchLikeOn) searchLikeOn = changes.zenSearchLikeOn.newValue === true;
  if (changes.zenSearchLikePct) searchLikePct = typeof changes.zenSearchLikePct.newValue === 'number' ? changes.zenSearchLikePct.newValue : 100;
  if (changes.zenSearchAutoMode) {
    searchAutoModeOn = changes.zenSearchAutoMode.newValue === true;
    if (searchAutoModeOn) searchAutoLoop();
  }
});

// Recompute the dashboard's combined mode label + uptime timer whenever
// either engine's on/off state changes. Called after both feedEngineOn
// and searchEngineOn are assigned above.
function zenAgentRefreshEngineState() {
  const anyOn = feedEngineOn || searchEngineOn || givEngineOn;
  if (anyOn) {
    zenAgentMarkEngineOn();
    const modes = [];
    if (searchEngineOn) modes.push('SEA');
    if (feedEngineOn) modes.push('FEED');
    if (givEngineOn) modes.push('GIV');
    ZenAgentStatus.activeModes = modes;
    if (ZenAgentStatus.state === 'idle') ZenAgentStatus.state = 'waiting';
  } else {
    ZenAgentStatus.activeModes = [];
    zenAgentMarkEngineOff();
  }
  zenAgentEmit();
}


function searchTryActivate() {
  if (window.__zexPvNav) return;   // Profile Visit in progress
  if (!searchEngineOn || !isSearchUrl(location.href)) {
    searchModeActive = false;
    if (searchScanTimer) { clearInterval(searchScanTimer); searchScanTimer = null; }
    return;
  }
  if (searchModeActive) return; // already running here
  searchModeActive = true;
  showToast('SEA engine ON — SEA buttons will appear on results', 'success');
  searchScanTimer = setInterval(searchScanPosts, 1200);
  searchScanPosts();
}
searchTryActivate();

function searchScanPosts() {
  if (!searchModeActive) return;
  if (window.__zexPvNav) return;   // Profile Visit in progress
  if (!extContextAlive()) { searchModeActive = false; clearInterval(searchScanTimer); searchScanTimer = null; return; }
  if (!searchEngineOn || !isSearchUrl(location.href)) {
    searchModeActive = false;
    clearInterval(searchScanTimer);
    searchScanTimer = null;
    return;
  }

  const articles = document.querySelectorAll('article[data-testid="tweet"]');
  articles.forEach((a) => searchInjectButton(a));
  articles.forEach((a) => givInjectButton(a));

  if (searchAutoModeOn) searchAutoLoop();
}

function searchIsAlreadyLiked(article) {
  return !!article.querySelector('[data-testid="unlike"]');
}


// ─── Reply / comment detection (used by the SEA engine) ──────────────────────
// Search results can contain replies ("comments") instead of original posts. A reply always carries
// the "Replying to @a and @b" row between the author header and the post body. We find that row
// by STRUCTURE (a row of @-links located after the author header and before the body / media /
// quote / action bar) so it works in any UI language, and also by the English/other-language
// wording as a second signal. Quote-posts and reposts are NOT replies and stay eligible.
const ZEN_REPLYING_RE = /^\s*(replying to|en réponse à|en respuesta a|respondiendo a|antwort an|als antwort auf|em resposta a|in risposta a|risposta a|в ответ|ответ|yanıt olarak|membalas|membalas ke|balasan untuk|replying)\b/i;
function zenIsReplyArticle(article) {
  try {
    if (!article) return false;
    const names = article.querySelectorAll('[data-testid="User-Name"]');
    const head = names[0];
    if (!head) return false;
    const after = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING); // b comes after a
    const stops = [
      article.querySelector('[data-testid="tweetText"]'),
      article.querySelector('[data-testid="tweetPhoto"]'),
      article.querySelector('[data-testid="videoPlayer"]'),
      article.querySelector('[data-testid="card.wrapper"]'),
      names[1],
      article.querySelector('[role="group"]'),
    ].filter(Boolean);
    let stop = null;
    for (const st of stops) { if (!stop || after(st, stop)) stop = st; }   // earliest stop in document order
    const links = article.querySelectorAll('a[href^="/"]');
    for (const a of links) {
      const txt = (a.textContent || '').trim();
      if (txt.charAt(0) !== '@') continue;
      if (head.contains(a)) continue;
      if (!after(head, a)) continue;                       // must come after the author header
      if (stop && (stop.contains(a) || !after(a, stop))) continue;   // …and before body / media / quote / actions
      // The row = biggest element holding this link that contains neither the header nor the stop element.
      let row = a.parentElement;
      while (row && row.parentElement && row.parentElement !== article &&
             !row.parentElement.contains(head) && !(stop && row.parentElement.contains(stop))) row = row.parentElement;
      if (!row) continue;
      const rowText = (row.textContent || '').trim();
      if (ZEN_REPLYING_RE.test(rowText)) return true;
      // Language-independent: the row is only @-links plus a few short connector words.
      let rest = rowText;
      row.querySelectorAll('a').forEach((l) => { rest = rest.split((l.textContent || '').trim()).join(' '); });
      rest = rest.replace(/[\s,،、.&]+/g, ' ').trim();
      if (rest.length <= 40 && !row.querySelector('[data-testid="tweetText"]')) return true;
    }
    return false;
  } catch (e) { return false; }
}

function searchInjectButton(article) {
  if (isAdArticle(article)) return; // skip promoted posts
  if (searchDoneArticles.has(article)) return;
  if (article.querySelector('.zen-sea-btn')) { searchDoneArticles.add(article); return; }

  const actionBar = article.querySelector('[role="group"]');
  if (!actionBar) return; // not fully rendered yet — retry on next scan

  const postTextEl = article.querySelector('[data-testid="tweetText"]');

  // Never show SEA on your own posts.
  if (isOwnArticle(article)) { searchDoneArticles.add(article); return; }

  // Engage By Wallchain Score — score outside the range = no SEA button on this post.
  { const g = zexWcGate(article, 'searchEngage'); if (g === 'wait') return; if (g === 'skip') { searchDoneArticles.add(article); return; } }

  // Search results can be replies/comments — SEA is for original posts only.
  if (zenIsReplyArticle(article)) { searchDoneArticles.add(article); return; }

  // Replied/History lists not loaded yet (right after a refresh) → don't decide, retry on the next scan.
  // Post Age Limit: outside the window = no SEA button on this post.
  { const _av = zexAgeVerdict(article);
    if (_av !== 'ok') { searchDoneArticles.add(article); if (_av === 'old') { const _oid = articleStatusId(article); if (_oid) zexAgeOldIds.add(_oid); } return; } }

  if (!_zenIdsReady) return;

  searchDoneArticles.add(article);

  // "Already engaged" is decided by History (same link saved) + the shared list — not by a Like.
  // Never show SEA on a post already replied to (shared tracking with REP/FEED).
  const sid = articleStatusId(article);
  if (zexBlockedArticle(article)) { zexLogBlocked(sid, 'SEA', zenArticleLink(article), getArticleAuthorHandle(article)); return; }
  if (hasAlreadyReplied(sid)) { zenLogSkip(sid, 'SEA', zenArticleLink(article), getArticleAuthorHandle(article)); return; }
  if (zenIsCommentOff(sid)) return; // comment off — already saved in History

  const btn = document.createElement('button');
  btn.className = 'zen-rep-btn zen-sea-btn';
  btn.type = 'button';
  btn.textContent = 'SEA';
  btn.title = 'Generate a short reply for this post';
  btn.addEventListener('click', async (e) => {
    e.preventDefault(); e.stopPropagation();
    await searchHandleClick(article, postTextEl, btn);
  });

  actionBar.appendChild(btn);
}

async function searchHandleClick(article, postTextEl, btn) {
  if (searchBusyArticles.has(article)) return;

  // Last-moment guard: never comment on a post that is already replied / in History.
  if (zenAlreadyGuard(article, 'SEA', btn)) { searchAutoSkipped.add(article); return; }

  try { const _tsid = articleStatusId(article); if (_tsid) await zexTagPost(_tsid, await zexSeaKwTags(article)); } catch (e) {}

  const { zenSearchPromptModel } = await getStorage(['zenSearchPromptModel']);
  const useModel2 = zenSearchPromptModel === 'model2';

  // ── Model 2: just open this post's real reply box and let the GET Reply
  // widget (which auto-injects into any open reply box) do everything —
  // Tone, Custom Tone, Big Reply, Project Name, Keywords, session/limit
  // checks, history — all handled by that one existing engine. Nothing
  // duplicated here.
  if (useModel2) {
    await searchHandleClickModel2(article, btn);
    return;
  }

  // ── Model 1: quick, search-only, always short — ignores tone/keyword/project settings.
  if (!navigator.onLine) { showToast('No internet connection!', 'error'); return; }
  if (!postTextEl || !postTextEl.innerText.trim()) { showToast('No text on this post — switch to Model 2 in settings', 'warn'); return; }

  const { zenDeviceSession } = await getStorage(['zenDeviceSession']);
  if (!zenDeviceSession || Date.now() >= zenDeviceSession.expiresAt) {
    showToast('Session expired! Open Z EX and login again.', 'warn');
    return;
  }

  const syncResult = await syncAdminApiKey(zenDeviceSession.email);
  if (syncResult && syncResult.locked) { showToast('Contact Admin', 'error'); return; }

  const limitCheck = await checkAndIncrementReplyCount(zenDeviceSession.email);
  if (!limitCheck.allowed) {
    showToast('' + (limitCheck.reason === 'Contact Admin' ? 'Contact Admin' : limitCheck.reason), 'error');
    return;
  }
  trackActivity(zenDeviceSession.email);

  const storage = await getStorage(['smartSwitch']);
  const smartSwitch = storage.smartSwitch !== false;

  const postText = postTextEl.innerText.trim();

  searchBusyArticles.add(article);
  const originalHTML = btn.innerHTML;
  btn.innerHTML = '<span class="zen-spin"></span>';
  btn.disabled = true;

  try {
    let editor = null;
    if (await zenLiveEnabled()) { // Live: like → open box → stream into it
      if (searchLikeOn && !searchIsAlreadyLiked(article) && zexLikeRoll(article, searchLikePct, 'SEA')) {
        try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
      }
      editor = await repOpenReplyBox(article, { eng: 'SEA' });
      if (!editor) throw new Error(zenNoBoxMsg());
      searchLastEditor = editor;
    }
    const reply = await zenLiveGenerate(editor, () => feedGenerateReplyWithFallback(
      postText, smartSwitch, article
    ));

    if (!editor) {
      // Like first if enabled — independent of whether the reply itself succeeds later.
      if (searchLikeOn && !searchIsAlreadyLiked(article) && zexLikeRoll(article, searchLikePct, 'SEA')) {
        try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
      }
      editor = await repOpenReplyBox(article, { eng: 'SEA' });
      if (!editor) throw new Error(zenNoBoxMsg());
      searchLastEditor = editor;
    }

    await insertReply(editor, reply);

    // Shared tracking with REP/FEED — a post replied to via SEA will never
    // show a REP/FED button for it either, and vice versa.
    const sidForWatch = articleStatusId(article);
    pendingReplyMap.set(editor, { tweetLink: sidForWatch ? `https://x.com/i/status/${sidForWatch}` : null, tweetAuthor: getArticleAuthorHandle(article) || '', replyText: reply, tone: 'SEA', ts: Date.now() });
    armPostWatcher(editor);

    let autoPosted = false;
    if (searchAutoModeOn) {
      autoPosted = await repAutoSubmit(editor);
    }

    btn.textContent = 'DONE';
    btn.classList.add('zen-rep-done');
    btn.disabled = true;
    showToast(autoPosted ? 'Reply posted' : 'Reply drafted — review & tap Reply', 'success');
    zenAgentRecord('SEA', true, !!autoPosted);

    if (sidForWatch) markStatusIdReplied(sidForWatch, 'SEA');

    chrome.storage.local.get(['zenSearchDraftCount'], (d) => {
      chrome.storage.local.set({ zenSearchDraftCount: (d.zenSearchDraftCount || 0) + 1 });
    });
  } catch (err) {
    zenAgentRecord('SEA', false, false, err && err.message);
    showToast('' + (err.message || 'Reply failed'), 'error');
    btn.innerHTML = originalHTML;
    btn.disabled = false;
  } finally {
    searchBusyArticles.delete(article);
  }
}

// ── Model 2 handler — opens the reply box, waits for the real GET Reply
// widget to auto-inject into its toolbar (the same MutationObserver that
// injects it on every other reply box on X), then invokes that exact
// engine directly. Session/limit checks, Tone, Custom Tone, Big Reply,
// Project Name, Keywords, and history — all come from that one place.
async function searchHandleClickModel2(article, btn) {
  searchBusyArticles.add(article);
  const originalHTML = btn.innerHTML;
  btn.innerHTML = '<span class="zen-spin"></span>';
  btn.disabled = true;

  try {
    // Like BEFORE opening the reply box: on mobile web, opening the reply
    // box can navigate to a dedicated compose page and unmount this
    // article's DOM node entirely, so clicking Like on it afterward would
    // silently do nothing.
    if (searchLikeOn && !searchIsAlreadyLiked(article) && zexLikeRoll(article, searchLikePct, 'SEA')) {
      try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
    }

    let editor = await repOpenReplyBox(article, { eng: 'SEA' });
    if (!editor) throw new Error(zenNoBoxMsg());
    searchLastEditor = editor;

    const _got = await zenAcquireGetReply(article, editor, 'SEA');
    if (!_got) throw zenSkipErr('GET Reply did not appear — post skipped');
    const replyBtn = _got.replyBtn;
    editor = _got.editor;
    searchLastEditor = editor;

    const cfg = await getStorage(['bigReplyConfig', 'bigReplyMode']);
    const bigOn = cfg.bigReplyMode === true;
    await zenEngineGetReply(editor, replyBtn, bigOn);

    if (isEditorEmpty(editor)) {
      throw new Error('No reply was drafted — check session, API key, or reply limit');
    }

    let autoPosted = false;
    if (searchAutoModeOn) {
      autoPosted = await repAutoSubmit(editor);
    }

    btn.textContent = 'DONE';
    btn.classList.add('zen-rep-done');
    btn.disabled = true;
    showToast(autoPosted ? 'Reply posted' : 'Reply drafted — review & tap Reply', 'success');
    zenAgentRecord('SEA', true, !!autoPosted);

    const sid = articleStatusId(article);
    if (sid) markStatusIdReplied(sid, 'SEA');

    chrome.storage.local.get(['zenSearchDraftCount'], (d) => {
      chrome.storage.local.set({ zenSearchDraftCount: (d.zenSearchDraftCount || 0) + 1 });
    });
  } catch (err) {
    zenAgentRecord('SEA', false, false, err && err.message);
    showToast('' + (err.message || 'Reply failed'), 'error');
    btn.innerHTML = originalHTML;
    btn.disabled = false;
  } finally {
    searchBusyArticles.delete(article);
  }
}

async function searchAutoLoop() {
  zenMarkEngineActivity();
  if (searchAutoRunning) return;
  searchAutoRunning = true;
  const _ep = _zenLoopEpoch;   // stuck-watchdog: this run is orphaned if the epoch changes
  let processed = 0;
  let noNewTargetStreak = 0;
  try {
    while (_ep === _zenLoopEpoch && searchAutoModeOn && searchModeActive && !zenRefreshHold && processed < SEARCH_AUTO_MAX_PER_RUN) {
      { // Follow By Wallchain Score — runs between replies, never in the middle of one
        const fs = await zexWcFollowStep('search', isSearchUrl);
        if (fs === 'limit') { showToast('Follow by Wallchain Score — limit reached', 'success'); try { chrome.storage.local.set({ zenSearchAutoMode: false }); } catch (e) {} break; }
        if (fs) { await repSleep(1200); continue; }
      }
      const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
      const _wcOnlyS = !!(zexWcFollowCfg('search') || {}).only;

      const target = articles.find((a) => {
        const btn = a.querySelector('.zen-sea-btn');
        if (_wcOnlyS) return false;   // follow-only: no replies
        if (!btn || btn.disabled || searchAutoSkipped.has(a) || searchBusyArticles.has(a) || zenPostSkipped(a)) return false;
        if (zenIsReplyArticle(a)) {          // a comment, not a post → skip it for good
          searchAutoSkipped.add(a);
          try { btn.remove(); } catch (e) {}
          return false;
        }
        return true;
      });

      if (!target) {
        // Nothing eligible visible right now — scroll down to load more
        // results and let the next scan cycle inject buttons on them,
        // instead of stopping the loop entirely.
        noNewTargetStreak++;
        ZenCursor.setState('search');
        if (zexAgeActive() && zexAgeOldIds.size >= ZEX_AGE_OLD_STOP) {
          showToast('Reached posts older than the age limit - stopped', 'success');
          try { chrome.storage.local.set({ zenSearchAutoMode: false }); } catch (e) {}
          break;
        }
        if (noNewTargetStreak > 6) break; // scrolled repeatedly with nothing new — likely end of results
        // Move cursor to bottom-center before scroll (visual feedback)
        if (ZenCursor.active) {
          await ZenCursor.moveToXY(
            window.innerWidth / 2 + (Math.random() * 60 - 30),
            window.innerHeight * 0.75,
            180
          );
        }
        const _ids0 = zexPostIds();
        await zenScroll(window.innerHeight * 1.5);
        const _wl = await zexWaitMorePosts(_ids0);   // wait for real new posts; error -> full reload
        if (_wl === 'reload' || _wl === 'hold') break;
        await repSleep(1500); // give X time to render the next batch
        continue;
      }
      noNewTargetStreak = 0;

      const btn = target.querySelector('.zen-sea-btn');
      const postTextEl = target.querySelector('[data-testid="tweetText"]');

      const _pv = await zexPvBefore(target, 'SEA');   // Profile Visit: may visit the author's profile before replying
      if (_pv.lost) continue;                  // page re-rendered after the visit → pick the post again
      // ── Pause if tab is hidden — X.com flags background automation ──
      await zenWaitForVisible();
      // ── Bring article into viewport first (virtual scroll fix) ──
      await ensureInViewport(target, { margin: 40, settle: 200 });
      ZenCursor.setState('found');
      // Move ZenCursor to the button for visual feedback
      if (ZenCursor.active && btn) await ZenCursor.moveTo(btn);

      // Last check right before acting: the row may have rendered/changed while we scrolled and waited.
      if (zenIsReplyArticle(target)) { searchAutoSkipped.add(target); try { btn.remove(); } catch (e) {} continue; }

      searchLastEditor = null;
      try {
        await searchHandleClick(target, postTextEl, btn);
      } catch (err) {
        // 1 retry after short pause
        await repSleep(800 + Math.random() * 400);
        try {
          await searchHandleClick(target, postTextEl, btn);
        } catch (err2) {
          searchAutoSkipped.add(target);
          showToast('' + (err2?.message || 'Reply failed — skipping post'), 'error');
        }
      }
      processed++;

      if (!btn.classList.contains('zen-rep-done')) {
        searchAutoSkipped.add(target);
        zenSkipPost(target, 'SEA', 'failed');   // by status id — survives X re-mounting the row
        await zenStuckCloseComposer();                 // never leave a half-open reply sheet blocking the next post
        await repSleep(1200);
        continue;
      }

      await repWaitForClose(searchLastEditor);
      ZenCursor.setState('rest');
      await zexPvAfter(_pv);
      await repPaceWait(); // same pacing preference as the Comment engine
    }
  } finally {
    if (_ep === _zenLoopEpoch) searchAutoRunning = false;
  }
}

// ═══ SEA LINK COLLECT ═══════════════════════════════════════
// Search-engine "Link Collect" mode. NO like, NO reply, NO AI: it only scrolls the
// search results and saves each original post's link into a Sweep folder
// (chrome.storage.local.zenTgSweepFolders — the same list the Telegram Sweep tab
// runs later). Target = an existing folder (new links are appended, duplicates
// skipped) or a brand-new folder.
//   zenSearchCollectOn    — start / stop flag (set by the popup)
//   zenSearchCollectCfg   — { target:'new'|folderId, name, max, tabId }
//   zenSearchCollectState — { phase, added, dup, skipped, folderId, folderName }
let seaColRunning = false;
let seaColStop = false;

function seaColTweetId(u) { const m = String(u || '').match(/status\/(\d+)/); return m ? m[1] : null; }

async function seaColSaveLinks(links, cfg, folderId) {
  const d = await getStorage(['zenTgSweepFolders']);
  const list = Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders.slice() : [];
  let f = folderId ? list.find((x) => x.id === folderId) : null;
  if (!f) {
    const label = ((cfg && cfg.name) || '').trim().slice(0, 60) ||
      'Search ' + new Date().toLocaleString([], { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
    f = { id: 'f' + Date.now().toString(36), name: label, links: [], createdAt: Date.now() };
    list.unshift(f);
  }
  const have = new Set((f.links || []).map(seaColTweetId));
  const fresh = [];
  let dup = 0;
  for (const u of links) {
    const id = seaColTweetId(u);
    if (!id || have.has(id)) { dup++; continue; }
    have.add(id);
    fresh.push(u);
  }
  f.links = (f.links || []).concat(fresh);
  await chrome.storage.local.set({ zenTgSweepFolders: list.slice(0, 100) });
  return { added: fresh.length, dup, folderId: f.id, folderName: f.name, total: f.links.length };
}

// Projects of a manually typed X search (q param). Filters / operators are ignored.
//   polymarket min_faves:10 lang:en                      -> [{name:'polymarket'}]
//   filter:blue_verified ("ZeruAI" OR @zerufinance OR "Quip Network" OR @quipnetwork) -filter:replies
//        -> [{name:'zeruai', alias:['@zerufinance']}, {name:'quip network', alias:['@quipnetwork']}]
// "Name OR @handle" pairs are ONE project; its tag is the name (or the @handle when there is no name before it).
function zexQueryProjects(url) {
  try {
    const q = (new URL(url).searchParams.get('q') || '').trim();
    if (!q) return [];
    // top-level tokens: quoted phrases, (groups), plain words
    function scan(str) {
      const out = []; let i = 0; const n = str.length;
      while (i < n) {
        const ch = str[i];
        if (/\s/.test(ch)) { i++; continue; }
        if (ch === '(') {
          let d = 0, j = i, inq = false;
          for (; j < n; j++) {
            const x = str[j];
            if (x === '"') inq = !inq;
            else if (!inq && x === '(') d++;
            else if (!inq && x === ')') { d--; if (d === 0) break; }
          }
          const prev = out[out.length - 1];
          const neg = !!(prev && !prev.q && prev.t === '-');
          if (neg) out.pop();
          out.push({ g: str.slice(i + 1, j), neg: neg });
          i = j + 1; continue;
        }
        if (ch === '"') {
          const j = str.indexOf('"', i + 1);
          const end = j < 0 ? n : j;
          out.push({ t: str.slice(i + 1, end), q: true });
          i = end + 1; continue;
        }
        let j = i;
        while (j < n && !/\s/.test(str[j]) && str[j] !== '(' && str[j] !== '"') j++;
        if (j === i) j = i + 1;
        out.push({ t: str.slice(i, j) });
        i = j;
      }
      return out;
    }
    const isOr = (x) => x && !x.q && x.t != null && /^OR$/i.test(x.t);
    const isOp = (x) => !x || x.g != null || (!x.q && (/:/.test(x.t) || /^-/.test(x.t) || /^(OR|AND)$/i.test(x.t)));
    const clean = (t) => String(t || '').trim().replace(/^[()]+|[()]+$/g, '').trim().toLowerCase().slice(0, 40);
    function plainTerms(tokens) {            // terms in order, operators dropped
      const out = [];
      tokens.forEach((x) => { if (!isOp(x)) { const t = clean(x.t); if (t.length >= 2 && out.indexOf(t) < 0) out.push(t); } });
      return out;
    }
    function toProjects(terms) {
      const ps = [];
      terms.forEach((t) => {
        const last = ps[ps.length - 1];
        if (t[0] === '@' && last && !last.name.startsWith('@') && last.alias.length === 0) last.alias.push(t);
        else ps.push({ name: t, alias: [] });
      });
      return ps.slice(0, 12);
    }
    const top = scan(q);
    // 1) first (non-negated) group that holds real terms = the project list
    for (let k = 0; k < top.length; k++) {
      if (top[k].g != null && !top[k].neg) {
        const terms = plainTerms(scan(top[k].g));
        if (terms.length) return toProjects(terms);
      }
    }
    // 2) no group: first plain term, plus an "A OR B OR C" chain right after it
    for (let k = 0; k < top.length; k++) {
      if (isOp(top[k])) continue;
      const terms = [];
      let m = k;
      while (m < top.length) {
        if (!isOp(top[m])) { const t = clean(top[m].t); if (t.length >= 2 && terms.indexOf(t) < 0) terms.push(t); }
        else if (top[m] && isOr(top[m]) && top[m + 1] && !isOp(top[m + 1])) { m++; continue; }
        else break;
        if (isOr(top[m + 1]) && top[m + 2] && !isOp(top[m + 2])) { m += 2; continue; }
        break;
      }
      return terms.length ? toProjects(terms) : [];
    }
    return [];
  } catch (e) { return []; }
}
function zexQueryKeywords(url) { return zexQueryProjects(url).map((p) => p.name); }

async function seaColRun() {
  if (seaColRunning) return;
  seaColRunning = true;
  seaColStop = false;
  let added = 0, dup = 0, skipped = 0, folderId = null, folderName = '';
  let _colUsers = 0, _colKnown = 0, _colFol = 0, _colWhatS = 'links';
  let phase = 'done';
  let ageStopped = false;
  const pushState = (ph) => {
    try { chrome.storage.local.set({ zenSearchCollectState: { phase: ph, added, dup, skipped, folderId, folderName, users: _colUsers, usersKnown: _colKnown, usersFollowing: _colFol, what: _colWhatS, ts: Date.now() } }); } catch (e) {}
  };
  try {
    const d0 = await getStorage(['zenSearchCollectCfg']);
    const cfg = d0.zenSearchCollectCfg || {};
    const max = Math.max(0, parseInt(cfg.max, 10) || 0);
    folderId = (cfg.target && cfg.target !== 'new') ? cfg.target : null;
    const seen = new Set();
    let idle = 0;
    let _colKws = [];
    let oldRun = 0;               // Post Age Limit: consecutive too-old posts
    const colWhat = cfg.what === 'users' || cfg.what === 'both' ? cfg.what : 'links';   // links | users (by Wallchain score) | both
    const colWc = { min: Number(cfg.wcMin) || 0, max: Number(cfg.wcMax) || 0 };
    let usersAdded = 0, usersKnown = 0, usersFollowing = 0;
    const noScore = {};
    try { const _up = zexQueryProjects(location.href); if (Array.isArray(cfg.qKws) && cfg.qKws.length) _colKws = cfg.qKws; else if (_up.length) _colKws = _up; else { const _kd = await getStorage(['zenSearchKeywords']); _colKws = _kd.zenSearchKeywords || []; } } catch (e) {}
    _colWhatS = colWhat;
    showToast(colWhat === 'users' ? 'Collect usernames ON — Wallchain ' + colWc.min + '–' + colWc.max : 'Link Collect ON — collecting links (no replies)', 'success');
    pushState('running');
    while (!seaColStop && extContextAlive() && isSearchUrl(location.href)) {
      await zenWaitForVisible();
      if (!_zenIdsReady) { await repSleep(600); continue; }
      const batch = [];
      const before = seen.size;
      for (const a of document.querySelectorAll('article[data-testid="tweet"]')) {
        if (!a.querySelector('[role="group"]')) continue;       // not fully rendered yet — look again next round
        const link = zenArticleLink(a);
        const id = seaColTweetId(link);
        if (!link || !id || seen.has(id)) continue;
        if (colWhat !== 'links') {
          // Collect username by Wallchain score: any post/comment author in range, not followed, not already collected
          if (isAdArticle(a) || isOwnArticle(a)) { seen.add(id); continue; }
          const r = zexPeopleCollectArticle(a, colWc, 'COL');
          if (r === 'noscore' && (noScore[id] = (noScore[id] || 0) + 1) <= 3) continue;   // badge may still be loading — look again next round
          if (r === 'added') { usersAdded++; _colUsers = usersAdded; }
          else if (r === 'known') { usersKnown++; _colKnown = usersKnown; }
          else if (r === 'following') { usersFollowing++; _colFol = usersFollowing; }
          if (r === 'added' || r === 'known' || r === 'following') pushState('running');
          if (colWhat === 'users') { seen.add(id); continue; }
        }
        seen.add(id);
        if (isAdArticle(a) || isOwnArticle(a) || zenIsReplyArticle(a) || zexBlockedArticle(a)) continue;   // originals only (blacklisted accounts are never collected)
        if (hasAlreadyReplied(id)) { skipped++; continue; }
        { const _av = zexAgeVerdict(a);
          if (_av === 'old') { oldRun++; continue; }
          if (_av === 'skip') continue;
          oldRun = 0; }
        try { const _ct = zexKwMatch(_colKws, a); if (_ct.length) zexTagPost(id, _ct); } catch (e) {}
        batch.push(link);
      }
      if (batch.length) {
        const room = max ? Math.max(0, max - added) : batch.length;
        const part = max ? batch.slice(0, room) : batch;
        if (part.length) {
          try {
            const r = await seaColSaveLinks(part, cfg, folderId);
            added += r.added; dup += r.dup; folderId = r.folderId; folderName = r.folderName;
          } catch (e) { phase = 'error'; break; }
          pushState('running');
        }
        if (max && added >= max) break;
      }
      if (zexAgeActive() && oldRun >= ZEX_AGE_OLD_STOP) { ageStopped = true; break; }   // reached posts older than the window
      idle = (seen.size === before) ? idle + 1 : 0;
      if (idle > 6) break;                                       // scrolled repeatedly, nothing new — end of results
      const _ids0 = zexPostIds();
      await zenScroll(window.innerHeight * 1.5);
      const _wl = await zexWaitMorePosts(_ids0);
      if (_wl === 'reload' || _wl === 'hold') break;
      await repSleep(1500);
    }
    if (phase !== 'error') phase = seaColStop ? 'stopped' : 'done';
  } catch (e) {
    phase = 'error';
  } finally {
    seaColRunning = false;
    pushState(phase);
    try { chrome.storage.local.set({ zenSearchCollectOn: false }); } catch (e) {}
    try {
      showToast(phase === 'error' ? 'Link Collect — could not save links'
        : 'Link Collect ' + (phase === 'stopped' ? 'stopped' : (ageStopped ? 'reached older posts, finished' : 'finished')) + ' — ' + added + ' link' + (added === 1 ? '' : 's') + ' saved' + (folderName ? ' to "' + folderName + '"' : '') + (_colWhatS !== 'links' ? ' · ' + _colUsers + ' username' + (_colUsers === 1 ? '' : 's') + ' collected' : ''),
        phase === 'error' ? 'error' : 'success');
    } catch (e) {}
  }
}

async function seaColMaybeStart() {
  const d = await getStorage(['zenSearchCollectOn', 'zenSearchCollectCfg']);
  if (d.zenSearchCollectOn !== true) return;
  if (!isSearchUrl(location.href)) return;
  const cfg = d.zenSearchCollectCfg || {};
  if (cfg.tabId != null) { const me = await _getTabId(); if (me !== cfg.tabId) return; }   // only the tab the popup chose
  seaColRun();
}
try {
  seaColMaybeStart();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.zenSearchCollectOn) return;
    if (changes.zenSearchCollectOn.newValue === true) seaColMaybeStart();
    else seaColStop = true;
  });
} catch (e) {}

// ═══ GIV ENGINE ══════════════════════════════════════════════
// Giveaway / Whitelist wallet-reply engine (x.com/home + x.com/search)
//
// Doesn't call any AI. Scans posts already surfaced by the FEED and SEA
// engines' own scan loops (so it needs no separate MutationObserver/timer)
// for giveaway/WL/GTD/FCFS-style language, and if matched, drops a fixed
// wallet-address reply template into the post's reply box. Shares the same
// "already replied" tracking as REP/FEED/SEA so a post never gets
// double-handled by any engine.
// ═══════════════════════════════════════════════════════════════

let givEngineOn = false;      // master toggle — set from the popup
let givAutoModeOn = false;
let givAutoRunning = false;
let givWalletAddress = '';
let givReplyTemplate = 'Wallet: {wallet} 🙏';
let givKeywords = ['giveaway', 'gtd', 'fcfs', 'whitelist', 'wl spot', 'wl giveaway', 'guaranteed spot'];
let givAiVerifyOn = false; // second-pass AI confirmation on top of the keyword match
let givLikeOn = false;      // like the post before replying (delay set by zenLikeDelay)
const givDoneArticles = new WeakSet();
const givCheckingArticles = new WeakSet(); // mid AI-classification — don't re-queue on next scan tick
const givBusyArticles = new WeakSet();
const givAutoSkipped = new WeakSet();
let givLastEditor = null;
const GIV_AUTO_MAX_PER_RUN = 40; // circuit breaker against any runaway loop

chrome.storage.local.get(['zenGivEngineOn', 'zenGivAutoMode', 'zenGivWallet', 'zenGivTemplate', 'zenGivKeywords', 'zenGivAiVerify', 'zenGivLikeOn'], (d) => {
  givLikeOn = d.zenGivLikeOn === true;
  givEngineOn = d.zenGivEngineOn === true;
  givAutoModeOn = d.zenGivAutoMode === true;
  givWalletAddress = d.zenGivWallet || '';
  if (d.zenGivTemplate) givReplyTemplate = d.zenGivTemplate;
  if (Array.isArray(d.zenGivKeywords) && d.zenGivKeywords.length) givKeywords = d.zenGivKeywords;
  givAiVerifyOn = d.zenGivAiVerify === true;
  zenAgentRefreshEngineState();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.zenGivEngineOn) {
    givEngineOn = changes.zenGivEngineOn.newValue === true;
    zenAgentRefreshEngineState();
  }
  if (changes.zenGivAutoMode) givAutoModeOn = changes.zenGivAutoMode.newValue === true;
  if (changes.zenGivWallet) givWalletAddress = changes.zenGivWallet.newValue || '';
  if (changes.zenGivTemplate) givReplyTemplate = changes.zenGivTemplate.newValue || givReplyTemplate;
  if (changes.zenGivKeywords) {
    const nv = changes.zenGivKeywords.newValue;
    if (Array.isArray(nv) && nv.length) givKeywords = nv;
  }
  if (changes.zenGivAiVerify) givAiVerifyOn = changes.zenGivAiVerify.newValue === true;
  if (changes.zenGivLikeOn) givLikeOn = changes.zenGivLikeOn.newValue === true;
});

// Matches giveaway/WL-style posts. Line-based so a post that's mostly
// unrelated text but has one giveaway line (like the examples with a
// "-------" divider and a details block below it) still matches.
// This is the FAST, FREE first pass — the AI verify step (if enabled)
// only ever runs on posts that already passed this check.
function givPostMatches(text) {
  if (!text) return false;
  const lower = text.toLowerCase();
  return givKeywords.some((kw) => kw && lower.includes(kw.toLowerCase()));
}

function givIsAlreadyLiked(article) {
  return !!article.querySelector('[data-testid="unlike"]');
}

// Called from both feedScanPosts and searchScanPosts on the exact same
// articles those engines already scan — no separate timer/observer needed.
function givInjectButton(article) {
  if (isAdArticle(article)) return; // skip promoted posts
  if (!givEngineOn) return;
  if (!givWalletAddress) return; // nothing to paste — don't show a dead button
  if (givDoneArticles.has(article) || givCheckingArticles.has(article)) return;
  if (article.querySelector('.zen-giv-btn')) { givDoneArticles.add(article); return; }

  const actionBar = article.querySelector('[role="group"]');
  if (!actionBar) return; // not fully rendered yet — retry on next scan

  const postTextEl = article.querySelector('[data-testid="tweetText"]');
  const postText = postTextEl ? postTextEl.innerText : '';

  // Never show GIV on your own posts.
  if (isOwnArticle(article)) { givDoneArticles.add(article); return; }

  // Fast/free keyword pass first — only posts that pass this ever reach
  // the (optional) AI verification step below.
  if (!givPostMatches(postText)) { givDoneArticles.add(article); return; }

  // Never show GIV on a post already replied to (shared tracking with REP/FEED/SEA).
  if (!_zenIdsReady) return;   // replied/History list not loaded yet — retry on the next scan
  const sid = articleStatusId(article);
  if (zexBlockedArticle(article)) { zexLogBlocked(sid, 'GIV', zenArticleLink(article), getArticleAuthorHandle(article)); givDoneArticles.add(article); return; }
  if (hasAlreadyReplied(sid)) { zenLogSkip(sid, 'GIV', zenArticleLink(article), getArticleAuthorHandle(article)); givDoneArticles.add(article); return; }

  if (!givAiVerifyOn) {
    givDoneArticles.add(article);
    givRenderButton(article, actionBar);
    return;
  }

  // AI verify path: keyword matched, but confirm with a cheap yes/no call
  // before showing the button, so posts that only mention the words in
  // passing (e.g. "this FCFS giveaway was a scam") don't get one.
  givCheckingArticles.add(article); // don't re-queue this article on the next 1200ms scan tick
  (async () => {
    try {
      const storage = await getStorage(['smartSwitch']);
      const isGiveaway = await givClassifyWithFallback(postText, storage.smartSwitch !== false, article);
      if (isGiveaway && document.body.contains(article) && actionBar.isConnected) {
        givRenderButton(article, actionBar);
      }
    } finally {
      givCheckingArticles.delete(article);
      givDoneArticles.add(article); // either way, don't re-check this article again
    }
  })();
}

function givRenderButton(article, actionBar) {
  if (article.querySelector('.zen-giv-btn')) return;
  const btn = document.createElement('button');
  btn.className = 'zen-rep-btn zen-giv-btn';
  btn.type = 'button';
  btn.textContent = 'GIV';
  btn.title = 'Drop your wallet address as a reply to claim this giveaway/WL spot';
  btn.addEventListener('click', async (e) => {
    e.preventDefault(); e.stopPropagation();
    await givHandleClick(article, btn);
  });

  actionBar.appendChild(btn);
}

async function givHandleClick(article, btn) {
  if (givBusyArticles.has(article)) return;
  if (zenAlreadyGuard(article, 'GIV', btn)) return;
  if (!givWalletAddress) { showToast('Set your wallet address in Z EX popup first!', 'warn'); return; }

  givBusyArticles.add(article);
  const originalHTML = btn.innerHTML;
  btn.innerHTML = '<span class="zen-spin"></span>';
  btn.disabled = true;

  // Capture everything we need from `article` NOW, before repOpenReplyBox
  // can navigate to a full-page composer and unmount it — after that,
  // `article` may be a detached node and querySelector calls on it go stale.
  const sidForWatch = articleStatusId(article);
  const authorForWatch = getArticleAuthorHandle(article) || '';

  try {
    const reply = givReplyTemplate.replace(/\{wallet\}/gi, givWalletAddress);

    if (givLikeOn && !givIsAlreadyLiked(article)) {
      try { await realClick(article.querySelector('[data-testid="like"]')); await zenWaitAfterLike(); } catch (e) {}
    }

    const editor = await repOpenReplyBox(article, { eng: 'GIV' });
    if (!editor) throw new Error(zenNoBoxMsg());
    givLastEditor = editor;

    await insertReply(editor, reply, { allowLinks: true });

    // Shared tracking with REP/FEED/SEA — a post replied to via GIV will
    // never show a REP/FED/SEA button for it either, and vice versa.
    pendingReplyMap.set(editor, { tweetLink: sidForWatch ? `https://x.com/i/status/${sidForWatch}` : null, tweetAuthor: authorForWatch, replyText: reply, tone: 'GIV', ts: Date.now() });
    armPostWatcher(editor);

    let autoPosted = false;
    if (givAutoModeOn) {
      autoPosted = await repAutoSubmit(editor);
    }

    btn.textContent = 'DONE';
    btn.classList.add('zen-rep-done');
    btn.disabled = true;
    showToast(autoPosted ? 'Wallet reply posted' : 'Wallet reply drafted — review & tap Reply', 'success');
    zenAgentRecord('GIV', true, !!autoPosted);

    if (sidForWatch) markStatusIdReplied(sidForWatch, 'GIV');

    chrome.storage.local.get(['zenGivDraftCount'], (d) => {
      chrome.storage.local.set({ zenGivDraftCount: (d.zenGivDraftCount || 0) + 1 });
    });
  } catch (err) {
    zenAgentRecord('GIV', false, false, err && err.message);
    showToast('' + (err.message || 'Reply failed'), 'error');
    btn.innerHTML = originalHTML;
    btn.disabled = false;
  } finally {
    givBusyArticles.delete(article);
  }
}

// Runs across whichever eligible GIV buttons are visible right now,
// regardless of whether they came from the FEED scan or the SEA scan —
// same "find, click, wait, repeat" shape as feedAutoLoop/searchAutoLoop.
async function givAutoLoop() {
  zenMarkEngineActivity();
  if (givAutoRunning) return;
  if (!givAutoModeOn || !givEngineOn) return;
  givAutoRunning = true;
  const _ep = _zenLoopEpoch;   // stuck-watchdog: this run is orphaned if the epoch changes
  let processed = 0;
  try {
    while (_ep === _zenLoopEpoch && givAutoModeOn && givEngineOn && !zenRefreshHold && processed < GIV_AUTO_MAX_PER_RUN) {
      const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));

      const target = articles.find((a) => {
        const btn = a.querySelector('.zen-giv-btn');
        return btn && !btn.disabled && !givAutoSkipped.has(a) && !givBusyArticles.has(a) && !zenPostSkipped(a);
      });
      if (!target) break; // nothing eligible visible right now

      const btn = target.querySelector('.zen-giv-btn');

      // ── Pause if tab is hidden — X.com flags background automation ──
      await zenWaitForVisible();
      givLastEditor = null;
      try {
        await givHandleClick(target, btn);
      } catch (err) {
        // 1 retry after short pause
        await repSleep(800 + Math.random() * 400);
        try {
          await givHandleClick(target, btn);
        } catch (err2) {
          givAutoSkipped.add(target);
          showToast('' + (err2?.message || 'Reply failed — skipping post'), 'error');
        }
      }
      processed++;

      if (!btn.classList.contains('zen-rep-done')) {
        givAutoSkipped.add(target);
        zenSkipPost(target, 'GIV', 'failed');   // by status id — survives X re-mounting the row
        await zenStuckCloseComposer();                 // never leave a half-open reply sheet blocking the next post
        await repSleep(1200);
        continue;
      }

      await repWaitForClose(givLastEditor);
      ZenCursor.setState('rest');
      await repPaceWait(); // same pacing preference as the other engines
    }
  } finally {
    if (_ep === _zenLoopEpoch) givAutoRunning = false;
  }
}

// ═══ SEA TOGGLE (now lives inside the agent dashboard, not floating outside) ═══
// Flips zenSearchEngineOn. Stays in sync with the popup's own SEA Engine
// switch (both just read and write the same storage key).
// ═══════════════════════════════════════════════════════════════

function searchFloatUpdateUI(btn) {
  if (!btn) return;
  if (searchEngineOn) {
    btn.textContent = 'SEA ■ STOP';
    btn.classList.add('zen-search-float-on');
  } else {
    btn.textContent = 'SEA ▶ START';
    btn.classList.remove('zen-search-float-on');
  }
}

// Kept for compatibility with any other call sites, but no longer injects
// a standalone floating button — the toggle now renders inside the agent
// dashboard (see zenOpenAgentDashboard). This just re-syncs whatever
// instance of the button currently exists in the DOM (if any).
function searchInjectFloatButton() {}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.zenSearchEngineOn) {
    const btn = (ZexShadow.$('#zen-search-float-btn') || document.getElementById('zen-search-float-btn'));
    if (btn) searchFloatUpdateUI(btn);
  }
});

// ═══ FLOATING AGENT AVATAR + DETAIL DASHBOARD ═══════════════════
// Small circular avatar (draggable, tap-to-open) sitting near the SEA
// button. Opens a draggable status screen showing live agent state:
// mode(s) running, which API/model answered last, uptime, reply count,
// and whether it's currently writing / sending / waiting / idle.
// ═══════════════════════════════════════════════════════════════

function zenAgentFormatUptime(startedAt) {
  if (!startedAt) return '00:00:00';
  const s = Math.floor((Date.now() - startedAt) / 1000);
  const hh = String(Math.floor(s / 3600)).padStart(2, '0');
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return `${hh}:${mm}:${ss}`;
}

function zenAgentStateLabel(state) {
  switch (state) {
    case 'writing': return 'WRITING REPLY';
    case 'sending': return 'SENDING REPLY';
    case 'waiting': return 'WAITING FOR TARGET';
    default: return 'IDLE';
  }
}

function zenMakeDraggable(handle, target) {
  let sx = 0, sy = 0, ox = 0, oy = 0, dragging = false, moved = 0;
  const onDown = (e) => {
    dragging = true;
    moved = 0;
    const p = e.touches ? e.touches[0] : e;
    sx = p.clientX; sy = p.clientY;
    const r = target.getBoundingClientRect();
    ox = r.left; oy = r.top;
    target.style.transition = 'none';
    // Do NOT preventDefault here — on touch devices this suppresses the
    // synthetic click that normally fires after a tap (touchstart+touchend
    // with no movement), which is exactly what opens the dashboard. Only
    // block default once real dragging motion is confirmed, in onMove.
  };
  const onMove = (e) => {
    if (!dragging) return;
    const p = e.touches ? e.touches[0] : e;
    const dx = p.clientX - sx, dy = p.clientY - sy;
    moved = Math.max(moved, Math.abs(dx), Math.abs(dy));
    if (moved > 6) {
      if (e.cancelable) e.preventDefault();
      let nx = ox + dx, ny = oy + dy;
      nx = Math.max(4, Math.min(window.innerWidth - target.offsetWidth - 4, nx));
      ny = Math.max(4, Math.min(window.innerHeight - target.offsetHeight - 4, ny));
      target.style.left = nx + 'px';
      target.style.top = ny + 'px';
      target.style.right = 'auto';
      target.style.bottom = 'auto';
    }
  };
  const onUp = () => {
    dragging = false;
    // Expose to caller: was this interaction a real drag or just a tap/click?
    target._zenWasDragged = moved > 6;
  };
  handle.addEventListener('mousedown', onDown);
  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
  handle.addEventListener('touchstart', onDown, { passive: true });
  window.addEventListener('touchmove', onMove, { passive: false });
  window.addEventListener('touchend', onUp);
}

function zenInjectAgentAvatar() {
  if (ZexShadow.$('#zen-agent-avatar')) return;
  const avatar = document.createElement('div');
  avatar.id = 'zen-agent-avatar';
  avatar.className = 'zen-agent-avatar';
  avatar.title = 'Agent status';
  const img = document.createElement('img');
  img.src = chrome.runtime.getURL('icons/agent_avatar.jpg');
  img.alt = 'Agent';
  avatar.appendChild(img);
  const dot = document.createElement('span');
  dot.className = 'zen-agent-avatar-dot';
  avatar.appendChild(dot);
  ZexShadow.mount(avatar);

  zenMakeDraggable(avatar, avatar);
  avatar.addEventListener('click', () => {
    if (avatar._zenWasDragged) { avatar._zenWasDragged = false; return; }
    zenToggleAgentDashboard();
  });
}

let zenAgentDashboardEl = null;
let zenAgentDashboardTimer = null;

function zenToggleAgentDashboard() {
  if (zenAgentDashboardEl) {
    zenCloseAgentDashboard();
    return;
  }
  zenOpenAgentDashboard();
}

function zenCloseAgentDashboard() {
  if (zenAgentDashboardTimer) { clearInterval(zenAgentDashboardTimer); zenAgentDashboardTimer = null; }
  if (zenAgentDashboardEl) {
    zenAgentDashboardEl.remove();
    zenAgentDashboardEl = null;
  }
}

// ── Dashboard: background-run state (TG Engage / TG Sweep / TAR / resume memory) ──
// Read from storage so the dashboard is right on ANY x.com tab, not only the tab the job runs in.
const ZexAgentBg = { jobs: {}, tar: null, tgActive: null, tgLastRun: null, tgLast: null, resume: {}, colOn: false, colState: null, folders: [], colPref: {}, errs: [], safety: null };
try {
  chrome.storage.local.get(['zSessAutoJobs', 'zTarJob', 'zenTgActive', 'zenTgLastRun', 'zenTgLast', 'zenAgentResume', 'zenSearchCollectOn', 'zenSearchCollectState', 'zenTgSweepFolders', 'zenSearchCollectPref', 'zexErrLog', 'zexSafetyStop'], (d) => {
    d = d || {};
    ZexAgentBg.jobs = d.zSessAutoJobs || {}; ZexAgentBg.tar = d.zTarJob || null;
    ZexAgentBg.tgActive = d.zenTgActive || null; ZexAgentBg.tgLastRun = d.zenTgLastRun || null;
    ZexAgentBg.tgLast = d.zenTgLast || null; ZexAgentBg.resume = d.zenAgentResume || {};
    ZexAgentBg.colOn = d.zenSearchCollectOn === true; ZexAgentBg.colState = d.zenSearchCollectState || null;
    ZexAgentBg.folders = Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders : []; ZexAgentBg.colPref = d.zenSearchCollectPref || {};
    ZexAgentBg.errs = Array.isArray(d.zexErrLog) ? d.zexErrLog : []; ZexAgentBg.safety = d.zexSafetyStop || null;
    try { zenAgentEmit(); } catch (e) {}
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    let hit = false;
    if ('zSessAutoJobs' in ch) { ZexAgentBg.jobs = ch.zSessAutoJobs.newValue || {}; hit = true; }
    if ('zTarJob' in ch) { ZexAgentBg.tar = ch.zTarJob.newValue || null; hit = true; }
    if ('zenTgActive' in ch) { ZexAgentBg.tgActive = ch.zenTgActive.newValue || null; hit = true; }
    if ('zenTgLastRun' in ch) { ZexAgentBg.tgLastRun = ch.zenTgLastRun.newValue || null; hit = true; }
    if ('zenTgLast' in ch) { ZexAgentBg.tgLast = ch.zenTgLast.newValue || null; hit = true; }
    if ('zenAgentResume' in ch) { ZexAgentBg.resume = ch.zenAgentResume.newValue || {}; hit = true; }
    if ('zenSearchCollectOn' in ch) { ZexAgentBg.colOn = ch.zenSearchCollectOn.newValue === true; hit = true; }
    if ('zenSearchCollectState' in ch) { ZexAgentBg.colState = ch.zenSearchCollectState.newValue || null; hit = true; }
    if ('zenTgSweepFolders' in ch) { ZexAgentBg.folders = Array.isArray(ch.zenTgSweepFolders.newValue) ? ch.zenTgSweepFolders.newValue : []; hit = true; }
    if ('zenSearchCollectPref' in ch) { ZexAgentBg.colPref = ch.zenSearchCollectPref.newValue || {}; hit = true; }
    if ('zexErrLog' in ch) { ZexAgentBg.errs = Array.isArray(ch.zexErrLog.newValue) ? ch.zexErrLog.newValue : []; hit = true; }
    if ('zexSafetyStop' in ch) { ZexAgentBg.safety = ch.zexSafetyStop.newValue || null; hit = true; }
    if (hit) { try { zenAgentEmit(); } catch (e) {} }
  });
} catch (e) {}
function zexJobLive(j) { return !!j && (j.status === 'navigating' || j.status === 'working' || j.status === 'idle'); }

function zenOpenAgentDashboard() {
  const panel = document.createElement('div');
  panel.className = 'zen-agent-dash';
  panel.style.cssText = `
    position:fixed;top:120px;right:12px;width:min(268px,calc(100vw - 24px));max-height:calc(100vh - 150px);display:flex;flex-direction:column;
    background:#17181a;border:1px solid rgba(234,179,8,0.3);border-radius:12px;
    z-index:2147483001;overflow:hidden;
    box-shadow:0 10px 34px rgba(0,0,0,0.7),0 0 22px rgba(234,179,8,0.14);
    font-family:'ZexPixel','Courier New',monospace;color:#facc15;
  `;

  const header = document.createElement('div');
  header.className = 'zen-agent-dash-header';
  header.style.cssText = `
    display:flex;align-items:center;justify-content:space-between;
    padding:8px 10px;cursor:grab;background:rgba(234,179,8,0.08);
    border-bottom:1px solid rgba(234,179,8,0.2);
  `;
  header.innerHTML = `<span style="font-size:12px;">AGENT STATUS</span><span id="zen-net-pill" style="margin-left:auto;margin-right:8px;display:inline-flex;align-items:center;gap:4px;font-size:9px;padding:1px 6px;border:1px solid rgba(234,179,8,0.3);border-radius:10px;"><span class="zen-net-dot" style="width:7px;height:7px;border-radius:50%;background:#22c55e;display:inline-block;"></span><span class="zen-net-txt">…</span></span>`;
  const closeBtn = document.createElement('span');
  closeBtn.textContent = '✕';
  closeBtn.style.cssText = 'cursor:pointer;font-size:12px;opacity:0.7;padding:0 2px;';
  closeBtn.addEventListener('click', zenCloseAgentDashboard);
  header.appendChild(closeBtn);
  panel.appendChild(header);

  const rain = document.createElement('canvas');
  rain.style.cssText = 'position:absolute;left:0;right:0;top:33px;bottom:0;width:100%;height:calc(100% - 33px);opacity:0.16;pointer-events:none;z-index:0;';
  panel.appendChild(rain);

  // Animated scene banner (same scenes as the popup background) — sits where the
  // SEA Start/Stop toggle used to be. SEA is still controlled from the popup.
  if (window.ZEX_PANEL_BG) ZEX_PANEL_BG.attach(panel, { height: 104 });

  const body = document.createElement('div');
  body.className = 'zen-agent-dash-body';
  body.style.cssText = 'position:relative;z-index:1;padding:10px;font-size:12px;line-height:1.6;overflow-y:auto;flex:1;min-height:0;';
  panel.appendChild(body);

  ZexShadow.mount(panel);
  zenAgentDashboardEl = panel;
  zenMakeDraggable(header, panel);

  // STOP / RESUME buttons (delegated, because the body is re-rendered every second).
  // Stop = engine OFF + its Auto mode OFF, written to the same storage keys the popup uses,
  // so the popup toggles update too. A reply already being written is allowed to finish.
  // Resume = engine back ON (+ the Auto mode it had when stopped). TAR / TG keep their place in the queue.
  const ENG_KEYS = {
    SEA: { eng: 'zenSearchEngineOn', auto: 'zenSearchAutoMode', cur: () => searchAutoModeOn },
    FED: { eng: 'zenFeedEngineOn',   auto: 'zenFeedAutoMode',   cur: () => feedAutoModeOn },
    REP: { eng: 'zenRepEngineOn',    auto: 'zenAutoRepMode',    cur: () => repAutoModeOn },
    GIV: { eng: 'zenGivEngineOn',    auto: 'zenGivAutoMode',    cur: () => givAutoModeOn },
  };
  const bgMsg = (m) => new Promise((res) => { try { chrome.runtime.sendMessage(m, (r) => { void chrome.runtime.lastError; res(r || null); }); } catch (e) { res(null); } });
  const resumeFail = (r) => {
    const why = r && r.reason;
    showToast(why === 'session' ? 'Login to Z EX first' : (why === 'already_running' ? 'Already running' : (why === 'queue_busy' || why === 'engage_busy') ? 'Another run is active  stop it first' : 'Nothing to resume'), 'warn');
  };
  // Folder <select> (Link Collect) must not be rebuilt while the picker is open → render() pauses until it closes.
  let selBusyTs = 0, errOpen = false;
  // Auto reset (times of day) — config lives in storage, the reset itself runs in background.js
  let arOpen = false, arDraft = '', arCfg = { on: false, times: [] };
  try { chrome.storage.local.get(['zenAgentAutoReset'], (d) => { if (d && d.zenAgentAutoReset) { arCfg = d.zenAgentAutoReset; render(); } }); } catch (e) {}
  try { chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.zenAgentAutoReset) { arCfg = ch.zenAgentAutoReset.newValue || { on: false, times: [] }; render(); } }); } catch (e) {}
  const arSave = (c) => { arCfg = c; try { chrome.storage.local.set({ zenAgentAutoReset: c }); } catch (e) {} };
  // Error list / panel scroll must survive the 1s re-render, and render() must not rebuild under an active touch-scroll.
  let errScroll = 0, bodyScroll = 0, touchBusyTs = 0;
  body.addEventListener('scroll', (ev) => {
    const t = ev.target;
    if (t && t.getAttribute && t.getAttribute('data-zen-errbox') != null) errScroll = t.scrollTop;
  }, true);
  const _touchHold = () => { touchBusyTs = Date.now(); };
  body.addEventListener('touchstart', _touchHold, { passive: true });
  body.addEventListener('touchmove', _touchHold, { passive: true });
  body.addEventListener('touchend', () => { touchBusyTs = Date.now() - 1200; }, { passive: true });   // ~0.8s grace for momentum scroll
  body.addEventListener('wheel', _touchHold, { passive: true });
  body.addEventListener('focusin', (ev) => { if (ev.target && (ev.target.tagName === 'SELECT' || ev.target.tagName === 'INPUT')) selBusyTs = Date.now(); });
  body.addEventListener('focusout', (ev) => { if (ev.target && (ev.target.tagName === 'SELECT' || ev.target.tagName === 'INPUT')) { selBusyTs = 0; setTimeout(render, 100); } });
  body.addEventListener('change', (ev) => {
    const t = ev.target;
    if (t && t.id === 'zen-ar-time') { arDraft = t.value || ''; return; }
    if (t && t.getAttribute && t.getAttribute('data-zen-folder') != null) {
      selBusyTs = 0;
      const pref = Object.assign({}, ZexAgentBg.colPref || {}, { target: t.value });
      ZexAgentBg.colPref = pref;
      try { chrome.storage.local.set({ zenSearchCollectPref: pref }); } catch (e) {}
      showToast(t.value === 'new' ? 'Link Collect → new folder' : 'Link Collect → folder selected', 'success');
      setTimeout(render, 100);
    }
  });
  body.addEventListener('click', async (ev) => {
    const t = ev.target && ev.target.closest && ev.target.closest('[data-zen-stop],[data-zen-go],[data-zen-auto],[data-zen-errs],[data-zen-errclear],[data-zen-safeok],[data-zen-ar]');
    if (!t) return;
    if (t.hasAttribute('data-zen-ar')) {
      ev.preventDefault(); ev.stopPropagation();
      const a = t.getAttribute('data-zen-ar');
      const times = Array.isArray(arCfg.times) ? arCfg.times.slice() : [];
      if (a === 'open') arOpen = !arOpen;
      else if (a === 'toggle') { if (!arCfg.on && !times.length) { showToast('Add a time first', 'warn'); } else arSave({ on: !arCfg.on, times }); }
      else if (a === 'add') {
        const inp = body.querySelector('#zen-ar-time');
        const v = inp && /^\d{1,2}:\d{2}$/.test(inp.value) ? inp.value.replace(/^(\d):/, '0$1:') : '';
        if (!v) showToast('Pick a time first', 'warn');
        else if (times.indexOf(v) >= 0) showToast(v + ' already added', 'warn');
        else if (times.length >= 6) showToast('Max 6 times', 'warn');
        else { times.push(v); times.sort(); arDraft = ''; arSave({ on: true, times }); showToast('Auto reset ON · ' + times.join(', '), 'success'); }
      }
      else if (a.indexOf('del:') === 0) { const v = a.slice(4); const nt = times.filter((x) => x !== v); arSave({ on: nt.length ? arCfg.on === true : false, times: nt }); }
      selBusyTs = 0; render(); return;
    }
    if (t.hasAttribute('data-zen-auto')) {
      ev.preventDefault(); ev.stopPropagation();
      const k = ENG_KEYS[t.getAttribute('data-zen-auto')];
      if (k) { const nv = !k.cur(); try { chrome.storage.local.set({ [k.auto]: nv }); } catch (e) {} showToast(t.getAttribute('data-zen-auto') + ' Auto Mode ' + (nv ? 'ON' : 'OFF'), 'success'); }
      setTimeout(render, 150); return;
    }
    if (t.hasAttribute('data-zen-errs')) { ev.preventDefault(); ev.stopPropagation(); errOpen = !errOpen; render(); return; }
    if (t.hasAttribute('data-zen-errclear')) { ev.preventDefault(); ev.stopPropagation(); try { chrome.storage.local.set({ zexErrLog: [] }); } catch (e) {} ZexAgentBg.errs = []; render(); return; }
    if (t.hasAttribute('data-zen-safeok')) { ev.preventDefault(); ev.stopPropagation(); try { chrome.storage.local.remove('zexSafetyStop'); } catch (e) {} ZexAgentBg.safety = null; render(); return; }
    ev.preventDefault(); ev.stopPropagation();
    const stopN = t.getAttribute('data-zen-stop'), goN = t.getAttribute('data-zen-go');
    try {
      if (stopN) {
        const n = stopN;
        if (n === 'TAR') await bgMsg({ type: 'tarStop' });
        else if (n === 'COL') await new Promise((r) => chrome.storage.local.set({ zenSearchCollectOn: false }, r));
        else if (n === 'TGE') await bgMsg({ type: 'zenTgStop' });
        else if (n === 'TGS') await bgMsg({ type: 'sessAutoPause', sessionPath: 'telegram_sweep' });
        else if (ENG_KEYS[n]) {
          const k = ENG_KEYS[n];
          const rec = Object.assign({}, ZexAgentBg.resume); rec[n] = { auto: !!k.cur(), ts: Date.now() };
          chrome.storage.local.set({ zenAgentResume: rec, [k.eng]: false, [k.auto]: false });
        }
        showToast((n === 'TGE' ? 'TG ENGAGE' : n === 'TGS' ? 'TG SWEEP' : n === 'COL' ? 'Link Collect' : n) + ' stopped', 'success');
      } else if (goN) {
        const n = goN;
        if (n === 'COL') {
          if (!isSearchUrl(location.href)) { showToast('Open an X search page first', 'warn'); }
          else {
            const d = await getStorage(['zenSearchEngineOn', 'zenSearchAutoMode', 'zenTgSweepFolders', 'zenSearchCollectPref']);
            if (d.zenSearchEngineOn === true && d.zenSearchAutoMode === true) { showToast('Turn SEA Auto Mode OFF first', 'warn'); }
            else {
              const pref = d.zenSearchCollectPref || {};
              let target = pref.target || 'new';
              if (target !== 'new' && !(Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders : []).some((f) => f.id === target)) target = 'new';
              const qp = zexQueryProjects(location.href), qk = qp.map((p) => p.name);
              const name = String(pref.name || '').trim() || (qk.length ? 'Search ' + qk.slice(0, 3).join(', ').slice(0, 40) : '');
              const cfg = { target, name, max: parseInt(pref.max, 10) || 0, tabId: await _getTabId(), qKws: qp, what: pref.what || 'links', wcMin: pref.wcMin, wcMax: pref.wcMax };
              await new Promise((r) => chrome.storage.local.set({ zenSearchCollectCfg: cfg, zenSearchCollectState: { phase: 'running', added: 0, dup: 0, skipped: 0, folderId: null, folderName: '' } }, r));
              await new Promise((r) => chrome.storage.local.set({ zenSearchCollectOn: true }, r));
              seaColMaybeStart();   // covers a stale ON flag (no change event)
              showToast('Link Collect started on this search', 'success');
            }
          }
        } else if (n === 'TAR') {
          const r = await bgMsg({ type: 'tarResume' });
          if (r && r.ok) showToast('TAR resumed', 'success'); else resumeFail(r);
        } else if (n === 'TGE') {
          const L = ZexAgentBg.tgLast;
          const r = L && L.link ? await bgMsg({ type: 'zenTgStart', link: L.link, endLink: L.endLink || null }) : null;
          if (r && r.ok) showToast('TG ENGAGE resumed', 'success'); else resumeFail(r);
        } else if (n === 'TGS') {
          await bgMsg({ type: 'zenLimitReset', kind: 'tgSweep' });
          const r = await bgMsg({ type: 'sessAutoResume', sessionPath: 'telegram_sweep' });
          if (r && r.ok) showToast('TG SWEEP resumed', 'success'); else resumeFail(r);
        } else if (ENG_KEYS[n]) {
          const k = ENG_KEYS[n];
          const rec = Object.assign({}, ZexAgentBg.resume); const prev = rec[n]; delete rec[n];
          await bgMsg({ type: 'zenLimitReset', kind: 'comment' });
          const upd = { zenAgentResume: rec, [k.eng]: true };
          if (prev && prev.auto) upd[k.auto] = true;
          chrome.storage.local.set(upd);
          showToast(n + (prev ? ' resumed' : ' started'), 'success');
        }
      }
    } catch (e) {}
    setTimeout(render, 150);
  });
  startProcRain({ isConnected: true, getBoundingClientRect: () => panel.getBoundingClientRect() }, rain);

  function render() {
    if (!panel.isConnected) return;
    if (document.hidden) return;   // nobody is looking — skip the rebuild
    if (selBusyTs && Date.now() - selBusyTs < 20000) return;   // folder picker open — don't rebuild under it
    if (touchBusyTs && Date.now() - touchBusyTs < 2000) return;   // finger/wheel scrolling — don't rebuild under it
    // ── OFFLINE: no internet → hide everything except the animation banner + a "NO INTERNET" line ──
    let _zenOff = false;
    try { _zenOff = !!(window.ZexNet && ZexNet.state && ZexNet.state.q === 'offline'); } catch (e) {}
    if (_zenOff) {
      const _pd = header.querySelector('.zen-net-dot'), _pt = header.querySelector('.zen-net-txt');
      if (_pd) _pd.style.background = '#6b7280';
      if (_pt) _pt.textContent = 'OFFLINE';
      if (!body.querySelector('[data-zen-offline]')) {
        body.innerHTML = '<div data-zen-offline="1" style="text-align:center;padding:14px 4px 10px;color:#facc15;font-size:12px;font-weight:800;letter-spacing:1px;">📡 NO INTERNET CONNECTION<div style="margin-top:4px;font-size:8px;font-weight:400;opacity:.6;letter-spacing:0;">Engines &amp; stuck-watch paused — waiting for the network…</div></div>';
        body.scrollTop = 0;
      }
      return;
    }
    const _prevErrBox = body.querySelector('[data-zen-errbox]');
    if (_prevErrBox) errScroll = _prevErrBox.scrollTop;
    bodyScroll = body.scrollTop;
    const S = ZenAgentStatus.stats || {};
    const esc = (t) => String(t == null ? '' : t).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
    const G = '#22c55e', R = '#ef4444', Y = '#facc15', D = '#6b7280';

    // ── engines ──
    const bg = ZexAgentBg;
    const tj = bg.tar;
    const tarLive = !!tarRunningFor || (!!tj && tj.status !== 'stopped' && tj.status !== 'done');
    const tarPaused = !!tj && tj.status === 'stopped' && (tj.currentIndex || 0) < ((tj.queue || []).length);
    const tarUser = tarRunningFor || (tj && tj.queue && tj.queue[tj.currentIndex || 0]) || '';
    const ta = bg.tgActive;
    const tgeLive = !!(ta && ta.running);
    const tgeLR = bg.tgLastRun, tgeLast = bg.tgLast;
    const tgeCan = !tgeLive && !!(tgeLR && tgeLR.reason === 'Stopped' && tgeLast && tgeLast.link);
    const sj = bg.jobs && bg.jobs['telegram_sweep'];
    const tgsLive = zexJobLive(sj);
    const tgsCan = !!(sj && sj.paused && (sj.currentIndex || 0) < ((sj.queue || []).length));
    const eng = [
      { n: 'SEA', on: searchEngineOn, auto: searchAutoModeOn, run: searchAutoRunning, go: true },
      { n: 'FED', on: feedEngineOn,   auto: feedAutoModeOn,   run: feedAutoRunning,   go: true },
      { n: 'REP', on: repModeActive,  auto: repAutoModeOn,    run: repAutoRunning,    go: true },
      { n: 'GIV', on: givEngineOn,    auto: givAutoModeOn,    run: givAutoRunning,    go: true },
      { n: 'COL', on: !!bg.colOn, auto: true, run: !!bg.colOn, go: true, label: 'LINK COLLECT', note: (bg.colOn && bg.colState) ? '  ' + (bg.colState.added || 0) + ' saved' : '' },
      { n: 'TAR', on: tarLive, auto: true, run: tarLive, can: tarPaused, label: 'TAR' + (tarUser ? ' @' + esc(tarUser) : ''), note: tarPaused ? 'PAUSED ' + (tj.currentIndex || 0) + '/' + (tj.queue || []).length : '' },
      { n: 'TGE', on: tgeLive, auto: true, run: tgeLive, can: tgeCan, label: 'TG ENGAGE', note: tgeLive ? '  ' + ((ta.doneCount) || 0) + ' done' : (tgeCan ? 'STOPPED' : '') },
      { n: 'TGS', on: tgsLive, auto: true, run: tgsLive, can: tgsCan, label: 'TG SWEEP', note: tgsLive ? '  ' + (sj.currentIndex || 0) + '/' + ((sj.queue || []).length) : (tgsCan ? 'PAUSED ' + (sj.currentIndex || 0) + '/' + ((sj.queue || []).length) : '') },
    ];
    const sec = 'margin-top:6px;padding-top:6px;border-top:1px solid rgba(234,179,8,0.15);';
    const lab = 'color:rgba(250,204,21,0.55);font-size:8px;';
    const engHtml = eng.map((e) => {
      const col = e.on ? G : D;
      const mode = !e.on ? (e.note || 'OFF') : (e.auto ? (e.n === 'COL' ? 'COLLECTING' : 'AUTO') : 'MANUAL');
      const st = e.on && e.auto && e.run ? ((e.note && e.n !== 'TAR') ? e.note : (e.n === 'COL' ? '' : '  RUNNING')) : '';
      // STOP while the engine is ON; START / RESUME while it is OFF (TAR / TG only when there is a paused run to continue).
      const btn = (attr, txt, c2) => `<span ${attr} style="display:inline-block;margin-left:8px;padding:1px 8px;border:1px solid ${c2};border-radius:4px;color:${c2};font-size:9px;font-weight:800;cursor:pointer;">${txt}</span>`;
      let ctl = '';
      if (e.on) ctl = btn(`data-zen-stop="${e.n}"`, 'STOP', R);
      else if (e.go) ctl = btn(`data-zen-go="${e.n}"`, (bg.resume && bg.resume[e.n]) ? 'RESUME' : 'START', G);
      else if (e.can) ctl = btn(`data-zen-go="${e.n}"`, 'RESUME', G);
      // AUTO MODE switch beside SEA / FED / REP / GIV (the engines that have an Auto Mode); TG / TAR / COL have none.
      const kk = ENG_KEYS[e.n];
      const autoPill = kk ? `<span data-zen-auto="${e.n}" style="display:inline-block;margin-left:6px;padding:1px 6px;border:1px solid ${e.auto ? G : D};border-radius:4px;color:${e.auto ? G : D};font-size:9px;font-weight:800;cursor:pointer;">AUTO ${e.auto ? 'ON' : 'OFF'}</span>` : '';
      let folderRow = '';
      if (e.n === 'COL') {
        const fl = bg.folders || [], pf = bg.colPref || {};
        const cur = (pf.target && fl.some((f) => f.id === pf.target)) ? pf.target : 'new';
        const opts = `<option value="new"${cur === 'new' ? ' selected' : ''}>＋ New folder</option>` + fl.map((f) => `<option value="${esc(f.id)}"${cur === f.id ? ' selected' : ''}>${esc(f.name)} (${(f.links && f.links.length) || 0})</option>`).join('');
        folderRow = `<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin:2px 0 4px;"><span style="${lab}">FOLDER</span><select data-zen-folder="1"${e.on ? ' disabled' : ''} style="flex:1;min-width:0;max-width:170px;background:#0f1012;color:#facc15;border:1px solid rgba(234,179,8,0.35);border-radius:4px;font-size:10px;padding:2px 4px;font-family:inherit;">${opts}</select></div>`;
      }
      return `<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;row-gap:2px;">
        <span><span style="color:${col};">●</span> ${e.label || e.n}</span>
        <span><b style="color:${col};">${mode}${st}</b>${autoPill}${ctl}</span></div>${folderRow}`;
    }).join('');

    // ── settings ──
    const cdp = _zenCdpMode;
    const tm = ZenAgentStatus.typeMode || { on: false, style: 'style' };
    const typing = !tm.on ? 'OFF (instant paste)' : (tm.style === 'live' ? 'ON · LIVE (streamed)' : 'ON · STYLE (after generate)');

    // ── replies ──
    const total = (S.ok || 0) + (S.fail || 0);
    const rate = total ? Math.round(((S.ok || 0) / total) * 100) : 0;
    const by = S.by || {};
    const byHtml = Object.keys(by).length
      ? Object.keys(by).map((k) => `${k} <span style="color:${G};">${by[k].ok}✓</span> <span style="color:${R};">${by[k].fail}✗</span>`).join(' · ')
      : '—';
    const ago = (ts) => { if (!ts) return ''; const s = Math.floor((Date.now() - ts) / 1000); return s < 60 ? s + 's ago' : s < 3600 ? Math.floor(s / 60) + 'm ago' : Math.floor(s / 3600) + 'h ago'; };

    const model = ZenAgentStatus.currentModel || '—';
    const provider = ZenAgentStatus.currentProvider || '—';
    const uptime = zenAgentFormatUptime(ZenAgentStatus.startedAt);
    const state = zenAgentStateLabel(ZenAgentStatus.state);
    const stateColor = ZenAgentStatus.state === 'writing' ? '#3b82f6'
      : ZenAgentStatus.state === 'sending' ? '#a855f7'
      : ZenAgentStatus.state === 'waiting' ? '#eab308'
      : '#6b7280';
    const errs = Array.isArray(bg.errs) ? bg.errs : [];

    // ── network + watchdog (top of the panel) ──
    let netQ = 'good', netTxt = '—', netCol = G;
    try { if (window.ZexNet) { netQ = ZexNet.state.q; netTxt = ZexNet.summary(); netCol = ZexNet.color(); } } catch (e) {}
    const pillDot = header.querySelector('.zen-net-dot'), pillTxt = header.querySelector('.zen-net-txt');
    if (pillDot) pillDot.style.background = netCol;
    if (pillTxt) pillTxt.textContent = netQ === 'offline' ? 'OFFLINE' : (netQ.toUpperCase() + (window.ZexNet && ZexNet.state.ms ? ' ' + (ZexNet.state.ms >= 8000 ? '—' : ZexNet.state.ms + 'ms') : ''));
    const wdLimit = Math.round(zenStuckLimit() / 1000);
    const wdRow = netQ === 'offline'
      ? `<span style="color:${Y};">PAUSED (offline)</span>`
      : zenDelayActive()
        ? `<span style="color:${Y};">${esc(_zenDelayLabel || 'DELAY')} · ${Math.ceil(zenDelayLeftMs() / 1000)}s</span>`
        : `<span style="color:${G};">${wdLimit}s limit</span>`;
    const netHtml = `
      <div style="${lab}">NETWORK</div>
      <div style="display:flex;justify-content:space-between;gap:8px;"><span><span style="color:${netCol};">●</span> QUALITY</span><b style="color:${netCol};text-align:right;">${esc(netTxt)}</b></div>
      <div style="display:flex;justify-content:space-between;"><span>STUCK WATCH</span><b>${wdRow}</b></div>
      <div style="${sec}"></div>`;

    const safeHtml = bg.safety ? `<div style="margin-bottom:8px;padding:6px 8px;border:1px solid ${R};border-radius:6px;background:rgba(239,68,68,0.1);color:${R};font-size:9px;line-height:1.6;font-weight:800;">⚠ SYSTEM AUTO STOPPED FOR SAFETY REASONS<br><span style="color:${Y};font-weight:600;">${bg.safety.n || 3}× \"Something went wrong\" in this session — take some break buddy.</span><div data-zen-safeok="1" style="margin-top:3px;opacity:.7;text-decoration:underline;cursor:pointer;">OK</div></div>` : '';
    const _zHtml = safeHtml + netHtml + `
      <div style="${lab}">ENGINES</div>
      ${engHtml}
      <div style="${sec}${lab}">SETTINGS</div>
      <div style="display:flex;justify-content:space-between;"><span>CLICK (CDP)</span><b style="color:${cdp ? G : D};">${cdp ? 'ON' : 'OFF'}</b></div>
      ${window.ZexPlus ? ZexPlus.rows(G, D) : ''}
      <div style="display:flex;justify-content:space-between;gap:8px;"><span>TYPING</span><b style="color:${tm.on ? G : D};text-align:right;">${typing}</b></div>
      <div style="${sec}${lab}">REPLIES</div>
      <div style="display:flex;justify-content:space-between;"><span>TOTAL</span><b>${total}</b></div>
      <div style="display:flex;justify-content:space-between;"><span>SUCCESS</span><b style="color:${G};">${S.ok || 0}</b></div>
      <div style="display:flex;justify-content:space-between;"><span>FAILED</span><b style="color:${(S.fail || 0) ? R : D};">${S.fail || 0}</b></div>
      <div style="display:flex;justify-content:space-between;"><span>POSTED / DRAFTED</span><b>${S.posted || 0} / ${S.drafted || 0}</b></div>
      <div style="display:flex;justify-content:space-between;"><span>SUCCESS RATE</span><b>${total ? rate + '%' : '—'}</b></div>
      <div style="font-size:8px;opacity:0.85;line-height:1.6;margin-top:2px;">${byHtml}</div>
      ${S.lastError ? `<div style="margin-top:4px;font-size:8px;color:${R};line-height:1.6;">LAST ERROR (${ago(S.lastErrorTs)}): ${esc(S.lastError)}</div>` : ''}
      ${(S.lastError || errs.length) ? `<div data-zen-errs="1" style="margin-top:3px;display:inline-block;padding:1px 8px;border:1px solid ${R};border-radius:4px;color:${R};font-size:9px;font-weight:800;cursor:pointer;">${errOpen ? 'HIDE' : 'VIEW'} ALL ERRORS (${errs.length})</div>` : ''}
      ${errOpen ? `<div data-zen-errbox="1" style="margin-top:4px;max-height:150px;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;touch-action:pan-y;border:1px solid rgba(239,68,68,0.3);border-radius:6px;padding:4px 6px;font-size:8px;line-height:1.55;">${errs.length ? errs.map((x) => `<div style="padding:2px 0;border-bottom:1px solid rgba(239,68,68,0.12);"><span style="opacity:.6;">${ago(x.ts)}</span> <b style="color:${Y};">${esc(x.eng)}</b> <span style="color:${R};">${esc(x.msg)}</span></div>`).join('') + `<div data-zen-errclear="1" style="text-align:center;margin-top:4px;opacity:.6;cursor:pointer;text-decoration:underline;">CLEAR LIST</div>` : '<div style="opacity:.6;">No errors logged.</div>'}</div>` : ''}
      <div style="${sec}${lab}">API</div>
      <div style="display:flex;justify-content:space-between;"><span>PROVIDER</span><b>${esc(provider)}</b></div>
      <div style="display:flex;justify-content:space-between;gap:8px;"><span>MODEL</span><b style="word-break:break-all;text-align:right;">${esc(model)}</b></div>
      <div style="display:flex;justify-content:space-between;"><span>UPTIME</span><b>${uptime}</b></div>
      <div style="${sec}color:${stateColor};font-weight:800;">● ${state}</div>
      <div id="zen-agent-reset" style="margin-top:6px;text-align:center;font-size:8px;opacity:0.55;cursor:pointer;text-decoration:underline;">RESET COUNTERS</div>
      <div data-zen-ar="open" style="margin-top:4px;text-align:center;font-size:8px;cursor:pointer;color:${arCfg.on ? G : 'rgba(250,204,21,0.7)'};">⏰ AUTO RESET · ${arCfg.on && (arCfg.times || []).length ? esc((arCfg.times || []).join(', ')) : 'OFF'} ${arOpen ? '▴' : '▾'}</div>
      ${arOpen ? `<div style="margin-top:4px;padding:5px 6px;border:1px solid rgba(234,179,8,0.25);border-radius:6px;font-size:9px;">
        <div style="display:flex;justify-content:space-between;align-items:center;"><span>Reset daily at</span><span data-zen-ar="toggle" style="padding:1px 8px;border:1px solid ${arCfg.on ? G : 'rgba(250,204,21,0.4)'};border-radius:4px;color:${arCfg.on ? G : 'inherit'};font-weight:800;cursor:pointer;">${arCfg.on ? 'ON' : 'OFF'}</span></div>
        <div style="margin-top:4px;display:flex;flex-wrap:wrap;gap:4px;">${(arCfg.times || []).map((t) => `<span data-zen-ar="del:${esc(t)}" style="padding:1px 6px;border:1px solid rgba(234,179,8,0.4);border-radius:10px;cursor:pointer;">${esc(t)} ✕</span>`).join('') || '<span style="opacity:.6;">no time set</span>'}</div>
        <div style="margin-top:5px;display:flex;gap:5px;align-items:center;"><input id="zen-ar-time" type="time" value="${esc(arDraft)}" style="flex:1;min-width:0;background:#111;color:inherit;border:1px solid rgba(234,179,8,0.4);border-radius:4px;font-size:10px;padding:2px 4px;color-scheme:dark;"><span data-zen-ar="add" style="padding:2px 9px;border:1px solid ${G};border-radius:4px;color:${G};font-weight:800;cursor:pointer;">ADD</span></div>
        <div style="margin-top:3px;opacity:.5;font-size:8px;">Your device time · works with no X tab open</div>
      </div>` : ''}
    `;
    if (body.__zH === _zHtml && body.querySelector('#zen-agent-reset')) return;   // unchanged → leave the DOM alone
    body.__zH = _zHtml; body.innerHTML = _zHtml;
    const rs = body.querySelector('#zen-agent-reset');
    if (rs) rs.onclick = () => zenAgentResetStats();
    const _eb = body.querySelector('[data-zen-errbox]');
    if (_eb) _eb.scrollTop = errScroll; else errScroll = 0;
    if (bodyScroll) body.scrollTop = bodyScroll;
  }

  render();
  zenAgentDashboardTimer = setInterval(render, 1000);
  ZenAgentStatus.listeners.push(render);
}

function zenAgentAvatarInit() {
  zenInjectAgentAvatar();
  let avatarCheckQueued = false;   // at most one check per frame, not one per DOM mutation
  const observer = new MutationObserver(() => {
    if (avatarCheckQueued) return;
    avatarCheckQueued = true;
    requestAnimationFrame(() => {
      avatarCheckQueued = false;
      if (!ZexShadow.$('#zen-agent-avatar')) zenInjectAgentAvatar();
    });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
}
if (document.body) zenAgentAvatarInit();
else document.addEventListener('DOMContentLoaded', zenAgentAvatarInit);

// ── Recovery watchdog ──────────────────────────────────────────
// On some mobile browsers (Kiwi included), a backgrounded/throttled tab
// can briefly lose its extension context (chrome.runtime.id becomes
// unavailable) even though nothing actually turned the engine off in
// storage. extContextAlive() going false makes searchScanPosts() tear
// down searchModeActive + the scan timer as a safety measure — but
// nothing was ever polling to notice the context coming back, so the
// engine looked "stuck off" on the page even while the popup still
// showed it ON. This just re-checks periodically and self-heals.
let _extDeadStreak = 0;
setInterval(() => {
  if (!extContextAlive()) {
    _extDeadStreak++;
    // ~30s of continuous dead context: this is a real invalidation
    // (extension reloaded/updated), not a brief mobile-browser throttle.
    // A JS-side watchdog can't recover from this — only a tab reload can.
    if (_extDeadStreak === 10) {
      try {
        const t = document.createElement('div');
        t.textContent = 'Z EX lost connection — please reload this tab';
        t.style.cssText = 'position:fixed;bottom:140px;right:16px;z-index:2147483000;background:#dc2626;color:#fff;font:700 12px Poppins,sans-serif;padding:10px 14px;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,0.3);';
        ZexShadow.mount(t);
      } catch (e) {}
    }
    return;
  }
  _extDeadStreak = 0;
  if (searchEngineOn && !searchModeActive) searchTryActivate();
  if (feedEngineOn && !feedModeActive) feedTryActivate();
  if (!ZexShadow.$('#zen-agent-avatar')) zenInjectAgentAvatar();
}, 3000);

















// ══════════════════════════════════════════════════════════════
//  SESSION AUTO MODE — engage-loop worker (runs on the page background.js
//  navigates to). Detects a pending job targeted at this exact URL, opens
//  the main post's reply box, gets an AI reply via the same GET Reply
//  engine used everywhere else, waits for the Reply button to enable,
//  waits a random 2-3s, clicks Reply, then (if Like is on) likes the post
//  once the reply is confirmed sent. Reports completion back to
//  background.js via chrome.storage so it can advance to the next link.
// ══════════════════════════════════════════════════════════════

let sessAutoRunningFor = null; // targetUrl currently being processed, guards re-entry

function sessAutoUrlMatches(targetUrl) {
  try {
    const a = new URL(location.href);
    const b = new URL(targetUrl);
    if (a.pathname.replace(/\/+$/, '') === b.pathname.replace(/\/+$/, '')) return true;
    // X rewrites /i/status/ID → /i/web/status/ID or /user/status/ID after load → compare the post ID instead of the path.
    const ia = a.pathname.match(/\/status\/(\d+)/), ib = b.pathname.match(/\/status\/(\d+)/);
    return !!(ia && ib && ia[1] === ib[1]);
  } catch (e) { return location.href.indexOf(targetUrl) !== -1; }
}


// ─── Telegram / Sweep: "already commented before ZEX" ────────────
// If the verified account already has a reply under this post (made by hand, before
// the extension ever touched it), don't comment again: save the link as done, note it
// in History as COMMENTED BEFORE ZEX, and move on to the next post.
async function zenTgOwnHandle() {
  let h = detectOwnHandle();
  if (h) return h;
  try {
    const d = await getStorage(['zenDeviceSession']);
    const x = d.zenDeviceSession && d.zenDeviceSession.xHandle;
    if (x) h = String(x).replace(/^@/, '').trim().toLowerCase();
  } catch (e) {}
  return h || '';
}
function zenOwnReplyInThread(mainArticle, own) {
  if (!own) return false;
  const arts = document.querySelectorAll('article[data-testid="tweet"]');
  for (const a of arts) {
    if (a === mainArticle) continue;
    if (getArticleAuthorHandle(a) === own) return true;
  }
  return false;
}
// Replies render a moment after the post itself — poll briefly (best effort, visible replies only).
async function zenWaitOwnReply(mainArticle, own, maxMs) {
  const end = Date.now() + (maxMs || 2500);
  while (Date.now() < end) {
    if (zenOwnReplyInThread(mainArticle, own)) return true;
    await new Promise(r => setTimeout(r, 250));
  }
  return zenOwnReplyInThread(mainArticle, own);
}
function zenLogCommentedBefore(sid, link, author) {
  try {
    if (sid) { try { if (typeof ZexDB !== 'undefined') ZexDB.set(sid, 'b', 'TG'); } catch (e) {} markStatusIdReplied(sid, ''); }   // remembered as engaged → every engine skips it from now on
    if (!sid) return;
    chrome.storage.local.get(['zenSkipLog'], (d) => {
      const log = Array.isArray(d.zenSkipLog) ? d.zenSkipLog : [];
      if (log.some((x) => x && x.sid === sid && x.reason === 'commented_before')) return;
      log.unshift({ sid, link: link || ('https://x.com/i/status/' + sid), author: author || '', by: '', cur: 'TG',
        reason: 'commented_before', prevReply: '', ts: Date.now(), wc: zexWcFor(sid, author) == null ? undefined : zexWcFor(sid, author) });
      chrome.storage.local.set({ zenSkipLog: log.slice(0, 300) });
    });
  } catch (e) {}
}

function sessAutoFindMainArticle() {
  // On a status detail page, the primary post is the first article in the
  // DOM (replies below it are separate articles further down the thread).
  const articles = document.querySelectorAll('article[data-testid="tweet"]');
  return articles.length ? articles[0] : null;
}

async function sessAutoCheckPending() {
  let pending;
  try {
    pending = (await getStorage(['zSessAutoPending'])).zSessAutoPending;
  } catch (e) { return; }
  if (!pending || !pending.targetUrl) return;
  if (!sessAutoUrlMatches(pending.targetUrl) && !(pending.latestUrl && sessAutoUrlMatches(pending.latestUrl))) return;
  if (sessAutoRunningFor === pending.targetUrl) return; // already working on this one
  if (Date.now() - (pending.issuedAt || 0) > 120000) return; // stale job, ignore

  sessAutoRunningFor = pending.targetUrl;
  await sessAutoRunEngageFlow(pending);
}

// ── Telegram Engage step timings (user-configurable, seconds) ─────────
// Stored in chrome.storage.local.zenTgTiming = { view:[min,max], like:[min,max], gen:[min,max], post:[min,max] }.
// Only applied to Telegram runs; every other session flow keeps its own timing.
const ZEN_TG_TIMING_DEFAULT = { view: [1, 2], like: [1, 2], gen: [1, 2], post: [1, 2] };
async function tgTimingLoad() {
  let t = {};
  try { t = (await getStorage(['zenTgTiming'])).zenTgTiming || {}; } catch (e) {}
  try {   // Timing page (Advanced) wins over the old Telegram boxes
    const r = (await getStorage(['zexTimingResolved'])).zexTimingResolved;
    if (r && r.ui === 'advanced' && r.tg) t = r.tg;
  } catch (e) {}
  const pick = (k) => {
    const d = ZEN_TG_TIMING_DEFAULT[k];
    let a = Array.isArray(t[k]) ? Number(t[k][0]) : d[0];
    let b = Array.isArray(t[k]) ? Number(t[k][1]) : d[1];
    if (!isFinite(a) || a < 0) a = d[0];
    if (!isFinite(b) || b < 0) b = d[1];
    if (b < a) { const x = a; a = b; b = x; }
    return [Math.min(a, 120), Math.min(b, 120)];
  };
  const rnd = (r) => Math.round((r[0] + Math.random() * (r[1] - r[0])) * 1000);
  return { view: () => rnd(pick('view')), like: () => rnd(pick('like')), gen: () => rnd(pick('gen')), post: () => rnd(pick('post')) };
}

// ── Flash / Sweep helpers ────────────────────────────────────────
// X error / dead-post screens (post deleted, account suspended, "Something went wrong", rate limit…).
function zexXPageErrorShowing() {
  try {
    if (document.querySelector('article[data-testid="tweet"]')) return false;   // a post is there → not an error page
    const roots = document.querySelectorAll('[data-testid="error-detail"], main [role="alert"], [data-testid="primaryColumn"]');
    for (const n of roots) {
      const t = (n.innerText || n.textContent || '').trim();
      if (t.length > 400) continue;
      if (/something went wrong|try reloading|this page doesn.?t exist|post is unavailable|this post was deleted|account suspended|rate limit exceeded|hmm\.\.\./i.test(t)) return true;
    }
  } catch (e) {}
  return false;
}
// Post deleted / account gone: X shows "Hmm...this page doesn't exist" (or "post was deleted" / "account suspended").
// This one is permanent, unlike "Something went wrong" or a rate limit, so it gets its own DELETED tag instead of FAILED.
function zexXPageDeleted() {
  try {
    if (document.querySelector('article[data-testid="tweet"]')) return false;
    const roots = document.querySelectorAll('[data-testid="error-detail"], main [role="alert"], [data-testid="primaryColumn"]');
    for (const n of roots) {
      const t = (n.innerText || n.textContent || '').trim();
      if (t.length > 400) continue;
      if (/this page doesn.?t exist|this post was deleted|post is unavailable|this post is from an account that no longer exists|account suspended/i.test(t)) return true;
    }
  } catch (e) {}
  return false;
}
// Flash only: instead of a fixed short wait, wait until the main post is really painted (text + like + reply),
// so speed stays max when the page is fast and nothing is missed when it is slow.
async function zexWaitMainPostReady(maxMs) {
  const end = Date.now() + (maxMs || 15000);
  let okSince = 0, seenSince = 0;
  while (Date.now() < end) {
    zenProgress();
    const a = sessAutoFindMainArticle();
    if (a && !seenSince) seenSince = Date.now();
    // text/media painted (or, for odd posts without either, the article has been there 1.5s) + reply + like buttons present
    const _content = a && (a.querySelector('[data-testid="tweetText"], [data-testid="tweetPhoto"], [data-testid="videoPlayer"]') || (seenSince && Date.now() - seenSince >= 1500));
    if (a && _content && a.querySelector('[data-testid="reply"]') && a.querySelector('[data-testid="like"], [data-testid="unlike"]')) {
      if (!okSince) okSince = Date.now();
      if (Date.now() - okSince >= 150) return a;   // stayed rendered for 150ms → hydration done
    } else {
      okSince = 0;
      if (zexXPageErrorShowing()) return null;
    }
    await new Promise(r => setTimeout(r, 60));
  }
  return sessAutoFindMainArticle();
}
// ─── "There's a new version of this post. See the latest post" ───────────────
// X shows this banner on the OLD version of an edited post. That version cannot be replied to, so the Reply click
// did nothing and the bot hung there. Now the bot taps "See the latest post", waits for the new version and
// engages that one instead (the result is also saved under the old link, so the Link Checker sees it as done).
function zexLatestPostLink() {
  try {
    const nodes = document.querySelectorAll('main a[href*="/status/"], main [role="link"], main a');
    for (const a of nodes) {
      const t = (a.textContent || '').trim();
      if (t.length < 40 && /^see the latest post\.?$/i.test(t)) return a;
    }
  } catch (e) {}
  return null;
}
// null = no banner · false = banner there but the hop failed · {url, article} = now on the latest version
async function zexSessLatestHop(pending) {
  let a = zexLatestPostLink();
  if (!a) { await new Promise(r => setTimeout(r, 500)); a = zexLatestPostLink(); }   // banner is drawn with the post; 0.5s is enough to be sure
  if (!a) return null;
  const oldId = repStatusIdSafe(location.href) || repStatusIdSafe(pending.targetUrl) || '';
  let href = a.getAttribute('href') || '';
  if (!href) { const inner = a.querySelector('a[href]'); if (inner) href = inner.getAttribute('href') || ''; }
  const hrefId = repStatusIdSafe(href) || '';
  if (hrefId && hrefId === oldId) return null;   // points at itself → nothing to hop to
  if (hrefId) {   // if X does a full page load instead of an in-app switch, the reloaded page still finds its job
    try { chrome.storage.local.set({ zSessAutoPending: Object.assign({}, pending, { latestUrl: new URL(href, location.origin).href }) }); } catch (e) {}
  }
  console.warn('[Z EX] Post has a newer version — opening the latest post.', oldId, '→', hrefId || '?');
  try { await ensureInViewport(a, { margin: 80, settle: 120 }); } catch (e) {}
  try { await realClick(a); } catch (e) { try { a.click(); } catch (e2) {} }
  const end = Date.now() + 12000;
  let urlSince = 0, okSince = 0;
  while (Date.now() < end) {
    zenProgress();
    const nid = repStatusIdSafe(location.href) || '';
    if (nid && nid !== oldId && (!hrefId || nid === hrefId)) {
      if (!urlSince) urlSince = Date.now();
      const art = sessAutoFindMainArticle();
      if (art && art.querySelector('[data-testid="reply"]') && (articleStatusId(art) === nid || Date.now() - urlSince > 3000)) {
        if (!okSince) okSince = Date.now();
        if (Date.now() - okSince >= 200) return { url: location.origin + location.pathname, article: art };
      } else okSince = 0;
    }
    await new Promise(r => setTimeout(r, 80));
  }
  return false;
}

const ZEX_SWEEP_LINK_MAX_MS = 75000;   // Telegram Sweep: one link may never take longer than this → fail it, go to the next link

async function sessAutoRunEngageFlow(pending) {
  window.__zexAutoFlag = true;   // Sweep / Telegram engage page: Z EX is in charge until this page unloads
  try { document.documentElement.setAttribute('data-zex-auto', '1'); } catch (e) {}
  const origUrl = pending.targetUrl;   // the link background.js is waiting on — results are always reported under this one
  let _aliasOld = '';                  // set when the post was edited and we engaged its latest version instead
  if (pending.latestUrl && !sessAutoUrlMatches(pending.targetUrl) && sessAutoUrlMatches(pending.latestUrl)) {
    _aliasOld = repStatusIdSafe(origUrl) || '';   // page was reloaded onto the latest version → carry on with that one
    pending = Object.assign({}, pending, { targetUrl: pending.latestUrl });
  }
  window.__zexSessPath = pending.sessionPath || '';   // workflow map: tells the comment logger this is a Telegram run
  const _isSweep = pending.sessionPath === 'telegram_sweep';
  let _reported = false, _linkTimer = null;
  const report = (ok, skipped, why) => {
    if (_reported) return;   // one result per link — a duplicate report used to be able to advance the queue twice
    _reported = true;
    if (_linkTimer) { clearTimeout(_linkTimer); _linkTimer = null; }
    try { if (!skipped && typeof pending.sessionPath === 'string' && pending.sessionPath.indexOf('telegram_') === 0) zenAgentRecord('TG', !!ok, !!ok, ok ? '' : 'Telegram link failed'); } catch (e) {}
    window.__zexSessPath = '';
    if (!ok && !skipped) {
      try { zenLogFail(repStatusIdSafe(origUrl), (typeof pending.sessionPath === 'string' && pending.sessionPath.indexOf('telegram_') === 0) ? 'TG' : 'SESS', origUrl, '', 'failed'); } catch (e) {}
    }
    // Edited post: the list link is the OLD version → copy the result onto its ID too (Link Checker / skip-lists).
    if (_aliasOld && (ok || skipped)) {
      try {
        const _nid = repStatusIdSafe(pending.targetUrl);
        const _e = (typeof ZexDB !== 'undefined' && _nid) ? ZexDB.get(_nid) : null;
        const _code = _e ? _e.code : ((ok && !skipped) ? 'd' : '');
        if (_code && typeof ZexDB !== 'undefined') ZexDB.set(_aliasOld, _code, 'TG');
      } catch (e) {}
    }
    try {
      chrome.storage.local.set({
        zSessAutoResult: { sessionPath: pending.sessionPath, targetUrl: origUrl, ok, skipped: !!skipped, why: (!ok && !skipped) ? String(why || 'Unknown error').slice(0, 80) : '', ts: Date.now() },
      });
    } catch (e) {}
    sessAutoRunningFor = null;
  };

  try {
    const isTg = typeof pending.sessionPath === 'string' && pending.sessionPath.indexOf('telegram_') === 0;
    const tgT = isTg ? await tgTimingLoad() : null;
    // Telegram Sweep safety net: if anything hangs or errors on a link, fail it and let the queue go to the next link.
    if (_isSweep) {
      _linkTimer = setTimeout(async () => {
        if (_reported) return;
        console.warn('[Z EX] Sweep: link took too long — skipping to the next link', pending.targetUrl);
        try { await zenStuckCloseComposer(); } catch (e) {}
        report(false, false, 'Took too long (75s)');
      }, ZEX_SWEEP_LINK_MAX_MS);
    }
    // Give the page a moment to finish its own initial render/hydration.
    // Flash: wait until the post is actually painted (fast when X is fast, safe when X is slow). Others: unchanged.
    let article;
    if (zexFlash()) {
      article = await zexWaitMainPostReady(15000);
    } else {
      await new Promise(r => setTimeout(r, zexFx(1500, 350)));
    }
    // Telegram runs: user-set wait after the post opens (default 1–2s).
    if (tgT) await new Promise(r => setTimeout(r, tgT.view()));

    if (!article || !document.body.contains(article)) article = sessAutoFindMainArticle();
    if (!article) {
      // No post on the page. Deleted / "page doesn't exist" → saved as DELETED (not failed) and the queue moves on at once.
      for (let _i = 0; _i < 15 && !article; _i++) {
        if (zexXPageDeleted()) {
          const _gid = repStatusIdSafe(origUrl) || repStatusIdSafe(pending.targetUrl) || '';
          try { if (_gid && typeof ZexDB !== 'undefined') ZexDB.set(_gid, 'x', 'TG'); } catch (e) {}
          console.warn('[Z EX] Post deleted / page does not exist — tagged DELETED.', _gid);
          report(true, true); return;
        }
        await new Promise(r => setTimeout(r, 200));
        article = sessAutoFindMainArticle();
      }
      if (!article) { report(false, false, 'Page did not load (X error / rate limit)'); return; }   // other error (something went wrong, rate limit…) → fail → next link
    }

    // Edited post ("There's a new version of this post — See the latest post") → open the latest version and engage that.
    for (let _h = 0; _h < 3; _h++) {
      const _hop = await zexSessLatestHop(pending);
      if (_hop === null) break;
      if (_hop === false) { report(false, false, 'Edited post: latest version did not open'); return; }   // could not get to the latest version → fail → next link (retry later from the Link Checker)
      if (!_aliasOld) _aliasOld = repStatusIdSafe(origUrl) || '';
      pending = Object.assign({}, pending, { targetUrl: _hop.url });
      article = _hop.article;
    }

    // Blacklisted account → skipped (shown in History + Link Checker as BLACKLIST), the queue moves on at once.
    if (zexBlockedArticle(article)) {
      zexLogBlocked(repStatusIdSafe(origUrl) || repStatusIdSafe(pending.targetUrl) || '', isTg ? 'TG' : 'SESS', origUrl, getArticleAuthorHandle(article) || '');
      report(true, true); return;
    }

    // Wallchain: save in-range commenters to the Follow list (Telegram Engage + Sweep option)
    if (isTg) await zexWcTgCollect(pending.sessionPath);

    // Telegram Engage / Sweep: a post any engine already engaged is skipped (and shown in History).
    if (isTg) {
      await zenWaitIdsReady(5000);   // list must be loaded before judging "already engaged"
      const _psid = repStatusIdSafe(pending.targetUrl);
      if (_psid && hasAlreadyReplied(_psid)) {
        zexBackfillDone(_psid);   // already commented (old lists) → saved as DONE, so it leaves the LEFT list
        zenLogSkip(_psid, 'TG', pending.targetUrl, '');
        report(true, true);
        return;
      }
      if (_psid && zenIsCommentOff(_psid)) { report(true, true); return; }
      if (zenReplyOffBannerPresent()) { zenHandleReplyOff(article, { link: pending.targetUrl, eng: 'TG' }); report(true, true); return; }
      // Already commented by hand before ZEX? → save as done, log to History, next post.
      try {
        const _own = await zenTgOwnHandle();
        if (_own && await zenWaitOwnReply(article, _own, 2500)) {
          zenLogCommentedBefore(_psid, pending.targetUrl, getArticleAuthorHandle(article) || '');
          report(true, true);
          return;
        }
      } catch (e) {}
    }

    // ── Like BEFORE opening reply box ───────────────────────────────
    // On mobile web, clicking the reply icon can navigate to x.com/compose/
    // which unmounts the article entirely — liking it afterwards silently
    // fails. Do it now while the article is still in the DOM.
    if (pending.likeOn && (typeof pending.likeDraw === 'boolean' ? pending.likeDraw : zexLikeRoll(article, pending.likePct, 'TG'))) {
      try {
        await ensureInViewport(article, { margin: 60, settle: 160 });
        const likeBtn = article.querySelector('[data-testid="like"]');
        const alreadyLiked = likeBtn && (likeBtn.getAttribute('data-testid') === 'unlike' ||
          likeBtn.querySelector('[data-testid="unlike"]') ||
          likeBtn.closest('[data-testid="unlike"]'));
        if (likeBtn && !alreadyLiked) await realClick(likeBtn);
        // Telegram runs: user-set wait after the like (default 1–2s); other flows keep 600ms.
        await new Promise(r => setTimeout(r, tgT ? tgT.like() : zexFx(600, 150)));
      } catch (e) {}
    }

    let editor = await repOpenReplyBox(article, { link: pending.targetUrl, eng: isTg ? 'TG' : 'SESS' });
    if (!editor) {
      // Comment off → logged to History by repOpenReplyBox; Telegram moves on without counting a failure.
      const _ro = window.__zenReplyOff;
      if (isTg && _ro && Date.now() - _ro.ts < 20000) { report(true, true); return; }
      report(false, false, 'Reply box did not open'); return;
    }

    const _got = await zenAcquireGetReply(article, editor, isTg ? 'TG' : 'SESS', 8000);
    if (!_got) { report(false, false, 'GET Reply button did not appear'); return; }   // retried twice + composer closed → this link counts as failed, next one starts
    const replyBtn = _got.replyBtn;
    editor = _got.editor;

    const cfg = await getStorage(['bigReplyConfig', 'bigReplyMode']);
    const bigOn = cfg.bigReplyMode === true;
    await handleGetReply(editor, replyBtn, bigOn);

    // Re-resolve editor in case compose page navigated and ref is stale
    const _resolveLive = () => {
      let le = editor;
      if (/\/compose\//.test(location.pathname)) {
        const w = document.querySelector('[data-testid="tweetTextarea_0"]');
        if (w) le = _zenResolveEditor(w);
      }
      return le;
    };
    let liveEditor = _resolveLive();

    // Flash: going fast can make the reply come back empty (AI rate-limit / editor not ready yet) → try once more before failing.
    if (isEditorEmpty(liveEditor) && zexFlash()) {
      await new Promise(r => setTimeout(r, 900));
      try { await handleGetReply(editor, replyBtn, bigOn); } catch (e) {}
      liveEditor = _resolveLive();
    }

    if (isEditorEmpty(liveEditor)) { report(false, false, 'AI reply was empty'); return; }

    // Telegram runs: wait after the reply is generated, before clicking Reply.
    const posted = await repAutoSubmit(liveEditor, tgT ? tgT.gen() : undefined);
    if (!posted) { report(false, false, 'Reply was not posted (Reply button / X blocked)'); return; }

    // Telegram runs: wait after clicking Reply before going back to Telegram.
    if (tgT) await new Promise(r => setTimeout(r, tgT.post()));

    report(true);

  } catch (e) {
    report(false, false, 'Script error: ' + String((e && e.message) || e).slice(0, 50));
  }
}

// Safety-net poll for pending jobs. The instant path is chrome.storage.onChanged (below);
// this only covers a job that was already waiting before the script loaded, so it can be slow
// and can sleep while the tab is hidden (it re-checks the moment the tab is visible again).
function zexSlowPoll(fn, ms) {
  setInterval(() => { if (!document.hidden) fn(); }, ms);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) fn(); });
}
// Poll for a pending job periodically (covers the case where the tab was
// already open/navigated before this script's listeners attach) and also
// react immediately when background.js writes a new pending job while
// this content script is already alive on the matching page.
zexSlowPoll(sessAutoCheckPending, 6000);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.zSessAutoPending) sessAutoCheckPending();
});
// Initial check shortly after script load, in case the job was already
// pending when this page/tab finished navigating.
setTimeout(sessAutoCheckPending, 1000);

// ══════════════════════════════════════════════════════════════
//  FOLLOW ENGINE — runs on the page background.js navigates to
//  (https://x.com/<username>). Finds that profile's Follow button and
//  clicks it, then reports success/failure back to background.js via
//  chrome.storage so it can advance the queue to the next username.
//  Remembers who it has already followed (zFollowJob.followed, kept by
//  background.js) so restarting the run never re-follows or re-visits
//  someone already done — it always resumes from the saved index.
// ══════════════════════════════════════════════════════════════

let followRunningFor = null; // username currently being processed, guards re-entry

function followUrlMatchesUsername(targetUrl, username) {
  try {
    const u = new URL(location.href);
    const path = u.pathname.replace(/^\/+|\/+$/g, '').toLowerCase();
    return path === String(username).toLowerCase();
  } catch (e) { return false; }
}

// Finds the primary profile Follow button. X marks it with a
// data-testid ending in "-follow" (e.g. "123456-follow") on the profile
// header; falls back to matching visible button text if that ever shifts.
function followFindButton() {
  const byTestId = document.querySelector('button[data-testid$="-follow"]');
  if (byTestId) return byTestId;

  const buttons = document.querySelectorAll('div[data-testid="placementTracking"] button, header + div button, main button');
  for (const b of buttons) {
    const txt = (b.textContent || '').trim().toLowerCase();
    if (txt === 'follow') return b;
  }
  return null;
}

// A profile shows "Following" (already followed), "Follow Back", or the
// account is protected/suspended/doesn't exist — all of these should be
// treated as "nothing to do here", not a failure, so they don't jam the
// stall guard or get retried.
function followAlreadyDoneOrUnavailable() {
  const buttons = document.querySelectorAll('button');
  for (const b of buttons) {
    const txt = (b.textContent || '').trim().toLowerCase();
    if (txt === 'following' || txt === 'unblock' || txt === 'unmute') return true;
  }
  if (/this account doesn.?t exist|account suspended/i.test(document.body.innerText || '')) return true;
  return false;
}

async function followCheckPending() {
  let pending;
  try {
    pending = (await getStorage(['zFollowPending'])).zFollowPending;
  } catch (e) { return; }
  if (!pending || !pending.username) return;
  if (!followUrlMatchesUsername(pending.targetUrl, pending.username)) return;
  if (followRunningFor === pending.username) return; // already working on this one
  if (Date.now() - (pending.issuedAt || 0) > 45000) return; // stale, background.js's stall guard will handle it

  followRunningFor = pending.username;
  await followRunFlow(pending);
}

async function followRunFlow(pending) {
  const report = (ok, already) => {
    try {
      chrome.storage.local.set({
        zFollowResult: { username: pending.username, ok, already: !!already, ts: Date.now() },
      });
    } catch (e) {}
    followRunningFor = null;
  };

  try {
    // Let the profile page finish its initial render before looking for the button.
    await new Promise(r => setTimeout(r, 1500 + Math.random() * 1000));

    if (followAlreadyDoneOrUnavailable()) { report(true, true); return; }

    const btn = await (async () => {
      for (let i = 0; i < 10; i++) {
        const b = followFindButton();
        if (b) return b;
        await new Promise(r => setTimeout(r, 400));
      }
      return null;
    })();

    if (!btn) { report(false); return; }
    if (followAlreadyDoneOrUnavailable()) { report(true, true); return; }

    btn.scrollIntoView({ block: 'center' });
    await new Promise(r => setTimeout(r, 200 + Math.random() * 300));
    await realClick(btn);

    // Confirm the click landed — button text should flip to "Following".
    let confirmed = false;
    for (let i = 0; i < 10; i++) {
      await new Promise(r => setTimeout(r, 300));
      const nowBtn = followFindButton();
      const txt = nowBtn ? (nowBtn.textContent || '').trim().toLowerCase() : '';
      if (txt === 'following' || followAlreadyDoneOrUnavailable()) { confirmed = true; break; }
    }

    report(confirmed);
  } catch (e) {
    report(false);
  }
}

zexSlowPoll(followCheckPending, 6000);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.zFollowPending) followCheckPending();
});
setTimeout(followCheckPending, 1000);

// ═══ ZEN CURSOR — Popup/Storage bridge ═══════════════════════════
// Reads zen_cursor_img from storage and applies custom image.
// popup.js can set chrome.storage.local { zen_cursor_img: 'URL' | '' }
(function initCursorBridge() {
  chrome.storage.local.get(['zen_cursor_size', 'zen_cursor_img', 'zen_cursor_skin'], (d) => {
    d = d || {};
    if (d.zen_cursor_size) ZenCursor.setSize(d.zen_cursor_size);
    if (d.zen_cursor_img) ZenCursor.setImage(d.zen_cursor_img);
    if (d.zen_cursor_skin) ZenCursor.setSkin(d.zen_cursor_skin);
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if ('zen_cursor_size' in changes) ZenCursor.setSize(changes.zen_cursor_size.newValue);
    if ('zen_cursor_img' in changes) ZenCursor.setImage(changes.zen_cursor_img.newValue || null);
    if ('zen_cursor_skin' in changes) ZenCursor.setSkin(changes.zen_cursor_skin.newValue || '');
  });
})();

// ══════════════════════════════════════════════════════════════
//  TAR ENGINE — Target Account List / Favourite (X) List
//  Runs on x.com profile pages: scans recent posts (latest first),
//  skips already-liked ones, engages (like/comment/both) the first
//  N fresh posts, then reports back to background.js so it can
//  advance the queue. Also scrapes X List member pages so a
//  Favourite List link can be turned into a username queue.
//
//  "TAR" button — same role as the FED/SEA button: it's what makes an
//  engine visibly identifiable on the post, and its behavior follows
//  the same Model 1 (quick direct AI) / Model 2 (opens the real reply
//  box, hands off to the GET Reply widget — Tone/Style/Project Name
//  etc all apply) split already used by the FED/SEA engines.
// ══════════════════════════════════════════════════════════════

function tarUrlMatchesUsername(username) {
  try {
    const u = new URL(location.href);
    const path = u.pathname.replace(/^\/+|\/+$/g, '');
    const seg = path.split('/')[0] || '';
    return seg.toLowerCase() === String(username || '').toLowerCase();
  } catch (e) { return false; }
}

function tarIsXListUrl() {
  try {
    const u = new URL(location.href);
    return /^\/i\/lists\/\d+/.test(u.pathname);
  } catch (e) { return false; }
}

// ── Favourite (X) List member scrape ────────────────────────────
// On an X List's page (x.com/i/lists/{id} or its /members tab), scroll
// the member cards into view and collect their @handles. Reports once
// via a runtime message so background.js can turn it into a TAR queue.
async function tarScrapeXListMembers() {
  if (!tarIsXListUrl()) return;

  // A List's own timeline page doesn't show members directly — jump to
  // the /members sub-page, which lists each member as a UserCell.
  if (!/\/members\/?$/.test(location.pathname)) {
    const membersUrl = location.pathname.replace(/\/?$/, '') + '/members';
    location.href = membersUrl;
    return; // this navigation reloads the content script fresh on /members
  }

  const collected = new Set();
  const MAX_SCROLLS = 30;
  const STALL_LIMIT = 3;
  let stall = 0;
  let lastCount = 0;

  await new Promise(r => setTimeout(r, 1200)); // let the member list start rendering

  for (let i = 0; i < MAX_SCROLLS; i++) {
    document.querySelectorAll('[data-testid="UserCell"] a[href^="/"]').forEach(a => {
      const href = a.getAttribute('href') || '';
      const m = href.match(/^\/([A-Za-z0-9_]{1,15})$/);
      if (m && !/^(i|home|explore|notifications|messages|settings)$/i.test(m[1])) collected.add(m[1]);
    });

    if (collected.size === lastCount) {
      stall++;
      if (stall >= STALL_LIMIT) break;
    } else {
      stall = 0;
      lastCount = collected.size;
    }

    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 900 + Math.random() * 400));
  }

  try {
    chrome.runtime.sendMessage({ type: 'zTarXListMembers', usernames: Array.from(collected) });
  } catch (e) {}
}

if (tarIsXListUrl()) {
  setTimeout(async () => {
    // "Engage with your list people" is ON → this list page is a timeline to engage on, not a member fetch.
    try { const d = await getStorage(['zexTarList']); if (d.zexTarList && d.zexTarList.on) return; } catch (e) {}
    tarScrapeXListMembers();
  }, 800);
}

// ── Per-account engage pass ──────────────────────────────────────
async function tarCheckPending() {
  let pending;
  try {
    pending = (await getStorage(['zTarPending'])).zTarPending;
  } catch (e) { return; }
  if (!pending || !pending.username) return;
  if (!tarUrlMatchesUsername(pending.username)) return;
  if (tarRunningFor === pending.username) return;
  if (Date.now() - (pending.issuedAt || 0) > 55000) return; // stale — background.js's stall guard handles it

  tarRunningFor = pending.username;
  await tarRunAccountFlow(pending);
}
let tarRunningFor = null;

function tarProfileUnavailable() {
  const t = (document.body.innerText || '');
  return /this account doesn.?t exist|account suspended|these posts are protected/i.test(t);
}

// Scrolls the profile's Posts timeline, collecting NOT-yet-liked articles
// (latest first, X's natural order) until `need` of them are found or the
// timeline runs dry.
async function tarCollectFreshPosts(need, skipReplied) {
  await zenWaitIdsReady(5000);   // the replied/History list must be loaded before posts are judged
  const found = [];
  const seen = new Set();
  const MAX_SCROLLS = 25;
  let stall = 0;

  for (let i = 0; i < MAX_SCROLLS && found.length < need; i++) {
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    let newThisPass = false;
    for (const a of articles) {
      const sid = articleStatusId(a);
      const key = sid || (a.querySelector('[data-testid="tweetText"]')?.innerText || Math.random().toString());
      if (seen.has(key)) continue;
      seen.add(key);
      newThisPass = true;

      if (isAdArticle(a)) continue; // skip promoted posts
      if (isOwnArticle(a)) continue; // shouldn't happen on a target's own profile, guard anyway
      if (!skipReplied && feedIsAlreadyLiked(a)) continue; // like-only run: "already engaged" = already liked; comment/both runs use History below
      if (zexBlockedArticle(a)) { zexLogBlocked(sid, 'TAR', zenArticleLink(a), getArticleAuthorHandle(a)); continue; }
      if (skipReplied && hasAlreadyReplied(sid)) { zenLogSkip(sid, 'TAR', zenArticleLink(a), getArticleAuthorHandle(a)); continue; } // any engine engaged it before
      const postTextEl = a.querySelector('[data-testid="tweetText"]');
      if (!postTextEl || !postTextEl.innerText.trim()) continue; // nothing to reply from if comment mode needs it

      found.push(a);
      if (found.length >= need) break;
    }

    if (found.length >= need) break;
    if (!newThisPass) { stall++; if (stall >= 3) break; } else { stall = 0; }

    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 900 + Math.random() * 500));
  }
  return found;
}

// Engages one article per the current engageMode, reusing the exact same
// AI-reply and reply-box machinery as the FED engine (Model 1 / Model 2).
async function tarEngageArticle(article, engageMode, replyModel, session, keys) {
  const wantLike = engageMode === 'like' || engageMode === 'both';
  const wantComment = engageMode === 'comment' || engageMode === 'both';

  if (wantLike && !feedIsAlreadyLiked(article)) {
    try { await realClick(article.querySelector('[data-testid="like"]')); } catch (e) {}
    if (wantComment && zexAdvComment()) await zenWaitAfterLike();
    else await new Promise(r => setTimeout(r, 250 + Math.random() * 250));
  }

  if (!wantComment) return true;

  const limitCheck = await checkAndIncrementReplyCount(session.email);
  if (!limitCheck.allowed) throw new Error(limitCheck.reason || 'Reply limit reached');
  trackActivity(session.email);

  if (replyModel === 'model2') {
    let editor = await repOpenReplyBox(article, { eng: 'TAR' });
    if (!editor) throw new Error(zenNoBoxMsg());
    const _got = await zenAcquireGetReply(article, editor, 'TAR');
    if (!_got) throw zenSkipErr('GET Reply did not appear — post skipped');
    const replyBtn = _got.replyBtn;
    editor = _got.editor;
    const cfg = await getStorage(['bigReplyConfig', 'bigReplyMode']);
    await zenEngineGetReply(editor, replyBtn, cfg.bigReplyMode === true);
    if (isEditorEmpty(editor)) throw new Error('No reply was drafted');
    await repAutoSubmit(editor);
  } else {
    const postTextEl = article.querySelector('[data-testid="tweetText"]');
    const postText = postTextEl ? postTextEl.innerText.trim() : '';
    let editor = null;
    if (await zenLiveEnabled()) { // Live: open the box first, then stream into it
      editor = await repOpenReplyBox(article, { eng: 'TAR' });
      if (!editor) throw new Error(zenNoBoxMsg());
    }
    const reply = await zenLiveGenerate(editor, () => feedGenerateReplyWithFallback(
      postText, keys.smartSwitch, article
    ));
    if (!editor) {
      editor = await repOpenReplyBox(article, { eng: 'TAR' });
      if (!editor) throw new Error(zenNoBoxMsg());
    }
    await insertReply(editor, reply);
    await repAutoSubmit(editor);
    zenBumpDashCounters('TAR'); // Model 1 has no post-watcher, so count it here (Model 2 is counted by saveReplyHistory)
  }

  const sid = articleStatusId(article);
  if (sid) markStatusIdReplied(sid, 'TAR');
  zenAgentRecord('TAR', true, true);
  chrome.storage.local.get(['zenTarEngagedCount'], (d) => {
    chrome.storage.local.set({ zenTarEngagedCount: (d.zenTarEngagedCount || 0) + 1 });
  });
  return true;
}

async function tarRunAccountFlow(pending) {
  const report = (ok, engagedCount) => {
    if (!ok) zenAgentRecord('TAR', false, false, 'Target account flow failed');
    try {
      chrome.storage.local.set({
        zTarResult: { username: pending.username, ok, engagedCount: engagedCount || 0, ts: Date.now() },
      });
    } catch (e) {}
    tarRunningFor = null;
  };

  try {
    await new Promise(r => setTimeout(r, 1500 + Math.random() * 1000)); // let the profile render

    if (tarProfileUnavailable()) { report(true, 0); return; } // nothing to do here, not a failure

    const { zenDeviceSession } = await getStorage(['zenDeviceSession']);
    if (!zenDeviceSession || Date.now() >= zenDeviceSession.expiresAt) {
      showToast('Session expired! Open Z EX and login again.', 'warn');
      report(false, 0);
      return;
    }

    const engageMode = pending.engageMode || 'like';
    const replyModel = pending.replyModel || 'model1';
    const need = pending.postsPerAccount || 2;

    let keys = {};
    if (engageMode !== 'like') {
      const syncResult = await syncAdminApiKey(zenDeviceSession.email);
      if (syncResult && syncResult.locked) { showToast('Contact Admin', 'error'); report(false, 0); return; }
      const storage = await getStorage(['smartSwitch']);
      keys = { smartSwitch: storage.smartSwitch !== false };
    }

    const candidates = await tarCollectFreshPosts(need, engageMode !== 'like');
    if (!candidates.length) { report(true, 0); return; } // fully liked already / no posts — skip, not an error

    let engaged = 0;
    for (const article of candidates.slice(0, need)) {
      try {
        await tarEngageArticle(article, engageMode, replyModel, zenDeviceSession, keys);
        engaged++;
        if (engageMode !== 'like' && zexAdvComment()) await repPaceWait();   // Timing page: same pacing as the comment engines
        else await new Promise(r => setTimeout(r, 1200 + Math.random() * 1500));
      } catch (e) {
        // one post failing doesn't fail the whole account — keep going with the rest
        continue;
      }
    }

    report(true, engaged);
  } catch (e) {
    report(false, 0);
  }
}

// ═══ TAR LIST ENGINE — "Engage with your list people" ═════════════
// The popup saves zexTarList = { url, on, auto }. On that list's timeline (x.com/i/lists/<id>) every post
// gets a TAR button; a click (or Auto Mode) engages it with the TAR engage settings
// (zenTarEngageMode like / comment / both + zenTarReplyModel). Auto Refresh works like Feed/Search:
// zenTarRefreshTime (min) / zenTarRefreshGoal (engaged posts).
let tarListOn = false, tarListAuto = false, tarListActive = false, tarListScanTimer = null, tarListAutoRunning = false;
const tarListDone = new WeakSet(), tarListBusy = new WeakSet(), tarListSkipped = new WeakSet();
function tarListIsListUrl(url) {
  try { const u = new URL(url || location.href); return /^\/i\/lists\/\d+\/?$/.test(u.pathname); } catch (e) { return false; }
}
chrome.storage.local.get(['zexTarList'], (d) => {
  const c = d.zexTarList || {};
  tarListOn = c.on === true; tarListAuto = c.auto === true;
  tarListTryActivate();
});
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local' || !ch.zexTarList) return;
  const c = ch.zexTarList.newValue || {};
  tarListOn = c.on === true; tarListAuto = c.auto === true;
  tarListTryActivate();
  if (tarListOn && tarListAuto) tarListAutoLoop();
});
function tarListTryActivate() {
  if (!tarListOn || !tarListIsListUrl()) {
    tarListActive = false;
    if (tarListScanTimer) { clearInterval(tarListScanTimer); tarListScanTimer = null; }
    return;
  }
  if (tarListActive) return;
  tarListActive = true;
  showToast('TAR list engine ON — TAR buttons will appear on this list', 'success');
  tarListScanTimer = setInterval(tarListScan, 1200);
  tarListScan();
}
setInterval(tarListTryActivate, 2000);   // X changes the URL without a reload

function tarListScan() {
  if (!tarListActive) return;
  if (!extContextAlive()) { tarListActive = false; clearInterval(tarListScanTimer); tarListScanTimer = null; return; }
  if (!tarListOn || !tarListIsListUrl()) { tarListTryActivate(); return; }
  document.querySelectorAll('article[data-testid="tweet"]').forEach((a) => tarListInjectButton(a));
  if (tarListAuto) tarListAutoLoop();
}

function tarListInjectButton(article) {
  if (isAdArticle(article)) return;
  if (tarListDone.has(article)) return;
  if (article.querySelector('.zen-tar-btn')) { tarListDone.add(article); return; }
  const actionBar = article.querySelector('[role="group"]');
  if (!actionBar) return;                       // not fully rendered yet — retry on next scan
  if (isOwnArticle(article)) { tarListDone.add(article); return; }
  if (!_zenIdsReady) return;   // replied/History list not loaded yet — retry on the next scan
  tarListDone.add(article);
  const sid = articleStatusId(article);
  if (zexBlockedArticle(article)) { zexLogBlocked(sid, 'TAR', zenArticleLink(article), getArticleAuthorHandle(article)); return; }
  if (hasAlreadyReplied(sid)) { zenLogSkip(sid, 'TAR', zenArticleLink(article), getArticleAuthorHandle(article)); return; }
  if (zenIsCommentOff(sid)) return;

  const btn = document.createElement('button');
  btn.className = 'zen-rep-btn zen-tar-btn';
  btn.type = 'button';
  btn.textContent = 'TAR';
  btn.title = 'Engage this post (TAR settings)';
  btn.addEventListener('click', async (e) => {
    e.preventDefault(); e.stopPropagation();
    await tarListHandle(article, btn);
  });
  actionBar.appendChild(btn);
}

// One post, with the TAR engage settings. Returns true when it landed.
async function tarListHandle(article, btn) {
  if (tarListBusy.has(article) || btn.disabled) return false;
  if (zenAlreadyGuard(article, 'TAR', btn)) return false;
  const { zenDeviceSession } = await getStorage(['zenDeviceSession']);
  if (!zenDeviceSession || Date.now() >= zenDeviceSession.expiresAt) { showToast('Session expired! Open Z EX and login again.', 'warn'); return false; }
  const st = await getStorage(['zenTarEngageMode', 'zenTarReplyModel', 'smartSwitch']);
  const engageMode = st.zenTarEngageMode || 'like', replyModel = st.zenTarReplyModel || 'model1';
  let keys = {};
  if (engageMode !== 'like') {
    const sync = await syncAdminApiKey(zenDeviceSession.email);
    if (sync && sync.locked) { showToast('Contact Admin', 'error'); return false; }
    keys = { smartSwitch: st.smartSwitch !== false };
  }
  tarListBusy.add(article);
  const original = btn.innerHTML;
  btn.innerHTML = '<span class="zen-spin"></span>'; btn.disabled = true;
  try {
    await tarEngageArticle(article, engageMode, replyModel, zenDeviceSession, keys);
    btn.classList.add('zen-rep-done'); btn.textContent = 'DONE';
    return true;
  } catch (err) {
    btn.innerHTML = original; btn.disabled = false;
    showToast('' + ((err && err.message) || 'TAR failed — skipping post'), 'error');
    try { zenLogFail(articleStatusId(article), 'TAR', zenArticleLink(article), getArticleAuthorHandle(article), 'failed'); } catch (e) {}
    return false;
  } finally { tarListBusy.delete(article); }
}

async function tarListAutoLoop() {
  zenMarkEngineActivity();
  if (tarListAutoRunning) return;
  tarListAutoRunning = true;
  const _ep = _zenLoopEpoch;
  let processed = 0, noTargetStreak = 0;
  try {
    while (_ep === _zenLoopEpoch && tarListAuto && tarListOn && tarListActive && !zenRefreshHold && processed < 500) {
      const target = Array.from(document.querySelectorAll('article[data-testid="tweet"]')).find((a) => {
        const b = a.querySelector('.zen-tar-btn');
        return b && !b.disabled && !tarListSkipped.has(a) && !tarListBusy.has(a);
      });
      if (!target) {
        noTargetStreak++;
        if (noTargetStreak > 8) { await repSleep(3000); break; }   // scan timer restarts the loop
        await zenWaitForVisible();
        const _ids0 = zexPostIds();
        await zenSmoothScroll(window.innerHeight * 1.0);
        const _wl = await zexWaitMorePosts(_ids0);
        if (_wl === 'reload' || _wl === 'hold') break;
        await repSleep(1500);
        continue;
      }
      noTargetStreak = 0;
      const btn = target.querySelector('.zen-tar-btn');
      await zenWaitForVisible();
      await ensureInViewport(target, { margin: 40, settle: 200 });
      if (ZenCursor.active && btn) await ZenCursor.moveTo(btn);
      const ok = await tarListHandle(target, btn);
      processed++;
      if (!ok) { tarListSkipped.add(target); await repSleep(1200); continue; }
      ZenCursor.setState('rest');
      await repPaceWait();
    }
  } finally { if (_ep === _zenLoopEpoch) tarListAutoRunning = false; }
}

zexSlowPoll(tarCheckPending, 6000);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.zTarPending) tarCheckPending();
});
setTimeout(tarCheckPending, 1000);

/* ══════════════════════════════════════════════════════════════
   AUTO REFRESH ENGINE
   Monitors Feed / Search / GIV reply counts against user-set
   Time and Goal limits. Whichever fires first triggers a page
   refresh (Feed & GIV → location.reload; Search → re-run same
   keyword search URL).
   ══════════════════════════════════════════════════════════════ */
(function () {
  // ── Helpers ──────────────────────────────────────────────────
  function _arGet(keys) {
    return new Promise(res => chrome.storage.local.get(keys, res));
  }

  // Build x.com search URL from stored keywords/filters (mirrors popup.js buildSehSearchUrl)
  function _buildSearchUrl(keywords, filters, resultType, raw) {
    /* exposed below as window.__zexBuildSearchUrl */
    if (raw) {
      let rurl = `https://x.com/search?q=${encodeURIComponent(raw)}&src=typed_query`;
      if (resultType === 'latest') rurl += '&f=live';
      return rurl;
    }
    if (!keywords || !keywords.length) return null;
    const kwExpr = keywords.length > 1
      ? '(' + keywords.map(k => (/\s/.test(k) ? `"${k}"` : k)).join(' OR ') + ')'
      : (/\s/.test(keywords[0]) ? `"${keywords[0]}"` : keywords[0]);
    const parts = [kwExpr];
    if (filters?.media)      parts.push('filter:media');
    if (filters?.replies)    parts.push('filter:replies');
    if (filters?.verified)   parts.push('filter:blue_verified');
    if (filters?.links)      parts.push('filter:links');
    if (filters?.retweets)   parts.push('filter:retweets');
    if (filters?.minReplies) parts.push(`min_replies:${filters.minReplies}`);
    if (filters?.minFaves)   parts.push(`min_faves:${filters.minFaves}`);
    if (filters?.lang)       parts.push(`lang:${filters.lang}`);
    if (filters?.withinTime) parts.push(`within_time:${filters.withinTime}`);
    const q = parts.join(' ');
    let url = `https://x.com/search?q=${encodeURIComponent(q)}&src=typed_query`;
    if (resultType === 'latest') url += '&f=live';
    return url;
  }

  // ── Per-engine refresh state ──────────────────────────────────
  const _arState = {
    feed:   { startTime: null, startCount: null, timer: null },
    search: { startTime: null, startCount: null, timer: null },
    giv:    { startTime: null, startCount: null, timer: null },
    tar:    { startTime: null, startCount: null, timer: null },
  };

  // Count keys per engine (same keys popup reads for session stats)
  const _arCountKey = { feed: 'zenFedCount', search: 'zenSeaCount', giv: 'zenGivCount', tar: 'zenTarEngagedCount' };

  // No auto loop is mid-post (Comment / Feed / Search / GIV / Session engage).
  window.__zexBuildSearchUrl = _buildSearchUrl;
  function _arIdle() {
    return !(repAutoRunning || feedAutoRunning || searchAutoRunning || givAutoRunning || tarListAutoRunning || sessAutoRunningFor);
  }

  // Refresh finished (or was abandoned): let the engines work again.
  function _arRelease(showDone) {
    zenRefreshHold = false;
    try { sessionStorage.removeItem('zenArResume'); } catch (e) {}
    if (showDone) showToast('Auto Refresh complete — engine resumed', 'success');
    if (showDone) { try { if (typeof zexT === 'function') zexT('resume', {}); } catch (e) {} }
    try {
      if (repAutoModeOn)    repAutoLoop();
      if (feedAutoModeOn)   feedAutoLoop();
      if (searchAutoModeOn) searchAutoLoop();
      if (givAutoModeOn)    givAutoLoop();
      if (tarListAuto && tarListOn) tarListAutoLoop();
    } catch (e) {}
  }

  // Page just came back from an Auto Refresh: keep the engine on hold until
  // the timeline has actually rendered, then resume.
  if (zenRefreshHold && !window.__zexEs1Busy) {
    (async () => {
      const t0 = Date.now();
      while (Date.now() - t0 < 20000) {
        if (document.querySelector('article[data-testid="tweet"] [data-testid="tweetText"]')) break;
        await new Promise(r => setTimeout(r, 500));
      }
      await new Promise(r => setTimeout(r, 1500)); // let X finish painting
      _arRelease(true);
    })();
  }

  async function _arTrigger(engine, why) {
    const st = _arState[engine];
    if (!st || st._triggered) return;
    st._triggered = true;
    try { if (typeof zexT === 'function') zexT('goal', { eng: engine === 'feed' ? 'FED' : engine === 'search' ? 'SEA' : engine === 'tar' ? 'TAR' : 'GIV', why: why || 'goal' }); } catch (e) {}
    if (st.timer) { clearInterval(st.timer); st.timer = null; }

    // 1) Alert the engines: stop taking new posts.
    zenRefreshHold = true;
    showToast(`Auto Refresh — ${engine.toUpperCase()} limit reached, engine paused`, 'info');

    // 2) Let the reply that is already in progress finish (max 2 min).
    const t0 = Date.now();
    while (!_arIdle() && Date.now() - t0 < 120000) {
      await new Promise(r => setTimeout(r, 500));
    }
    await new Promise(r => setTimeout(r, 1500)); // post-confirmation watcher settles

    // 3) Refresh. The flag tells the next page load to resume after it renders.
    showToast(`Auto Refresh — ${engine.toUpperCase()} refreshing…`, 'info');
    try { if (typeof zexT === 'function') zexT('refresh', { eng: engine === 'feed' ? 'FED' : engine === 'search' ? 'SEA' : engine === 'tar' ? 'TAR' : 'GIV' }); } catch (e) {}
    try { sessionStorage.setItem('zenArResume', String(Date.now())); } catch (e) {}
    // Safety: if the page somehow did not reload, do not stay paused forever.
    setTimeout(() => { if (zenRefreshHold) _arRelease(false); }, 30000);
    await new Promise(r => setTimeout(r, 800));

    if (engine === 'search') {
      const d = await _arGet(['zenSearchKeywords', 'zenSearchFilters', 'zenSearchResultType', 'zenSearchRawOn', 'zenSearchRawQuery']);
      const _raw = d.zenSearchRawOn === true && typeof d.zenSearchRawQuery === 'string' ? d.zenSearchRawQuery.replace(/\s+/g, ' ').trim() : '';
      const url = _buildSearchUrl(
        d.zenSearchKeywords || [],
        d.zenSearchFilters  || {},
        d.zenSearchResultType || 'top',
        _raw
      );
      if (url) { location.replace(url); return; }
    }
    // Feed & GIV → plain reload
    location.reload();
  }

  async function _arStartEngine(engine) {
    const st = _arState[engine];
    // clear previous
    if (st.timer) { clearInterval(st.timer); st.timer = null; }
    st._triggered = false;

    const tKey = `zen${engine.charAt(0).toUpperCase() + engine.slice(1)}RefreshTime`;
    const gKey = `zen${engine.charAt(0).toUpperCase() + engine.slice(1)}RefreshGoal`;
    const d = await _arGet([tKey, gKey, _arCountKey[engine]]);
    const timeLimitMin = d[tKey]  || 0;
    const goalLimit    = d[gKey]  || 0;

    if (!timeLimitMin && !goalLimit) return; // disabled

    st.startTime  = Date.now();
    st.startCount = d[_arCountKey[engine]] || 0;

    const CHECK_MS = 15_000; // check every 15s
    st.timer = setInterval(async () => {
      if (!extContextAlive()) { clearInterval(st.timer); st.timer = null; return; }

      const now = Date.now();

      // Time check
      if (timeLimitMin > 0 && (now - st.startTime) >= timeLimitMin * 60_000) {
        await _arTrigger(engine, 'time'); return;
      }

      // Goal check
      if (goalLimit > 0) {
        const cur = await _arGet([_arCountKey[engine]]);
        const count = cur[_arCountKey[engine]] || 0;
        if ((count - st.startCount) >= goalLimit) {
          await _arTrigger(engine, 'goal'); return;
        }
      }
    }, CHECK_MS);
  }

  // ── Activate when the relevant engine turns ON ─────────────────
  // Feed
  chrome.storage.local.get(['zenFeedEngineOn'], d => {
    if (d.zenFeedEngineOn) _arStartEngine('feed');
  });
  // Search
  chrome.storage.local.get(['zenSearchEngineOn'], d => {
    if (d.zenSearchEngineOn) _arStartEngine('search');
  });
  // GIV
  chrome.storage.local.get(['zenGivEngineOn'], d => {
    if (d.zenGivEngineOn) _arStartEngine('giv');
  });
  // TAR list ("Engage with your list people")
  chrome.storage.local.get(['zexTarList'], d => {
    if (d.zexTarList && d.zexTarList.on) _arStartEngine('tar');
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.zenFeedEngineOn) {
      if (changes.zenFeedEngineOn.newValue) _arStartEngine('feed');
      else { clearInterval(_arState.feed.timer); _arState.feed.timer = null; }
    }
    if (changes.zenSearchEngineOn) {
      if (changes.zenSearchEngineOn.newValue) _arStartEngine('search');
      else { clearInterval(_arState.search.timer); _arState.search.timer = null; }
    }
    if (changes.zexTarList) {
      const nv = changes.zexTarList.newValue || {};
      if (nv.on) _arStartEngine('tar');
      else { clearInterval(_arState.tar.timer); _arState.tar.timer = null; }
    }
    if (changes.zenTarRefreshTime || changes.zenTarRefreshGoal) {
      chrome.storage.local.get(['zexTarList'], d => { if (d.zexTarList && d.zexTarList.on) _arStartEngine('tar'); });
    }
    if (changes.zenGivEngineOn) {
      if (changes.zenGivEngineOn.newValue) _arStartEngine('giv');
      else { clearInterval(_arState.giv.timer); _arState.giv.timer = null; }
    }
    // Re-arm if refresh settings change while engine is ON
    if (changes.zenFeedRefreshTime || changes.zenFeedRefreshGoal) {
      chrome.storage.local.get(['zenFeedEngineOn'], d => { if (d.zenFeedEngineOn) _arStartEngine('feed'); });
    }
    if (changes.zenSearchRefreshTime || changes.zenSearchRefreshGoal) {
      chrome.storage.local.get(['zenSearchEngineOn'], d => { if (d.zenSearchEngineOn) _arStartEngine('search'); });
    }
    if (changes.zenGivRefreshTime || changes.zenGivRefreshGoal) {
      chrome.storage.local.get(['zenGivEngineOn'], d => { if (d.zenGivEngineOn) _arStartEngine('giv'); });
    }
  });
})();
