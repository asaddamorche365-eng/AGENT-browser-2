// ZEX workflow tracker — page side (x.com / twitter.com).
// Loaded before content.js. Exposes window.zexT(type, data) and records
// "open X" and every Like click (manual or auto) into the workflow map.
(function () {
  if (window.__zexTrackCS) return;
  window.__zexTrackCS = true;

  function alive() { try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; } }

  window.zexT = function (type, data) {
    try {
      if (!alive()) return;
      chrome.runtime.sendMessage({ type: 'zexTrack', evt: Object.assign({ type: type }, data || {}) }, function () { void chrome.runtime.lastError; });
    } catch (e) {}
  };

  // Open X — skipped when this load is just an Auto Refresh coming back (that logs "continue").
  try {
    var t = +sessionStorage.getItem('zenArResume') || 0;
    if (!(t && Date.now() - t < 120000)) window.zexT('open_x', {});
  } catch (e) { window.zexT('open_x', {}); }

  // Like clicks (real or scripted) on any post.
  var lastLike = { l: '', t: 0 };
  document.addEventListener('click', function (e) {
    try {
      var b = e.target && e.target.closest && e.target.closest('[data-testid="like"]');
      if (!b) return;
      var art = b.closest('article');
      var link = '', h = '';
      var a = art && art.querySelector('a[href*="/status/"]');
      if (a) {
        var m = (a.getAttribute('href') || '').match(/^\/([^/]+)\/status\/(\d+)/);
        if (m) { h = '@' + m[1]; link = 'https://x.com/' + m[1] + '/status/' + m[2]; }
      }
      var now = Date.now();
      if (link && link === lastLike.l && now - lastLike.t < 5000) return;
      lastLike = { l: link, t: now };
      var wc = null; try { if (window.zexWcScore) wc = window.zexWcScore(art) ; if (wc == null && window.zexWcScore && h) wc = window.zexWcScore(h); } catch (e2) {}
      window.zexT('like', { h: h, link: link, wc: wc });
    } catch (err) {}
  }, true);
})();
