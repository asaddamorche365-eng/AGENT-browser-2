/* Z EX — TAR "Engage with your list people" (popup card inside the TAR page).
   Saves chrome.storage.local.zexTarList = { url, on, auto } and zenTarRefreshTime / zenTarRefreshGoal.
   content.js shows TAR buttons on that X list's posts and (Auto Mode) engages them with the TAR Engage Settings. */
(function () {
  'use strict';
  var cfg = { url: '', on: false, auto: false };
  function el(h) { var d = document.createElement('div'); d.innerHTML = h; return d.firstElementChild; }
  function save(cb) { try { chrome.storage.local.set({ zexTarList: cfg }, cb); } catch (e) {} }
  function listUrl(v) {
    var m = String(v || '').trim().match(/(?:https?:\/\/)?(?:www\.)?(?:x|twitter)\.com\/i\/lists\/(\d+)/i);
    return m ? 'https://x.com/i/lists/' + m[1] : '';
  }

  function init() {
    var box = document.getElementById('tarSourceSection');
    if (!box || document.getElementById('zwTarList')) return;
    var lbl = box.previousElementSibling;
    var anchor = lbl && lbl.classList.contains('sec-label') ? lbl : box;
    var css = document.createElement('style');
    css.textContent = '#zwTarList{background:rgba(255,255,255,0.88);border:1px solid var(--border);padding:12px 14px;margin:0 0 12px}' +
      '#zwTarList .t{font-size:13px;font-weight:800;color:var(--text)}#zwTarList .s{font-size:11px;color:var(--dim);margin-top:2px;line-height:1.5}' +
      '#zwTarList .r{display:flex;align-items:center;gap:6px;margin-top:8px;flex-wrap:wrap}#zwTarList .r label{font-size:11px;color:var(--dim);flex:1 1 110px}' +
      '#zwTarList .n{flex:none;width:62px;text-align:center;padding:7px 2px;background:#f7f7f5;border:1px solid var(--border);color:#17181a;font-size:12px;font-weight:600;outline:none}' +
      '#zwTarList .b{padding:8px 12px;border:1px solid #17181a;background:var(--blue);color:#17181a;font-size:12px;font-weight:800;cursor:pointer}' +
      '#zwTarList .b2{padding:8px 12px;border:1px solid var(--border);background:var(--dark2);color:var(--text);font-size:12px;font-weight:700;cursor:pointer}';
    document.head.appendChild(css);
    var n = el('<div id="zwTarList"><div class="t">ENGAGE WITH YOUR LIST PEOPLE</div>' +
      '<div class="s">Paste your X list link and press Go. It opens that list and every post gets a TAR button. Uses the Engage Settings below (Like / Comment / Both). Turn this OFF before using Fetch Members.</div>' +
      '<div class="r"><input type="text" class="verify-input" id="zwTlUrl" placeholder="https://x.com/i/lists/1234567890123456789" autocomplete="off" style="flex:1;margin:0;"></div>' +
      '<div class="r"><button class="b" id="zwTlGo" type="button">Go</button><button class="b2" id="zwTlOff" type="button">Stop</button><span class="s" id="zwTlState" style="margin:0"></span></div>' +
      '<div class="r"><label>Auto Mode (engage posts one by one)</label><label class="toggle"><input type="checkbox" id="zwTlAuto"><span class="toggle-slider"></span></label></div>' +
      '<div class="r"><label>Auto Refresh · every</label><input type="number" class="n" id="zwTlRefT" min="0" placeholder="min"><span class="s" style="margin:0">min or after</span><input type="number" class="n" id="zwTlRefG" min="0" placeholder="posts"><span class="s" style="margin:0">posts (0 = off)</span></div>' +
      '<div class="r"><button class="b2" id="zwTlRefSave" type="button">Save Refresh</button><span class="s" id="zwTlMsg" style="margin:0"></span></div></div>');
    anchor.parentNode.insertBefore(n, anchor);

    var $ = function (id) { return document.getElementById(id); };
    function paint() {
      $('zwTlUrl').value = cfg.url || $('zwTlUrl').value;
      $('zwTlAuto').checked = !!cfg.auto;
      $('zwTlState').textContent = cfg.on ? 'ON — ' + (cfg.url || '') : 'OFF';
    }
    chrome.storage.local.get(['zexTarList', 'zenTarRefreshTime', 'zenTarRefreshGoal'], function (d) {
      if (d.zexTarList) cfg = Object.assign(cfg, d.zexTarList);
      if (d.zenTarRefreshTime) $('zwTlRefT').value = d.zenTarRefreshTime;
      if (d.zenTarRefreshGoal) $('zwTlRefG').value = d.zenTarRefreshGoal;
      paint();
    });
    $('zwTlGo').addEventListener('click', function () {
      var u = listUrl($('zwTlUrl').value);
      if (!u) { $('zwTlState').textContent = 'Paste a valid list link (x.com/i/lists/…)'; return; }
      cfg.url = u; cfg.on = true; cfg.auto = $('zwTlAuto').checked;
      save(function () {
        paint();
        try { chrome.tabs.create({ url: u, active: true }); } catch (e) { window.open(u, '_blank'); }
      });
    });
    $('zwTlOff').addEventListener('click', function () { cfg.on = false; save(paint); });
    $('zwTlAuto').addEventListener('change', function () { cfg.auto = $('zwTlAuto').checked; save(); });
    $('zwTlRefSave').addEventListener('click', function () {
      var t = parseInt($('zwTlRefT').value, 10) || 0, g = parseInt($('zwTlRefG').value, 10) || 0;
      chrome.storage.local.set({ zenTarRefreshTime: t > 0 ? t : 0, zenTarRefreshGoal: g > 0 ? g : 0 }, function () {
        $('zwTlMsg').textContent = (!t && !g) ? 'Auto Refresh disabled.' : 'Saved — ' + [t ? t + ' min' : '', g ? g + ' posts' : ''].filter(Boolean).join(' | ');
        setTimeout(function () { $('zwTlMsg').textContent = ''; }, 3000);
      });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
