/* Z EX — Link Checker (Telegram Sweep tab).
   Upload the same .txt (or load a saved folder) → every X post link in it is checked against what the extension knows:
     DONE         comment posted (link database zl_<id> = d)
     BEFORE ZEX   you had already commented by hand (b)
     COMMENT OFF  replies are restricted on that post (o)
     FAILED       the sweep opened it but no comment was saved (in zenTgSweepDone / History FAILED, not in the link database)
     LEFT         the sweep never touched it
   The list is shown in a scroll box and refreshes live while a sweep runs. Run left / Retry failed / Retry comment-off
   send the chosen links to the normal Telegram Sweep queue (message zenTgSweepSend). The loaded list is kept in
   chrome.storage.local.zexLinkCheck so it is still there when the popup is reopened. Nothing here changes the folders. */
(function () {
  'use strict';
  var KEY = 'zexLinkCheck', PAGE = 200;
  var S = { name: '', urls: [], rows: [], filter: 'all', shown: PAGE, q: '', sort: 'file', dups: 0 };
  var COL = { done: '#16a34a', failed: '#dc2626', off: '#d97706', before: '#2563eb', gone: '#7c3aed', own: '#0d9488', block: '#111827', left: '#8a8d93' };
  var LBL = { done: 'DONE', failed: 'FAILED', off: 'COMMENT OFF', before: 'BEFORE ZEX', gone: 'DELETED', own: 'OWN POST', block: 'BLACKLIST', left: 'LEFT' };
  var CHIPS = [['all', 'All'], ['left', 'Left'], ['failed', 'Failed'], ['gone', 'Deleted'], ['own', 'Own post'], ['block', 'Blacklist'], ['off', 'Comment off'], ['done', 'Done'], ['before', 'Before ZEX']];
  var REASONS = {
    session: 'Session expired — log in again.',
    queue_busy: 'Another queue is running — stop it first.',
    engage_busy: 'Group Engage is running — stop it first.',
    no_links: 'No links to run.',
  };
  var timer = null;
  function $(id) { return document.getElementById(id); }
  function idOf(u) { var m = String(u || '').match(/status\/(\d+)/); return m ? m[1] : ''; }

  // Every X post link in any text (one per line, "@handle: link", csv, json …). Query strings are dropped, duplicates removed.
  function parse(text) {
    var re = /https?:\/\/(?:www\.|mobile\.)?(?:x|twitter)\.com\/(?:i\/(?:web\/)?|[A-Za-z0-9_]+\/)status\/\d+/gi;
    var seen = {}, out = [], m;
    parse.dups = 0;
    while ((m = re.exec(String(text || '')))) {
      var id = idOf(m[0]);
      if (!id) continue;
      if (seen[id]) { parse.dups++; continue; }
      seen[id] = 1; out.push(m[0].replace(/^http:/i, 'https:'));
    }
    return out;
  }

  function compute(cb) {
    var ids = S.urls.map(idOf);
    var keys = ids.map(function (i) { return 'zl_' + i; }).concat(['zenTgSweepDone', 'zenSkipLog', 'zenRepliedStatusIds', 'zenReplyHistory', 'zenDeviceSession', 'zexFailWhy', 'zexBlackList']);
    chrome.storage.local.get(keys, function (d) {
      d = d || {};
      var touched = (d.zenTgSweepDone && typeof d.zenTgSweepDone === 'object') ? d.zenTgSweepDone : {};
      // Same sources the engines use to decide "already engaged": link DB + old replied-ID list + Reply History + History log.
      var replied = {};
      (Array.isArray(d.zenRepliedStatusIds) ? d.zenRepliedStatusIds : []).forEach(function (i) { replied[String(i)] = 1; });
      (Array.isArray(d.zenReplyHistory) ? d.zenReplyHistory : []).forEach(function (h) { var i = idOf(h && h.link); if (i) replied[i] = 1; });
      var bl = {}; (Array.isArray(d.zexBlackList) ? d.zexBlackList : []).forEach(function (h) { bl[String(h || '').replace(/^@/, '').toLowerCase()] = 1; });
      var logOff = {}, logBefore = {}, failedLog = {}, logBlk = {};
      (Array.isArray(d.zenSkipLog) ? d.zenSkipLog : []).forEach(function (x) {
        if (!x || !x.sid) return;
        if (x.reason === 'comment_off') logOff[x.sid] = 1;
        else if (x.reason === 'commented_before') logBefore[x.sid] = 1;
        else if (x.reason === 'failed') failedLog[x.sid] = 1;
        else if (x.reason === 'blacklist') logBlk[x.sid] = (x.author || '').toLowerCase() || 1;
      });
      var why = (d.zexFailWhy && typeof d.zexFailWhy === 'object') ? d.zexFailWhy : {};
      var own = '';
      try { var h = d.zenDeviceSession && d.zenDeviceSession.xHandle; if (h) own = String(h).replace(/^@/, '').trim().toLowerCase(); } catch (e) {}
      S.rows = S.urls.map(function (u, i) {
        var id = ids[i], e = d['zl_' + id], st = 'left';
        var um = String(u).match(/(?:x|twitter)\.com\/([A-Za-z0-9_]+)\/status\//i);
        var user = um ? um[1].toLowerCase() : '';
        if (Array.isArray(e)) st = e[0] === 'b' ? 'before' : e[0] === 'o' ? 'off' : e[0] === 'x' ? 'gone' : 'done';
        else if ((user && bl[user]) || (logBlk[id] && (logBlk[id] === 1 || bl[logBlk[id]]))) st = 'block';
        else if (logBefore[id]) st = 'before';
        else if (logOff[id] && !replied[id]) st = 'off';
        else if (replied[id]) st = 'done';
        else if (own && user === own) st = 'own';      // your own post — the sweep never comments on it
        else if (touched[id] || failedLog[id]) st = 'failed';
        return { u: u, id: id, st: st, user: user, i: i, why: st === 'failed' && why[id] ? why[id].why : '' };
      });
      if (cb) cb();
    });
  }

  function counts() {
    var c = { all: S.rows.length, left: 0, failed: 0, gone: 0, own: 0, block: 0, off: 0, done: 0, before: 0 };
    S.rows.forEach(function (r) { c[r.st]++; });
    return c;
  }
  function mk(tag, css, text) { var n = document.createElement(tag); if (css) n.style.cssText = css; if (text != null) n.textContent = text; return n; }

  function render() {
    var sum = $('zlcSummary'), chips = $('zlcChips'), box = $('zlcBox');
    if (!sum || !chips || !box) return;
    var c = counts();
    sum.className = 'verify-status';
    sum.textContent = S.urls.length ? (S.name + ' — ' + c.all + ' links · ' + c.done + ' done · ' + c.failed + ' failed · ' + c.gone + ' deleted · ' + c.own + ' own · ' + c.block + ' blacklist · ' + c.off + ' comment off · ' + c.before + ' before ZEX · ' + c.left + ' left') : '';
    chips.textContent = '';
    CHIPS.forEach(function (ch) {
      var b = mk('button', 'width:auto;margin:0;padding:5px 9px;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid var(--border);background:' + (S.filter === ch[0] ? 'var(--blue)' : 'transparent') + ';color:var(--text);', ch[1] + ' ' + c[ch[0]]);
      b.type = 'button';
      b.addEventListener('click', function () { S.filter = ch[0]; S.shown = PAGE; render(); });
      chips.appendChild(b);
    });
    box.textContent = '';
    var q = String(S.q || '').trim().toLowerCase().replace(/^@/, '');
    var list = S.rows.filter(function (r) {
      if (S.filter !== 'all' && r.st !== S.filter) return false;
      if (q && (r.u.toLowerCase().indexOf(q) < 0) && (!r.why || r.why.toLowerCase().indexOf(q) < 0)) return false;
      return true;
    });
    var ORD = { failed: 0, left: 1, off: 2, block: 3, gone: 4, own: 5, before: 6, done: 7 };
    if (S.sort === 'status') list.sort(function (a, b) { return (ORD[a.st] - ORD[b.st]) || (a.i - b.i); });
    else if (S.sort === 'handle') list.sort(function (a, b) { return (a.user || '~').localeCompare(b.user || '~') || (a.i - b.i); });
    else if (S.sort === 'new') list.sort(function (a, b) { return (a.id.length - b.id.length) || (a.id < b.id ? 1 : a.id > b.id ? -1 : 0); });
    else if (S.sort === 'old') list.sort(function (a, b) { return (a.id.length - b.id.length) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0); });
    if (!S.urls.length) box.appendChild(mk('div', 'color:var(--dim);padding:6px;', 'No file loaded yet. Tap “Check file” and pick your .txt.'));
    else if (!list.length) box.appendChild(mk('div', 'color:var(--dim);padding:6px;', 'Nothing in this filter.'));
    list.slice(0, S.shown).forEach(function (r) {
      var row = mk('div', 'display:flex;align-items:center;gap:6px;padding:5px 0;border-bottom:1px solid var(--border);min-width:0;');
      row.appendChild(mk('span', 'flex:none;width:84px;text-align:center;font-size:9px;font-weight:800;color:#fff;padding:3px 2px;background:' + COL[r.st] + ';', LBL[r.st]));
      var a = mk('a', 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text);text-decoration:none;', r.u.replace(/^https?:\/\/(?:www\.|mobile\.)?(?:x|twitter)\.com\//i, ''));
      a.href = r.u; a.target = '_blank'; a.rel = 'noopener'; a.title = r.u;
      if (r.why) {
        var col = mk('div', 'flex:1;min-width:0;display:flex;flex-direction:column;gap:1px;');
        a.style.flex = 'none';
        col.appendChild(a);
        col.appendChild(mk('span', 'font-size:9px;color:#dc2626;line-height:1.2;white-space:normal;', '↳ ' + r.why));
        row.appendChild(col);
      } else row.appendChild(a);
      box.appendChild(row);
    });
    if (list.length > S.shown) {
      var more = mk('button', 'width:100%;margin:6px 0 2px;padding:8px;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid var(--border);background:transparent;color:var(--text);', 'Show more (' + (list.length - S.shown) + ' more)');
      more.type = 'button';
      more.addEventListener('click', function () { S.shown += PAGE; render(); });
      box.appendChild(more);
    }
    var set = function (id, label, n) { var b = $(id); if (!b) return; b.textContent = label + ' (' + n + ')'; b.disabled = !n; b.style.opacity = n ? '1' : '0.45'; };
    set('zlcRunLeft', '▶ Run left', c.left);
    set('zlcRetryFail', '↻ Retry failed', c.failed);
    set('zlcRetryOff', '↻ Retry comment-off', c.off);
  }

  function setStatus(t, cls) { var s = $('zlcStatus'); if (s) { s.textContent = t; s.className = 'verify-status' + (cls ? ' ' + cls : ''); } }
  function send(rows, retry, label) {
    if (!rows.length) return;
    setStatus('Starting…');
    var msg = { type: 'zenTgSweepSend', links: rows.map(function (r) { return r.u; }), retryIds: retry ? rows.map(function (r) { return r.id; }) : [] };
    try {
      chrome.runtime.sendMessage(msg, function (res) {
        if (chrome.runtime.lastError) res = null;
        if (res && res.ok) setStatus('Started — ' + label + ' · ' + rows.length + ' links. This list updates live.', 'ok');
        else setStatus((res && REASONS[res.reason]) || 'Could not start. Try again.', 'err');
      });
    } catch (e) { setStatus('Could not start. Try again.', 'err'); }
  }

  function load(name, urls) {
    S.name = String(name || 'List').slice(0, 40); S.urls = urls || []; S.filter = 'all'; S.shown = PAGE; S.q = ''; try { var _q = $('zlcSearch'); if (_q) _q.value = ''; } catch (e) {}
    try { var o = {}; o[KEY] = { name: S.name, urls: S.urls, ts: Date.now() }; chrome.storage.local.set(o); } catch (e) {}
    compute(function () { render(); setStatus(S.dups ? S.dups + ' duplicate link' + (S.dups === 1 ? '' : 's') + ' merged (same post ID).' : ''); });
  }
  window.zexLinkCheckLoad = function (name, urls) { load(name, Array.isArray(urls) ? urls : []); var b = $('zlcBox'); if (b && b.scrollIntoView) b.scrollIntoView({ block: 'nearest' }); };

  function init() {
    if (!$('zlcBox')) return;
    $('zlcFile').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      if (!f) return;
      var rd = new FileReader();
      rd.onload = function (ev) {
        var urls = parse(ev.target.result); S.dups = parse.dups || 0;
        if (!urls.length) { setStatus('No X post links found in that file.', 'err'); return; }
        load(f.name.replace(/\.[a-z0-9]{1,5}$/i, ''), urls);
      };
      rd.onerror = function () { setStatus('Could not read that file.', 'err'); };
      rd.readAsText(f);
      e.target.value = '';   // same file can be picked again
    });
    var _qi = $('zlcSearch'), _so = $('zlcSort'), _ar = $('zlcAutoRetry');
    if (_qi) _qi.addEventListener('input', function () { S.q = _qi.value; S.shown = PAGE; render(); });
    if (_so) _so.addEventListener('change', function () { S.sort = _so.value; S.shown = PAGE; render(); });
    if (_ar) {
      try { chrome.storage.local.get(['zenSweepAutoRetry'], function (d) { var c = (d && d.zenSweepAutoRetry) || {}; _ar.checked = c.on !== false; }); } catch (e) {}
      _ar.addEventListener('change', function () { try { chrome.storage.local.set({ zenSweepAutoRetry: { on: _ar.checked, max: 2 } }); } catch (e) {} });
    }
    $('zlcRefresh').addEventListener('click', function () { compute(render); });
    $('zlcClear').addEventListener('click', function () {
      S.name = ''; S.urls = []; S.rows = []; try { chrome.storage.local.remove(KEY); } catch (e) {}
      render(); setStatus('');
    });
    $('zlcRunLeft').addEventListener('click', function () { send(S.rows.filter(function (r) { return r.st === 'left'; }), false, 'left links'); });
    $('zlcRetryFail').addEventListener('click', function () { send(S.rows.filter(function (r) { return r.st === 'failed'; }), true, 'retry failed'); });
    $('zlcRetryOff').addEventListener('click', function () { send(S.rows.filter(function (r) { return r.st === 'off'; }), true, 'retry comment-off'); });
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== 'local' || !S.urls.length) return;
      var hit = false;
      for (var k in ch) { if (k.indexOf('zl_') === 0 || k === 'zenTgSweepDone' || k === 'zenSkipLog' || k === 'zenRepliedStatusIds' || k === 'zenReplyHistory' || k === 'zexFailWhy' || k === 'zexBlackList') { hit = true; break; } }
      if (!hit) return;
      clearTimeout(timer); timer = setTimeout(function () { compute(render); }, 900);
    });
    chrome.storage.local.get([KEY], function (d) {
      var v = d && d[KEY];
      if (v && Array.isArray(v.urls) && v.urls.length) { S.name = v.name || 'List'; S.urls = v.urls; compute(render); } else render();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.__zexLinkCheckParse = parse;   // (test hook)
})();
