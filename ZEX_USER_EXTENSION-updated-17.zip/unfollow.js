// ═══════════════════════════════════════════════════════════════════
//  Z EX — Auto Unfollow (runs on https://x.com/<you>/following)
//
//  Started from the popup (Activity → Auto Unfollow). background.js opens the
//  verified account's Following page and stores:
//    zenUnfRun    — true while a run should be going
//    zenUnfCfg    — { handle, tabId, mode, limit, minSec, maxSec, breakEvery, breakSec }
//    zenUnfStats  — { running, unfollowed, skipped, failed, status, ts }
//  Modes: 'nonfollowers' → only unfollow accounts that don't follow you back
//         'all'          → unfollow everyone on the list
//  Every timing value is user-set in the popup (defaults 15–20s gap, a break
//  every 15 unfollows). The run stops by itself if X refuses unfollows.
// ═══════════════════════════════════════════════════════════════════
(function () {
  if (window.__zenUnfLoaded) return;
  window.__zenUnfLoaded = true;

  const HARD_LIMIT = 2000;
  const CONFIRM_WAIT_MS = 1800;
  const AFTER_CONFIRM_MS = 1000;
  const SCROLL_SETTLE_MS = 2500;
  const SCROLL_STALL_ROUNDS = 10;
  const MAX_CONSEC_FAIL = 3;
  const FONT = "'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif";
  const LIMIT_RE = /(daily limit|over the (daily )?limit|reached (the |your )?(daily )?limit|rate limit|limit (on|for) (following|unfollowing)|unable to (follow|unfollow)|too many (follows|requests)|temporarily (restricted|limited|locked)|(account|profile) (has been )?(locked|restricted|limited)|automated behavio|suspicious activity)/i;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rnd = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
  const get = keys => new Promise(res => {
    try { chrome.storage.local.get(keys, r => { void chrome.runtime.lastError; res(r || {}); }); } catch (e) { res({}); }
  });
  const set = obj => new Promise(res => {
    try { chrome.storage.local.set(obj, () => { void chrome.runtime.lastError; res(); }); } catch (e) { res(); }
  });
  const ask = msg => new Promise(res => {
    try { chrome.runtime.sendMessage(msg, r => { void chrome.runtime.lastError; res(r); }); } catch (e) { res(undefined); }
  });

  let running = false;
  let cfg = null;
  const stats = { unfollowed: 0, skipped: 0, failed: 0, status: '' };
  const processed = new Set();
  let widget = null;
  let wakeLock = null;

  const isRunFlag = async () => !!(await get('zenUnfRun')).zenUnfRun;
  const onFollowingPage = () => {
    const m = location.pathname.match(/^\/([^/]+)\/following\/?$/i);
    return !!m && !!cfg && m[1].toLowerCase() === cfg.handle;
  };

  // ── Stats + widget ──────────────────────────────────────────────
  function pushStats(over) {
    set({ zenUnfStats: Object.assign({ running, unfollowed: stats.unfollowed, skipped: stats.skipped, failed: stats.failed, status: stats.status, ts: Date.now() }, over || {}) });
  }
  function setStatus(text) {
    stats.status = text;
    if (widget) { const s = widget.querySelector('#zen-unf-status'); if (s) s.textContent = text; }
    pushStats();
  }
  function renderCounts() {
    if (!widget) return;
    widget.querySelector('#zen-unf-un').textContent = stats.unfollowed;
    widget.querySelector('#zen-unf-sk').textContent = stats.skipped;
    widget.querySelector('#zen-unf-fl').textContent = stats.failed;
    const t = cfg && cfg.limit ? cfg.limit : '∞';
    widget.querySelector('#zen-unf-target').textContent = stats.unfollowed + ' / ' + t;
    pushStats();
  }
  function ensureWidget() {
    if (widget || !document.body) return;
    widget = document.createElement('div');
    widget.id = 'zen-unf-widget';
    widget.style.cssText = `position:fixed;bottom:18px;right:18px;z-index:2147483000;width:250px;max-width:calc(100vw - 36px);box-sizing:border-box;padding:12px 14px 13px;border-radius:18px;color:#fdf6e3;font-family:${FONT};font-size:12px;background:linear-gradient(165deg,rgba(28,24,14,0.97),rgba(9,9,10,0.98));border:1px solid rgba(250,204,21,0.28);box-shadow:0 20px 48px rgba(0,0,0,0.62);`;
    widget.innerHTML = `
      <div style="font-size:8px;letter-spacing:2.2px;font-weight:700;color:rgba(250,204,21,0.75);">Z EX</div>
      <div style="font-size:12px;font-weight:700;color:#fff8e1;margin-bottom:9px;">Auto Unfollow</div>
      <div style="display:grid;grid-template-columns:1.3fr 1fr 1fr;text-align:center;border-radius:12px;background:rgba(255,255,255,0.04);border:1px solid rgba(250,204,21,0.14);padding:8px 0;margin-bottom:8px;">
        <div><b id="zen-unf-un" style="display:block;font-size:22px;color:#fde047;">0</b><span style="font-size:8px;letter-spacing:1.4px;color:rgba(253,246,227,0.5);">UNFOLLOWED</span></div>
        <div><b id="zen-unf-sk" style="display:block;font-size:18px;">0</b><span style="font-size:8px;letter-spacing:1.4px;color:rgba(253,246,227,0.5);">SKIPPED</span></div>
        <div><b id="zen-unf-fl" style="display:block;font-size:18px;color:#ff8a8a;">0</b><span style="font-size:8px;letter-spacing:1.4px;color:rgba(253,246,227,0.5);">FAILED</span></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:9px;letter-spacing:1.3px;color:rgba(253,246,227,0.5);margin-bottom:6px;"><span>TARGET</span><b id="zen-unf-target" style="color:#fde047;">0 / ∞</b></div>
      <div id="zen-unf-status" style="font-size:11px;line-height:1.4;color:rgba(253,246,227,0.8);min-height:16px;margin-bottom:9px;word-break:break-word;"></div>
      <button id="zen-unf-stop" type="button" style="width:100%;height:34px;border-radius:12px;cursor:pointer;font-family:${FONT};font-size:10.5px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#ffd9d9;background:linear-gradient(180deg,rgba(255,92,92,0.22),rgba(255,92,92,0.07));border:1px solid rgba(255,130,130,0.4);">Stop</button>`;
    ZexShadow.mount(widget);
    widget.querySelector('#zen-unf-stop').onclick = () => { ask({ type: 'unfStop' }); setStatus('Stopping…'); };
  }
  function removeWidgetLater(ms) { setTimeout(() => { if (widget) { widget.remove(); widget = null; } }, ms); }

  // ── Keep the screen awake while running ─────────────────────────
  async function holdAwake() {
    try {
      if (!('wakeLock' in navigator) || wakeLock) return;
      wakeLock = await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release', () => { wakeLock = null; if (running) setTimeout(holdAwake, 1000); });
    } catch (e) { wakeLock = null; }
  }
  async function releaseAwake() {
    try { if (wakeLock) await wakeLock.release(); } catch (e) {}
    wakeLock = null;
  }

  // ── Following list DOM ──────────────────────────────────────────
  const cells = () => document.querySelectorAll('[data-testid="UserCell"]');
  function cellUser(cell) {
    const a = cell.querySelector('a[href^="/"]');
    const href = a ? a.getAttribute('href') : '';
    const u = (href || '').replace('/', '');
    if (!u || u === 'i' || u.includes('/')) return null;
    return u;
  }
  const followingBtn = cell => Array.from(cell.querySelectorAll('[role="button"]')).find(b => (b.textContent || '').includes('Following')) || null;
  function readRows() {
    const rows = [];
    for (const c of cells()) {
      const username = cellUser(c);
      if (!username) continue;
      rows.push({ username, followsYou: (c.textContent || '').includes('Follows you'), following: !!followingBtn(c) });
    }
    return rows;
  }
  function findCell(username) {
    const u = username.toLowerCase();
    return Array.from(cells()).find(c => (cellUser(c) || '').toLowerCase() === u) || null;
  }
  function limitToast() {
    for (const el of document.querySelectorAll('[data-testid="toast"], [role="alert"], [aria-live="assertive"], [role="alertdialog"], [data-testid="sheetDialog"], [data-testid="confirmationSheetDialog"]')) {
      const t = (el.innerText || '').slice(0, 400);
      if (t && LIMIT_RE.test(t)) return t.trim().slice(0, 160);
    }
    return '';
  }

  // Clicks through content.js realClick() (visible cursor + CDP trusted click
  // when CDP mode is on, pointer-event sequence otherwise). Falls back to a
  // plain .click() only if content.js isn't loaded in this page.
  async function humanClick(el) {
    try {
      if (typeof realClick === 'function') { await realClick(el); return; }
    } catch (e) {}
    el.click();
  }

  // Clicks "Following" then confirms. → { ok, attempted, strong }
  async function unfollowUser(username) {
    const cell = findCell(username);
    if (!cell) return { ok: false, attempted: false };
    const btn = followingBtn(cell);
    if (!btn) return { ok: false, attempted: false };
    try { cell.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (e) {}
    await sleep(rnd(250, 650));
    await humanClick(btn);
    let confirm = null;
    for (let waited = 0; waited < CONFIRM_WAIT_MS && !confirm; waited += 150) {
      await sleep(150);
      confirm = document.querySelector('[data-testid="confirmationSheetConfirm"]');
    }
    if (!confirm) return { ok: false, attempted: true, strong: limitToast() };
    await sleep(rnd(300, 800));
    await humanClick(confirm);
    await sleep(rnd(AFTER_CONFIRM_MS, AFTER_CONFIRM_MS + 900));
    const after = findCell(username);
    if (after && followingBtn(after)) return { ok: false, attempted: true, strong: limitToast() };
    return { ok: true, attempted: true };
  }

  // Waits, but wakes early when the run is stopped. Returns false if stopped.
  async function pause(totalMs, label) {
    const end = Date.now() + totalMs;
    while (Date.now() < end) {
      if (!(await isRunFlag())) return false;
      if (label) setStatus(label + ' ' + Math.max(0, Math.ceil((end - Date.now()) / 1000)) + 's');
      await sleep(Math.min(1000, Math.max(50, end - Date.now())));
    }
    return true;
  }

  // ── Main loop ───────────────────────────────────────────────────
  async function runLoop() {
    const limit = Math.min(HARD_LIMIT, cfg.limit || HARD_LIMIT);
    const startUrl = location.href;
    const seen = new Set();
    let stall = 0;
    let consecFail = 0;
    let sinceBreak = 0;
    let reason = 'Done ✓';

    const collectSeen = () => { for (const c of cells()) { const u = cellUser(c); if (u) seen.add(u); } };

    // Unfollow By Score (Wallchain): accounts whose score is INSIDE the set range are kept; score outside the range, or no score at all → unfollowed
    const _wc = (await get('zexWc')).zexWc;
    const wcUnf = _wc && _wc.unf && _wc.unf.on ? _wc.unf : null;

    setStatus('Loading list…');
    await sleep(2500);

    while (await isRunFlag()) {
      if (!onFollowingPage()) {
        setStatus('Recovering…');
        location.href = startUrl;
        await sleep(6000);
        continue;
      }
      const rows = readRows().filter(r => !processed.has(r.username));

      if (!rows.length) {
        stall++;
        setStatus('Scrolling… (' + stall + '/' + SCROLL_STALL_ROUNDS + ')');
        collectSeen();
        const before = seen.size;
        window.scrollBy(0, window.innerHeight * 1.5);
        await sleep(SCROLL_SETTLE_MS);
        collectSeen();
        if (seen.size > before) { stall = 0; continue; }
        if (stall >= SCROLL_STALL_ROUNDS) {
          window.scrollTo(0, document.documentElement.scrollHeight);
          await sleep(SCROLL_SETTLE_MS * 2);
          const b2 = seen.size; collectSeen();
          if (seen.size > b2) { stall = 0; continue; }
          break;   // bottom of the list
        }
        continue;
      }
      stall = 0;

      let stop = false;
      for (const row of rows) {
        if (!onFollowingPage()) break;
        if (!(await isRunFlag())) { stop = true; reason = 'Stopped'; break; }
        processed.add(row.username);
        if (stats.unfollowed >= limit) { reason = 'Target reached · ' + limit; stop = true; break; }
        if (!row.following) continue;
        // never touch my own row, and keep mutuals unless "everyone" mode
        if (row.username.toLowerCase() === cfg.handle) continue;
        if (cfg.mode !== 'all' && row.followsYou) { stats.skipped++; renderCounts(); continue; }

        if (wcUnf) {
          setStatus('Reading score @' + row.username + '…');
          let sc = null;
          for (let t = 0; t < 18 && sc == null; t++) {
            const cell = findCell(row.username);
            sc = cell && window.zexWcCell ? window.zexWcCell(cell) : null;
            if (sc == null) await sleep(400);
          }
          // score inside the range → keep. Outside the range, or no score seen → fall through and unfollow.
          if (!window.zexWcIn || (sc != null && window.zexWcIn(sc, wcUnf))) { stats.skipped++; renderCounts(); continue; }   // helper missing = keep (safe)
        }

        setStatus('Unfollowing @' + row.username + '…');
        const r = await unfollowUser(row.username);
        if (r.ok) {
          stats.unfollowed++; consecFail = 0; sinceBreak++;
          renderCounts();
        } else if (r.attempted) {
          stats.failed++; consecFail++;
          renderCounts();
          if (r.strong) { reason = 'X limit: ' + r.strong; stop = true; break; }
          if (consecFail >= MAX_CONSEC_FAIL) { reason = 'X refused ' + MAX_CONSEC_FAIL + ' unfollows in a row — stopped. Try again later.'; stop = true; break; }
        } else {
          continue;   // row vanished from the DOM before we got to it
        }

        if (stats.unfollowed >= limit) { reason = 'Target reached · ' + limit; stop = true; break; }
        if (cfg.breakEvery > 0 && sinceBreak >= cfg.breakEvery) {
          sinceBreak = 0;
          if (!(await pause(cfg.breakSec * 1000, 'Break'))) { reason = 'Stopped'; stop = true; break; }
        } else if (!(await pause(rnd(cfg.minSec, cfg.maxSec) * 1000, 'Next in'))) {
          reason = 'Stopped'; stop = true; break;
        }
      }
      if (stop) break;
    }
    return reason;
  }

  async function start() {
    if (running) return;
    const d = await get(['zenUnfRun', 'zenUnfCfg']);
    if (!d.zenUnfRun || !d.zenUnfCfg) return;
    if (!/^\/[^/]+\/following\/?$/i.test(location.pathname)) return;
    const claim = await ask({ type: 'unfClaim' });
    if (!claim || !claim.ok) return;
    cfg = claim.cfg;
    if (!onFollowingPage()) return;

    running = true;
    try {
      const prev = (await get('zenUnfStats')).zenUnfStats;
      if (prev && prev.running !== undefined) { stats.unfollowed = prev.unfollowed || 0; stats.skipped = prev.skipped || 0; stats.failed = prev.failed || 0; }
    } catch (e) {}
    holdAwake();
    ensureWidget();
    renderCounts();
    let reason = 'Done ✓';
    try { reason = await runLoop(); }
    catch (e) { reason = 'Stopped: ' + (e && e.message ? e.message : 'error'); }
    running = false;
    await set({ zenUnfRun: false });
    stats.status = reason;
    if (widget) {
      const s = widget.querySelector('#zen-unf-status'); if (s) s.textContent = reason;
      const b = widget.querySelector('#zen-unf-stop'); if (b) { b.textContent = 'Close'; b.onclick = () => { widget.remove(); widget = null; }; }
    }
    pushStats({ running: false });
    releaseAwake();
  }

  setInterval(start, 2500);
  try { chrome.storage.onChanged.addListener(ch => { if (ch.zenUnfRun && ch.zenUnfRun.newValue) start(); }); } catch (e) {}
  setTimeout(start, 1200);
})();
