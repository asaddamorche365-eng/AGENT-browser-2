// Z EX — Post Studio tab (W1d): AI post from an X link or own idea + optional AI image + free image search.
// Every call goes through background.js ("zexpayCall") → Worker. Prices/switches/styles/warnings come from GET /v1/studio/config.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var ERR = {
    NO_CREDITS: 'Not enough credits. Buy credits or redeem a code in ZEXPAY.',
    NEEDS_FIRST_PAYMENT: 'Activate your account with the first payment first.',
    X_NOT_VERIFIED: 'Verify your X account first (Home tab).',
    API_LOCKED: 'Your AI access is locked. Contact admin.',
    NO_API_KEY: 'No AI is set up for your account yet. Contact admin.',
    EXPIRED: 'Your access expired. Contact admin.',
    NOT_APPROVED: 'Your account is not approved yet.',
    RATE_LIMIT: 'Too fast — wait a few seconds and try again.',
    DAILY_LIMIT: 'Daily limit reached. Try again tomorrow.',
    POST_OFF: 'Post Studio is switched off right now.',
    IMAGE_OFF: 'Image maker is switched off right now.',
    FREE_SEARCH_OFF: 'Image search is switched off right now.',
    PROJECT_REQUIRED: 'Enter the project name first.',
    BAD_POST_URL: 'That is not an X post link (x.com/user/status/…).',
    NO_SORSA_KEY: 'Cannot read posts automatically here — paste the post text below.',
    NOT_FOUND: 'Post not found — paste the post text below.',
    EMPTY_SOURCE: 'Add the other post’s text (or press READ).',
    EMPTY_TOPIC: 'Write your idea / topic first.',
    EMPTY_PROMPT: 'Write or generate an image prompt first.',
    AI_FAILED: 'The AI failed — your credits were refunded. Try again.',
    IMAGE_REFUSED: 'The AI refused this image prompt — credits refunded. Change the prompt and retry.',
    NETWORK: 'Network error — try again.',
    NO_AUTH: 'Please sign in again.'
  };
  var st = { cfg: null, mode: 'link', len: 'medium', style: '', tier: '', aspect: '', b64: '', mime: 'image/png',
    busy: {}, bound: false, confirm: false, loaded: false };

  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function call(path, body, method) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'zexpayCall', path: path, body: body, method: method }, function (res) {
          if (chrome.runtime.lastError || !res) return resolve({ ok: false, error: 'NETWORK' });
          resolve(res);
        });
      } catch (e) { resolve({ ok: false, error: 'NETWORK' }); }
    });
  }
  function errText(r) {
    var e = r && r.error;
    if (ERR[e]) return ERR[e];
    if (/^[A-Z]+_[45]\d\d$/.test(e || '') && e.indexOf('HTTP_') !== 0) return 'Post reader is busy — paste the post text below.';
    return 'Error: ' + (e || 'unknown');
  }
  function msg(id, text, cls) { var m = $(id); if (!m) return; m.textContent = text || ''; m.className = 'act-msg' + (cls ? ' ' + cls : ''); }
  function show(id, on, disp) { var e = $(id); if (e) e.style.display = on ? (disp || 'block') : 'none'; }
  function setBusy(key, btnId, on, label) {
    st.busy[key] = on; var b = $(btnId); if (!b) return;
    b.disabled = !!on;
    if (on) { b.dataset.old = b.textContent; b.textContent = label || '…'; } else if (b.dataset.old) { b.textContent = b.dataset.old; delete b.dataset.old; }
  }
  function warnBox(id, text) { var e = $(id); if (!e) return; e.textContent = text || ''; e.style.display = text ? 'block' : 'none'; }

  function chips(id, items, sel, onPick) {
    var g = $(id); if (!g) return; g.innerHTML = '';
    items.forEach(function (it) {
      var b = document.createElement('button'); b.type = 'button';
      b.className = 'act-chip' + (String(it.v) === String(sel) ? ' sel' : '');
      b.textContent = it.t; b.addEventListener('click', function () { onPick(it.v); });
      g.appendChild(b);
    });
  }
  function copyText(text, btn) {
    function done() { if (btn) { var o = btn.textContent; btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = o; }, 1200); } }
    function fb() { try { var t = document.createElement('textarea'); t.value = text; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t); done(); } catch (e) {} }
    try { navigator.clipboard.writeText(text).then(done, fb); } catch (e) { fb(); }
  }

  // ── credits refresh (same /v1/me the ZEXPAY tab uses) ──
  function refreshCredits(known) {
    if (typeof known === 'number' && window.ZP && ZP.refreshMe) { /* server told us the balance; still refresh the shared widgets */ }
    try { if (window.ZP && ZP.refreshMe) ZP.refreshMe(); } catch (e) {}
  }

  // ── config ──
  function loadConfig(force) {
    if (st.cfg && !force && st.loaded) return Promise.resolve(st.cfg);
    return call('/v1/studio/config', undefined, 'GET').then(function (r) {
      if (r.ok && r.data) { st.cfg = r.data; st.loaded = true; try { chrome.storage.local.set({ zexStudioCfg: r.data }); } catch (e) {} }
      render(); return st.cfg;
    });
  }
  function imgCost() {
    var c = st.cfg; if (!c) return 0;
    var t = (c.image_tiers || []).filter(function (x) { return x.id === st.tier; })[0]; if (!t) return 0;
    var a = (c.aspects || []).filter(function (x) { return x.id === st.aspect; })[0];
    return a && a.wide ? t.cost_wide : t.cost;
  }
  function render() {
    var c = st.cfg;
    warnBox('psBanner', c && c.warnings ? c.warnings.banner : '');
    chips('psMode', [{ v: 'link', t: 'From X link' }, { v: 'free', t: 'My own idea' }], st.mode, function (v) { st.mode = v; render(); });
    show('psLinkBox', st.mode === 'link'); show('psTopicBox', st.mode === 'free');
    var lens = (c && c.lengths) || ['short', 'medium', 'long'];
    chips('psLen', lens.map(function (l) { return { v: l, t: l.charAt(0).toUpperCase() + l.slice(1) }; }), st.len, function (v) { st.len = v; render(); });
    var gen = $('psGenBtn');
    if (gen && !st.busy.gen) gen.textContent = 'GENERATE POST' + (c ? ' · ' + fmt(c.cost_post) + ' credits' : '');
    if (c && c.post_enabled === false) { msg('psMsg', ERR.POST_OFF, 'warn'); if (gen) gen.disabled = true; }
    else if (gen && !st.busy.gen) gen.disabled = false;
    // image block
    var imgOn = !!(c && c.image_enabled !== false);
    var hasPost = $('psText') && $('psText').value.trim().length > 0;
    show('psResultCard', hasPost);
    show('psImgCard', hasPost && imgOn);
    show('psFreeCard', !!(c && c.free_search_enabled !== false));
    if (c) {
      var styles = c.styles || [];
      if (!styles.some(function (s) { return s.id === st.style; })) st.style = styles.length ? styles[0].id : '';
      chips('psStyles', styles.map(function (s) { return { v: s.id, t: s.label }; }), st.style, function (v) { st.style = v; render(); });
      var tiers = c.image_tiers || [];
      if (!tiers.some(function (t) { return t.id === st.tier; })) st.tier = tiers.length ? tiers[0].id : '';
      chips('psTiers', tiers.map(function (t) { return { v: t.id, t: t.label + ' · ' + fmt(t.cost) + (t.cost_wide !== t.cost ? '–' + fmt(t.cost_wide) : '') + ' cr' }; }), st.tier, function (v) { st.tier = v; st.confirm = false; render(); });
      var asp = c.aspects || [];
      if (!asp.some(function (a) { return a.id === st.aspect; })) st.aspect = asp.length ? asp[0].id : '';
      chips('psAspects', asp.map(function (a) { return { v: a.id, t: a.label }; }), st.aspect, function (v) { st.aspect = v; st.confirm = false; render(); });
      renderImgWarn();
      warnBox('psFreeWarn', c.warnings ? c.warnings.free : '');
    }
    var ib = $('psImgBtn');
    if (ib && !st.busy.img) ib.textContent = st.confirm ? 'CONFIRM · USE ' + fmt(imgCost()) + ' CREDITS' : 'MAKE IMAGE · ' + fmt(imgCost()) + ' credits';
    updateTone(); recent();
  }
  function renderImgWarn() {
    var c = st.cfg; if (!c) return;
    var line = 'This will use ' + fmt(imgCost()) + ' credits. AI images can contain mistakes or wrong details; no refund for results you do not like. Check before posting.';
    var extra = c.warnings && c.warnings.image ? '\n' + c.warnings.image : '';
    warnBox('psImgWarn', line + extra);
  }
  function updateTone() {
    try {
      chrome.storage.local.get(['defaultTone'], function (d) {
        var t = (d && d.defaultTone) || 'Smart';
        if ($('psToneHint')) $('psToneHint').textContent = 'Tone: ' + t + ' · change it in the Tone tab. Your trained style is used automatically.';
      });
    } catch (e) {}
  }

  // ── recent project names (local) ──
  function recent() {
    try {
      chrome.storage.local.get(['zexStudioRecent'], function (d) {
        var list = (d && d.zexStudioRecent) || [];
        chips('psRecent', list.map(function (x) { return { v: x.p, t: x.p }; }), $('psProject') ? $('psProject').value.trim() : '', function (v) {
          var it = list.filter(function (x) { return x.p === v; })[0];
          $('psProject').value = v; $('psHandle').value = it && it.h ? '@' + it.h : '';
          render();
        });
      });
    } catch (e) {}
  }
  function saveRecent(p, h) {
    try {
      chrome.storage.local.get(['zexStudioRecent'], function (d) {
        var list = ((d && d.zexStudioRecent) || []).filter(function (x) { return x.p !== p; });
        list.unshift({ p: p, h: h || '' });
        chrome.storage.local.set({ zexStudioRecent: list.slice(0, 6) });
      });
    } catch (e) {}
  }
  function project() {
    var p = $('psProject').value.trim(), h = $('psHandle').value.trim().replace(/^@/, '');
    return { project: p, handle: h };
  }

  // ── read a post for free through X's public oEmbed (no credits, no API key). null = not available → caller falls back ──
  function oembedRead(url) {
    var m = String(url).match(/(?:x|twitter)\.com\/([A-Za-z0-9_]{1,15})\/status(?:es)?\/(\d{5,25})/i);
    if (!m) return Promise.resolve(null);
    var link = 'https://x.com/' + m[1] + '/status/' + m[2];
    var ctl = new AbortController(), tm = setTimeout(function () { ctl.abort(); }, 12000);
    return fetch('https://publish.twitter.com/oembed?omit_script=1&dnt=1&url=' + encodeURIComponent(link), { signal: ctl.signal })
      .then(function (res) { clearTimeout(tm); return res.ok ? res.json() : null; })
      .then(function (j) {
        if (!j || !j.html) return null;
        var doc = new DOMParser().parseFromString(String(j.html), 'text/html');
        var p = doc.querySelector('blockquote p'); if (!p) return null;
        p.querySelectorAll('br').forEach(function (b) { b.replaceWith('\n'); });
        p.querySelectorAll('a').forEach(function (a) { if (/^pic\.(twitter|x)\.com/i.test((a.textContent || '').trim())) a.remove(); });
        var text = (p.textContent || '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, 1500);
        if (!text) return null;
        var ah = String(j.author_url || '').match(/(?:x|twitter)\.com\/([A-Za-z0-9_]{1,15})/i);
        return { text: text, author: { handle: ah ? ah[1] : m[1], name: String(j.author_name || '').slice(0, 60) }, project_hint: '' };
      })
      .catch(function () { clearTimeout(tm); return null; });
  }

  // ── read another post by link ──
  function readLink() {
    var url = $('psLink').value.trim();
    if (!url) { msg('psMsg', 'Paste an X post link first.', 'warn'); return Promise.resolve(false); }
    setBusy('read', 'psReadBtn', true, '…'); msg('psMsg', 'Reading post…', '');
    return oembedRead(url).then(function (o) {
      if (o) return { ok: true, data: o };
      return call('/v1/post/source', { url: url });          // fallback: Worker (Sorsa)
    }).then(function (r) {
      setBusy('read', 'psReadBtn', false);
      if (!r.ok) { msg('psMsg', errText(r), 'err'); return false; }
      var d = r.data || {};
      $('psSource').value = d.text || '';
      if (!$('psProject').value.trim() && d.project_hint) $('psProject').value = d.project_hint;
      if (!$('psHandle').value.trim() && d.author && d.author.handle) $('psHandle').value = '@' + d.author.handle;
      msg('psMsg', 'Post read ✓', 'ok'); render(); return true;
    });
  }

  // ── style data from the existing Style/Tone tabs ──
  function styleData() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(['defaultTone', 'replyStyle', 'customTonePrompt', 'zenActiveStyleId', 'zenTrainedStyles', 'zenStyleExamples'], function (d) {
          d = d || {};
          var pool = d.zenStyleExamples || [];
          if (d.zenActiveStyleId) {
            var s = (d.zenTrainedStyles || []).filter(function (x) { return x.id === d.zenActiveStyleId; })[0];
            if (s && s.examples) pool = s.examples;
          }
          var texts = (pool || []).map(function (x) { return typeof x === 'string' ? x : (x && (x.text || x.reply || x.content)) || ''; }).filter(function (x) { return x && x.trim(); });
          for (var i = texts.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = texts[i]; texts[i] = texts[j]; texts[j] = t; }
          resolve({ tone: d.defaultTone || 'Smart', style: String(d.replyStyle || '').slice(0, 1200), custom: String(d.customTonePrompt || '').slice(0, 1000), examples: texts.slice(0, 3).map(function (x) { return x.slice(0, 280); }) });
        });
      } catch (e) { resolve({ tone: 'Smart', style: '', custom: '', examples: [] }); }
    });
  }

  // ── generate post ──
  function generate() {
    if (st.busy.gen) return;
    var pj = project();
    if (!pj.project) { msg('psMsg', ERR.PROJECT_REQUIRED, 'warn'); $('psProject').focus(); return; }
    var pre = Promise.resolve(true);
    if (st.mode === 'link') {
      if (!$('psSource').value.trim()) {
        if ($('psLink').value.trim()) pre = readLink();
        else { msg('psMsg', ERR.EMPTY_SOURCE, 'warn'); return; }
      }
    } else if (!$('psTopic').value.trim()) { msg('psMsg', ERR.EMPTY_TOPIC, 'warn'); return; }
    st.busy.gen = true;
    pre.then(function (ok) {
      if (ok === false || (st.mode === 'link' && !$('psSource').value.trim())) { st.busy.gen = false; if (ok !== false) msg('psMsg', ERR.EMPTY_SOURCE, 'warn'); return; }
      return styleData().then(function (sd) {
        setBusy('gen', 'psGenBtn', true, 'WRITING…'); msg('psMsg', '', '');
        var body = { mode: st.mode === 'link' ? 'idea' : 'free', project: pj.project, handle: pj.handle, tone: sd.tone, style: sd.style, style_examples: sd.examples, length: st.len, lang: 'English' };
        if (sd.tone === 'Custom') body.custom_prompt = sd.custom;
        if (st.mode === 'link') body.source_text = $('psSource').value.trim(); else body.topic = $('psTopic').value.trim();
        return call('/v1/post/generate', body).then(function (r) {
          setBusy('gen', 'psGenBtn', false);
          if (!r.ok) { msg('psMsg', errText(r), 'err'); render(); refreshCredits(); return; }
          $('psText').value = r.data.text || ''; counter();
          saveRecent(pj.project, pj.handle);
          st.confirm = false; clearImage();
          msg('psMsg', 'Done ✓ · ' + fmt(r.data.cost) + ' credits used, ' + fmt(r.data.credits) + ' left.', 'ok');
          refreshCredits(r.data.credits); render();
          if (st.cfg && st.cfg.image_enabled !== false) imagePrompt(true);
        });
      });
    }).catch(function () { setBusy('gen', 'psGenBtn', false); st.busy.gen = false; msg('psMsg', ERR.NETWORK, 'err'); });
  }
  function counter() {
    var n = $('psText').value.length, c = $('psCnt');
    var lim = st.len === 'deep' ? 4000 : 280;   // deep = long-form (X Premium); normal accounts are limited to 280
    c.textContent = n + ' / ' + lim; c.className = 'ps-cnt' + (n > lim ? ' over' : '');
    show('psResultCard', n > 0); show('psImgCard', n > 0 && !!(st.cfg && st.cfg.image_enabled !== false));
  }
  function tweet() {
    var t = $('psText').value.trim(); if (!t) return;
    var u = 'https://x.com/intent/tweet?text=' + encodeURIComponent(t);
    try { chrome.tabs.create({ url: u }); } catch (e) { window.open(u, '_blank'); }
  }

  // ── image prompt ──
  function imagePrompt(silent) {
    if (st.busy.prm) return;
    var text = $('psText').value.trim(); if (!text) return;
    var s = (st.cfg && st.cfg.styles || []).filter(function (x) { return x.id === st.style; })[0];
    setBusy('prm', 'psPromptBtn', true, 'WRITING…');
    return call('/v1/image/prompt', { post_text: text, style: st.style, project: project().project }).then(function (r) {
      setBusy('prm', 'psPromptBtn', false);
      if (!r.ok) { if (!silent) msg('psImgMsg', errText(r), 'err'); return; }
      $('psPrompt').value = r.data.prompt || ''; msg('psImgMsg', '', '');
    });
  }
  function clearImage() {
    st.b64 = ''; var i = $('psImgOut'); if (i) { i.removeAttribute('src'); i.style.display = 'none'; }
    show('psImgActs', false); show('psImgHint', false); msg('psImgMsg', '', '');
  }

  // ── make image: first tap shows the cost warning, second tap confirms ──
  function makeImage() {
    if (st.busy.img) return;
    var prompt = $('psPrompt').value.trim();
    if (prompt.length < 5) { msg('psImgMsg', ERR.EMPTY_PROMPT, 'warn'); return; }
    if (!st.confirm) { st.confirm = true; renderImgWarn(); msg('psImgMsg', 'Read the box above, then tap CONFIRM.', 'warn'); render(); return; }
    st.confirm = false;
    setBusy('img', 'psImgBtn', true, 'MAKING…'); msg('psImgMsg', 'Making image… (can take up to a minute)', '');
    call('/v1/image/generate', { prompt: prompt, style: st.style, aspect: st.aspect, tier: st.tier }).then(function (r) {
      setBusy('img', 'psImgBtn', false);
      if (!r.ok) { msg('psImgMsg', errText(r), 'err'); render(); refreshCredits(); return; }
      st.b64 = r.data.image_b64 || ''; st.mime = r.data.mime || 'image/png';
      var i = $('psImgOut'); i.src = 'data:' + st.mime + ';base64,' + st.b64; i.style.display = 'block';
      show('psImgActs', true, 'flex'); show('psImgHint', true);
      msg('psImgMsg', 'Image ready ✓ · ' + fmt(r.data.cost) + ' credits used, ' + fmt(r.data.credits) + ' left.', 'ok');
      refreshCredits(r.data.credits); render();
    });
  }
  function b64Blob() {
    var bin = atob(st.b64), arr = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: st.mime });
  }
  function saveBlob(blob, name) {
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
  }
  function dlImage() { if (!st.b64) return; saveBlob(b64Blob(), 'zex-image.' + (/jpe?g/.test(st.mime) ? 'jpg' : /webp/.test(st.mime) ? 'webp' : 'png')); }
  function copyImage() {
    if (!st.b64) return;
    var btn = $('psImgCopy');
    try {
      var blob = b64Blob();
      navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]).then(function () { var o = btn.textContent; btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = o; }, 1200); },
        function () { msg('psImgMsg', 'Copy not allowed here — use Download.', 'warn'); });
    } catch (e) { msg('psImgMsg', 'Copy not supported — use Download.', 'warn'); }
  }

  // ── free image search ──
  function freeSearch() {
    if (st.busy.free) return;
    var pj = project();
    if (!pj.project) { msg('psFreeMsg', ERR.PROJECT_REQUIRED, 'warn'); return; }
    setBusy('free', 'psFreeBtn', true, 'SEARCHING…'); msg('psFreeMsg', '', ''); $('psFreeGrid').innerHTML = '';
    call('/v1/image/free-search', { project: pj.project, handle: pj.handle || undefined }).then(function (r) {
      setBusy('free', 'psFreeBtn', false);
      if (!r.ok) { msg('psFreeMsg', errText(r), 'err'); return; }
      var list = (r.data && r.data.results) || [];
      if (!list.length) { msg('psFreeMsg', 'No images found. Try the exact project name or add the @handle.', 'warn'); return; }
      list.forEach(function (it) {
        var box = document.createElement('div'); box.className = 'ps-res';
        var im = document.createElement('img'); im.src = it.thumb || it.url; im.alt = ''; im.referrerPolicy = 'no-referrer';
        var sm = document.createElement('small'); sm.textContent = (it.source === 'x_avatar' ? 'X avatar' : it.source === 'x_banner' ? 'X banner' : 'Web') + (it.title ? ' · ' + it.title : '');
        var b = document.createElement('button'); b.type = 'button'; b.className = 'act-btn'; b.style.width = '100%'; b.textContent = 'Download';
        b.addEventListener('click', function () { downloadRemote(it, b); });
        box.appendChild(im); box.appendChild(sm); box.appendChild(b); $('psFreeGrid').appendChild(box);
      });
    });
  }
  function downloadRemote(it, btn) {
    var old = btn.textContent; btn.textContent = '…'; btn.disabled = true;
    fetch(it.url, { referrerPolicy: 'no-referrer' }).then(function (res) { if (!res.ok) throw new Error('x'); return res.blob(); }).then(function (blob) {
      var ext = /png/.test(blob.type) ? 'png' : /webp/.test(blob.type) ? 'webp' : /gif/.test(blob.type) ? 'gif' : 'jpg';
      saveBlob(blob, 'zex-' + (it.source || 'image') + '.' + ext); btn.textContent = 'Saved'; setTimeout(function () { btn.textContent = old; btn.disabled = false; }, 1500);
    }).catch(function () {
      btn.textContent = old; btn.disabled = false;
      try { chrome.tabs.create({ url: it.url }); } catch (e) {}
      msg('psFreeMsg', 'Could not download directly — opened the image in a new tab (long-press / right-click to save).', 'warn');
    });
  }

  function onOpen() { loadConfig(false).then(function () { if (st.cfg && !st.cfg.post_enabled && st.cfg.post_enabled === false) render(); }); }

  function bind() {
    if (st.bound || !$('tabPanelPost')) return; st.bound = true;
    $('psReadBtn').addEventListener('click', readLink);
    $('psGenBtn').addEventListener('click', generate);
    $('psText').addEventListener('input', counter);
    $('psCopyBtn').addEventListener('click', function () { copyText($('psText').value, $('psCopyBtn')); });
    $('psTweetBtn').addEventListener('click', tweet);
    $('psPromptBtn').addEventListener('click', function () { imagePrompt(false); });
    $('psImgBtn').addEventListener('click', makeImage);
    $('psPrompt').addEventListener('input', function () { st.confirm = false; render(); });
    $('psImgDl').addEventListener('click', dlImage);
    $('psImgCopy').addEventListener('click', copyImage);
    $('psFreeBtn').addEventListener('click', freeSearch);
    $('psProject').addEventListener('input', recent);
    document.querySelectorAll('.nav-tab[data-tabpanel="tabPanelPost"]').forEach(function (b) { b.addEventListener('click', onOpen); });
    // show the last known config instantly, then refresh
    try { chrome.storage.local.get(['zexStudioCfg'], function (d) { if (d && d.zexStudioCfg && !st.cfg) { st.cfg = d.zexStudioCfg; } render(); }); } catch (e) { render(); }
  }

  window.ZPS = { loadConfig: loadConfig, _state: st };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();
