// ═══════════════════════════════════════════════════════════════
// zauth.js v3 — Cloudflare Worker login (Phase 4 / S5, Firebase removed)
// Loaded in: popup (script tag), background (importScripts),
// content script (manifest js list), admin panel (same file, byte-for-byte).
// REST only — no SDK, works in MV3 service workers.
//
// Public names are unchanged: zSignIn, zSignUp, zSendVerifyEmail, zSendPasswordReset,
// zRefresh, zGetToken, zGetSession, zSignOut, zGoogleFlow, zRegisterAuthMessages.
// NEW (Worker): zVerifyCode, zResetPassword, zAuthConfig, zWorkerUrl.
// Session shape (unchanged): {uid:email, email, emailVerified, provider, idToken, refreshToken, expiresAt}
// plus src:'worker'. A stored session WITHOUT src (old Firebase login) is dropped: the user logs in again.
// ═══════════════════════════════════════════════════════════════
var ZCFG = {
  googleClientId: '618182812684-a457qld66e4sep0ql6tbj4piisb7522c.apps.googleusercontent.com',
  adminEmail: 'zeenzenitsu@gmail.com',   // must match the Worker ADMIN_EMAIL
  workerUrl: 'https://zexpay.asaddamorche365.workers.dev'   // default; admin panel may override via storage key zexpayUrl
};
var Z_SESSION_KEY = 'zAuth';      // current session (Worker)

function zEmailToKey(e) { return String(e || '').toLowerCase().replace(/\./g, '_dot_').replace(/@/g, '_at_'); }

function zJwt(t) {
  try {
    var p = t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    while (p.length % 4) p += '=';
    return JSON.parse(decodeURIComponent(escape(atob(p))));
  } catch (e) { return {}; }
}
function _zStoreGetK(k) { return new Promise(function (r) { chrome.storage.local.get([k], function (d) { r((d || {})[k] || null); }); }); }
function _zStoreSetK(k, s) { return new Promise(function (r) { var o = {}; o[k] = s; chrome.storage.local.set(o, r); }); }
function _zStoreGet() { return _zStoreGetK(Z_SESSION_KEY); }
function _zStoreSet(s) { return _zStoreSetK(Z_SESSION_KEY, s); }

// ── Worker URL ──────────────────────────────────────────────────
async function zWorkerUrl() {
  var u = await new Promise(function (r) { chrome.storage.local.get(['zexpayUrl'], function (d) { r((d && d.zexpayUrl) || ''); }); });
  return String(u || ZCFG.workerUrl).replace(/\/+$/, '');
}
// POST/GET to the Worker (public /auth/* endpoints, no token). Throws Error(code) with err.code = Worker error code.
async function _zW(method, path, body) {
  var url = (await zWorkerUrl()) + path, res, j = {};
  try {
    res = await fetch(url, { method: method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  } catch (e) { var ne = new Error('NETWORK_ERROR'); ne.code = 'NETWORK_ERROR'; throw ne; }
  try { j = await res.json(); } catch (e) {}
  if (!res.ok || j.ok === false) { var m = (j && j.error) || ('HTTP_' + res.status); var err = new Error(m); err.code = m; err.status = res.status; throw err; }
  return j;
}
async function zAuthConfig() { return _zW('GET', '/auth/config'); }

// Worker response -> stored session
function _zWSession(r) {
  return {
    uid: String(r.email || '').toLowerCase(),
    email: String(r.email || '').toLowerCase(),
    emailVerified: r.email_verified === true,
    provider: r.provider || 'password',
    idToken: r.idToken,
    refreshToken: r.refreshToken,
    expiresAt: Date.now() + ((parseInt(r.expiresIn, 10) || 3600) * 1000),
    src: 'worker'
  };
}

// ── Email + password (Worker) ───────────────────────────────────
// Signup does NOT log in: the Worker mails a 6-digit code. Call zVerifyCode(email, code) next.
async function zSignUp(email, pw) { return _zW('POST', '/auth/signup', { email: email, password: pw }); }          // -> {ok, need_verify}
async function zVerifyCode(email, code) { var s = _zWSession(await _zW('POST', '/auth/verify', { email: email, code: code })); await _zStoreSet(s); return s; }
async function zSignIn(email, pw) { var s = _zWSession(await _zW('POST', '/auth/login', { email: email, password: pw })); await _zStoreSet(s); return s; }
// Re-send the verify code (old name kept). Pass the email; if omitted uses the stored session email.
async function zSendVerifyEmail(email) {
  if (!email) { var s = await _zStoreGet(); email = s && s.email; }
  if (!email) throw new Error('NOT_SIGNED_IN');
  return _zW('POST', '/auth/resend', { email: email });
}
// Forgot password: mails a code. Finish with zResetPassword(email, code, newPassword).
async function zSendPasswordReset(email) { return _zW('POST', '/auth/forgot', { email: email }); }
async function zResetPassword(email, code, pw) { return _zW('POST', '/auth/reset', { email: email, code: code, password: pw }); }

// ── Token refresh ───────────────────────────────────────────────
var _zRefreshing = null;
async function _zRefreshWorker(s) {
  try {
    var r = await _zW('POST', '/auth/refresh', { refresh_token: s.refreshToken });
    var ns = _zWSession(r); await _zStoreSet(ns); return ns;
  } catch (e) {
    if (e.code === 'INVALID_REFRESH') { await zSignOut(); return null; }
    return s.expiresAt > Date.now() ? s : null;     // offline / server error: keep a still-valid token
  }
}
async function zRefresh(force) {
  var s = await _zStoreGet(); if (!s || !s.refreshToken) return null;
  if (!force && s.expiresAt - Date.now() > 60000) return s;
  if (_zRefreshing) return _zRefreshing;                       // one refresh at a time (refresh tokens rotate)
  if (s.src !== 'worker') { await new Promise(function (r) { chrome.storage.local.remove([Z_SESSION_KEY], r); }); return null; }   // old Firebase session: sign in again
  _zRefreshing = _zRefreshWorker(s);
  try { return await _zRefreshing; } finally { _zRefreshing = null; }
}
async function zGetToken() { var s = await zRefresh(false); return s ? s.idToken : null; }
async function zGetSession() { return await zRefresh(false); }
async function zSignOut() {
  var s = await _zStoreGet();
  if (s && s.src === 'worker' && s.refreshToken) { try { await _zW('POST', '/auth/logout', { refresh_token: s.refreshToken }); } catch (e) {} }
  await new Promise(function (r) { chrome.storage.local.remove([Z_SESSION_KEY], r); });
}

// ── Google sign-in (Worker) — run in the BACKGROUND (popups close on mobile) ──
// Implicit id_token flow. Redirect URI = https://<extension-id>.chromiumapp.org/ (add it in Google Cloud console).
// Uses chrome.identity.launchWebAuthFlow when the browser has it; otherwise opens a tab and reads the redirect URL (Kiwi fallback).
function _zRedirectUri() {
  try { if (chrome.identity && chrome.identity.getRedirectURL) return chrome.identity.getRedirectURL(); } catch (e) {}
  return 'https://' + chrome.runtime.id + '.chromiumapp.org/';
}
function _zNonce() { return Array.prototype.map.call(crypto.getRandomValues(new Uint8Array(16)), function (b) { return b.toString(16).padStart(2, '0'); }).join(''); }
function _zGoogleUrl(redirect, nonce) {
  return 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({
    client_id: ZCFG.googleClientId, redirect_uri: redirect, response_type: 'id_token',
    scope: 'openid email profile', nonce: nonce, prompt: 'select_account'
  }).toString();
}
function _zIdTokenFromUrl(u) {
  var h = new URLSearchParams((u.split('#')[1] || '')), q = new URLSearchParams((u.split('#')[0].split('?')[1] || ''));
  if (h.get('id_token')) return h.get('id_token');
  throw new Error(h.get('error') || q.get('error') || 'GOOGLE_NO_TOKEN');
}
async function _zGoogleIdToken(redirect, nonce) {
  var url = _zGoogleUrl(redirect, nonce);
  if (chrome.identity && chrome.identity.launchWebAuthFlow) {
    var done = await new Promise(function (resolve, reject) {
      try {
        chrome.identity.launchWebAuthFlow({ url: url, interactive: true }, function (u) {
          if (chrome.runtime.lastError || !u) reject(new Error((chrome.runtime.lastError && chrome.runtime.lastError.message) || 'GOOGLE_CANCELLED')); else resolve(u);
        });
      } catch (e) { reject(e); }
    }).catch(function (e) { return { _err: e }; });
    if (!done._err) return _zIdTokenFromUrl(done);
    if (!/not supported|undefined|is not a function/i.test(String(done._err && done._err.message))) throw done._err;   // real cancel/error; else fall through to the tab flow
  }
  var tab = await chrome.tabs.create({ url: url, active: true });
  return new Promise(function (resolve, reject) {
    var fin0 = false;
    function fin(fn, v) { if (fin0) return; fin0 = true; chrome.tabs.onUpdated.removeListener(onUp); chrome.tabs.onRemoved.removeListener(onRm); clearTimeout(to); fn(v); }
    function onUp(id, info, t) {
      if (id !== tab.id) return;
      var u = info.url || (t && t.url) || '';
      if (u.indexOf(redirect) !== 0) return;
      try { chrome.tabs.remove(tab.id); } catch (e) {}
      try { fin(resolve, _zIdTokenFromUrl(u)); } catch (e) { fin(reject, e); }
    }
    function onRm(id) { if (id === tab.id) fin(reject, new Error('GOOGLE_CANCELLED')); }
    var to = setTimeout(function () { fin(reject, new Error('GOOGLE_TIMEOUT')); }, 5 * 60 * 1000);
    chrome.tabs.onUpdated.addListener(onUp); chrome.tabs.onRemoved.addListener(onRm);
  });
}
async function zGoogleFlow() {
  var redirect = _zRedirectUri(), nonce = _zNonce();
  var idTok = await _zGoogleIdToken(redirect, nonce);
  if (zJwt(idTok).nonce !== nonce) throw new Error('GOOGLE_NONCE_MISMATCH');
  var s = _zWSession(await _zW('POST', '/auth/google', { id_token: idTok })); await _zStoreSet(s); return s;
}
// Background registers this once so popup can trigger Google login
function zRegisterAuthMessages() {
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg) return;
    if (msg.type === 'zGoogleLogin') {
      zGoogleFlow().then(function (s) { sendResponse({ ok: true, email: s.email }); })
        .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
      return true;
    }
  });
}
