// Z EX v8 — Full Feature Update

// ── Extension-context-invalidated guard ─────────────────────────
// Fires when the extension gets reloaded/updated while this popup is
// still open — any chrome.* call after that throws "Extension context
// invalidated", which some browsers (Mises included) treat as a crash
// and auto-close the extension. This swallows just that one error class
// so a stale popup fails silently instead of taking the extension down;
// closing and reopening the popup gets a fresh, valid context.
function extContextAlive() {
  try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
}
window.addEventListener('error', (e) => {
  const msg = (e && e.message) || (e && e.error && e.error.message) || '';
  if (msg.includes('Extension context invalidated')) e.preventDefault();
});
window.addEventListener('unhandledrejection', (e) => {
  const msg = (e && e.reason && (e.reason.message || String(e.reason))) || '';
  if (msg.includes('Extension context invalidated')) e.preventDefault();
});

// ── Storage-result safety net ────────────────────────────────────
// Some browsers (Mises included) can invoke chrome.storage.local.get's
// callback with `undefined` instead of `{}` when the requested key has
// no stored value yet — real Chrome never does this. Every call site in
// this file assumes it always gets an object back (e.g. `d.someKey`),
// so without this guard a fresh install/empty key throws
// "Cannot read properties of undefined" and can crash the popup. This
// wraps the API once, here, so every existing call site downstream is
// protected without needing to be touched individually.
if (chrome && chrome.storage && chrome.storage.local && !chrome.storage.local.__zenSafeGetWrapped) {
  const _zenOrigGet = chrome.storage.local.get.bind(chrome.storage.local);
  chrome.storage.local.get = function (a, b) {
    if (typeof a === 'function') return _zenOrigGet(function (res) { a(res || {}); });
    if (typeof b === 'function') return _zenOrigGet(a, function (res) { b(res || {}); });
    if (b === undefined) return _zenOrigGet(a);   // promise form: don't pass an undefined 2nd arg
    return _zenOrigGet(a, b);
  };
  chrome.storage.local.__zenSafeGetWrapped = true;
}

// Firebase (new project) — all DB calls are authenticated via zauth.js
function emailToKey(e) { return e.replace(/\./g,'_dot_').replace(/@/g,'_at_'); }
function getStorage(keys) { return new Promise(r => chrome.storage.local.get(keys, r)); }

// ── SORSA key now lives only in the Worker (STEP 6b); nothing is stored in the extension ──

let countdownInterval=null, serverCheckInterval=null, clockInterval=null, netCheckInterval=null;
let autoLogoutTimer=null;
let allNotices = [];

// ── AUTO LOGOUT SYSTEM (admin controlled per user) ──────────────
// Default: 60 minutes. Admin can set per user via Firebase: users/{uKey}/autoLogoutMinutes
// 0 = disabled. Hidden from user.
let autoLogoutMinutes = 60; // default fallback

function clearAutoLogout() {
  if(autoLogoutTimer) { clearTimeout(autoLogoutTimer); autoLogoutTimer=null; }
}

function startAutoLogout(minutes) {
  clearAutoLogout();
  if(!minutes || minutes<=0) return; // disabled
  autoLogoutTimer = setTimeout(()=>{ zForceLogout(); }, minutes * 60 * 1000);
}

function resetAutoLogout() {
  // Reset the timer on any user interaction
  startAutoLogout(autoLogoutMinutes);
}

// Theme (dark/light) is handled by theme-init.js

let currentSlide = 0;
const slides = document.querySelectorAll('.bg-slide');
function nextSlide() { if (document.hidden || !slides.length) return; slides[currentSlide].classList.remove('active'); currentSlide=(currentSlide+1)%slides.length; slides[currentSlide].classList.add('active'); }
setInterval(nextSlide, 3500);

function getDeviceInfo() {
  const ua = navigator.userAgent;
  let browser='Unknown', os='Unknown', device='Desktop';
  if(ua.includes('Edg/')) browser='Edge'; else if(ua.includes('OPR/')||ua.includes('Opera')) browser='Opera'; else if(ua.includes('Chrome/')&&!ua.includes('Chromium')) browser='Chrome'; else if(ua.includes('Firefox/')) browser='Firefox'; else if(ua.includes('Safari/')&&!ua.includes('Chrome')) browser='Safari'; else if(ua.includes('Chromium')) browser='Chromium';
  if(ua.includes('Windows NT 10.0')) os='Windows 10/11'; else if(ua.includes('Windows')) os='Windows'; else if(ua.includes('Mac OS X')) os='macOS'; else if(ua.includes('Android')) os='Android'; else if(ua.includes('iPhone')||ua.includes('iPad')) os='iOS'; else if(ua.includes('Linux')) os='Linux';
  if(ua.includes('Mobile')||ua.includes('Android')) device='Mobile';
  return { browser, os, device, screen:`${window.screen.width}×${window.screen.height}`, lang:navigator.language||'en', cores:navigator.hardwareConcurrency||'?' };
}
function renderDeviceInfo() {
  const info=getDeviceInfo(); const el=document.getElementById('deviceInfoBox'); if(!el) return;
  el.innerHTML=`<div class="dev-row"><span class="dev-key">Browser</span><span class="dev-val" data-devval="${info.browser}"></span></div><div class="dev-row"><span class="dev-key">OS</span><span class="dev-val" data-devval="${info.os}"></span></div><div class="dev-row"><span class="dev-key">Device</span><span class="dev-val" data-devval="${info.device}"></span></div><div class="dev-row"><span class="dev-key">Screen</span><span class="dev-val" data-devval="${info.screen}"></span></div><div class="dev-row"><span class="dev-key">Language</span><span class="dev-val" data-devval="${info.lang}"></span></div><div class="dev-row"><span class="dev-key">CPU Cores</span><span class="dev-val" data-devval="${info.cores}"></span></div>`;
  const vals = el.querySelectorAll('.dev-val');
  vals.forEach((v,i)=>{
    setTimeout(()=>{ zenScrambleText(v, v.getAttribute('data-devval'), { speed: 24, startSpread: 4, settleSpread: 8 }); }, i*90);
  });
}

function checkInternet() {
  const isOnline=navigator.onLine; const bar=document.getElementById('offlineBar'); const dot=document.getElementById('onlineDot'); const netVal=document.getElementById('netStatusVal');
  if(bar) bar.style.display=isOnline?'none':'block'; if(dot){dot.className='online-dot '+(isOnline?'online':'offline');} if(netVal){netVal.textContent=isOnline?'ONLINE':'OFFLINE';netVal.style.color=isOnline?'#10a37f':'#ff4444';} return isOnline;
}

function startClock() {
  clearInterval(clockInterval);
  function tick(){ const now=new Date(); const h=String(now.getHours()).padStart(2,'0'); const m=String(now.getMinutes()).padStart(2,'0'); const s=String(now.getSeconds()).padStart(2,'0'); const el=document.getElementById('clockDisplay'); if(el) el.textContent=`${h}:${m}:${s}`; }
  tick(); clockInterval=setInterval(tick,1000);
}
function startLoginClock() {
  function tick(){ const now=new Date(); const h=String(now.getHours()).padStart(2,'0'); const m=String(now.getMinutes()).padStart(2,'0'); const s=String(now.getSeconds()).padStart(2,'0'); const el=document.getElementById('loginClockDisplay'); if(el) el.textContent=`${h}:${m}:${s}`; }
  tick(); setInterval(tick,1000);
}

// ── Notice System ─────────────────────────────────────────────
async function checkNotices(email) {
  const cfg=await zAppConfig(true);
  const g=cfg&&cfg.global_notice;
  const st=await getStorage(['zenNoticeLog']);
  let log=Array.isArray(st.zenNoticeLog)?st.zenNoticeLog:[];
  if(g&&g.msg&&g.id&&!log.find(n=>n.id===g.id)){
    log.unshift({id:g.id,msg:String(g.msg).slice(0,1000),sentAt:g.sentAt||Date.now()}); log=log.slice(0,30);
    chrome.storage.local.set({zenNoticeLog:log});
  }
  allNotices=log.slice();
  if(g&&g.msg){ const stored=await getStorage(['zenLastNoticeId']); if(stored.zenLastNoticeId!==g.id){ showNoticePopup(g.msg); chrome.storage.local.set({zenLastNoticeId:g.id}); } }
  renderNoticeHistory();
}

function showNoticePopup(msg) { const popup=document.getElementById('noticePopup'); const msgEl=document.getElementById('noticeMsg'); if(!popup||!msgEl) return; msgEl.textContent=msg; popup.classList.add('show'); }

function renderNoticeHistory() {
  const container=document.getElementById('noticeHistoryList'); if(!container) return;
  if(!allNotices.length){ container.innerHTML='<div style="color:#5a7a9a;font-size:11px;text-align:center;padding:16px;">No notices yet.</div>'; return; }
  container.innerHTML=allNotices.map(n=>{
    const d=new Date(n.sentAt); const timeStr=d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'})+' '+d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:true});
    return `<div class="notice-history-item"><div class="notice-history-msg">${escapeHtml(n.msg)}</div><div class="notice-history-time">${timeStr}</div></div>`;
  }).join('');
}

// ── Feature Flags ─────────────────────────────────────────────
const FEATURE_SECTIONS = {
  'projectName':['projectNameSection','projectNameRow'], 'smartSwitch':['smartSwitchSection','smartSwitchRow'],
  'bigReply':['bigReplySectionLabel','bigReplySection'], 'replyStyle':['replyStyleSectionLabel','replyStyleSection'],
  'keyword':['keywordSectionLabel','keywordSection'], 'customTone':['customToneSectionLabel','customToneSection'],
  'tone':['toneSectionLabel','toneSection'], 'grammar':['grammarSectionLabel','grammarSection'], 'sk1':['sk1SectionLabel','sk1Section']
};

async function applyFeatureFlags(userKey) {
  const flags=null;   // S4b: per-user feature flags were dropped (all sections visible)
  document.querySelectorAll('.feature-disabled-banner').forEach(b=>b.remove());

  for(const [feature,ids] of Object.entries(FEATURE_SECTIONS)){
    const enabled=!flags||(flags[feature]!==false);
    ids.forEach(id=>{ const el=document.getElementById(id); if(el) el.style.display=enabled?'':'none'; });
    if(!enabled){
      const labelEl=document.getElementById(ids[0]);
      if(labelEl&&labelEl.parentNode){
        const banner=document.createElement('div'); banner.id='disabledBanner_'+feature; banner.className='feature-disabled-banner'; banner.textContent='Feature Disabled By Z EX';
        labelEl.parentNode.insertBefore(banner,labelEl.nextSibling);
      }
    }
  }
}

// ── X Verify (v11 — Profile Page "Edit Profile" Button Detection) ────────
// CORE IDEA: Open x.com/<enteredUsername> profile page directly.
// X shows "Edit profile" button ONLY on the logged-in user's own profile.
// Any other account shows "Follow" / "Following" instead.
// This is 100% reliable, unaffected by multi-tab tricks, and needs no
// DOM guessing — we just check one definitive UI element.

let xVerifyFailCount = 0;
const X_MAX_FAILS = 3;

// Injected into the profile tab — checks for Edit Profile button
function xProfileOwnerScript() {
  // Method 1: data-testid="editProfileButton" — most reliable
  const editBtn = document.querySelector('[data-testid="editProfileButton"]');
  if(editBtn) return { isOwner: true, method: 'editProfileButton' };

  // Method 2: any <a> or <button> whose visible text is exactly "Edit profile"
  const allBtns = Array.from(document.querySelectorAll('a[href], button, div[role="button"]'));
  for(const el of allBtns){
    const txt = el.innerText && el.innerText.trim();
    if(txt === 'Edit profile') return { isOwner: true, method: 'editProfileText' };
  }

  // Method 3: confirm Follow button exists → definitely NOT owner
  const followBtn = document.querySelector('[data-testid="followButton"], [data-testid="placementTracking"]');
  if(followBtn) return { isOwner: false, method: 'followButton' };

  // Inconclusive — page may not have finished loading
  return { isOwner: null, method: 'inconclusive' };
}

// Open a tab, wait for load, run script, close tab
function openTabAndRun(url, scriptFn, waitMs = 8000) {
  return new Promise(resolve => {
    chrome.tabs.create({ url, active: false }, tab => {
      let settled = false;

      const finish = async () => {
        if(settled) return;
        settled = true;
        chrome.tabs.onUpdated.removeListener(listener);
        // Extra pause for React hydration
        await new Promise(r => setTimeout(r, 1800));
        let result = null;
        try {
          const results = await new Promise(res =>
            chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scriptFn }, res)
          );
          result = results && results[0] && results[0].result;
        } catch(e){}
        try { chrome.tabs.remove(tab.id); } catch(e){}
        resolve(result);
      };

      const listener = (tabId, info) => {
        if(tabId === tab.id && info.status === 'complete') finish();
      };
      chrome.tabs.onUpdated.addListener(listener);
      setTimeout(finish, waitMs); // safety timeout
    });
  });
}

// The check itself runs in the background (x_verify_bg.js) so closing the popup / switching tabs cannot break it.
// This function only starts it; the result is rendered by xVerifyRender() from storage key zexXVerifyJob.
async function handleXVerify() {
  const session=(await getStorage(['zenDeviceSession'])).zenDeviceSession; if(!session) return;
  const xUsernameInput = document.getElementById('xUsernameInput');
  const verifyBtn=document.getElementById('xVerifyBtn');
  const enteredUsername = xUsernameInput ? xUsernameInput.value.trim().replace(/^@/,'').toLowerCase() : '';
  if(!enteredUsername) { setVerifyStatus('x','Enter your X username'); return; }
  if(verifyBtn){verifyBtn.textContent='Verifying...';verifyBtn.disabled=true;}
  setVerifyStatus('x',`Checking @${enteredUsername} ... you can close this popup, it keeps going.`);
  const r = await new Promise(res=>{ try{ chrome.runtime.sendMessage({type:'zexXVerifyStart',handle:enteredUsername},x=>res((chrome.runtime.lastError||!x)?null:x)); }catch(e){ res(null); } });
  if(!r){ setVerifyStatus('x','Could not start the check. Reload the extension and try again.'); if(verifyBtn){verifyBtn.textContent='Verify X Account';verifyBtn.disabled=false;} }
}

// Render the background job (called when the popup opens and live on every change).
function xVerifyRender(job) {
  if(!job || !job.status) return;
  const verifyBtn=document.getElementById('xVerifyBtn');
  const input=document.getElementById('xUsernameInput');
  const fresh = Date.now() - (job.at||0) < 10*60*1000;
  if(job.status==='running'){
    if(input && job.handle && !input.value) input.value='@'+job.handle;
    setVerifyStatus('x', job.msg || 'Checking ...');
    if(verifyBtn){verifyBtn.textContent='Verifying...';verifyBtn.disabled=true;}
    return;
  }
  if(job.status==='verified'){
    setVerifyStatus('x', job.msg || ('Verified: @'+job.handle));
    const badge=document.getElementById('xVerifiedBadge'); if(badge) badge.style.display='inline-flex';
    if(verifyBtn){verifyBtn.textContent='X Verified';verifyBtn.disabled=true;}
    const xEl=document.getElementById('dashXHandle'); if(xEl) xEl.textContent='@'+job.handle;
    return;
  }
  if(!fresh) return;                       // old failure: don't nag after a reopen days later
  setVerifyStatus('x', job.msg || 'Verification failed. Please try again.');
  if(verifyBtn){
    if(job.status==='muted'){verifyBtn.textContent='MUTED';verifyBtn.disabled=true;}
    else {verifyBtn.textContent='Verify X Account';verifyBtn.disabled=false;}
  }
}
function xVerifySyncInit() {
  // X verification was dropped (admin released the handle) while the popup is open -> go back to the Verify page
  chrome.storage.onChanged.addListener((ch,area)=>{
    if(area!=='local'||!ch.zenDeviceSession) return;
    const o=ch.zenDeviceSession.oldValue, n=ch.zenDeviceSession.newValue;
    if(o&&o.xHandle&&n&&!n.xHandle) showVerifyPage(n);
  });
  const pull=()=>chrome.storage.local.get(['zexXVerifyJob'],d=>xVerifyRender(d&&d.zexXVerifyJob));
  pull();
  chrome.storage.onChanged.addListener((ch,area)=>{ if(area==='local'&&ch.zexXVerifyJob) xVerifyRender(ch.zexXVerifyJob.newValue); });
  document.addEventListener('visibilitychange',()=>{ if(!document.hidden) pull(); });
  window.addEventListener('focus',pull);
}

async function handleTgVerify() {
  const tgInput=document.getElementById('tgVerifyInput'); const handle=tgInput?.value.trim().replace(/^@/,'');
  if(!handle){setVerifyStatus('tg','Enter your Telegram username');return;}
  const session=(await getStorage(['zenDeviceSession'])).zenDeviceSession; if(!session) return;
  const pr=await zexpayCall('/v1/profile','POST',{patch:{tg:handle,tgVerified:true,tgVerifiedAt:Date.now()}});
  if(!pr.ok){ setVerifyStatus('tg','Could not save (network). Try again.'); return; }
  chrome.storage.local.set({zenDeviceSession:{...session,tgHandle:handle}});
  setVerifyStatus('tg',`Saved: @${handle}`);
  const badge=document.getElementById('tgVerifiedBadge'); if(badge) badge.style.display='inline-flex';
}

function setVerifyStatus(type, msg) { const el=document.getElementById(type==='x'?'xVerifyStatus':'tgVerifyStatus'); if(el) el.textContent=msg; }

// ── INIT ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  renderDeviceInfo(); checkInternet();
  netCheckInterval=setInterval(checkInternet,3000);
  window.addEventListener('online',checkInternet); window.addEventListener('offline',checkInternet);

  document.getElementById('noticeCloseBtn')?.addEventListener('click',()=>document.getElementById('noticePopup')?.classList.remove('show'));
  document.getElementById('noticeBellBtn')?.addEventListener('click',()=>document.getElementById('noticeHistoryPanel')?.classList.toggle('show'));
  document.getElementById('noticeHistoryClose')?.addEventListener('click',()=>document.getElementById('noticeHistoryPanel')?.classList.remove('show'));
  document.getElementById('replyCounterCard')?.addEventListener('click', toggleReplyClickBreakdown);

  zBindAuthUI();
  await zInitAuth();
  xVerifySyncInit();

  loadSettings(); loadReplyCount(); loadRepDraftCount(); loadFeedDraftCount(); loadSearchDraftCount(); loadGivDraftCount();
  document.getElementById('logoutBtn')?.addEventListener('click',handleLogout);
  document.getElementById('saveAllBtn')?.addEventListener('click',saveAll);
  document.getElementById('historyClearBtn')?.addEventListener('click',()=>{
    if(!confirm('Clear all reply history? This cannot be undone.')) return;
    chrome.storage.local.set({zenReplyHistory:[],zenSkipLog:[]},()=>{loadHistory();showStatus('History cleared','ok');});
  });
  document.getElementById('xVerifyBtn')?.addEventListener('click',handleXVerify);
  document.getElementById('tgVerifyBtn')?.addEventListener('click',handleTgVerify);
  document.getElementById('verifyDoneBtn')?.addEventListener('click',async()=>{
    const s=(await getStorage(['zenDeviceSession'])).zenDeviceSession; if(!s) return;
    const prof=await zProfileGet();
    const hasX=(prof&&prof.xVerified)||s.xHandle;
    if(!hasX){
      const el=document.getElementById('xVerifyStatus');
      if(el){el.textContent='X verification is mandatory — please verify your X account first.';el.style.color='#ff4444';}
      return;
    }
    showDashboard(s);
  });

  document.getElementById('toneCollapsedRow')?.addEventListener('click',()=>{const d=document.getElementById('tonesDropdown');const a=document.getElementById('toneArrow');const o=d.classList.contains('open');d.classList.toggle('open',!o);if(a)a.classList.toggle('open',!o);});
  document.getElementById('bigReplyToneBtn')?.addEventListener('click',(e)=>{e.stopPropagation();const d=document.getElementById('bigReplyToneDropdown');const a=document.getElementById('bigReplyToneArrow');const o=d.classList.contains('open');d.classList.toggle('open',!o);if(a)a.classList.toggle('open',!o);});
  document.querySelectorAll('.big-reply-tone-option').forEach(opt=>{
    opt.addEventListener('click',(e)=>{e.stopPropagation();setBigReplyTone(opt.dataset.tone);document.getElementById('bigReplyToneDropdown')?.classList.remove('open');document.getElementById('bigReplyToneArrow')?.classList.remove('open');});
  });
  document.addEventListener('click',(e)=>{
    const wrap=document.querySelector('.big-reply-select-wrap');
    if(wrap && !wrap.contains(e.target)){document.getElementById('bigReplyToneDropdown')?.classList.remove('open');document.getElementById('bigReplyToneArrow')?.classList.remove('open');}
  });
  document.getElementById('grammarCollapsedRow')?.addEventListener('click',()=>{const d=document.getElementById('grammarDropdown');const a=document.getElementById('grammarArrow');const o=d.classList.contains('open');d.classList.toggle('open',!o);if(a)a.classList.toggle('open',!o);});
  document.querySelectorAll('.tone-chip').forEach(btn=>{
    btn.addEventListener('click',()=>{
      document.querySelectorAll('.tone-chip').forEach(b=>b.classList.remove('active')); btn.classList.add('active');
      const toneEl=document.getElementById('toneSelectedText');if(toneEl)toneEl.textContent=btn.textContent;
      document.getElementById('tonesDropdown')?.classList.remove('open');document.getElementById('toneArrow')?.classList.remove('open');
      const isCustom=btn.dataset.tone==='Custom';const customSec=document.getElementById('customToneSection');const customLabel=document.getElementById('customToneSectionLabel');
      if(customSec)customSec.style.display=isCustom?'block':'none';if(customLabel)customLabel.style.display=isCustom?'block':'none';
    });
  });
  const smartSwitch=document.getElementById('smartSwitch');
  if(smartSwitch){chrome.storage.local.get(['smartSwitch'],d=>{smartSwitch.checked=d.smartSwitch!==false;});smartSwitch.addEventListener('change',()=>{chrome.storage.local.set({smartSwitch:smartSwitch.checked});updateSwitchLabel(smartSwitch.checked);});}
  const riSw=document.getElementById('readImagesSwitch'), riLbl=document.getElementById('readImagesLabel');
  if(riSw){
    const riLabel=(on,off)=>{ if(riLbl) riLbl.textContent=off?'OFF — Admin turned image reading off':(on?'ON — Replies can use photos in the post':'OFF — Text only'); };
    chrome.storage.local.get(['zenReadImages','zexpayMe'],d=>{ riSw.checked=d.zenReadImages!==false; riLabel(riSw.checked,!!(d.zexpayMe&&d.zexpayMe.vision_enabled===false)); });
    riSw.addEventListener('change',()=>{ chrome.storage.local.set({zenReadImages:riSw.checked}); chrome.storage.local.get(['zexpayMe'],d=>riLabel(riSw.checked,!!(d.zexpayMe&&d.zexpayMe.vision_enabled===false))); });
  }
  const pnSw=document.getElementById('projectNameSwitch');
  if(pnSw){chrome.storage.local.get(['useProjectNameGlobal'],d=>{pnSw.checked=d.useProjectNameGlobal!==false;updateProjectNameLabel(pnSw.checked);});pnSw.addEventListener('change',()=>{chrome.storage.local.set({useProjectNameGlobal:pnSw.checked});updateProjectNameLabel(pnSw.checked);});}

  // ── CDP Click toggle ──
  const cdpSw=document.getElementById('cdpClickSwitch');
  if(cdpSw){
    chrome.storage.local.get(['zen_cdp_click'],d=>{
      const on=d.zen_cdp_click===true;
      cdpSw.checked=on;
      updateCdpClickLabel(on);
    });
    cdpSw.addEventListener('change',()=>{
      chrome.storage.local.set({zen_cdp_click:cdpSw.checked});
      updateCdpClickLabel(cdpSw.checked);
    });
  }


  // ── ZEX+ CDP tools (focus lock / trusted typing / touch tap / keep awake / net test) ──
  (function zexPlusUi(){
    const DESC={
      zexplus_focus:['OFF','ON — hidden X tabs behave as focused'],
      zexplus_key:['OFF','ON — real keystrokes (Input.dispatchKeyEvent / insertText)'],
      zexplus_touch:['OFF','ON — touch-style tap (needs RL STEALTH CLICK ON)'],
      zexplus_idle:['OFF','ON — screen/system stay awake while an engine runs']
    };
    const MAP=[['zpFocus','zexplus_focus'],['zpKey','zexplus_key'],['zpTouch','zexplus_touch'],['zpIdle','zexplus_idle']];
    chrome.storage.local.get(MAP.map(m=>m[1]).concat(['zexplus_net']),d=>{
      MAP.forEach(([id,key])=>{
        const sw=document.getElementById(id+'Switch'),lb=document.getElementById(id+'Label');
        if(!sw)return;
        const set=on=>{sw.checked=on;if(lb)lb.textContent=DESC[key][on?1:0];};
        set(d[key]===true);
        sw.addEventListener('change',()=>{
          set(sw.checked);
          chrome.storage.local.set({[key]:sw.checked});
          if(key==='zexplus_idle'&&sw.checked&&chrome.permissions){   // optional permissions: idle + power (power does not exist on every mobile browser)
            try{chrome.permissions.request({permissions:['idle']},()=>{void chrome.runtime.lastError;});}catch(e){}
            try{chrome.permissions.request({permissions:['power']},()=>{void chrome.runtime.lastError;});}catch(e){}
          }
        });
      });
      const sel=document.getElementById('zpNetSelect'),nl=document.getElementById('zpNetLabel');
      if(sel){
        const setN=v=>{sel.value=v;if(nl)nl.textContent=v==='off'?'OFF — normal connection':'ON — '+sel.options[sel.selectedIndex].text+' on every X tab';};
        setN(d.zexplus_net||'off');
        sel.addEventListener('change',()=>{setN(sel.value);chrome.storage.local.set({zexplus_net:sel.value});});
      }
    });
  })();

  // ── ZenCursor custom image (auto 28×28 + auto bg remove + upload) ──
  const cursorSw=document.getElementById('zenCursorImgSwitch');
  const cursorBox=document.getElementById('zenCursorImgBox');
  const cursorUrlInput=document.getElementById('zenCursorImgUrl');
  const cursorSaveBtn=document.getElementById('zenCursorImgSave');
  const cursorClearBtn=document.getElementById('zenCursorImgClear');
  const cursorLabel=document.getElementById('zenCursorImgLabel');
  const cursorFile=document.getElementById('zenCursorImgFile');
  const cursorUploadBtn=document.getElementById('zenCursorImgUpload');
  const cursorAutoBg=document.getElementById('zenCursorAutoBg');
  const cursorPrev=document.getElementById('zenCursorPreview');
  const cursorStatus=document.getElementById('zenCursorStatus');
  const CUR_OUT=128; // stored sharp; shown at the chosen size (16–64px) via CSS
  const cursorSize=document.getElementById('zenCursorSize');
  const cursorSizeVal=document.getElementById('zenCursorSizeVal');
  const cursorHist=document.getElementById('zenCursorHist');
  const cursorHistWrap=document.getElementById('zenCursorHistWrap');
  let curPx=28, curSrc='';

  function updateCursorLabel(name){
    if(cursorLabel) cursorLabel.textContent = name ? 'Custom — '+String(name).slice(0,30) : 'Default — white arrow pointer';
  }
  function curStatus(t,color){ if(cursorStatus){ cursorStatus.textContent=t; cursorStatus.style.color=color||''; } }
  function showPreview(src){
    if(!cursorPrev) return;
    if(src) curSrc=src;
    if(!curSrc) return;
    const im=new Image();
    im.onload=()=>{ const c=cursorPrev.getContext('2d'); c.clearRect(0,0,128,128); c.imageSmoothingQuality='high';
      const s=curPx*2; c.drawImage(im,(128-s)/2,(128-s)/2,s,s); };
    im.src=curSrc;
  }

  // ── saved cursors (history) ──
  const HIST_MAX=12;
  const _stGet=k=>new Promise(r=>chrome.storage.local.get(k,d=>r(d||{})));
  async function getHist(){ const d=await _stGet(['zen_cursor_hist']); return Array.isArray(d.zen_cursor_hist)?d.zen_cursor_hist:[]; }
  async function addHist(src,name){
    if(!src||src.length>400000) return;
    let l=await getHist();
    l=l.filter(x=>x.src!==src);
    l.unshift({src,name:name||'image'});
    l=l.slice(0,HIST_MAX);
    await chrome.storage.local.set({zen_cursor_hist:l});
    renderHist();
  }
  async function renderHist(){
    if(!cursorHist) return;
    const l=await getHist();
    cursorHist.innerHTML='';
    if(cursorHistWrap) cursorHistWrap.style.display=l.length?'block':'none';
    const cur=(await _stGet(['zen_cursor_img'])).zen_cursor_img||'';
    l.forEach((it,idx)=>{
      const w=document.createElement('div');
      w.style.cssText='position:relative;width:46px;height:46px;border-radius:8px;border:2px solid '+(it.src===cur?'#0066ff':'#ddd')+';background:repeating-conic-gradient(#e5e5e5 0% 25%,#fff 0% 50%) 50%/10px 10px;cursor:pointer;';
      w.title=it.name;
      const im=document.createElement('img'); im.src=it.src; im.style.cssText='width:100%;height:100%;object-fit:contain;border-radius:6px;';
      const x=document.createElement('span'); x.textContent='✕';
      x.style.cssText='position:absolute;top:-7px;right:-7px;width:18px;height:18px;border-radius:9px;background:#dc2626;color:#fff;font-size:10px;line-height:18px;text-align:center;';
      w.appendChild(im); w.appendChild(x);
      w.addEventListener('click',async(e)=>{
        if(e.target===x){ const cl=await getHist(); cl.splice(idx,1); await chrome.storage.local.set({zen_cursor_hist:cl}); renderHist(); return; }
        await chrome.storage.local.set({zen_cursor_img:it.src,zen_cursor_name:it.name});
        if(cursorSw) cursorSw.checked=true;
        updateCursorLabel(it.name); showPreview(it.src); curStatus('Custom cursor active.','#16a34a'); renderHist();
      });
      cursorHist.appendChild(w);
    });
  }

  function _blobToImage(blob){
    return new Promise((res,rej)=>{
      const u=URL.createObjectURL(blob);
      const im=new Image();
      im.onload=()=>res(im);
      im.onerror=()=>rej(new Error('Not a valid image'));
      im.src=u;
    });
  }
  function _blobToDataURL(blob){
    return new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(blob); });
  }
  async function _fetchBlob(url){
    try{
      const r=await fetch(url); if(!r.ok) throw new Error('HTTP '+r.status);
      return await r.blob();
    }catch(e1){
      // ask for wider access once (needed for cross-site image links), then retry
      try{
        if(chrome.permissions?.request){
          const ok=await chrome.permissions.request({origins:['https://*/*','http://*/*']});
          if(ok){ const r=await fetch(url); if(r.ok) return await r.blob(); }
        }
      }catch(_){}
      throw e1;
    }
  }

  // Remove a plain/solid background: flood-fill from the edges using the edge colour.
  // Returns true if a background was actually removed.
  function removeBg(imgData,w,h){
    const d=imgData.data, N=w*h;
    // already transparent? leave it alone
    let tr=0; for(let i=3;i<d.length;i+=4) if(d[i]<200) tr++;
    if(tr/N>0.03) return false;
    // most common (quantised) colour along the border = background colour
    const q=v=>v>>4, bucket=new Map(), border=[];
    const push=(x,y)=>{ const i=(y*w+x)*4; border.push(i); const k=q(d[i])*256+q(d[i+1])*16+q(d[i+2]); bucket.set(k,(bucket.get(k)||0)+1); };
    for(let x=0;x<w;x++){ push(x,0); push(x,h-1); }
    for(let y=1;y<h-1;y++){ push(0,y); push(w-1,y); }
    let bk=0,bc=0; bucket.forEach((c,k)=>{ if(c>bc){bc=c;bk=k;} });
    if(bc/border.length<0.5) return false;            // busy background (real photo) → can't do it
    let sr=0,sg=0,sb=0,sn=0;
    for(const i of border){ const k=q(d[i])*256+q(d[i+1])*16+q(d[i+2]); if(k===bk){ sr+=d[i]; sg+=d[i+1]; sb+=d[i+2]; sn++; } }
    const br=sr/sn, bg=sg/sn, bb=sb/sn;
    const dist=i=>Math.hypot(d[i]-br,d[i+1]-bg,d[i+2]-bb);
    const T1=38, T2=80;                                // hard / soft thresholds
    const seen=new Uint8Array(N), stack=[];
    const tryPush=(x,y)=>{ if(x<0||y<0||x>=w||y>=h) return; const p=y*w+x; if(seen[p]) return; if(dist(p*4)<=T2){ seen[p]=1; stack.push(p); } };
    for(let x=0;x<w;x++){ tryPush(x,0); tryPush(x,h-1); }
    for(let y=0;y<h;y++){ tryPush(0,y); tryPush(w-1,y); }
    let removed=0;
    while(stack.length){
      const p=stack.pop(), x=p%w, y=(p/w)|0, i=p*4, dd=dist(i);
      if(dd<=T1) d[i+3]=0; else d[i+3]=Math.round(255*(dd-T1)/(T2-T1)); // soft edge
      removed++;
      tryPush(x+1,y); tryPush(x-1,y); tryPush(x,y+1); tryPush(x,y-1);
    }
    return removed/N>0.05 && removed/N<0.97;
  }

  // image → 56×56 PNG dataURL (crop to content, fit, centre) + whether bg was removed
  function processCursorImage(im,autoBg){
    const MAXW=300;
    const sc=Math.min(1,MAXW/Math.max(im.naturalWidth,im.naturalHeight));
    const w=Math.max(1,Math.round(im.naturalWidth*sc)), h=Math.max(1,Math.round(im.naturalHeight*sc));
    const c=document.createElement('canvas'); c.width=w; c.height=h;
    const x=c.getContext('2d',{willReadFrequently:true});
    x.drawImage(im,0,0,w,h);
    let bgDone=false;
    if(autoBg){
      const id=x.getImageData(0,0,w,h);
      bgDone=removeBg(id,w,h);
      if(bgDone) x.putImageData(id,0,0);
    }
    // bounding box of visible pixels
    const id2=x.getImageData(0,0,w,h).data;
    let x0=w,y0=h,x1=-1,y1=-1;
    for(let yy=0;yy<h;yy++) for(let xx=0;xx<w;xx++) if(id2[(yy*w+xx)*4+3]>16){ if(xx<x0)x0=xx; if(xx>x1)x1=xx; if(yy<y0)y0=yy; if(yy>y1)y1=yy; }
    if(x1<0){ x0=0;y0=0;x1=w-1;y1=h-1; }
    const bw=x1-x0+1, bh=y1-y0+1, pad=Math.round(CUR_OUT/14);
    const f=(CUR_OUT-pad*2)/Math.max(bw,bh);
    const o=document.createElement('canvas'); o.width=CUR_OUT; o.height=CUR_OUT;
    const ox=o.getContext('2d'); ox.imageSmoothingQuality='high';
    const dw=bw*f, dh=bh*f;
    ox.drawImage(c,x0,y0,bw,bh,(CUR_OUT-dw)/2,(CUR_OUT-dh)/2,dw,dh);
    return {dataUrl:o.toDataURL('image/png'), bgDone};
  }

  // Accepts ANY link: direct image, web page (finds og:image / <img>), or Google imgres link.
  async function _resolveImageBlob(inputUrl){
    let url=inputUrl.trim();
    if(url.startsWith('data:image/')){ const r=await fetch(url); return await r.blob(); }
    try{ // Google Images "imgres?imgurl=..." style links carry the real image url
      const u=new URL(url);
      const iu=u.searchParams.get('imgurl');
      if(iu) url=iu;
    }catch(_){}
    const blob=await _fetchBlob(url);
    if(blob.type.startsWith('image/')) return blob;
    if(!/html|text|xml/.test(blob.type||'text/html')){ const e=new Error('Link is not an image.'); e.notImg=true; throw e; }
    const html=await blob.text();
    const doc=new DOMParser().parseFromString(html,'text/html');
    const abs=s=>{ try{ return new URL(s,url).href; }catch(_){ return null; } };
    const cands=[];
    ['meta[property="og:image"]','meta[property="og:image:url"]','meta[name="twitter:image"]','meta[name="twitter:image:src"]','link[rel="image_src"]']
      .forEach(sel=>{ const el=doc.querySelector(sel); const v=el&&(el.getAttribute('content')||el.getAttribute('href')); if(v) cands.push(abs(v)); });
    doc.querySelectorAll('img').forEach(im=>{ const v=im.getAttribute('src')||im.getAttribute('data-src'); if(v&&!/logo|icon|sprite|avatar/i.test(v)) cands.push(abs(v)); });
    const uniq=[...new Set(cands.filter(Boolean))].slice(0,8);
    for(const c of uniq){
      try{ const b=await _fetchBlob(c); if(b.type.startsWith('image/') && b.size>200) return b; }catch(_){}
    }
    const e=new Error('No image found on that page (Google search pages don\'t work — open the image and copy its address, or use Upload).');
    e.notImg=true; throw e;
  }

  async function applyCursorFromBlob(blob,name){
    curStatus('Processing…');
    try{
      let dataUrl,bgDone=false;
      if(blob.type==='image/gif'){                    // keep animation, no canvas
        dataUrl=await _blobToDataURL(blob);
        curStatus('GIF kept as-is (animated).','#16a34a');
      }else{
        if(blob.type && !blob.type.startsWith('image/')) throw new Error('This link is a web page, not an image. Long-press the image → copy image address, or use Upload.');
        const im=await _blobToImage(blob);
        const r=processCursorImage(im,!!cursorAutoBg?.checked);
        dataUrl=r.dataUrl; bgDone=r.bgDone;
        curStatus(bgDone?'Done ✓ resized + background removed.'
          :(cursorAutoBg?.checked?'Resized. Background not removed (already transparent or too busy).':'Resized.'),
          bgDone?'#16a34a':'#b45309');
      }
      await chrome.storage.local.set({zen_cursor_img:dataUrl,zen_cursor_name:name||'image'});
      updateCursorLabel(name||'image');
      showPreview(dataUrl);
      await addHist(dataUrl,name);
      return true;
    }catch(err){
      curStatus('Failed: '+(err?.message||err),'#dc2626');
      return false;
    }
  }

  if(cursorSw){
    chrome.storage.local.get(['zen_cursor_img','zen_cursor_name','zen_cursor_size'],d=>{
      curPx=parseInt(d.zen_cursor_size,10)||28;
      if(cursorSize) cursorSize.value=curPx; if(cursorSizeVal) cursorSizeVal.textContent=curPx+'px';
      renderHist();
      const src=d.zen_cursor_img||'';
      const on=!!src;
      cursorSw.checked=on;
      if(cursorBox) cursorBox.style.display=on?'block':'none';
      if(cursorUrlInput && src && !src.startsWith('data:')) cursorUrlInput.value=src;
      updateCursorLabel(on?(d.zen_cursor_name||'image'):'');
      if(on){ showPreview(src); curStatus('Custom cursor active.'); }
    });
    cursorSw.addEventListener('change',()=>{
      if(cursorBox) cursorBox.style.display=cursorSw.checked?'block':'none';
      if(!cursorSw.checked){
        chrome.storage.local.set({zen_cursor_img:'',zen_cursor_name:''});
        if(cursorUrlInput) cursorUrlInput.value='';
        updateCursorLabel('');
        curStatus('No custom cursor yet.');
      }
    });
  }
  if(cursorSaveBtn){
    cursorSaveBtn.addEventListener('click',async()=>{
      const url=(cursorUrlInput?.value||'').trim();
      if(!url) return;
      cursorSaveBtn.disabled=true; curStatus('Downloading…');
      let ok=false;
      try{
        const blob=await _resolveImageBlob(url);
        ok=await applyCursorFromBlob(blob,url.split('?')[0].split('/').pop()||'image');
      }catch(e){
        if(e&&e.notImg){ curStatus(e.message,'#dc2626'); }
        else{
          // network/CORS failure → keep raw link, browser scales it to 28px
          await chrome.storage.local.set({zen_cursor_img:url,zen_cursor_name:url.split('/').pop()});
          updateCursorLabel(url.split('/').pop()); showPreview(url); await addHist(url,url.split('/').pop());
          curStatus('Link saved, but download was blocked so auto-resize / bg remove was skipped. Try Upload instead.','#b45309');
          ok=true;
        }
      }
      cursorSaveBtn.disabled=false;
      if(ok){ cursorSaveBtn.textContent='Saved ✓'; setTimeout(()=>{ cursorSaveBtn.textContent='Apply'; },1500); }
    });
  }
  if(cursorUploadBtn&&cursorFile){
    cursorUploadBtn.addEventListener('click',()=>cursorFile.click());
    cursorFile.addEventListener('change',async()=>{
      const f=cursorFile.files&&cursorFile.files[0];
      if(!f) return;
      if(cursorUrlInput) cursorUrlInput.value='';
      await applyCursorFromBlob(f,f.name);
      cursorFile.value='';
    });
  }
  if(cursorSize){
    cursorSize.addEventListener('input',()=>{
      curPx=Math.max(16,Math.min(64,parseInt(cursorSize.value,10)||28));
      if(cursorSizeVal) cursorSizeVal.textContent=curPx+'px';
      chrome.storage.local.set({zen_cursor_size:curPx});
      const c=cursorPrev&&cursorPrev.getContext('2d'); if(c) c.clearRect(0,0,128,128);
      showPreview();
    });
  }
  if(cursorClearBtn){
    cursorClearBtn.addEventListener('click',()=>{
      chrome.storage.local.set({zen_cursor_img:'',zen_cursor_name:''});
      if(cursorUrlInput) cursorUrlInput.value='';
      if(cursorSw) cursorSw.checked=false;
      if(cursorBox) cursorBox.style.display='none';
      if(cursorPrev) cursorPrev.getContext('2d').clearRect(0,0,128,128); curSrc=''; renderHist();
      updateCursorLabel('');
      curStatus('No custom cursor yet.');
    });
  }

  // ── ZEN RAG — Trained Styles + My Style Examples ──────────────
  const ragTweetInput  = document.getElementById('ragTweetInput');
  const ragReplyInput  = document.getElementById('ragReplyInput');
  const ragSaveBtn     = document.getElementById('ragSaveBtn');
  const ragExampleList = document.getElementById('ragExampleList');
  const ragEmptyHint   = document.getElementById('ragEmptyHint');
  const styleChipsRow  = document.getElementById('styleChipsRow');
  const newStyleRow    = document.getElementById('newStyleRow');
  const newStyleNameInput   = document.getElementById('newStyleNameInput');
  const newStyleConfirmBtn  = document.getElementById('newStyleConfirmBtn');
  const newStyleCancelBtn   = document.getElementById('newStyleCancelBtn');
  const ragActiveStyleBadge = document.getElementById('ragActiveStyleBadge');

  // null = the original "Default" pool (zenStyleExamples); otherwise a
  // zenTrainedStyles id. Loaded from storage below, kept in sync with it.
  let _activeStyleId = null;

  // Pulls the examples array for whichever style is active, from an
  // already-fetched storage object.
  function _activeExamplesFrom(d) {
    if (_activeStyleId) {
      const st = (d.zenTrainedStyles || []).find(s => s.id === _activeStyleId);
      if (st) return st.examples || [];
    }
    return d.zenStyleExamples || [];
  }

  function _activeStyleNameFrom(d) {
    if (_activeStyleId) {
      const st = (d.zenTrainedStyles || []).find(s => s.id === _activeStyleId);
      if (st) return st.name;
    }
    return 'Default';
  }

  // Writes a full examples array back to wherever the active style lives.
  function _writeActiveExamples(examplesArr, cb) {
    if (_activeStyleId) {
      chrome.storage.local.get(['zenTrainedStyles'], d => {
        const styles = d.zenTrainedStyles || [];
        const idx = styles.findIndex(s => s.id === _activeStyleId);
        if (idx === -1) { if (cb) cb(); return; }
        const updated = styles.slice();
        updated[idx] = { ...styles[idx], examples: examplesArr };
        chrome.storage.local.set({ zenTrainedStyles: updated }, () => { if (cb) cb(); });
      });
    } else {
      chrome.storage.local.set({ zenStyleExamples: examplesArr }, () => { if (cb) cb(); });
    }
  }

  // Smart match toggle (storage.zenRagMode: 'smart' | 'random'). Needs >= 1 saved example.
  const ragSmartToggle = document.getElementById('ragSmartToggle');
  const ragSmartRow    = document.getElementById('ragSmartRow');
  function ragSyncSmart(n) {
    if (!ragSmartToggle) return;
    ragSmartToggle.disabled = !(n > 0);
    if (ragSmartRow) ragSmartRow.style.opacity = n > 0 ? '1' : '.5';
  }
  if (ragSmartToggle) {
    chrome.storage.local.get(['zenRagMode'], d => { ragSmartToggle.checked = d.zenRagMode === 'smart'; });
    ragSmartToggle.addEventListener('change', () => {
      chrome.storage.local.set({ zenRagMode: ragSmartToggle.checked ? 'smart' : 'random' });
    });
  }

  function renderRagExamples(examples) {
    if (!ragExampleList) return;
    ragSyncSmart(examples ? examples.length : 0);
    ragExampleList.innerHTML = '';
    if (!examples || examples.length === 0) {
      if (ragEmptyHint) ragEmptyHint.style.display = 'block';
      return;
    }
    if (ragEmptyHint) ragEmptyHint.style.display = 'none';
    examples.forEach((ex, i) => {
      const row = document.createElement('div');
      row.style.cssText = 'background:#f7f7f6;border-radius:7px;padding:7px 9px;font-size:11px;position:relative;border:1px solid #eee;';
      row.innerHTML = `
        <div style="color:#555;margin-bottom:3px;padding-right:20px;"><b style="color:#222;">Tweet:</b> ${ex.tweet.slice(0,80)}${ex.tweet.length>80?'…':''}</div>
        <div style="color:#0066ff;"><b style="color:#222;">Reply:</b> ${ex.myReply.slice(0,80)}${ex.myReply.length>80?'…':''}</div>
        <button data-idx="${i}" style="position:absolute;top:6px;right:7px;background:none;border:none;cursor:pointer;font-size:14px;color:#bbb;padding:0;line-height:1;">✕</button>`;
      row.querySelector('button').addEventListener('click', (e) => {
        const idx = +e.currentTarget.dataset.idx;
        const arr = examples.filter((_, j) => j !== idx);
        _writeActiveExamples(arr, () => renderRagExamples(arr));
      });
      ragExampleList.appendChild(row);
    });
  }

  // ── Trained Styles chip row ───────────────────────────────────
  function renderStyleChips() {
    if (!styleChipsRow) return;
    chrome.storage.local.get(['zenTrainedStyles'], d => {
      const styles = d.zenTrainedStyles || [];
      styleChipsRow.innerHTML = '';

      const defaultChip = document.createElement('button');
      defaultChip.className = 'style-chip' + (!_activeStyleId ? ' active' : '');
      defaultChip.textContent = 'Default';
      defaultChip.addEventListener('click', () => selectStyle(null));
      styleChipsRow.appendChild(defaultChip);

      styles.forEach(st => {
        const chip = document.createElement('button');
        chip.className = 'style-chip' + (_activeStyleId === st.id ? ' active' : '');
        chip.innerHTML = `<span>${st.name}</span><span class="style-chip-del" data-id="${st.id}">✕</span>`;
        chip.addEventListener('click', (e) => {
          if (e.target.classList.contains('style-chip-del')) return; // handled below
          selectStyle(st.id);
        });
        chip.querySelector('.style-chip-del').addEventListener('click', (e) => {
          e.stopPropagation();
          if (!confirm(`Delete trained style "${st.name}"? Its ${ (st.examples||[]).length } example(s) will be lost.`)) return;
          const remaining = styles.filter(s => s.id !== st.id);
          chrome.storage.local.set({ zenTrainedStyles: remaining }, () => {
            if (_activeStyleId === st.id) _activeStyleId = null;
            chrome.storage.local.set({ zenActiveStyleId: _activeStyleId }, () => {
              renderStyleChips();
              chrome.storage.local.get(['zenTrainedStyles', 'zenStyleExamples'], dd => {
                renderRagExamples(_activeExamplesFrom(dd));
                if (ragActiveStyleBadge) ragActiveStyleBadge.textContent = '· ' + _activeStyleNameFrom(dd);
              });
            });
          });
        });
        styleChipsRow.appendChild(chip);
      });

      const newChip = document.createElement('button');
      newChip.className = 'style-chip-new';
      newChip.textContent = '＋ New';
      newChip.addEventListener('click', () => {
        if (newStyleRow) newStyleRow.style.display = 'flex';
        if (newStyleNameInput) newStyleNameInput.focus();
      });
      styleChipsRow.appendChild(newChip);
    });
  }

  function selectStyle(id) {
    _activeStyleId = id;
    chrome.storage.local.set({ zenActiveStyleId: id }, () => {
      renderStyleChips();
      chrome.storage.local.get(['zenTrainedStyles', 'zenStyleExamples'], d => {
        renderRagExamples(_activeExamplesFrom(d));
        if (ragActiveStyleBadge) ragActiveStyleBadge.textContent = '· ' + _activeStyleNameFrom(d);
      });
    });
  }

  if (newStyleConfirmBtn) {
    newStyleConfirmBtn.addEventListener('click', () => {
      const name = newStyleNameInput?.value.trim() || '';
      if (!name) { newStyleNameInput?.focus(); return; }
      chrome.storage.local.get(['zenTrainedStyles'], d => {
        const styles = d.zenTrainedStyles || [];
        const id = 'style_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
        const updated = [...styles, { id, name, examples: [] }];
        chrome.storage.local.set({ zenTrainedStyles: updated }, () => {
          if (newStyleNameInput) newStyleNameInput.value = '';
          if (newStyleRow) newStyleRow.style.display = 'none';
          selectStyle(id);
        });
      });
    });
  }
  if (newStyleCancelBtn) {
    newStyleCancelBtn.addEventListener('click', () => {
      if (newStyleNameInput) newStyleNameInput.value = '';
      if (newStyleRow) newStyleRow.style.display = 'none';
    });
  }

  // Load active style + its chips + its examples on open
  chrome.storage.local.get(['zenActiveStyleId', 'zenTrainedStyles', 'zenStyleExamples'], d => {
    _activeStyleId = d.zenActiveStyleId || null;
    // If the previously-active style was deleted elsewhere, fall back to Default.
    if (_activeStyleId && !(d.zenTrainedStyles || []).some(s => s.id === _activeStyleId)) {
      _activeStyleId = null;
    }
    renderStyleChips();
    renderRagExamples(_activeExamplesFrom(d));
    if (ragActiveStyleBadge) ragActiveStyleBadge.textContent = '· ' + _activeStyleNameFrom(d);
  });

  if (ragSaveBtn) {
    ragSaveBtn.addEventListener('click', () => {
      const tweet = ragTweetInput?.value.trim() || '';
      const myReply = ragReplyInput?.value.trim() || '';
      if (!tweet || !myReply) {
        ragSaveBtn.textContent = '⚠ Fill both fields';
        setTimeout(() => { ragSaveBtn.textContent = '＋ Save Example'; }, 1500);
        return;
      }
      chrome.storage.local.get(['zenTrainedStyles', 'zenStyleExamples'], d => {
        const arr = [..._activeExamplesFrom(d), { tweet, myReply }];
        _writeActiveExamples(arr, () => {
          renderRagExamples(arr);
          if (ragTweetInput) ragTweetInput.value = '';
          if (ragReplyInput) ragReplyInput.value = '';
          ragSaveBtn.textContent = 'Saved ✓';
          setTimeout(() => { ragSaveBtn.textContent = '＋ Save Example'; }, 1500);
        });
      });
    });
  }

  // ── Export Style ─────────────────────────────────────────────
  // Downloads the ACTIVE style's examples as JSON — embeddings stripped
  // so the file is clean and re-generates automatically on next use.
  const ragExportBtn = document.getElementById('ragExportBtn');
  if (ragExportBtn) {
    ragExportBtn.addEventListener('click', () => {
      chrome.storage.local.get(['zenTrainedStyles', 'zenStyleExamples'], d => {
        const examples = _activeExamplesFrom(d).map(({ tweet, myReply }) => ({ tweet, myReply }));
        if (!examples.length) {
          ragExportBtn.textContent = '⚠ No examples';
          setTimeout(() => { ragExportBtn.textContent = '⬇ Export Style'; }, 1500);
          return;
        }
        const name = _activeStyleNameFrom(d);
        const blob = new Blob([JSON.stringify(examples, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `zen_style_${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}.json`;
        a.click();
        URL.revokeObjectURL(url);
        ragExportBtn.textContent = 'Exported ✓';
        setTimeout(() => { ragExportBtn.textContent = '⬇ Export Style'; }, 1800);
      });
    });
  }

  // ── Import Style ─────────────────────────────────────────────
  // Reads a JSON file and merges into the ACTIVE style's examples.
  // Only {tweet, myReply} fields accepted — embeddings stripped/ignored.
  const ragImportInput = document.getElementById('ragImportInput');
  if (ragImportInput) {
    ragImportInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const label = document.getElementById('ragImportLabel');
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const parsed = JSON.parse(ev.target.result);
          if (!Array.isArray(parsed)) throw new Error('Not an array');
          const incoming = parsed
            .filter(item => item && typeof item.tweet === 'string' && typeof item.myReply === 'string')
            .map(({ tweet, myReply }) => ({ tweet: tweet.trim(), myReply: myReply.trim() }))
            .filter(({ tweet, myReply }) => tweet && myReply);
          if (!incoming.length) throw new Error('No valid entries');
          chrome.storage.local.get(['zenTrainedStyles', 'zenStyleExamples'], d => {
            const existing = _activeExamplesFrom(d);
            const existingKeys = new Set(existing.map(x => x.tweet + '|||' + x.myReply));
            const merged = [...existing, ...incoming.filter(x => !existingKeys.has(x.tweet + '|||' + x.myReply))];
            _writeActiveExamples(merged, () => {
              renderRagExamples(merged);
              const added = merged.length - existing.length;
              if (label) { label.dataset.orig = label.dataset.orig || label.textContent.trim(); label.textContent = 'Imported ' + added + ' ✓'; }
              setTimeout(() => { if (label) label.textContent = '⬆ Import'; }, 1800);
            });
          });
        } catch (err) {
          if (label) { label.textContent = '⚠ Invalid file'; }
          setTimeout(() => { if (label) label.textContent = '⬆ Import'; }, 1800);
        }
        ragImportInput.value = '';
      };
      reader.readAsText(file);
    });
  }


  // ── Recent Generated Replies ──────────────────────────────────
  // All replies generated by GET Reply are auto-saved to zenRecentReplies
  // in content.js. Here we render them so the user can review and save
  // the good ones as style examples without relying on the 6s toast bar.
  const ragRecentSection = document.getElementById('ragRecentSection');
  const ragRecentList    = document.getElementById('ragRecentList');
  const ragRecentClearBtn = document.getElementById('ragRecentClearBtn');

  function renderRecentReplies(items) {
    if (!ragRecentList) return;
    ragRecentList.innerHTML = '';

    if (!items || items.length === 0) {
      if (ragRecentSection) ragRecentSection.style.display = 'none';
      return;
    }
    if (ragRecentSection) ragRecentSection.style.display = 'block';

    items.forEach((item, i) => {
      const row = document.createElement('div');
      row.style.cssText = 'background:#f0f4ff;border-radius:7px;padding:7px 9px;font-size:11px;border:1px solid #dde5ff;position:relative;';

      const age = (() => {
        const diff = Date.now() - (item.ts || 0);
        if (diff < 60000)   return 'just now';
        if (diff < 3600000) return Math.floor(diff / 60000) + 'm ago';
        if (diff < 86400000) return Math.floor(diff / 3600000) + 'h ago';
        return Math.floor(diff / 86400000) + 'd ago';
      })();

      row.innerHTML = `
        <div style="color:#555;margin-bottom:3px;padding-right:20px;"><b style="color:#222;">Tweet:</b> ${item.tweet.slice(0,90)}${item.tweet.length > 90 ? '…' : ''}</div>
        <div style="color:#0044cc;margin-bottom:5px;"><b style="color:#222;">Reply:</b> ${item.myReply.slice(0,90)}${item.myReply.length > 90 ? '…' : ''}</div>
        <div style="display:flex;align-items:center;gap:5px;">
          <button data-idx="${i}" data-action="save"
            style="flex:1;padding:4px 0;border-radius:5px;border:none;background:#0066ff;color:#fff;font-size:10px;font-weight:600;cursor:pointer;">✓ Save as Example</button>
          <button data-idx="${i}" data-action="dismiss"
            style="padding:4px 8px;border-radius:5px;border:1px solid #ddd;background:#fff;color:#999;font-size:10px;cursor:pointer;">✕</button>
        </div>
        <span style="position:absolute;top:6px;right:8px;font-size:9px;color:#bbb;">${age}</span>`;

      row.querySelectorAll('button[data-action]').forEach(btn => {
        btn.addEventListener('click', () => {
          const idx = +btn.dataset.idx;
          const action = btn.dataset.action;
          chrome.storage.local.get(['zenRecentReplies', 'zenTrainedStyles', 'zenStyleExamples'], d => {
            const recent = d.zenRecentReplies || [];
            const entry  = recent[idx];
            if (!entry) return;

            if (action === 'save') {
              const examples = [..._activeExamplesFrom(d), { tweet: entry.tweet, myReply: entry.myReply }];
              if (examples.length > 50) examples.splice(0, examples.length - 50);
              _writeActiveExamples(examples, () => renderRagExamples(examples));
              btn.textContent = 'Saved ✓';
              btn.style.background = '#00a862';
              setTimeout(() => {
                const newRecent = recent.filter((_, j) => j !== idx);
                chrome.storage.local.set({ zenRecentReplies: newRecent }, () => renderRecentReplies(newRecent));
              }, 800);
            } else {
              const newRecent = recent.filter((_, j) => j !== idx);
              chrome.storage.local.set({ zenRecentReplies: newRecent }, () => renderRecentReplies(newRecent));
            }
          });
        });
      });

      ragRecentList.appendChild(row);
    });
  }

  // Load on open
  chrome.storage.local.get(['zenRecentReplies'], d => renderRecentReplies(d.zenRecentReplies || []));

  if (ragRecentClearBtn) {
    ragRecentClearBtn.addEventListener('click', () => {
      chrome.storage.local.set({ zenRecentReplies: [] }, () => renderRecentReplies([]));
    });
  }

  // ── AI Process Log toggle (terminal readout on X) ──
  const procLogSw=document.getElementById('procLogSwitch');
  const procLogLbl=document.getElementById('procLogLabel');
  function renderProcLog(on){ if(procLogLbl) procLogLbl.textContent=on?'ON — Show terminal readout while generating':'OFF — Hidden (no readout while generating)'; }
  if(procLogSw){
    chrome.storage.local.get(['zexProcLog'],d=>{ const on=d.zexProcLog===true; procLogSw.checked=on; renderProcLog(on); });
    procLogSw.addEventListener('change',()=>{ chrome.storage.local.set({zexProcLog:procLogSw.checked}); renderProcLog(procLogSw.checked); });
  }

  // ── Human Typing Mode toggle + style (Style | Live) ──
  const typingSw=document.getElementById('humanTypingSwitch');
  const typingStyleBox=document.getElementById('typingStyleBox');
  const tsBtnStyle=document.getElementById('typeStyleBtnStyle');
  const tsBtnLive=document.getElementById('typeStyleBtnLive');
  const tsHint=document.getElementById('typeStyleHint');
  function renderTypingStyle(style,on){
    if(typingStyleBox) typingStyleBox.style.display=on?'block':'none';
    const act='border:1.5px solid #0066ff;background:#eef4ff;color:#0066ff;';
    const off='border:1.5px solid #ddd;background:#fff;color:#444;';
    const base='flex:1;padding:9px 6px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;';
    if(tsBtnStyle) tsBtnStyle.style.cssText=base+(style==='live'?off:act);
    if(tsBtnLive) tsBtnLive.style.cssText=base+(style==='live'?act:off);
    if(tsHint) tsHint.textContent = style==='live'
      ? 'YEAH, I\'m the Live feature, just turn me on and enjoy my streaming power! And if I fail, my brother Style is set automatically. One more thing: Style is my little brother.'
      : 'Style is not a safety feature, it is just a visual style (uneven speed, pauses after words and sentences, max ~9s). If you need actual typing, look at my right side: Live.';
  }
  if(typingSw){
    chrome.storage.local.get(['zen_type_mode','zen_type_style'],d=>{
      const on=d.zen_type_mode===true;
      const style=d.zen_type_style==='live'?'live':'style';
      typingSw.checked=on;
      updateHumanTypingLabel(on);
      renderTypingStyle(style,on);
    });
    typingSw.addEventListener('change',()=>{
      chrome.storage.local.set({zen_type_mode:typingSw.checked});
      updateHumanTypingLabel(typingSw.checked);
      chrome.storage.local.get(['zen_type_style'],d=>renderTypingStyle(d.zen_type_style==='live'?'live':'style',typingSw.checked));
    });
    const setTS=s=>{ chrome.storage.local.set({zen_type_style:s}); renderTypingStyle(s,typingSw.checked); };
    if(tsBtnStyle) tsBtnStyle.addEventListener('click',()=>setTS('style'));
    if(tsBtnLive) tsBtnLive.addEventListener('click',()=>setTS('live'));
  }
  document.querySelectorAll('.scheme-chip').forEach(btn=>{
    btn.addEventListener('click',()=>{
      document.querySelectorAll('.scheme-chip').forEach(b=>b.classList.remove('active')); btn.classList.add('active');
    });
  });
  const proxySw=document.getElementById('proxyEnableSwitch');
  if(proxySw)proxySw.addEventListener('change',()=>updateProxyEnableLabel(proxySw.checked));
  const warpBtn=document.getElementById('warpQuickSetupBtn');
  if(warpBtn)warpBtn.addEventListener('click',()=>{
    document.querySelectorAll('.scheme-chip').forEach(b=>b.classList.toggle('active',b.dataset.scheme==='socks5'));
    const h=document.getElementById('proxyHost'); if(h)h.value='127.0.0.1';
    const p=document.getElementById('proxyPort'); if(p)p.value='40000';
    if(proxySw){proxySw.checked=true;updateProxyEnableLabel(true);}
    const hint=document.getElementById('warpQuickSetupHint');
    if(hint)hint.innerHTML='Filled in! Make sure Cloudflare WARP\'s <b>Proxy Mode</b> is turned ON on this device, then tap "SAVE ALL SETTINGS" below.';
    if(typeof saveAll==='function')saveAll();
  });
});

// ══════════════════════════════════════════════════════════════
// Z. v2 AUTH — Login / Register / Verify / Pending (Step 2)
// Firebase Auth (email+password, Google) + admin approval gate.
// Session shape kept: zenDeviceSession {email,loginTime,expiresAt,uid,xHandle,tgHandle}
// ══════════════════════════════════════════════════════════════
let zPollTimer = null, zGateKey = '', zRouting = false, zGoogleWaiting = false, zVerifySentAt = 0;

function zEl(id){ return document.getElementById(id); }
function zStopPoll(){ if(zPollTimer){ clearInterval(zPollTimer); zPollTimer=null; } }

function zFriendly(e){
  const c = String((e && (e.code || e.message)) || '').split(' ')[0];
  const map = {
    EMAIL_EXISTS: 'An account already exists with this email — please log in',
    BAD_CREDENTIALS: 'Wrong email or password',
    NOT_VERIFIED: 'Email not verified — enter the 6-digit code we sent you',
    DISABLED: 'This account has been disabled',
    RATE_LIMIT: 'Too many attempts — try again later',
    BAD_CODE: 'Wrong code — check and try again',
    CODE_EXPIRED: 'Code expired — tap RESEND CODE',
    WEAK_PASSWORD: 'Password must be at least 8 characters',
    BAD_EMAIL: 'Enter a valid email',
    MAIL_FAILED: 'Could not send the email — try again in a minute',
    MAIL_NOT_CONFIGURED: 'Email sending is not set up yet — use Google login',
    SIGNUP_CLOSED: 'Sign-ups are closed right now',
    BAD_GOOGLE_TOKEN: 'Google sign-in failed — try again',
    INVALID_REFRESH: 'Session expired — please log in again',
    FIREBASE_LOGIN_OFF: 'Please log in again',
    NETWORK_ERROR: 'No connection — check your internet',
    GOOGLE_CANCELLED: 'Google sign-in was cancelled',
    GOOGLE_TIMEOUT: 'Google sign-in timed out — try again',
    GOOGLE_NO_TOKEN: 'Google sign-in failed — try again',
    GOOGLE_NONCE_MISMATCH: 'Google sign-in failed — try again',
    NOT_SIGNED_IN: 'Session expired — please log in again'
  };
  if (map[c]) return map[c];
  if (/redirect_uri_mismatch/i.test(c)) return 'Google redirect URI mismatch (check Google Cloud Console)';
  if (/access_denied/i.test(c)) return 'Google sign-in was cancelled';
  return 'Something went wrong (' + (c || 'unknown') + ')';
}

// Call the Worker through the background bridge (it attaches the token). -> {ok, data} | {ok:false, error}
function zexpayCall(path, method, body){
  return new Promise(function(resolve){
    try {
      chrome.runtime.sendMessage({ type:'zexpayCall', path:path, method:method||'GET', body:body }, function(res){
        if (chrome.runtime.lastError || !res) return resolve({ ok:false, error:'NETWORK' });
        resolve(res);
      });
    } catch(e){ resolve({ ok:false, error:'NETWORK' }); }
  });
}
// ── App config from the Worker (offer, tab gate, global notice, contact) — one fetch shared by popup scripts ──
let _zCfg = null, _zCfgAt = 0, _zCfgP = null;
function zAppConfig(force){
  if (!force && _zCfg && Date.now()-_zCfgAt < 30000) return Promise.resolve(_zCfg);
  if (_zCfgP) return _zCfgP;
  _zCfgP = zexpayCall('/v1/app-config','GET').then(r=>{
    if (r.ok && r.data){ _zCfg = r.data; _zCfgAt = Date.now(); return _zCfg; }
    return null;      // failure: callers keep what they showed before
  }).catch(()=>null).then(v=>{ _zCfgP=null; return v; });
  return _zCfgP;
}

// Profile (x, xVerified, tg, tgVerified, autoLogoutMinutes ...) from the Worker. null on failure.
async function zProfileGet(){
  const r = await zexpayCall('/v1/profile','GET');
  return (r.ok && r.data && r.data.profile) ? r.data.profile : null;
}

function zShowLoginPage(){
  zEl('loginPage').style.display='flex';
  zEl('dashboard').style.display='none';
  zEl('verifyPage').style.display='none';
}

function switchTab(tab){
  zStopPoll(); zGateKey='';
  const g=zEl('gateScreen'); if(g) g.style.display='none';
  const tr=zEl('loginTabsRow'); if(tr) tr.style.display='flex';
  ['login','register'].forEach(t=>{
    const f=zEl(t+'Form'); const tb=zEl('tab'+t.charAt(0).toUpperCase()+t.slice(1));
    if(f) f.style.display = t===tab ? 'block' : 'none';
    if(tb) tb.classList.toggle('tab-active', t===tab);
  });
  ['loginErr','registerErr'].forEach(id=>{ const e=zEl(id); if(e) e.textContent=''; });
  const li=zEl('loginInfo'); if(li) li.style.display='none';
}

// ── Gate screen (code / reset / pending / expired / disabled / error) ──
function showGate(kind, opts){
  opts = opts || {};
  const key = kind + '|' + (opts.email || '');
  const gs = zEl('gateScreen');
  if (zGateKey === key && gs && gs.style.display === 'block') return;
  zStopPoll(); zGateKey = key;
  zShowLoginPage();
  zEl('loginTabsRow').style.display='none';
  zEl('loginForm').style.display='none';
  zEl('registerForm').style.display='none';
  gs.style.display='block';
  const T=zEl('gateTitle'), M=zEl('gateMsg'), R=zEl('gateReason'), D=zEl('gateDots'), E=zEl('gateErr'), P=zEl('gatePrimaryBtn'), S=zEl('gateSecondaryBtn');
  const CW=zEl('gateCodeWrap'), CI=zEl('gateCode'), NP=zEl('gateNewPw');
  zEl('gateEmail').textContent = opts.email || '';
  E.textContent=''; E.style.color=''; R.style.display='none'; D.style.display='none'; P.style.display='none'; S.style.display='none';
  if (CW) CW.style.display='none'; if (CI) CI.value=''; if (NP) { NP.value=''; NP.style.display='none'; }
  P.onclick=null; S.onclick=null; P.disabled=false; S.disabled=false;
  let pollMs = 0;
  if (kind==='code'){
    T.textContent='ENTER YOUR CODE'; T.style.color='#b45309';
    M.innerHTML='We sent a 6-digit code to your email.<br>Type it below. (Check spam too.)';
    if (CW) CW.style.display='block';
    P.textContent='VERIFY'; P.style.display='block'; P.onclick=()=>zSubmitCode(opts.email);
    S.textContent='RESEND CODE'; S.style.display='block'; S.onclick=()=>zResendCode(opts.email,'verify');
  } else if (kind==='reset'){
    T.textContent='RESET PASSWORD'; T.style.color='#b45309';
    M.innerHTML='If this email has an account, we sent a 6-digit code.<br>Enter it and choose a new password.';
    if (CW) CW.style.display='block'; if (NP) NP.style.display='block';
    P.textContent='SET NEW PASSWORD'; P.style.display='block'; P.onclick=()=>zSubmitReset(opts.email);
    S.textContent='RESEND CODE'; S.style.display='block'; S.onclick=()=>zResendCode(opts.email,'reset');
  } else if (kind==='pending'){
    T.textContent='WAITING FOR APPROVAL'; T.style.color='#b45309';
    M.innerHTML="Your account is waiting for Admin's approval.<br>Auto-checking... (If you were approved before and still see this, contact Admin.)";
    D.style.display='flex'; pollMs=8000;
  } else if (kind==='expired'){
    T.textContent='SUBSCRIPTION ENDED'; T.style.color='#dc2626';
    M.textContent='Your access has expired. Contact Admin to renew, then check again.';
    P.textContent='CHECK AGAIN'; P.style.display='block'; P.onclick=()=>zRoute(true);
    pollMs=15000;
  } else if (kind==='disabled'){
    T.textContent='ACCOUNT DISABLED'; T.style.color='#dc2626';
    M.textContent='Your account is disabled. Contact Admin.';
    P.textContent='CHECK AGAIN'; P.style.display='block'; P.onclick=()=>zRoute(true);
    pollMs=15000;
  } else if (kind==='error'){
    T.textContent='CONNECTION PROBLEM'; T.style.color='#dc2626';
    M.textContent='Could not reach the server. Check your internet and retry.';
    P.textContent='RETRY'; P.style.display='block'; P.onclick=()=>zRoute(true);
  }
  P.style.background=''; P.style.borderColor=''; P.style.color='';
  if (pollMs) zPollTimer = setInterval(()=>{ if(!zRouting) zRoute(false); }, pollMs);
}

async function zSubmitCode(email){
  const E=zEl('gateErr'), P=zEl('gatePrimaryBtn');
  const code=String(zEl('gateCode')?.value||'').replace(/\D/g,'');
  E.style.color=''; E.textContent='';
  if(code.length!==6){ E.textContent='Enter the 6-digit code'; return; }
  if(!checkInternet()){ E.textContent='No internet connection!'; return; }
  P.disabled=true;
  try { await zVerifyCode(email, code); }
  catch(e){ E.textContent=zFriendly(e); P.disabled=false; return; }
  P.disabled=false; zGateKey='';
  await zRoute(true);
}

async function zSubmitReset(email){
  const E=zEl('gateErr'), P=zEl('gatePrimaryBtn');
  const code=String(zEl('gateCode')?.value||'').replace(/\D/g,''); const pw=zEl('gateNewPw')?.value||'';
  E.style.color=''; E.textContent='';
  if(code.length!==6){ E.textContent='Enter the 6-digit code'; return; }
  if(pw.length<8){ E.textContent=zFriendly({code:'WEAK_PASSWORD'}); return; }
  if(!checkInternet()){ E.textContent='No internet connection!'; return; }
  P.disabled=true;
  try { await zResetPassword(email, code, pw); }
  catch(e){ E.textContent=zFriendly(e); P.disabled=false; return; }
  P.disabled=false;
  showLogin();
  const ei=zEl('emailInput'); if(ei) ei.value=email;
  const li=zEl('loginInfo'); if(li){ li.textContent='Password changed. Log in with your new password.'; li.style.display='block'; }
}

async function zResendCode(email, kind){
  const E=zEl('gateErr');
  if (Date.now()-zVerifySentAt < 30000){ E.style.color=''; E.textContent='Wait a little before resending'; return; }
  try {
    if (kind==='reset') await zSendPasswordReset(email); else await zSendVerifyEmail(email);
    zVerifySentAt=Date.now(); E.style.color='#16a34a'; E.textContent='Code sent — check your email';
    setTimeout(()=>{ if(E.textContent==='Code sent — check your email'){ E.textContent=''; E.style.color=''; } },4000);
  } catch(e){ E.style.color=''; E.textContent=zFriendly(e); }
}

// ── Central router: decides what the signed-in user sees (Worker /v1/me + /v1/profile) ──
const ZNO_EXPIRY_MS = 3650 * 86400000;   // access expiry is not enforced (info only), so the session never "ends" locally
async function zRoute(force){
  if (zRouting) return; zRouting = true;
  try {
    let a = await zGetSession();
    if (!a){ showLogin(); return; }
    if (!a.emailVerified){ showGate('code',{email:a.email}); return; }
    const r = await zexpayCall('/v1/me','GET');
    if (!r.ok){
      const er = String(r.error||'');
      if (['NO_AUTH','NO_TOKEN','BAD_TOKEN','BAD_SIGNATURE','TOKEN_EXPIRED','FIREBASE_LOGIN_OFF','UNKNOWN_KEY','WRONG_PROJECT','NO_EMAIL','HTTP_401'].indexOf(er)>-1){
        await zSignOut(); await chrome.storage.local.remove(['zenDeviceSession']); showLogin(); return;
      }
      // offline / server down: reuse the cached session
      const c = (await getStorage(['zenDeviceSession'])).zenDeviceSession;
      if (c && c.email===a.email){ zStopPoll(); zGateKey=''; if(!c.xHandle) showVerifyPage(c); else showDashboard(c); return; }
      showGate('error',{email:a.email}); return;
    }
    const me = r.data || {};
    if (me.lock_reason==='not_approved'){ await chrome.storage.local.remove(['zenDeviceSession']); showGate('pending',{email:a.email}); return; }
    if (me.lock_reason==='expired'){ await chrome.storage.local.remove(['zenDeviceSession']); showGate('expired',{email:a.email}); return; }
    const prof = await zProfileGet();
    const cached = (await getStorage(['zenDeviceSession'])).zenDeviceSession;
    const keep = (cached && cached.email===a.email) ? cached : null;
    const now = Date.now();
    const session = {
      email:a.email, loginTime:now, expiresAt:now+ZNO_EXPIRY_MS, noExpiry:true, expInfo:Number(me.expires_at)||0, uid:a.uid,
      xHandle: prof ? (prof.xVerified ? (prof.x||'') : '') : (keep ? keep.xHandle||'' : ''),
      tgHandle: prof ? (prof.tg||'') : (keep ? keep.tgHandle||'' : '')
    };
    await new Promise(res=>chrome.storage.local.set({zenDeviceSession:session}, res));
    zStopPoll(); zGateKey='';
    if (!session.xHandle) showVerifyPage(session); else showDashboard(session);
  } catch(e){
    console.error('zRoute', e);
    showGate('error',{});
  } finally { zRouting = false; }
}

// ── Handlers ──────────────────────────────────────────────────────
async function handleLogin(){
  const email=zEl('emailInput')?.value.trim().toLowerCase();
  const pw=zEl('pwInput')?.value;
  const errEl=zEl('loginErr'); const info=zEl('loginInfo'); if(info) info.style.display='none';
  errEl.textContent='';
  if(!email||!pw){ errEl.textContent='Enter your email and password'; return; }
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ errEl.textContent='Enter a valid email'; return; }
  if(!checkInternet()){ errEl.textContent='No internet connection!'; return; }
  errEl.textContent='Checking...';
  try { await zSignIn(email,pw); }
  catch(e){
    const p=zEl('pwInput'); if(p) p.value='';
    if (e && e.code==='NOT_VERIFIED'){ errEl.textContent=''; zVerifySentAt=Date.now(); showGate('code',{email:email}); return; }   // Worker re-sent a code
    errEl.textContent=zFriendly(e); return;
  }
  errEl.textContent='';
  await zRoute(true);
}

async function handleRegister(){
  const email=zEl('regEmail')?.value.trim().toLowerCase();
  const pw=zEl('regPassword')?.value;
  const pw2=zEl('regPasswordConfirm')?.value;
  const errEl=zEl('registerErr'); const btn=zEl('registerBtn');
  errEl.textContent='';
  if(!email){ errEl.textContent='Enter your email address'; return; }
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ errEl.textContent='Enter a valid email'; return; }
  if(!pw){ errEl.textContent='Set a password'; return; }
  if(pw.length<8){ errEl.textContent='Password must be at least 8 characters'; return; }
  if(pw!==pw2){ errEl.textContent='Passwords do not match'; return; }
  if(!checkInternet()){ errEl.textContent='No internet connection!'; return; }
  btn.disabled=true; const old=btn.textContent; btn.textContent='Creating...';
  try { await zSignUp(email,pw); zVerifySentAt=Date.now(); }
  catch(e){
    errEl.textContent=zFriendly(e); btn.disabled=false; btn.textContent=old; return;
  }
  btn.disabled=false; btn.textContent=old;
  ['regEmail','regPassword','regPasswordConfirm'].forEach(id=>{ const el=zEl(id); if(el) el.value=''; });
  showGate('code',{email:email});
}

async function handleForgot(){
  const email=zEl('emailInput')?.value.trim().toLowerCase();
  const errEl=zEl('loginErr'); const info=zEl('loginInfo');
  errEl.textContent=''; if(info) info.style.display='none';
  if(!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ errEl.textContent='Enter your email above first'; return; }
  if(!checkInternet()){ errEl.textContent='No internet connection!'; return; }
  try { await zSendPasswordReset(email); zVerifySentAt=Date.now(); }
  catch(e){ errEl.textContent=zFriendly(e); return; }
  showGate('reset',{email:email});
}

function handleGoogle(errId){
  const errEl=zEl(errId); if(errEl) errEl.textContent='';
  if(!checkInternet()){ if(errEl) errEl.textContent='No internet connection!'; return; }
  zGoogleWaiting = true;
  try {
    chrome.runtime.sendMessage({type:'zGoogleLogin'}, res=>{
      void chrome.runtime.lastError;
      if(res && res.ok===false){
        zGoogleWaiting=false;
        if(errEl) errEl.textContent=zFriendly({message:res.error});
      } else if(res && res.ok){ zGoogleWaiting=false; zRoute(true); }
    });
  } catch(e){ zGoogleWaiting=false; if(errEl) errEl.textContent=zFriendly(e); }
}

async function zForceLogout(){
  clearAutoLogout(); zStopPoll(); zGateKey='';
  clearInterval(countdownInterval); clearInterval(serverCheckInterval); clearInterval(clockInterval);
  // tell background to remove this device from the admin's device list (needs token, so before sign-out)
  try { await Promise.race([new Promise(r=>chrome.runtime.sendMessage({type:'zDevLogout'}, ()=>{ void chrome.runtime.lastError; r(); })), new Promise(r=>setTimeout(r,2500))]); } catch(e){}
  await zSignOut();
  await new Promise(r=>chrome.storage.local.remove(['zenDeviceSession','zexpayMe','zexpayIntent'], r));
  if(window.ZP) window.ZP.clear();
  showLogin();
}
function handleLogout(){ zForceLogout(); }

function zBindAuthUI(){
  zEl('tabLogin')?.addEventListener('click',()=>switchTab('login'));
  zEl('tabRegister')?.addEventListener('click',()=>switchTab('register'));
  zEl('loginBtn')?.addEventListener('click',()=>{
    const btn=zEl('loginBtn');
    if(btn){
      const original=btn.textContent;
      zenScrambleText(btn,'VERIFYING...',{speed:22,startSpread:4,settleSpread:8,onDone:()=>{
        btn._zenAccessRestoreTimer && clearTimeout(btn._zenAccessRestoreTimer);
        btn._zenAccessRestoreTimer=setTimeout(()=>{ if(!btn._zenScrambleTimer) zenScrambleText(btn,original,{speed:22}); },1400);
      }});
    }
    handleLogin();
  });
  zEl('emailInput')?.addEventListener('keypress',e=>{ if(e.key==='Enter') zEl('pwInput')?.focus(); });
  zEl('pwInput')?.addEventListener('keypress',e=>{ if(e.key==='Enter') handleLogin(); });
  zEl('pwEye')?.addEventListener('click',()=>{ const i=zEl('pwInput'); if(i) i.type=i.type==='password'?'text':'password'; });
  zEl('forgotBtn')?.addEventListener('click',handleForgot);
  zEl('googleLoginBtn')?.addEventListener('click',()=>handleGoogle('loginErr'));
  zEl('registerBtn')?.addEventListener('click',handleRegister);
  zEl('regPasswordConfirm')?.addEventListener('keypress',e=>{ if(e.key==='Enter') handleRegister(); });
  zEl('regPwEye')?.addEventListener('click',()=>{ const i=zEl('regPassword'); if(i) i.type=i.type==='password'?'text':'password'; });
  zEl('googleRegBtn')?.addEventListener('click',()=>handleGoogle('registerErr'));
  zEl('gateSignOutBtn')?.addEventListener('click',zForceLogout);
  // Google runs in background; popup only listens for the session to appear
  chrome.storage.onChanged.addListener((ch,area)=>{
    if(area==='local' && ch.zAuth && ch.zAuth.newValue && zGoogleWaiting){ zGoogleWaiting=false; zRoute(true); }
  });
}

async function zInitAuth(){
  chrome.storage.local.remove(['zenDeviceLocked','zenUID','zenPendingReg','zenCodeReqState']);
  const a = await zGetSession();
  if(!a){ await chrome.storage.local.remove(['zenDeviceSession']); showLogin(); return; }
  await zRoute(true);
}

function showLogin() {
  document.getElementById('loginPage').style.display='flex';
  document.getElementById('dashboard').style.display='none';
  document.getElementById('verifyPage').style.display='none';
  clearInterval(countdownInterval); clearInterval(serverCheckInterval); clearInterval(clockInterval);
  clearAutoLogout();
  switchTab('login');
}

function showVerifyPage(session) {
  document.getElementById('loginPage').style.display='none';
  document.getElementById('dashboard').style.display='none';
  document.getElementById('verifyPage').style.display='flex';
  if(!session.xHandle){
    const vb=document.getElementById('xVerifyBtn'); if(vb){vb.textContent='Verify';vb.disabled=false;}
    const xb=document.getElementById('xVerifiedBadge'); if(xb) xb.style.display='none';
  }
  if(session.xHandle){setVerifyStatus('x',`Verified: @${session.xHandle}`);const btn=document.getElementById('xVerifyBtn');if(btn){btn.textContent='X Verified';btn.disabled=true;}const b=document.getElementById('xVerifiedBadge');if(b)b.style.display='inline-flex';}
  if(session.tgHandle){const inp=document.getElementById('tgVerifyInput');if(inp)inp.value=session.tgHandle;setVerifyStatus('tg',`Saved: @${session.tgHandle}`);const b=document.getElementById('tgVerifiedBadge');if(b)b.style.display='inline-flex';}
}

async function showDashboard(session) {
  document.getElementById('loginPage').style.display='none';
  document.getElementById('verifyPage').style.display='none';
  const dash=document.getElementById('dashboard'); dash.style.display='flex'; dash.style.flexDirection='column';
  const tgEl=document.getElementById('userTgDisplay'); const xEl=document.getElementById('userXDisplay');
  if(tgEl) tgEl.textContent=session.tgHandle?'@'+session.tgHandle:'—';
  if(xEl) xEl.textContent=session.xHandle?'@'+session.xHandle:'—';
  startClock(); startTimer(session); loadSettings(); loadReplyCount(); loadHistory(); loadRepDraftCount(); loadFeedDraftCount(); loadSearchDraftCount(); loadGivDraftCount();
  const uKey=emailToKey(session.email);
  await loadApiDisplay(uKey); await applyFeatureFlags(uKey); await checkNotices(session.email); await updateLimitDisplay(uKey);
  await loadContactLinks();
  if(window.ZP) window.ZP.onDashboard(session);

  // Load auto logout setting from the Worker profile (hidden)
  const userData = await zProfileGet();
  // autoLogoutMinutes: 0 = disabled, default = 60
  const minutes = userData && typeof userData.autoLogoutMinutes === 'number' ? userData.autoLogoutMinutes : 60;
  autoLogoutMinutes = minutes;
  startAutoLogout(autoLogoutMinutes);
}

// Ask the Worker (via background) for this user's account state. Returns null on any failure.
function zexpayMe() {
  return new Promise(function (resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'zexpayCall', path: '/v1/me' }, function (res) {
        if (chrome.runtime.lastError || !res || !res.ok) return resolve(null);
        resolve(res.data || null);
      });
    } catch (e) { resolve(null); }
  });
}

async function loadApiDisplay(uKey) {
  const activeSection=document.getElementById('apiActiveSection'); const lockedSection=document.getElementById('apiLockedSection'); const activeDisplay=document.getElementById('activeApiDisplay');
  // AI keys live only in the Worker now — wipe any leftovers from older versions.
  chrome.storage.local.remove(['geminiApiKey','openrouterApiKey','openaiApiKey','deepseekApiKey','groqApiKey','adminApiType','adminApiKey']);
  const me=await zexpayMe();
  if(me&&me.api_locked){if(activeSection)activeSection.style.display='none';if(lockedSection)lockedSection.style.display='block';
    return;}
  if(lockedSection)lockedSection.style.display='none';if(activeSection)activeSection.style.display='block';

  chrome.storage.local.remove(['sorsaApiKey']);   // legacy: key is server-side now

  // Sorsa is a separate admin-controlled API: show it under CONNECTED API when connected
  const sorsaRow=document.getElementById('activeSorsaRow'); const sorsaDisp=document.getElementById('activeSorsaDisplay');
  if(sorsaRow){
    const hasSorsa=!!(me&&me.has_sorsa);
    sorsaRow.style.display=hasSorsa?'flex':'none';
    if(hasSorsa&&sorsaDisp){ sorsaDisp.textContent='ZEX'; zenLoopModelScramble(sorsaDisp); }
  }

  if(activeDisplay){
    // M4b: show the model label(s) the Worker routes this user to (+ 👁 when one can read images); falls back to 'ZEX'
    const labels=(me&&Array.isArray(me.models))?me.models.map(x=>String(x||'').trim().slice(0,18)).filter(Boolean):[];
    let txt='ZEX';
    if(me&&me.has_api===false) txt='—';
    else if(labels.length) txt=labels.slice(0,2).join(' · ')+(labels.length>2?' +'+(labels.length-2):'');
    activeDisplay.textContent=txt;
    const vEl=document.getElementById('activeApiVision');
    if(vEl) vEl.style.display=(txt!=='—'&&me&&me.vision===true)?'inline':'none';
    zenLoopModelScramble(activeDisplay);
  }
}

async function updateLimitDisplay(uKey) {
  // Credits now come from the Worker (ZEXPAY). The old Firebase replyLimit is no longer used.
  const infoEl=document.getElementById('replyLimitInfo'); if(infoEl){ infoEl.textContent='Tap to see per-post breakdown'; infoEl.style.color=''; }
  if(window.ZP) await window.ZP.refreshMe();
}

function startTimer(session) {
  clearInterval(countdownInterval); clearInterval(serverCheckInterval);
  function tick(){
    const timerEl=document.getElementById('timerDisplay');
    if(session.noExpiry){   // S4: expiry is not enforced; if admin set one (expInfo) just show the countdown, never log out
      const ri=(Number(session.expInfo)||0)-Date.now();
      if(ri>0){ const d=Math.floor(ri/86400000),h=Math.floor((ri%86400000)/3600000),m=Math.floor((ri%3600000)/60000),sc=Math.floor((ri%60000)/1000);
        if(timerEl) timerEl.textContent=d>0?`${d}d ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(sc).padStart(2,'0')}`;
      } else if(timerEl) timerEl.textContent='ACTIVE';
      return;
    }
    const remaining=Math.max(0,session.expiresAt-Date.now());
    const days=Math.floor(remaining/86400000); const hrs=Math.floor((remaining%86400000)/3600000); const mins=Math.floor((remaining%3600000)/60000); const secs=Math.floor((remaining%60000)/1000);
    if(timerEl) timerEl.textContent=days>0?`${days}d ${String(hrs).padStart(2,'0')}:${String(mins).padStart(2,'0')}`:`${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
    if(remaining<=0){clearInterval(countdownInterval);clearInterval(serverCheckInterval);clearAutoLogout();chrome.storage.local.remove(['zenDeviceSession']);zRoute(true);}
  }
  tick(); countdownInterval=setInterval(tick,1000);
  serverCheckInterval=setInterval(async()=>{
    const stored=await getStorage(['zenDeviceSession']);
    const au=await zGetSession();
    if(!stored.zenDeviceSession||!au){ await zForceLogout(); return; }
    const uKey=emailToKey(stored.zenDeviceSession.email);
    const r=await zexpayCall('/v1/me','GET');
    if(!r.ok){
      const er=String(r.error||'');
      if(['NO_AUTH','NO_TOKEN','BAD_TOKEN','BAD_SIGNATURE','TOKEN_EXPIRED','FIREBASE_LOGIN_OFF','HTTP_401'].indexOf(er)>-1) await zForceLogout();
      return;   // offline / server error: keep going
    }
    const me=r.data||{};
    if(session.noExpiry){ const ne=Number(me.expires_at)||0; if(ne!==(Number(session.expInfo)||0)){ session.expInfo=ne; try{ chrome.storage.local.set({zenDeviceSession:Object.assign({},stored.zenDeviceSession,{expInfo:ne})}); }catch(e){} } }
    if(me.lock_reason==='not_approved'||me.lock_reason==='expired'){
      clearInterval(countdownInterval);clearInterval(serverCheckInterval);clearAutoLogout();
      await chrome.storage.local.remove(['zenDeviceSession']); zRoute(true);
    } else {
      await applyFeatureFlags(uKey); await loadApiDisplay(uKey); await updateLimitDisplay(uKey);
      // auto logout minutes (profile)
      const prof=await zProfileGet();
      const newMinutes = prof && typeof prof.autoLogoutMinutes === 'number' ? prof.autoLogoutMinutes : 60;
      if(newMinutes !== autoLogoutMinutes){
        autoLogoutMinutes = newMinutes;
        startAutoLogout(autoLogoutMinutes);
      }
    }
  },5*60*1000);
}

function loadReplyCount() { chrome.storage.local.get(['zenReplyCount'],d=>{const el=document.getElementById('replyCount');if(el)el.textContent=(d.zenReplyCount||0).toLocaleString();}); }
chrome.storage.onChanged.addListener(changes=>{if(changes.zenReplyCount){const el=document.getElementById('replyCount');if(el)el.textContent=(changes.zenReplyCount.newValue||0).toLocaleString();}});

// ── Comment REP Engine (Activity tab) ──────────────────────────
// "Open" stamps a short-lived { statusId, ts } flag in storage, then opens
// the post link in a new tab. content.js checks that flag against the tab's
// URL on load — this is the ONLY way the REP engine ever turns on; normal
// X browsing never triggers it.
function repExtractStatusId(url) {
  if (!url) return null;
  const m = String(url).trim().match(/\/status\/(\d+)/);
  return m ? m[1] : null;
}

function loadRepDraftCount() { chrome.storage.local.get(['zenRepDraftCount'],d=>{const el=document.getElementById('repDraftCount');if(el)el.textContent=(d.zenRepDraftCount||0).toLocaleString();}); }
chrome.storage.onChanged.addListener(changes=>{if(changes.zenRepDraftCount){const el=document.getElementById('repDraftCount');if(el)el.textContent=(changes.zenRepDraftCount.newValue||0).toLocaleString();}});

function loadFeedDraftCount() { chrome.storage.local.get(['zenFeedDraftCount'],d=>{const el=document.getElementById('feedDraftCount');if(el)el.textContent=(d.zenFeedDraftCount||0).toLocaleString();}); }
chrome.storage.onChanged.addListener(changes=>{if(changes.zenFeedDraftCount){const el=document.getElementById('feedDraftCount');if(el)el.textContent=(changes.zenFeedDraftCount.newValue||0).toLocaleString();}});

function loadSearchDraftCount() { chrome.storage.local.get(['zenSearchDraftCount'],d=>{const el=document.getElementById('searchDraftCount');if(el)el.textContent=(d.zenSearchDraftCount||0).toLocaleString();}); }
chrome.storage.onChanged.addListener(changes=>{if(changes.zenSearchDraftCount){const el=document.getElementById('searchDraftCount');if(el)el.textContent=(changes.zenSearchDraftCount.newValue||0).toLocaleString();}});

function loadGivDraftCount() { chrome.storage.local.get(['zenGivDraftCount'],d=>{const el=document.getElementById('givDraftCount');if(el)el.textContent=(d.zenGivDraftCount||0).toLocaleString();}); }
chrome.storage.onChanged.addListener(changes=>{if(changes.zenGivDraftCount){const el=document.getElementById('givDraftCount');if(el)el.textContent=(changes.zenGivDraftCount.newValue||0).toLocaleString();}});

async function handleRepOpen() {
  const input = document.getElementById('repLinkInput');
  const statusEl = document.getElementById('repLinkStatus');
  const link = (input?.value || '').trim();
  const statusId = repExtractStatusId(link);

  if (!statusId) {
    if (statusEl) { statusEl.textContent = 'Paste a valid post link (must contain /status/...)'; statusEl.style.color = '#ff4444'; }
    return;
  }

  if (statusEl) { statusEl.textContent = 'Opening...'; statusEl.style.color = ''; }

  chrome.storage.local.set({ zenRepMode: { statusId, ts: Date.now() }, zenRepSavedLink: link }, () => {
    chrome.tabs.create({ url: link, active: true }, () => {
      if (statusEl) { statusEl.textContent = 'Opened! REP buttons will appear next to comments.'; statusEl.style.color = '#16a34a'; }
    });
  });
}

function handleRepSave() {
  const input = document.getElementById('repLinkInput');
  const statusEl = document.getElementById('repLinkStatus');
  const link = (input?.value || '').trim();
  const statusId = repExtractStatusId(link);

  if (!statusId) {
    if (statusEl) { statusEl.textContent = 'Paste a valid post link (must contain /status/...)'; statusEl.style.color = '#ff4444'; }
    return;
  }

  chrome.storage.local.set({ zenRepSavedLink: link }, () => {
    if (statusEl) { statusEl.textContent = 'Link saved!'; statusEl.style.color = '#16a34a'; }
  });
}

chrome.storage.local.get(['zenRepSavedLink'], (d) => {
  const input = document.getElementById('repLinkInput');
  if (input && d.zenRepSavedLink && !input.value) input.value = d.zenRepSavedLink;
});

document.getElementById('repOpenBtn')?.addEventListener('click', handleRepOpen);
document.getElementById('goToXBtn')?.addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://x.com/home', active: true });
});
document.getElementById('repSaveBtn')?.addEventListener('click', handleRepSave);
document.getElementById('repLinkInput')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); handleRepOpen(); }
});

// ── Search Engine: keyword tags ──
function renderSehKeywordTags(list) {
  const wrap = document.getElementById('sehKeywordTags');
  if (!wrap) return;
  wrap.innerHTML = '';
  (list || []).forEach((kw) => {
    const tag = document.createElement('div');
    tag.className = 'seh-kw-tag';
    const label = document.createElement('span');
    label.textContent = kw;
    const x = document.createElement('span');
    x.className = 'seh-kw-tag-x';
    x.textContent = '×';
    x.addEventListener('click', () => {
      chrome.storage.local.get(['zenSearchKeywords'], (d) => {
        const next = (d.zenSearchKeywords || []).filter((k) => k !== kw);
        chrome.storage.local.set({ zenSearchKeywords: next });
        renderSehKeywordTags(next);
      });
    });
    tag.appendChild(label);
    tag.appendChild(x);
    wrap.appendChild(tag);
  });
}
chrome.storage.local.get(['zenSearchKeywords'], (d) => renderSehKeywordTags(d.zenSearchKeywords || []));

function addSehKeyword() {
  const input = document.getElementById('sehKeywordInput');
  if (!input) return;
  const val = input.value.trim();
  if (!val) return;
  chrome.storage.local.get(['zenSearchKeywords'], (d) => {
    const list = d.zenSearchKeywords || [];
    if (list.some((k) => k.toLowerCase() === val.toLowerCase())) { input.value = ''; return; }
    const next = [...list, val];
    chrome.storage.local.set({ zenSearchKeywords: next });
    renderSehKeywordTags(next);
    input.value = '';
    input.focus();
  });
}
document.getElementById('sehKeywordAddBtn')?.addEventListener('click', addSehKeyword);
document.getElementById('sehKeywordInput')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); addSehKeyword(); }
});

// ── GIV Engine: wallet address + reply template ──
chrome.storage.local.get(['zenGivWallet', 'zenGivTemplate'], (d) => {
  const walletInput = document.getElementById('givWalletInput');
  if (walletInput) walletInput.value = d.zenGivWallet || '';
  const tplInput = document.getElementById('givTemplateInput');
  if (tplInput) tplInput.value = d.zenGivTemplate || 'Wallet: {wallet} 🙏';
});
document.getElementById('givWalletInput')?.addEventListener('input', (e) => {
  chrome.storage.local.set({ zenGivWallet: e.target.value.trim() });
});
document.getElementById('givTemplateInput')?.addEventListener('input', (e) => {
  chrome.storage.local.set({ zenGivTemplate: e.target.value });
});

// ── GIV Engine: keyword tags (same pattern as Search Engine's) ──
function renderGivKeywordTags(list) {
  const wrap = document.getElementById('givKeywordTags');
  if (!wrap) return;
  wrap.innerHTML = '';
  (list || []).forEach((kw) => {
    const tag = document.createElement('div');
    tag.className = 'seh-kw-tag';
    const label = document.createElement('span');
    label.textContent = kw;
    const x = document.createElement('span');
    x.className = 'seh-kw-tag-x';
    x.textContent = '×';
    x.addEventListener('click', () => {
      chrome.storage.local.get(['zenGivKeywords'], (d) => {
        const next = (d.zenGivKeywords || []).filter((k) => k !== kw);
        chrome.storage.local.set({ zenGivKeywords: next });
        renderGivKeywordTags(next);
      });
    });
    tag.appendChild(label);
    tag.appendChild(x);
    wrap.appendChild(tag);
  });
}
const GIV_DEFAULT_KEYWORDS = ['giveaway', 'gtd', 'fcfs', 'whitelist', 'wl spot', 'wl giveaway', 'guaranteed spot'];
chrome.storage.local.get(['zenGivKeywords'], (d) => {
  const list = (Array.isArray(d.zenGivKeywords) && d.zenGivKeywords.length) ? d.zenGivKeywords : GIV_DEFAULT_KEYWORDS;
  renderGivKeywordTags(list);
});

function addGivKeyword() {
  const input = document.getElementById('givKeywordInput');
  if (!input) return;
  const val = input.value.trim();
  if (!val) return;
  chrome.storage.local.get(['zenGivKeywords'], (d) => {
    const list = (Array.isArray(d.zenGivKeywords) && d.zenGivKeywords.length) ? d.zenGivKeywords : GIV_DEFAULT_KEYWORDS;
    if (list.some((k) => k.toLowerCase() === val.toLowerCase())) { input.value = ''; return; }
    const next = [...list, val];
    chrome.storage.local.set({ zenGivKeywords: next });
    renderGivKeywordTags(next);
    input.value = '';
    input.focus();
  });
}
document.getElementById('givKeywordAddBtn')?.addEventListener('click', addGivKeyword);
document.getElementById('givKeywordInput')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); addGivKeyword(); }
});

// ── Search Engine: build the X advanced-search query & open it ──
function sehRawFrom(d) {
  const q = d && d.zenSearchRawOn === true && typeof d.zenSearchRawQuery === 'string' ? d.zenSearchRawQuery.replace(/\s+/g, ' ').trim() : '';
  return q;
}
function buildSehSearchUrl(keywords, filters, resultType, raw) {
  if (raw) {
    let rurl = `https://x.com/search?q=${encodeURIComponent(raw)}&src=typed_query`;
    if (resultType === 'latest') rurl += '&f=live';
    return { url: rurl, q: raw };
  }
  const parts = [];
  if (keywords && keywords.length) {
    const kwExpr = keywords.length > 1
      ? '(' + keywords.map((k) => (/\s/.test(k) ? `"${k}"` : k)).join(' OR ') + ')'
      : (/\s/.test(keywords[0]) ? `"${keywords[0]}"` : keywords[0]);
    parts.push(kwExpr);
  }
  if (filters?.media) parts.push('filter:media');
  if (filters?.replies) parts.push('filter:replies');
  if (filters?.verified) parts.push('filter:blue_verified');
  if (filters?.links) parts.push('filter:links');
  if (filters?.retweets) parts.push('filter:retweets');
  if (filters?.minReplies) parts.push(`min_replies:${filters.minReplies}`);
  if (filters?.minFaves) parts.push(`min_faves:${filters.minFaves}`);
  if (filters?.lang) parts.push(`lang:${filters.lang}`);
  if (filters?.withinTime) parts.push(`within_time:${filters.withinTime}`);
  const q = parts.join(' ');
  let url = `https://x.com/search?q=${encodeURIComponent(q)}&src=typed_query`;
  if (resultType === 'latest') url += '&f=live';
  return { url, q };
}
// ── Profile Visit settings — separate for FED (Feed tab) and SEA (Search tab) ──
(function pvInit() {
  const boxes = Array.from(document.querySelectorAll('.pv-box'));
  if (!boxes.length) return;
  const DEF = { on: false, every: 20, min: 5, max: 6, sec: 8 };
  const field = (box, k) => box.querySelector('[data-pv="' + k + '"]');
  const num = (e, d, lo) => { const n = parseInt(e && e.value, 10); return Number.isFinite(n) && n >= lo ? n : d; };
  // storage: zenProfVisit = { fed: {...}, sea: {...} }; older flat shape is migrated
  function cfgOf(v, eng) {
    v = v || {};
    if (v[eng] && typeof v[eng] === 'object') return Object.assign({}, DEF, v[eng]);
    const flat = Object.assign({}, DEF, v);
    flat.on = v[eng] !== undefined ? !!v[eng] : v.on === true;   // old: fed/sea booleans or one master toggle
    delete flat.fed; delete flat.sea;
    return flat;
  }
  function paint(v) {
    boxes.forEach((box) => {
      const c = cfgOf(v, box.dataset.eng);
      const on = field(box, 'on'); if (on) on.checked = !!c.on;
      ['every', 'min', 'max', 'sec'].forEach((k) => { const e = field(box, k); if (e && document.activeElement !== e) e.value = c[k]; });
    });
  }
  chrome.storage.local.get(['zenProfVisit'], (d) => paint(d.zenProfVisit));
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.zenProfVisit) paint(ch.zenProfVisit.newValue); });
  boxes.forEach((box) => {
    box.querySelectorAll('[data-pv]').forEach((e) => e.addEventListener('change', () => {
      chrome.storage.local.get(['zenProfVisit'], (d) => {
        const every = num(field(box, 'every'), DEF.every, 1);
        const mn = Math.min(num(field(box, 'min'), DEF.min, 1), every);
        const mx = Math.min(Math.max(mn, num(field(box, 'max'), DEF.max, 1)), every);   // can't visit more profiles than posts in a block
        const next = { fed: cfgOf(d.zenProfVisit, 'fed'), sea: cfgOf(d.zenProfVisit, 'sea') };
        next[box.dataset.eng] = { on: field(box, 'on').checked, every, min: mn, max: mx, sec: num(field(box, 'sec'), DEF.sec, 3) };
        chrome.storage.local.set({ zenProfVisit: next });
        paint(next);
      });
    }));
  });
})();

// ── Search Engine: custom raw queries — save many, switch one ON (used exactly as typed) ──
// zenSearchRawList = [{ id, name, text }]   zenSearchRawActive = id of the ON box ('' = none)
// zenSearchRawOn / zenSearchRawQuery stay the single "live" pair every engine already reads.
(function sehRawInit() {
  const listEl = document.getElementById('sehRawList');
  const addBtn = document.getElementById('sehRawAddBtn');
  const statusEl = document.getElementById('sehRawStatus');
  if (!listEl || !addBtn) return;
  let items = [], active = '';
  const uid = () => 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  const syncLive = () => {
    const cur = items.find((x) => x.id === active);
    chrome.storage.local.set({
      zenSearchRawList: items, zenSearchRawActive: cur ? cur.id : '',
      zenSearchRawOn: !!cur, zenSearchRawQuery: cur ? cur.text : '',
    });
    if (statusEl) statusEl.textContent = cur ? 'ON: ' + (cur.name || 'Query ' + (items.indexOf(cur) + 1)) : 'All OFF — keywords & filters are used';
  };
  const render = () => {
    listEl.textContent = '';
    items.forEach((q, i) => {
      const box = document.createElement('div');
      box.style.cssText = 'border:1.5px solid ' + (q.id === active ? '#e6b010' : '#444') + ';border-radius:12px;padding:8px;margin:0 0 8px;';
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:8px;margin:0 0 6px;';
      const name = document.createElement('input');
      name.type = 'text'; name.className = 'verify-input'; name.placeholder = 'Query ' + (i + 1) + ' (name)'; name.value = q.name || '';
      name.style.cssText = 'flex:1;margin:0;font-size:12px;';
      name.addEventListener('input', () => { q.name = name.value; syncLive(); });
      const sw = document.createElement('label'); sw.className = 'toggle';
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = q.id === active;
      const sl = document.createElement('span'); sl.className = 'toggle-slider';
      sw.appendChild(cb); sw.appendChild(sl);
      cb.addEventListener('change', () => { active = cb.checked ? q.id : ''; syncLive(); render(); });
      const del = document.createElement('button');
      del.type = 'button'; del.textContent = '✕'; del.title = 'Delete this query';
      del.style.cssText = 'background:transparent;border:1.5px solid #666;color:#ccc;border-radius:8px;width:32px;height:32px;font-size:14px;';
      del.addEventListener('click', () => {
        if (!confirm('Delete this query?')) return;
        items = items.filter((x) => x.id !== q.id); if (active === q.id) active = ''; syncLive(); render();
      });
      row.appendChild(name); row.appendChild(sw); row.appendChild(del);
      const ta = document.createElement('textarea');
      ta.className = 'verify-input'; ta.rows = 3; ta.spellcheck = false; ta.autocomplete = 'off'; ta.value = q.text || '';
      ta.placeholder = 'filter:blue_verified ("ProjectName" OR @handle) -filter:replies min_replies:20 lang:en within_time:1440min';
      ta.style.cssText = 'width:100%;box-sizing:border-box;margin:0;resize:vertical;font-family:monospace;font-size:11px;';
      ta.addEventListener('input', () => { q.text = ta.value; syncLive(); });
      box.appendChild(row); box.appendChild(ta);
      listEl.appendChild(box);
    });
  };
  addBtn.addEventListener('click', () => { items.push({ id: uid(), name: '', text: '' }); syncLive(); render(); });
  chrome.storage.local.get(['zenSearchRawList', 'zenSearchRawActive', 'zenSearchRawOn', 'zenSearchRawQuery'], (d) => {
    items = Array.isArray(d.zenSearchRawList) ? d.zenSearchRawList.filter((x) => x && x.id) : [];
    active = typeof d.zenSearchRawActive === 'string' ? d.zenSearchRawActive : '';
    if (!items.length) {                       // first run: carry the old single query over as box 1
      items.push({ id: uid(), name: '', text: d.zenSearchRawQuery || '' });
      if (d.zenSearchRawOn === true) active = items[0].id;
      syncLive();
    }
    if (active && !items.some((x) => x.id === active)) active = '';
    render();
    if (statusEl) { const cur = items.find((x) => x.id === active); statusEl.textContent = cur ? 'ON: ' + (cur.name || 'Query ' + (items.indexOf(cur) + 1)) : 'All OFF — keywords & filters are used'; }
  });
})();
document.getElementById('goToSearchBtn')?.addEventListener('click', () => {
  const statusEl = document.getElementById('sehSearchStatus');
  chrome.storage.local.get(['zenSearchKeywords', 'zenSearchFilters', 'zenSearchResultType', 'zenSearchRawOn', 'zenSearchRawQuery'], (d) => {
    const keywords = d.zenSearchKeywords || [];
    const raw = sehRawFrom(d);
    if (d.zenSearchRawOn === true && !raw) {
      if (statusEl) { statusEl.textContent = 'Custom query is ON but empty'; statusEl.style.color = '#dc2626'; }
      return;
    }
    if (!raw && !keywords.length) {
      if (statusEl) { statusEl.textContent = 'Add at least one keyword first'; statusEl.style.color = '#dc2626'; }
      return;
    }
    const { url } = buildSehSearchUrl(keywords, d.zenSearchFilters || {}, d.zenSearchResultType || 'top', raw);
    chrome.tabs.create({ url, active: true });
    if (statusEl) { statusEl.textContent = 'Opened search — SEA buttons will appear on results'; statusEl.style.color = '#16a34a'; }
  });
});

// ── Search Engine: Link Collect (links only → Sweep folder) ──
(function seaCollectInit() {
  const sel = document.getElementById('seaCollectTarget');
  const nameRow = document.getElementById('seaCollectNameRow');
  const nameEl = document.getElementById('seaCollectName');
  const maxEl = document.getElementById('seaCollectMax');
  const btn = document.getElementById('seaCollectBtn');
  const st = document.getElementById('seaCollectStatus');
  const whatEl = document.getElementById('seaCollectWhat'), wcRow = document.getElementById('seaCollectWcRow'), saveRow = document.getElementById('seaCollectSaveRow');
  const wcMinEl = document.getElementById('seaCollectWcMin'), wcMaxEl = document.getElementById('seaCollectWcMax');
  if (!sel || !btn) return;
  function paintWhat() {
    const w = whatEl ? whatEl.value : 'links';
    if (wcRow) wcRow.style.display = w === 'links' ? 'none' : 'flex';
    if (saveRow) saveRow.style.display = w === 'users' ? 'none' : 'flex';
    if (nameRow && w === 'users') nameRow.style.display = 'none'; else if (nameRow) nameRow.style.display = sel.value === 'new' ? 'flex' : 'none';
  }
  let running = false;

  function setStatus(msg, cls) { if (st) { st.textContent = msg || ''; st.className = 'verify-status' + (cls ? ' ' + cls : ''); } }
  function renderFolders(list, keep) {
    const cur = keep != null ? keep : sel.value;
    sel.textContent = '';
    const n = document.createElement('option'); n.value = 'new'; n.textContent = '＋ New folder'; sel.appendChild(n);
    (Array.isArray(list) ? list : []).filter((f) => !(f && f.auto === 'zexerr') && !(f && f.auto === 'tgfail' && Date.now() - (f.createdAt || 0) > 86400000)).forEach((f) => {
      const o = document.createElement('option'); o.value = f.id;
      o.textContent = f.name + ' (' + ((f.links && f.links.length) || 0) + ')';
      sel.appendChild(o);
    });
    sel.value = Array.from(sel.options).some((o) => o.value === cur) ? cur : 'new';
    if (nameRow) nameRow.style.display = sel.value === 'new' ? 'flex' : 'none';
  }
  function savePref() {
    chrome.storage.local.set({ zenSearchCollectPref: { target: sel.value, name: nameEl.value.trim(), max: parseInt(maxEl.value, 10) || 0, what: whatEl ? whatEl.value : 'links', wcMin: wcMinEl ? parseInt(wcMinEl.value, 10) || 0 : 100, wcMax: wcMaxEl ? parseInt(wcMaxEl.value, 10) || 0 : 105 } });
  }
  function renderState(state, on) {
    running = !!on;
    btn.textContent = running ? 'STOP COLLECT' : 'START COLLECT';
    if (!state) return;
    const uTxt = (state.what && state.what !== 'links') ? (state.users || 0) + ' usernames collected' + (state.usersKnown ? ' · ' + state.usersKnown + ' already saved' : '') + (state.usersFollowing ? ' · ' + state.usersFollowing + ' already followed' : '') : '';
    const base = (state.what === 'users' ? uTxt : state.added + ' added' + (state.dup ? ' · ' + state.dup + ' duplicate' : '') + (state.skipped ? ' · ' + state.skipped + ' already replied' : '') + (state.folderName ? ' → ' + state.folderName : '') + (state.what === 'both' ? ' · ' + uTxt : ''));
    if (state.phase === 'running' && running) setStatus('Collecting… ' + base, 'ok');
    else if (state.phase === 'done') setStatus('Finished — ' + base, 'ok');
    else if (state.phase === 'stopped') setStatus('Stopped — ' + base, 'ok');
    else if (state.phase === 'error') setStatus('Could not save links. Try again.', 'err');
  }

  chrome.storage.local.get(['zenTgSweepFolders', 'zenSearchCollectPref', 'zenSearchCollectState', 'zenSearchCollectOn'], (d) => {
    const pref = d.zenSearchCollectPref || {};
    renderFolders(d.zenTgSweepFolders, pref.target || 'new');
    if (pref.name) nameEl.value = pref.name;
    if (pref.max) maxEl.value = pref.max;
    if (whatEl && pref.what) whatEl.value = pref.what;
    if (wcMinEl && pref.wcMin != null) wcMinEl.value = pref.wcMin;
    if (wcMaxEl && pref.wcMax != null) wcMaxEl.value = pref.wcMax;
    paintWhat();
    renderState(d.zenSearchCollectState, d.zenSearchCollectOn === true);
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.zenTgSweepFolders) renderFolders(ch.zenTgSweepFolders.newValue);
    if (ch.zenSearchCollectOn || ch.zenSearchCollectState) {
      chrome.storage.local.get(['zenSearchCollectState', 'zenSearchCollectOn'], (d) => renderState(d.zenSearchCollectState, d.zenSearchCollectOn === true));
    }
  });
  sel.addEventListener('change', () => { if (nameRow) nameRow.style.display = sel.value === 'new' && (!whatEl || whatEl.value !== 'users') ? 'flex' : 'none'; savePref(); });
  [whatEl, wcMinEl, wcMaxEl].forEach((e) => { if (e) e.addEventListener('change', () => { paintWhat(); savePref(); }); });
  nameEl.addEventListener('change', savePref);
  maxEl.addEventListener('change', savePref);

  btn.addEventListener('click', () => {
    if (running) { chrome.storage.local.set({ zenSearchCollectOn: false }); setStatus('Stopping…'); return; }
    chrome.storage.local.get(['zenSearchKeywords', 'zenSearchFilters', 'zenSearchResultType', 'zenSearchEngineOn', 'zenSearchAutoMode', 'zenSearchRawOn', 'zenSearchRawQuery'], (d) => {
      if (d.zenSearchEngineOn === true && d.zenSearchAutoMode === true) { setStatus('Turn SEA Auto Mode OFF first — Link Collect does not reply.', 'err'); return; }
      const keywords = d.zenSearchKeywords || [];
      const raw = sehRawFrom(d);
      if (!raw && !keywords.length) { setStatus('Add at least one keyword first', 'err'); return; }
      const { url } = buildSehSearchUrl(keywords, d.zenSearchFilters || {}, d.zenSearchResultType || 'top', raw);
      const cfgBase = { target: sel.value, name: nameEl.value.trim(), max: parseInt(maxEl.value, 10) || 0, what: whatEl ? whatEl.value : 'links', wcMin: wcMinEl ? parseInt(wcMinEl.value, 10) || 0 : 100, wcMax: wcMaxEl ? parseInt(wcMaxEl.value, 10) || 0 : 105 };
      savePref();
      chrome.tabs.create({ url, active: true }, (tab) => {
        const cfg = Object.assign({}, cfgBase, { tabId: tab && tab.id != null ? tab.id : null });
        chrome.storage.local.set({ zenSearchCollectCfg: cfg, zenSearchCollectState: { phase: 'running', added: 0, dup: 0, skipped: 0, folderId: null, folderName: '', what: cfgBase.what } }, () => {
          chrome.storage.local.set({ zenSearchCollectOn: true });
          setStatus(cfgBase.what === 'users' ? 'Opened search — collecting usernames…' : 'Opened search — collecting links…', 'ok');
        });
      });
    });
  });
})();

// ── Reply History (real posted replies, logged by content.js once a reply is actually sent) ──
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
// Wallchain score chip next to a name (score saved by wc_score.js; empty when none was seen).
function zexWcBadge(v){ if(v==null||v==='') return ''; v=Number(v); return (v>=0 && isFinite(v)) ? ` <span style="font-size:10px;font-weight:700;background:#fffbeb;border:1px solid #fde68a;padding:0 5px;margin-left:4px;">WC ${v>=10000?Math.round(v/1000)+'K':v}</span>` : ''; }
function loadHistory(){chrome.storage.local.get(['zenReplyHistory','zenSkipLog'],d=>renderHistoryList(Array.isArray(d.zenReplyHistory)?d.zenReplyHistory:[], Array.isArray(d.zenSkipLog)?d.zenSkipLog:[]));}
const ZEN_ENG_NAMES={REP:'REP',FED:'FED',SEA:'SEA',GIV:'GIV',TAR:'TAR',TG:'Telegram',SESS:'Session',MANUAL:'Manual GET'};
const ZEN_FAIL_REASONS=['failed','no_get_reply','stuck'];
let zenHistFilter='all';
function zenHistFilterInit(){
  const row=document.getElementById('historyFilterRow'); if(!row||row._zenBound) return; row._zenBound=true;
  row.addEventListener('click',e=>{
    const b=e.target.closest&&e.target.closest('.history-filter'); if(!b) return;
    zenHistFilter=b.dataset.f||'all'; loadHistory();
  });
}
function zexFmtDur(ms){ if(ms==null||!isFinite(ms)||ms<0) return ''; const s=ms/1000; if(s<10) return s.toFixed(1)+'s'; if(s<60) return Math.round(s)+'s'; const m=Math.floor(s/60), r=Math.round(s%60); return m+'m '+(r<10?'0':'')+r+'s'; }
function zexDurChip(d){
  if(!d||d.t==null) return '';
  const parts=[]; if(d.o!=null) parts.push('open '+zexFmtDur(d.o)); if(d.g!=null) parts.push('generate '+zexFmtDur(d.g)); if(d.s!=null) parts.push('send '+zexFmtDur(d.s));
  return '<div style="font-size:10px;color:#8d9096;margin:2px 0 6px;"><b style="color:#eab308;">⏱ '+zexFmtDur(d.t)+'</b> total'+(parts.length?' <span style="opacity:.8">· '+parts.join(' · ')+'</span>':'')+'</div>';
}
function renderHistoryList(replies, skips){
  zenHistFilterInit();
  const list=document.getElementById('historyList'); const empty=document.getElementById('historyEmpty'); const countEl=document.getElementById('historyCount');
  if(!list) return;
  skips=Array.isArray(skips)?skips:[];
  const isFailE=x=>ZEN_FAIL_REASONS.indexOf(x&&x.reason)>=0;
  const nFail=skips.filter(isFailE).length, nSkip=skips.length-nFail;
  const f=zenHistFilter;
  const all=replies.map(e=>e).concat(skips.map(x=>Object.assign({},x,{__skip:true})));
  const hist=all.filter(e=>f==='all'?true:f==='replies'?!e.__skip:f==='skipped'?(e.__skip&&!isFailE(e)):(e.__skip&&isFailE(e))).sort((a,b)=>(b.ts||0)-(a.ts||0));
  if(countEl) countEl.textContent=`${replies.length} repl${replies.length===1?'y':'ies'} posted`+(nSkip?` · ${nSkip} skipped`:'')+(nFail?` · ${nFail} failed`:'');
  document.querySelectorAll('#historyFilterRow .history-filter').forEach(b=>{
    const k=b.dataset.f, n=k==='replies'?replies.length:k==='skipped'?nSkip:k==='failed'?nFail:null;
    b.textContent=({all:'All',replies:'Replies',skipped:'Skipped',failed:'Failed'})[k]+(n==null?'':' '+n);
    b.classList.toggle('active',k===f);
  });
  if(!hist.length){ list.innerHTML=''; if(empty){ empty.textContent=f==='all'?'No posted replies yet.':'Nothing here.'; empty.style.display='block'; } return; }
  if(empty) empty.style.display='none';
  list.innerHTML = hist.map(entry=>{
    const dt = new Date(entry.ts || Date.now());
    const dateStr = dt.toLocaleDateString(undefined,{month:'short',day:'numeric'});
    const timeStr = dt.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});
    const safeReply = escapeHtml(entry.reply||'');
    const safeAuthor = escapeHtml(entry.author||'');
    const safeTone = escapeHtml(entry.tone||'Smart');
    const hasLink = !!(entry.link && entry.link.trim());
    const safeLink = escapeHtml(entry.link||'');
    const linkHtml = hasLink
      ? `<a class="history-link" href="${safeLink}" target="_blank" rel="noopener">View Tweet ↗</a>`
      : `<span class="history-link history-link-disabled" title="Tweet link wasn't captured for this reply">Link unavailable</span>`;
    if(entry.__skip){
      const byName=entry.by?(ZEN_ENG_NAMES[entry.by]||entry.by):'';
      const curName=entry.cur?(ZEN_ENG_NAMES[entry.cur]||entry.cur):'';
      const isOff=entry.reason==='comment_off';
      const isBefore=entry.reason==='commented_before';
      const isBlk=entry.reason==='blacklist';
      const isFail=ZEN_FAIL_REASONS.indexOf(entry.reason)>=0;
      const failMsg={failed:'Engine failed on this post — open the link and check it by hand.',no_get_reply:'GET Reply never appeared on this post — open the link and check it by hand.',stuck:'Engine got stuck on this post — open the link and check it by hand.'}[entry.reason];
      const msg=isFail?failMsg:isBlk?"Blacklisted account — skipped, no comment made.":isOff?"Comment couldn't be done — comments are turned off for this post.":isBefore?"You already commented on this post before ZEX — link saved as done.":(byName?`Already engaged by ${escapeHtml(byName)}`:'Already engaged earlier');
      const who=curName?` <span style="opacity:.6">· ${isFail?'failed in':'skipped by'} ${escapeHtml(curName)}</span>`:'';
      const prevTxt=entry.prevReply?`<div style="opacity:.6;margin-top:4px;">${escapeHtml(entry.prevReply)}</div>`:'';
      return `<div class="history-card">
      <div class="history-card-top">
        <span class="history-tone-badge"${isFail?' style="border-color:rgba(239,68,68,.5);color:#f87171;background:rgba(239,68,68,.12)"':''}>${isFail?(entry.reason==='no_get_reply'?'NO GET REPLY':entry.reason==='stuck'?'STUCK':'FAILED'):isBlk?'BLACKLISTED':isOff?'COMMENT OFF':isBefore?'COMMENTED BEFORE ZEX':'SKIPPED'}</span>
        <span class="history-time">${dateStr}, ${timeStr}</span>
      </div>
      <div class="history-reply-text">${msg}${who}${prevTxt}</div>
      <div class="history-card-bottom">
        <span class="history-author">${safeAuthor?'@'+safeAuthor:''}${zexWcBadge(entry.wc)}</span>
        ${linkHtml}
      </div>
    </div>`;
    }
    return `<div class="history-card">
      <div class="history-card-top">
        <span class="history-tone-badge">${safeTone}</span>
        <span class="history-time">${dateStr}, ${timeStr}</span>
      </div>
      <div class="history-dotgrid"></div>
      <div class="history-reply-text">${safeReply}</div>
      ${zexDurChip(entry.dur)}
      ${(Array.isArray(entry.kw)&&entry.kw.length)?'<div style="display:flex;flex-wrap:wrap;gap:4px;margin:4px 0 2px;">'+entry.kw.slice(0,6).map(k=>'<span style="font-size:9px;font-weight:700;padding:1px 6px;border-radius:6px;border:1px solid rgba(234,179,8,.45);color:#eab308;background:rgba(234,179,8,.1);">'+escapeHtml(String(k))+'</span>').join('')+'</div>':''}
      <div class="history-card-bottom">
        <span class="history-author">${safeAuthor?'@'+safeAuthor:''}${zexWcBadge(entry.wc)}</span>
        ${linkHtml}
      </div>
    </div>`;
  }).join('');
  zenAnimateHistoryDots(list);
}

// Small 7x3 dot grid per history card that cycles a random lit pattern,
// echoing the dot-loader "activity" visual — purely decorative.
function zenAnimateHistoryDots(list){
  const grids = list.querySelectorAll('.history-dotgrid');
  grids.forEach(grid=>{
    if (grid._zenDotsBuilt) return;
    grid._zenDotsBuilt = true;
    for (let i=0;i<21;i++){
      const d=document.createElement('span');
      grid.appendChild(d);
    }
    function randomFrame(){
      const dots = grid.children;
      const litCount = 5 + Math.floor(Math.random()*4);
      const lit = new Set();
      while(lit.size<litCount) lit.add(Math.floor(Math.random()*dots.length));
      for(let i=0;i<dots.length;i++) dots[i].classList.toggle('on', lit.has(i));
    }
    randomFrame();
    grid._zenDotsTimer = setInterval(randomFrame, 450);
  });
}
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local' && (changes.zenReplyHistory||changes.zenSkipLog)) loadHistory();});

// ── Reply History: Export / Import ──────────────────────────────
// Export writes zenReplyHistory + the "already replied" ID list to a JSON file.
// Import MERGES that file into whatever is already stored (duplicates skipped,
// nothing existing is deleted), so it's safe to use on a fresh device or after
// reinstalling the extension. Restoring the ID list matters: it's what keeps
// GET Reply buttons hidden on posts you've already answered.
const ZEN_HISTORY_MAX = 300;      // same cap content.js applies on every save
const ZEN_REPLIED_IDS_MAX = 2000; // same cap content.js applies to zenRepliedStatusIds

function zenHistIoStatus(msg, type){
  const el = document.getElementById('historyIoStatus'); if(!el) return;
  el.textContent = msg || '';
  el.className = 'history-io-status' + (type ? ' ' + type : '');
  clearTimeout(zenHistIoStatus._t);
  if(msg) zenHistIoStatus._t = setTimeout(()=>{ el.textContent=''; el.className='history-io-status'; }, 6000);
}
function zenHistStatusId(url){ const m = String(url||'').match(/\/status\/(\d+)/); return m ? m[1] : null; }

// Files can come from anywhere, so never trust them: keep only the five known
// fields, cap lengths, and only accept x.com / twitter.com links.
function zenSanitizeHistoryEntry(e){
  if(!e || typeof e !== 'object') return null;
  const reply = typeof e.reply === 'string' ? e.reply.trim() : '';
  if(!reply) return null;
  let link = typeof e.link === 'string' ? e.link.trim() : '';
  if(!/^https:\/\/(?:[a-z0-9-]+\.)?(?:x|twitter)\.com\/[^\s"'<>]*$/i.test(link)) link = '';
  const ts = Number(e.ts);
  return {
    link,
    author: typeof e.author === 'string' ? e.author.trim().slice(0, 60) : '',
    reply: reply.slice(0, 2000),
    tone: typeof e.tone === 'string' && e.tone.trim() ? e.tone.trim().slice(0, 30) : 'Smart',
    ts: isFinite(ts) && ts > 0 ? ts : 0
  };
}
function zenHistKey(e){ return (Number(e.ts)||0) + '|' + (e.link||'') + '|' + (e.reply||''); }

document.getElementById('historyExportBtn')?.addEventListener('click', ()=>{
  chrome.storage.local.get(['zenReplyHistory','zenRepliedStatusIds'], d=>{
    const history = Array.isArray(d.zenReplyHistory) ? d.zenReplyHistory : [];
    if(!history.length){ zenHistIoStatus('No history to export yet.', 'err'); return; }
    const payload = {
      app: 'ZEX',
      type: 'reply-history',
      version: 1,
      exportedAt: new Date().toISOString(),
      count: history.length,
      history,
      repliedStatusIds: Array.isArray(d.zenRepliedStatusIds) ? d.zenRepliedStatusIds : []
    };
    const now = new Date();
    const pad = n => String(n).padStart(2,'0');
    const stamp = now.getFullYear() + '-' + pad(now.getMonth()+1) + '-' + pad(now.getDate());
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'zex_history_' + stamp + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 1500); // not instant — some mobile browsers cancel the download otherwise
    zenHistIoStatus('Exported ' + history.length + ' repl' + (history.length===1?'y':'ies') + ' ✓', 'ok');
  });
});

document.getElementById('historyImportInput')?.addEventListener('change', e=>{
  const input = e.target;
  const file = input.files && input.files[0];
  if(!file) return;
  if(file.size > 5*1024*1024){ zenHistIoStatus('File too large — is this really a ZEX history export?', 'err'); input.value=''; return; }
  const reader = new FileReader();
  reader.onerror = ()=>{ zenHistIoStatus('Could not read that file.', 'err'); input.value=''; };
  reader.onload = ev=>{
    input.value = ''; // lets the same file be picked again later
    let parsed;
    try { parsed = JSON.parse(ev.target.result); }
    catch(_){ zenHistIoStatus('Invalid file — not valid JSON.', 'err'); return; }

    const rawList = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.history) ? parsed.history : null);
    if(!rawList){ zenHistIoStatus('Invalid file — no history found in it.', 'err'); return; }
    const incoming = rawList.map(zenSanitizeHistoryEntry).filter(Boolean);
    if(!incoming.length){ zenHistIoStatus('No valid replies found in that file.', 'err'); return; }

    const importedIds = (parsed && Array.isArray(parsed.repliedStatusIds) ? parsed.repliedStatusIds : [])
      .map(String).filter(s=>/^\d{5,25}$/.test(s));

    chrome.storage.local.get(['zenReplyHistory','zenRepliedStatusIds'], d=>{
      const existing = Array.isArray(d.zenReplyHistory) ? d.zenReplyHistory : [];
      const seen = new Set(existing.map(zenHistKey));
      const fresh = [];
      incoming.forEach(x=>{ const k = zenHistKey(x); if(!seen.has(k)){ seen.add(k); fresh.push(x); } });

      const merged = existing.concat(fresh).sort((a,b)=>(Number(b.ts)||0)-(Number(a.ts)||0));
      const kept = merged.slice(0, ZEN_HISTORY_MAX);
      const dropped = merged.length - kept.length;

      // Restore "already replied" IDs: the file's own list + every link in the imported
      // history (covers files edited by hand), merged with what's already on this device.
      const existingIds = Array.isArray(d.zenRepliedStatusIds) ? d.zenRepliedStatusIds : [];
      const linkIds = incoming.map(x=>zenHistStatusId(x.link)).filter(Boolean);
      const ids = Array.from(new Set(importedIds.concat(linkIds, existingIds))).slice(-ZEN_REPLIED_IDS_MAX);

      chrome.storage.local.set({ zenReplyHistory: kept, zenRepliedStatusIds: ids }, ()=>{
        if(chrome.runtime.lastError){ zenHistIoStatus('Import failed: ' + chrome.runtime.lastError.message, 'err'); return; }
        loadHistory(); // storage.onChanged only fires when something actually changed
        const skipped = incoming.length - fresh.length;
        let msg = 'Imported ' + fresh.length + ' new';
        if(skipped) msg += ' · ' + skipped + ' duplicate' + (skipped===1?'':'s') + ' skipped';
        if(dropped > 0) msg += ' · ' + dropped + ' oldest dropped (max ' + ZEN_HISTORY_MAX + ')';
        zenHistIoStatus(msg + ' ✓', 'ok');
      });
    });
  };
  reader.readAsText(file);
});

// ── GET Reply Click Breakdown (per post — how many times a reply was generated for it, tap "Total Replies Generated" to toggle) ──
let replyClickBreakdownOpen = false;
function toggleReplyClickBreakdown(){
  replyClickBreakdownOpen = !replyClickBreakdownOpen;
  if(replyClickBreakdownOpen){ loadReplyClickBreakdown(); }
  else {
    const panel=document.getElementById('replyClickBreakdown'); const emptyEl=document.getElementById('replyClickBreakdownEmpty');
    if(panel) panel.style.display='none';
    if(emptyEl) emptyEl.style.display='none';
  }
}
function loadReplyClickBreakdown(){
  if (!extContextAlive()) return;
  chrome.storage.local.get(['zenGetReplyClicks'],d=>renderReplyClickBreakdown(d.zenGetReplyClicks&&typeof d.zenGetReplyClicks==='object'?d.zenGetReplyClicks:{}));
}
function renderReplyClickBreakdown(map){
  const panel=document.getElementById('replyClickBreakdown'); const emptyEl=document.getElementById('replyClickBreakdownEmpty');
  if(!panel) return;
  const rows=Object.keys(map).map(link=>({link,...map[link]})).sort((a,b)=>(b.count||0)-(a.count||0));
  if(!replyClickBreakdownOpen){ panel.style.display='none'; if(emptyEl) emptyEl.style.display='none'; return; }
  if(!rows.length){ panel.style.display='none'; panel.innerHTML=''; if(emptyEl) emptyEl.style.display='block'; return; }
  if(emptyEl) emptyEl.style.display='none';
  panel.style.display='flex';
  panel.innerHTML = rows.map(r=>{
    const safeAuthor=escapeHtml(r.author||'');
    const safeLink=escapeHtml(r.link||'');
    const dt=new Date(r.lastTs||Date.now());
    const dateStr=dt.toLocaleDateString(undefined,{month:'short',day:'numeric'});
    return `<div class="history-card">
      <div class="history-card-top">
        <span class="history-tone-badge">${r.count} time${r.count===1?'':'s'}</span>
        <span class="history-time">last ${dateStr}</span>
      </div>
      <div class="history-card-bottom">
        <span class="history-author">${safeAuthor?'@'+safeAuthor:''}</span>
        <a class="history-link" href="${safeLink}" target="_blank" rel="noopener">View Tweet ↗</a>
      </div>
    </div>`;
  }).join('');
}
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local' && changes.zenGetReplyClicks && replyClickBreakdownOpen) loadReplyClickBreakdown();});

function updateSwitchLabel(on){const lbl=document.getElementById('switchLabel');if(lbl)lbl.textContent=on?'ON — Auto tries Z EX APIs':'OFF — Use primary API only';}
function updateProjectNameLabel(on){const lbl=document.getElementById('projectNameLabel');if(lbl)lbl.textContent=on?'ON — Uses project/brand name in reply':'OFF — No project name used';}
function updateCdpClickLabel(on){const lbl=document.getElementById('cdpClickLabel');if(lbl)lbl.textContent=on?'ON — RL stealth click (isTrusted: true, debug banner visible)':'OFF — Standard click (no Chrome debug banner)';}
function updateHumanTypingLabel(on){const lbl=document.getElementById('humanTypingLabel');if(lbl)lbl.textContent=on?'ON — Human typing (choose Style or Live below)':'OFF — Instant paste (fast, default)';}
function updateProxyEnableLabel(on){const lbl=document.getElementById('proxyEnableLabel');if(lbl)lbl.textContent=on?'ON — browser routes through your proxy':'OFF — browser uses your normal connection';}

function loadSettings() {
  chrome.storage.local.get(['zenRepEngineOn','defaultTone','replyStyle','smartSwitch','useProjectNameGlobal','bigReplyConfig','bigReplyMode','sk1Mode','customTonePrompt','customToneWords','zenAutoRepMode','zenRepAutoPercentage','zenRepSpeedMode','zenRepCustomSeconds','zenFeedEngineOn','zenFeedAutoMode','zenFeedLikeOn','zenFeedPromptModel','zenSearchEngineOn','zenSearchAutoMode','zenSearchLikeOn','zenSearchPromptModel','zenSearchResultType','zenSearchFilters','zenGivEngineOn','zenGivAutoMode','zenGivAiVerify','zenFeedGivDetectOn','zenFeedTargetKeywords','zenFeedTargetFilterOn','zenProxyConfig'],data=>{
    const px=data.zenProxyConfig||{};
    const pxSw=document.getElementById('proxyEnableSwitch');
    if(pxSw){pxSw.checked=px.enabled===true;updateProxyEnableLabel(pxSw.checked);}
    document.querySelectorAll('.scheme-chip').forEach(b=>b.classList.toggle('active',b.dataset.scheme===(px.scheme||'http')));
    const pxHost=document.getElementById('proxyHost');if(pxHost)pxHost.value=px.host||'';
    const pxPort=document.getElementById('proxyPort');if(pxPort)pxPort.value=px.port||'';
    const pxUser=document.getElementById('proxyUsername');if(pxUser)pxUser.value=px.username||'';
    const pxPass=document.getElementById('proxyPassword');if(pxPass)pxPass.value=px.password||'';
    if(data.defaultTone){
      document.querySelectorAll('.tone-chip').forEach(b=>{b.classList.toggle('active',b.dataset.tone===data.defaultTone);if(b.dataset.tone===data.defaultTone){const toneEl=document.getElementById('toneSelectedText');if(toneEl)toneEl.textContent=b.textContent;}});
      const isCustom=data.defaultTone==='Custom';const cs=document.getElementById('customToneSection');const cl=document.getElementById('customToneSectionLabel');if(cs)cs.style.display=isCustom?'block':'none';if(cl)cl.style.display=isCustom?'block':'none';
    } else {const cs=document.getElementById('customToneSection');const cl=document.getElementById('customToneSectionLabel');if(cs)cs.style.display='none';if(cl)cl.style.display='none';}
    if(data.replyStyle){const b=document.getElementById('styleBox');if(b)b.value=data.replyStyle;}
    if(data.customTonePrompt){const b=document.getElementById('customTonePrompt');if(b)b.value=data.customTonePrompt;}
    if(data.customToneWords){const b=document.getElementById('customToneWords');if(b)b.value=data.customToneWords;}
    const sw=document.getElementById('smartSwitch');if(sw){sw.checked=data.smartSwitch!==false;updateSwitchLabel(sw.checked);}
    const pnSw=document.getElementById('projectNameSwitch');if(pnSw){pnSw.checked=data.useProjectNameGlobal!==false;updateProjectNameLabel(pnSw.checked);}
    const bigChk=document.getElementById('bigReplyModeToggle');const bigLbl=document.getElementById('bigReplyModeLabel');
    if(bigChk){const isOn=data.bigReplyMode===true;bigChk.checked=isOn;if(bigLbl){bigLbl.textContent=isOn?'ON':'OFF';bigLbl.className='grammar-toggle-label '+(isOn?'toggle-on':'toggle-off');}
      bigChk.addEventListener('change',()=>{const on=bigChk.checked;chrome.storage.local.set({bigReplyMode:on});if(bigLbl){bigLbl.textContent=on?'ON':'OFF';bigLbl.className='grammar-toggle-label '+(on?'toggle-on':'toggle-off');}});}
    const wcInput=document.getElementById('wordCountInput');if(wcInput&&data.bigReplyConfig)wcInput.value=data.bigReplyConfig.words||'';
    if(data.bigReplyConfig)setBigReplyTone(data.bigReplyConfig.tone||'Smart');
    const clearBtn=document.getElementById('bigReplyClearBtn');
    if(clearBtn)clearBtn.addEventListener('click',()=>{chrome.storage.local.set({bigReplyConfig:{words:'',tone:'Smart'},bigReplyMode:false});if(wcInput)wcInput.value='';setBigReplyTone('Smart');if(bigChk)bigChk.checked=false;if(bigLbl){bigLbl.textContent='OFF';bigLbl.className='grammar-toggle-label toggle-off';}showStatus('↺ Big Reply reset!','ok');});
    const sk1Chk=document.getElementById('sk1Toggle');if(sk1Chk){sk1Chk.checked=data.sk1Mode===true;sk1Chk.addEventListener('change',()=>chrome.storage.local.set({sk1Mode:sk1Chk.checked}));}
    const autoRepChk=document.getElementById('autoRepModeToggle');const autoRepLbl=document.getElementById('autoRepModeLabel');
    if(autoRepChk){
      const isOn=data.zenAutoRepMode===true;
      autoRepChk.checked=isOn;
      if(autoRepLbl)autoRepLbl.textContent=isOn?'ON':'OFF';
      autoRepChk.addEventListener('change',()=>{
        const on=autoRepChk.checked;
        chrome.storage.local.set({zenAutoRepMode:on});
        if(autoRepLbl)autoRepLbl.textContent=on?'ON':'OFF';
      });
    }
    const repEngineChk=document.getElementById('repEngineToggle');const repEngineLbl=document.getElementById('repEngineLabel');
    if(repEngineChk){
      const isOn=data.zenRepEngineOn===true; // default OFF
      repEngineChk.checked=isOn;
      if(repEngineLbl)repEngineLbl.textContent=isOn?'ON':'OFF';
      repEngineChk.addEventListener('change',()=>{
        const on=repEngineChk.checked;
        chrome.storage.local.set({zenRepEngineOn:on});
        if(repEngineLbl)repEngineLbl.textContent=on?'ON':'OFF';
      });
    }
    const feedEngineChk=document.getElementById('feedEngineToggle');const feedEngineLbl=document.getElementById('feedEngineLabel');
    if(feedEngineChk){
      const isOn=data.zenFeedEngineOn===true;
      feedEngineChk.checked=isOn;
      if(feedEngineLbl)feedEngineLbl.textContent=isOn?'ON':'OFF';
      feedEngineChk.addEventListener('change',()=>{
        const on=feedEngineChk.checked;
        chrome.storage.local.set({zenFeedEngineOn:on});
        if(feedEngineLbl)feedEngineLbl.textContent=on?'ON':'OFF';
      });
    }
    const feedAutoChk=document.getElementById('feedAutoModeToggle');const feedAutoLbl=document.getElementById('feedAutoModeLabel');
    if(feedAutoChk){
      const isOn=data.zenFeedAutoMode===true;
      feedAutoChk.checked=isOn;
      if(feedAutoLbl)feedAutoLbl.textContent=isOn?'ON':'OFF';
      feedAutoChk.addEventListener('change',()=>{
        const on=feedAutoChk.checked;
        chrome.storage.local.set({zenFeedAutoMode:on});
        if(feedAutoLbl)feedAutoLbl.textContent=on?'ON':'OFF';
      });
    }
    const feedLikeChk=document.getElementById('feedLikeToggle');const feedLikeLbl=document.getElementById('feedLikeLabel');
    if(feedLikeChk){
      const isOn=data.zenFeedLikeOn===true;
      feedLikeChk.checked=isOn;
      if(feedLikeLbl)feedLikeLbl.textContent=isOn?'ON':'OFF';
      feedLikeChk.addEventListener('change',()=>{
        const on=feedLikeChk.checked;
        chrome.storage.local.set({zenFeedLikeOn:on});
        if(feedLikeLbl)feedLikeLbl.textContent=on?'ON':'OFF';
      });
    }
    const feedGivDetectChk=document.getElementById('feedGivDetectToggle');const feedGivDetectLbl=document.getElementById('feedGivDetectLabel');
    if(feedGivDetectChk){
      const isOn=data.zenFeedGivDetectOn===true;
      feedGivDetectChk.checked=isOn;
      if(feedGivDetectLbl)feedGivDetectLbl.textContent=isOn?'ON':'OFF';
      feedGivDetectChk.addEventListener('change',()=>{
        const on=feedGivDetectChk.checked;
        chrome.storage.local.set({zenFeedGivDetectOn:on});
        if(feedGivDetectLbl)feedGivDetectLbl.textContent=on?'ON':'OFF';
      });
    }

    // ── Target Post Filter ────────────────────────────────────────
    let feedTargetKws = data.zenFeedTargetKeywords || [];
    const feedTargetToggle = document.getElementById('feedTargetFilterToggle');
    const feedTargetInput  = document.getElementById('feedTargetInput');
    const feedTargetAddBtn = document.getElementById('feedTargetAddBtn');
    const feedTargetTags   = document.getElementById('feedTargetTags');

    function renderFeedTargetTags(arr) {
      if (!feedTargetTags) return;
      feedTargetTags.innerHTML = '';
      arr.forEach((kw, i) => {
        const tag = document.createElement('span');
        tag.className = 'seh-kw-tag';
        tag.textContent = kw + ' ';
        const x = document.createElement('span');
        x.textContent = '✕';
        x.style.cursor = 'pointer';
        x.addEventListener('click', () => {
          feedTargetKws.splice(i, 1);
          chrome.storage.local.set({ zenFeedTargetKeywords: feedTargetKws });
          renderFeedTargetTags(feedTargetKws);
        });
        tag.appendChild(x);
        feedTargetTags.appendChild(tag);
      });
    }

    if (feedTargetToggle) {
      feedTargetToggle.checked = !!data.zenFeedTargetFilterOn;
      feedTargetToggle.addEventListener('change', () => {
        chrome.storage.local.set({ zenFeedTargetFilterOn: feedTargetToggle.checked });
      });
    }
    renderFeedTargetTags(feedTargetKws);

    function addFeedTargetKw() {
      const val = feedTargetInput?.value.trim();
      if (!val) return;
      val.split(',').map(v => v.trim()).filter(Boolean).forEach(kw => {
        if (!feedTargetKws.includes(kw)) feedTargetKws.push(kw);
      });
      if (feedTargetInput) feedTargetInput.value = '';
      chrome.storage.local.set({ zenFeedTargetKeywords: feedTargetKws });
      renderFeedTargetTags(feedTargetKws);
    }
    if (feedTargetAddBtn) feedTargetAddBtn.addEventListener('click', addFeedTargetKw);
    if (feedTargetInput) feedTargetInput.addEventListener('keypress', e => { if (e.key === 'Enter') addFeedTargetKw(); });

    const feedModelSel=document.getElementById('feedModelSelect');
    if(feedModelSel){
      const validModels=['model1','model2'];
      const storedModel=validModels.includes(data.zenFeedPromptModel)?data.zenFeedPromptModel:'model1';
      feedModelSel.value=storedModel;
      feedModelSel.addEventListener('change',()=>{
        chrome.storage.local.set({zenFeedPromptModel:feedModelSel.value});
      });
    }
    const repPercentSel=document.getElementById('repPercentSelect');
    if(repPercentSel){
      const validPercents=['100','75','50','25','10'];
      const stored=String(data.zenRepAutoPercentage||100);
      repPercentSel.value=validPercents.includes(stored)?stored:'100';
      repPercentSel.addEventListener('change',()=>{
        chrome.storage.local.set({zenRepAutoPercentage:Number(repPercentSel.value)});
      });
    }
    // Reply Speed — one shared setting (zenRepSpeedMode / zenRepCustomSeconds)
    // surfaced as a control in all three engines: Comment REP, FED, Search.
    function wireSharedSpeedControl(selEl, rowEl, inputEl, storedSpeed, storedSeconds){
      if(!selEl) return;
      const validSpeeds=['normal','fast','custom'];
      const speed=validSpeeds.includes(storedSpeed)?storedSpeed:'normal';
      selEl.value=speed;
      if(rowEl)rowEl.style.display=(speed==='custom')?'flex':'none';
      if(inputEl)inputEl.value=storedSeconds||5;
      selEl.addEventListener('change',()=>{
        const v=selEl.value;
        chrome.storage.local.set({zenRepSpeedMode:v});
        if(rowEl)rowEl.style.display=(v==='custom')?'flex':'none';
      });
      if(inputEl){
        inputEl.addEventListener('change',()=>{
          let s=Number(inputEl.value);
          if(!Number.isFinite(s)||s<1)s=1; if(s>120)s=120;
          inputEl.value=s;
          chrome.storage.local.set({zenRepCustomSeconds:s});
        });
      }
    }
    const repSpeedSel=document.getElementById('repSpeedSelect');
    const repCustomRow=document.getElementById('repCustomSecondsRow');
    const repCustomInput=document.getElementById('repCustomSecondsInput');
    wireSharedSpeedControl(repSpeedSel, repCustomRow, repCustomInput, data.zenRepSpeedMode, data.zenRepCustomSeconds);

    const feedSpeedSel=document.getElementById('feedSpeedSelect');
    const feedCustomRow=document.getElementById('feedCustomSecondsRow');
    const feedCustomInput=document.getElementById('feedCustomSecondsInput');
    wireSharedSpeedControl(feedSpeedSel, feedCustomRow, feedCustomInput, data.zenRepSpeedMode, data.zenRepCustomSeconds);

    const searchSpeedSel=document.getElementById('searchSpeedSelect');
    const searchCustomRow=document.getElementById('searchCustomSecondsRow');
    const searchCustomInput=document.getElementById('searchCustomSecondsInput');
    wireSharedSpeedControl(searchSpeedSel, searchCustomRow, searchCustomInput, data.zenRepSpeedMode, data.zenRepCustomSeconds);

    const givSpeedSel=document.getElementById('givSpeedSelect');
    const givCustomRow=document.getElementById('givCustomSecondsRow');
    const givCustomInput=document.getElementById('givCustomSecondsInput');
    wireSharedSpeedControl(givSpeedSel, givCustomRow, givCustomInput, data.zenRepSpeedMode, data.zenRepCustomSeconds);

    // Like → comment delay (shared by FED, Search, GIV): zenLikeDelay = [minSec, maxSec]; GIV like toggle.
    chrome.storage.local.get(['zenLikeDelay','zenGivLikeOn'],ld=>{
      const rng=Array.isArray(ld.zenLikeDelay)?ld.zenLikeDelay:[0,0];
      const ldIns=Array.from(document.querySelectorAll('.zexLikeDelayInput'));
      ldIns.forEach(inp=>{
        const v=Number(rng[+inp.dataset.idx]);
        inp.value=(isFinite(v)&&v>=0)?v:0;
        inp.addEventListener('change',()=>{
          let v=parseInt(inp.value,10); if(!isFinite(v)||v<0)v=0; if(v>120)v=120;
          ldIns.forEach(o=>{ if(o.dataset.idx===inp.dataset.idx) o.value=v; });
          let a=Number(ldIns.find(o=>o.dataset.idx==='0').value)||0;
          let b=Number(ldIns.find(o=>o.dataset.idx==='1').value)||0;
          if(b<a){const x=a;a=b;b=x;}
          ldIns.forEach(o=>{ o.value=(o.dataset.idx==='0')?a:b; });
          chrome.storage.local.set({zenLikeDelay:[a,b]});
        });
      });
      const givLikeChk=document.getElementById('givLikeToggle');const givLikeLbl=document.getElementById('givLikeLabel');
      if(givLikeChk){
        givLikeChk.checked=ld.zenGivLikeOn===true;
        if(givLikeLbl)givLikeLbl.textContent=givLikeChk.checked?'ON':'OFF';
        givLikeChk.addEventListener('change',()=>{
          chrome.storage.local.set({zenGivLikeOn:givLikeChk.checked});
          if(givLikeLbl)givLikeLbl.textContent=givLikeChk.checked?'ON':'OFF';
        });
      }
    });

    // Keep all three speed selects/inputs in sync live, since they're one shared setting.
    chrome.storage.onChanged.addListener((changes,area)=>{
      if(area!=='local')return;
      if(changes.zenRepSpeedMode){
        const v=changes.zenRepSpeedMode.newValue;
        [repSpeedSel,feedSpeedSel,searchSpeedSel,givSpeedSel].forEach(sel=>{ if(sel && sel.value!==v) sel.value=v; });
        [repCustomRow,feedCustomRow,searchCustomRow,givCustomRow].forEach(row=>{ if(row) row.style.display=(v==='custom')?'flex':'none'; });
      }
      if(changes.zenRepCustomSeconds){
        const s=changes.zenRepCustomSeconds.newValue;
        [repCustomInput,feedCustomInput,searchCustomInput,givCustomInput].forEach(inp=>{ if(inp && Number(inp.value)!==Number(s)) inp.value=s; });
      }
    });
    const searchEngineChk=document.getElementById('searchEngineToggle');const searchEngineLbl=document.getElementById('searchEngineLabel');
    if(searchEngineChk){
      const isOn=data.zenSearchEngineOn===true;
      searchEngineChk.checked=isOn;
      if(searchEngineLbl)searchEngineLbl.textContent=isOn?'ON':'OFF';
      searchEngineChk.addEventListener('change',()=>{
        const on=searchEngineChk.checked;
        chrome.storage.local.set({zenSearchEngineOn:on});
        if(searchEngineLbl)searchEngineLbl.textContent=on?'ON':'OFF';
      });
    }
    const searchAutoChk=document.getElementById('searchAutoModeToggle');const searchAutoLbl=document.getElementById('searchAutoModeLabel');
    if(searchAutoChk){
      const isOn=data.zenSearchAutoMode===true;
      searchAutoChk.checked=isOn;
      if(searchAutoLbl)searchAutoLbl.textContent=isOn?'ON':'OFF';
      searchAutoChk.addEventListener('change',()=>{
        const on=searchAutoChk.checked;
        chrome.storage.local.set({zenSearchAutoMode:on});
        if(searchAutoLbl)searchAutoLbl.textContent=on?'ON':'OFF';
      });
    }
    const searchLikeChk=document.getElementById('searchLikeToggle');const searchLikeLbl=document.getElementById('searchLikeLabel');
    if(searchLikeChk){
      const isOn=data.zenSearchLikeOn===true;
      searchLikeChk.checked=isOn;
      if(searchLikeLbl)searchLikeLbl.textContent=isOn?'ON':'OFF';
      searchLikeChk.addEventListener('change',()=>{
        const on=searchLikeChk.checked;
        chrome.storage.local.set({zenSearchLikeOn:on});
        if(searchLikeLbl)searchLikeLbl.textContent=on?'ON':'OFF';
      });
    }
    const searchModelSel=document.getElementById('searchModelSelect');
    if(searchModelSel){
      const validModels=['model1','model2'];
      const storedModel=validModels.includes(data.zenSearchPromptModel)?data.zenSearchPromptModel:'model1';
      searchModelSel.value=storedModel;
      searchModelSel.addEventListener('change',()=>{
        chrome.storage.local.set({zenSearchPromptModel:searchModelSel.value});
      });
    }
    const givEngineChk=document.getElementById('givEngineToggle');const givEngineLbl=document.getElementById('givEngineLabel');
    if(givEngineChk){
      const isOn=data.zenGivEngineOn===true;
      givEngineChk.checked=isOn;
      if(givEngineLbl)givEngineLbl.textContent=isOn?'ON':'OFF';
      givEngineChk.addEventListener('change',()=>{
        const on=givEngineChk.checked;
        chrome.storage.local.set({zenGivEngineOn:on});
        if(givEngineLbl)givEngineLbl.textContent=on?'ON':'OFF';
      });
    }
    const givAutoChk=document.getElementById('givAutoModeToggle');const givAutoLbl=document.getElementById('givAutoModeLabel');
    if(givAutoChk){
      const isOn=data.zenGivAutoMode===true;
      givAutoChk.checked=isOn;
      if(givAutoLbl)givAutoLbl.textContent=isOn?'ON':'OFF';
      givAutoChk.addEventListener('change',()=>{
        const on=givAutoChk.checked;
        chrome.storage.local.set({zenGivAutoMode:on});
        if(givAutoLbl)givAutoLbl.textContent=on?'ON':'OFF';
      });
    }
    const givAiVerifyChk=document.getElementById('givAiVerifyToggle');const givAiVerifyLbl=document.getElementById('givAiVerifyLabel');
    if(givAiVerifyChk){
      const isOn=data.zenGivAiVerify===true;
      givAiVerifyChk.checked=isOn;
      if(givAiVerifyLbl)givAiVerifyLbl.textContent=isOn?'ON':'OFF';
      givAiVerifyChk.addEventListener('change',()=>{
        const on=givAiVerifyChk.checked;
        chrome.storage.local.set({zenGivAiVerify:on});
        if(givAiVerifyLbl)givAiVerifyLbl.textContent=on?'ON':'OFF';
      });
    }
    const sehResultTypeSel=document.getElementById('sehResultTypeSelect');
    if(sehResultTypeSel){
      const validTypes=['top','latest'];
      sehResultTypeSel.value=validTypes.includes(data.zenSearchResultType)?data.zenSearchResultType:'top';
      sehResultTypeSel.addEventListener('change',()=>{
        chrome.storage.local.set({zenSearchResultType:sehResultTypeSel.value});
      });
    }
    const sehFilterIds=['sehFilterMedia','sehFilterReplies','sehFilterVerified','sehFilterLinks','sehFilterRetweets'];
    const sehSelectIds=['sehMinRepliesSelect','sehMinFavesSelect','sehLangSelect','sehWithinTimeSelect'];
    const f=Object.assign({media:false,replies:false,verified:false,links:false,retweets:false,minReplies:'',minFaves:'',lang:'',withinTime:''},data.zenSearchFilters||{});
    const chkMedia=document.getElementById('sehFilterMedia');if(chkMedia)chkMedia.checked=!!f.media;
    const chkReplies=document.getElementById('sehFilterReplies');if(chkReplies)chkReplies.checked=!!f.replies;
    const chkVerified=document.getElementById('sehFilterVerified');if(chkVerified)chkVerified.checked=!!f.verified;
    const chkLinks=document.getElementById('sehFilterLinks');if(chkLinks)chkLinks.checked=!!f.links;
    const chkRetweets=document.getElementById('sehFilterRetweets');if(chkRetweets)chkRetweets.checked=!!f.retweets;
    const selMinReplies=document.getElementById('sehMinRepliesSelect');if(selMinReplies)selMinReplies.value=f.minReplies||'';
    const selMinFaves=document.getElementById('sehMinFavesSelect');if(selMinFaves)selMinFaves.value=f.minFaves||'';
    const selLang=document.getElementById('sehLangSelect');if(selLang)selLang.value=f.lang||'';
    const selWithinTime=document.getElementById('sehWithinTimeSelect');if(selWithinTime)selWithinTime.value=f.withinTime||'';
    function saveSehFilters(){
      chrome.storage.local.set({zenSearchFilters:{
        media:!!document.getElementById('sehFilterMedia')?.checked,
        replies:!!document.getElementById('sehFilterReplies')?.checked,
        verified:!!document.getElementById('sehFilterVerified')?.checked,
        links:!!document.getElementById('sehFilterLinks')?.checked,
        retweets:!!document.getElementById('sehFilterRetweets')?.checked,
        minReplies:document.getElementById('sehMinRepliesSelect')?.value||'',
        minFaves:document.getElementById('sehMinFavesSelect')?.value||'',
        lang:document.getElementById('sehLangSelect')?.value||'',
        withinTime:document.getElementById('sehWithinTimeSelect')?.value||''
      }});
    }
    [...sehFilterIds,...sehSelectIds].forEach(id=>{
      const el=document.getElementById(id);
      if(el)el.addEventListener('change',saveSehFilters);
    });
  });
  const tones=['Smart','Funny','Professional','Supportive','Witty','Curious','Short','Human','Alpha','Positive','PositiveQuestion','Helpful','Auto'];
  chrome.storage.local.get(tones.map(t=>'useGrammar_'+t),d=>{
    tones.forEach(tone=>{const chk=document.getElementById('grammar_'+tone);const lbl=document.getElementById('grammarLabel_'+tone);if(!chk)return;const isOn=d['useGrammar_'+tone]!==false;chk.checked=isOn;if(lbl){lbl.textContent=isOn?'ON':'OFF';lbl.className='grammar-toggle-label '+(isOn?'toggle-on':'toggle-off');}chk.addEventListener('change',()=>{const on=chk.checked;chrome.storage.local.set({['useGrammar_'+tone]:on});if(lbl){lbl.textContent=on?'ON':'OFF';lbl.className='grammar-toggle-label '+(on?'toggle-on':'toggle-off');}});});
  });
  chrome.storage.local.get(['keywordBox','autoKeyword','customKeyword'],d=>{
    const kBox=document.getElementById('keywordBox');if(kBox&&d.keywordBox)kBox.value=d.keywordBox;
    ['autoKeyword','customKeyword'].forEach(key=>{const chk=document.getElementById(key+'Toggle');const lbl=document.getElementById(key+'Label');if(!chk)return;const isOn=d[key]!==false;chk.checked=isOn;if(lbl){lbl.textContent=isOn?'ON':'OFF';lbl.className='grammar-toggle-label '+(isOn?'toggle-on':'toggle-off');}chk.addEventListener('change',()=>{const on=chk.checked;chrome.storage.local.set({[key]:on});if(lbl){lbl.textContent=on?'ON':'OFF';lbl.className='grammar-toggle-label '+(on?'toggle-on':'toggle-off');}});});
  });
}

function saveAll() {
  const styleBox=document.getElementById('styleBox').value.trim();
  const activeTone=document.querySelector('.tone-chip.active'); const tone=activeTone?activeTone.dataset.tone:'Smart';
  const smartOn=document.getElementById('smartSwitch')?.checked??true; const projectOn=document.getElementById('projectNameSwitch')?.checked??true;
  const wcInput=document.getElementById('wordCountInput'); const bigToneBtn=document.getElementById('bigReplyToneBtn'); const bigModeChk=document.getElementById('bigReplyModeToggle');
  const sk1Chk=document.getElementById('sk1Toggle'); const kBox=document.getElementById('keywordBox');
  const customPrompt=document.getElementById('customTonePrompt')?.value.trim()||''; const customWords=document.getElementById('customToneWords')?.value.trim()||'';

  let pxEnabled=document.getElementById('proxyEnableSwitch')?.checked||false;
  const pxScheme=document.querySelector('.scheme-chip.active')?.dataset.scheme||'http';
  const pxHost=document.getElementById('proxyHost')?.value.trim()||'';
  const pxPort=document.getElementById('proxyPort')?.value.trim()||'';
  const pxUser=document.getElementById('proxyUsername')?.value.trim()||'';
  const pxPass=document.getElementById('proxyPassword')?.value||'';
  const pxHint=document.getElementById('proxyStatusHint');
  if(pxEnabled && (!pxHost || !pxPort)){
    pxEnabled=false;
    if(pxHint){pxHint.textContent='Enter a proxy host and port to turn USE PROXY on — left off for now.';pxHint.style.color='#c2410c';}
  } else if(pxHint){
    pxHint.textContent=pxEnabled?`Proxy applied: ${pxScheme}://${pxHost}:${pxPort}`:'Proxy is off — using your normal connection.';
    pxHint.style.color='';
  }
  const proxyConfig={enabled:pxEnabled,scheme:pxScheme,host:pxHost,port:pxPort,username:pxUser,password:pxPass};

  chrome.storage.local.set({defaultTone:tone,replyStyle:styleBox,smartSwitch:smartOn,useProjectNameGlobal:projectOn,bigReplyConfig:{words:wcInput?.value.trim()||'',tone:bigToneBtn?.dataset.tone||'Smart'},bigReplyMode:bigModeChk?.checked||false,sk1Mode:sk1Chk?.checked||false,keywordBox:kBox?.value.trim()||'',customTonePrompt:customPrompt,customToneWords:customWords,zenProxyConfig:proxyConfig},()=>{
    showStatus('Settings saved!','ok');
    chrome.runtime.sendMessage({type:'zenApplyProxy'});
  });
}

// ── Custom in-extension dropdown for Big Reply Tone (replaces native <select> which opened the OS picker UI) ──
function setBigReplyTone(tone){
  const btn=document.getElementById('bigReplyToneBtn'); const txt=document.getElementById('bigReplyToneText');
  if(btn)btn.dataset.tone=tone; if(txt)txt.textContent=tone;
  document.querySelectorAll('.big-reply-tone-option').forEach(o=>o.classList.toggle('active',o.dataset.tone===tone));
}

let statusTimeout;
function showStatus(msg,type){const el=document.getElementById('saveStatus');if(!el)return;el.textContent=msg;el.className='save-status '+type;clearTimeout(statusTimeout);statusTimeout=setTimeout(()=>{el.textContent='';el.className='save-status';},3000);}

// ── REGISTRATION REQUEST SYSTEM ───────────────────────────────
// ── Dynamic Contact Links ─────────────────────────────────────
async function loadContactLinks(){
  try {
    const cfg = await zAppConfig(false); const data = cfg && cfg.contact_settings;
    const xU = (data && data.xUsername) ? data.xUsername : 'Z3NITSUxZz';
    const tgU = (data && data.tgUsername) ? data.tgUsername : 'zenitsu_x777';
    document.querySelectorAll('a[data-contact="x"]').forEach(el=>{
      el.href = 'https://x.com/'+xU;
      el.textContent = '𝕏 '+xU;
    });
    document.querySelectorAll('a[data-contact="tg"]').forEach(el=>{
      el.href = 'https://t.me/'+tgU;
      el.textContent = ''+tgU;
    });
  } catch(e){}
}

// ── Slide-out menu drawer: open/close + tab switching ──
function zenOpenHub(hash){
  try { chrome.tabs.create({ url: chrome.runtime.getURL('hub.html') + (hash || ''), active: true }); } catch(e){}
}
// Backup & FAQ now lives INSIDE the extension as a normal tab (iframe of hub.html, loaded the first time it is opened).
function zenLoadHub(hash){
  var f = document.getElementById('hubFrame'); if (!f) return;
  var want = chrome.runtime.getURL('hub.html') + '?embed=1' + (hash || '');
  if (!f.getAttribute('src')) f.src = want;
}
window.addEventListener('message', function(e){
  var f = document.getElementById('hubFrame');
  if (!f || e.source !== f.contentWindow || !e.data || typeof e.data.zexHubH !== 'number') return;
  f.style.height = Math.max(520, Math.ceil(e.data.zexHubH)) + 'px';
});
document.getElementById('openHubBtn')?.addEventListener('click', function(){ var b = document.getElementById('navOpenHub'); if (b) b.click(); });
document.querySelectorAll('.nav-tab').forEach(function(btn){
  btn.addEventListener('click', function(){
    if (!btn.dataset.tabpanel) return;
    document.querySelectorAll('.nav-tab').forEach(function(b){ b.classList.remove('active'); });
    document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.remove('active'); });
    btn.classList.add('active');
    var panel = document.getElementById(btn.dataset.tabpanel);
    if (panel) panel.classList.add('active');
    var body = document.querySelector('.dash-body');
    if (body) body.scrollTop = 0;
    if (btn.dataset.tabpanel === 'tabPanelActivity') showActivityLanding();
    if (btn.dataset.tabpanel === 'tabPanelBackup') zenLoadHub();
    zenCloseMenuDrawer();
  });
});

function zenOpenMenuDrawer(){
  var overlay = document.getElementById('menuDrawerOverlay');
  var drawer = document.getElementById('menuDrawer');
  if (overlay) overlay.classList.add('open');
  if (drawer) drawer.classList.add('open');
}
function zenCloseMenuDrawer(){
  var overlay = document.getElementById('menuDrawerOverlay');
  var drawer = document.getElementById('menuDrawer');
  if (overlay) overlay.classList.remove('open');
  if (drawer) drawer.classList.remove('open');
}
document.getElementById('menuHamburgerBtn')?.addEventListener('click', zenOpenMenuDrawer);
document.getElementById('menuDrawerCloseBtn')?.addEventListener('click', zenCloseMenuDrawer);
document.getElementById('menuDrawerOverlay')?.addEventListener('click', zenCloseMenuDrawer);

// ── Activity tab: agent picker (Comment REP vs FED Engine) ──
function showActivityLanding(){
  var landing = document.getElementById('activityLanding');
  var repSec = document.getElementById('activityRepSection');
  var feedSec = document.getElementById('activityFeedSection');
  var searchSec = document.getElementById('activitySearchSection');
  var givSec = document.getElementById('activityGivSection');
  var followSec = document.getElementById('activityFollowSection');
  var tgEngSec = document.getElementById('activityTgEngageSection');
  var tgSwpSec = document.getElementById('activityTgSweepSection');
  var unfSec = document.getElementById('activityUnfollowSection');
  var tarSec = document.getElementById('activityTarSection');
  if (unfSec) unfSec.style.display = 'none';
  if (tarSec) tarSec.style.display = 'none';
  if (landing) landing.style.display = 'block';
  if (tgEngSec) tgEngSec.style.display = 'none';
  if (tgSwpSec) tgSwpSec.style.display = 'none';
  if (repSec) repSec.style.display = 'none';
  if (feedSec) feedSec.style.display = 'none';
  if (searchSec) searchSec.style.display = 'none';
  if (givSec) givSec.style.display = 'none';
  if (followSec) followSec.style.display = 'none';
  var body = document.querySelector('.dash-body');
  if (body) body.scrollTop = 0;
}
function showActivitySection(id){
  var landing = document.getElementById('activityLanding');
  var repSec = document.getElementById('activityRepSection');
  var feedSec = document.getElementById('activityFeedSection');
  var searchSec = document.getElementById('activitySearchSection');
  var givSec = document.getElementById('activityGivSection');
  var followSec = document.getElementById('activityFollowSection');
  var tgEngSec = document.getElementById('activityTgEngageSection');
  var tgSwpSec = document.getElementById('activityTgSweepSection');
  var unfSec = document.getElementById('activityUnfollowSection');
  var tarSec = document.getElementById('activityTarSection');
  if (unfSec) unfSec.style.display = (id === 'activityUnfollowSection') ? 'block' : 'none';
  if (tarSec) tarSec.style.display = (id === 'activityTarSection') ? 'block' : 'none';
  if (landing) landing.style.display = 'none';
  if (tgEngSec) tgEngSec.style.display = (id === 'activityTgEngageSection') ? 'block' : 'none';
  if (tgSwpSec) tgSwpSec.style.display = (id === 'activityTgSweepSection') ? 'block' : 'none';
  if (repSec) repSec.style.display = (id === 'activityRepSection') ? 'block' : 'none';
  if (feedSec) feedSec.style.display = (id === 'activityFeedSection') ? 'block' : 'none';
  if (searchSec) searchSec.style.display = (id === 'activitySearchSection') ? 'block' : 'none';
  if (givSec) givSec.style.display = (id === 'activityGivSection') ? 'block' : 'none';
  if (followSec) followSec.style.display = (id === 'activityFollowSection') ? 'block' : 'none';
  var body = document.querySelector('.dash-body');
  if (body) body.scrollTop = 0;
}
document.getElementById('chooseRepAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityRepSection'); });
document.getElementById('chooseFeedAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityFeedSection'); });
document.getElementById('chooseSearchAgentBtn')?.addEventListener('click', function(){ showActivitySection('activitySearchSection'); });
document.getElementById('chooseGivAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityGivSection'); });
document.getElementById('chooseFollowAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityFollowSection'); refreshFollowStatus(); });
document.getElementById('chooseTarAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityTarSection'); refreshTarStatus(); });
document.getElementById('chooseUnfollowAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityUnfollowSection'); });
document.getElementById('activityUnfollowBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('activityRepBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('activityFeedBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('activitySearchBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('activityGivBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('activityFollowBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('activityTarBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('chooseTgEngageAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityTgEngageSection'); refreshTgStatus(); });
document.getElementById('chooseTgSweepAgentBtn')?.addEventListener('click', function(){ showActivitySection('activityTgSweepSection'); refreshTgStatus(); });
document.getElementById('activityTgEngageBackBtn')?.addEventListener('click', showActivityLanding);
document.getElementById('activityTgSweepBackBtn')?.addEventListener('click', showActivityLanding);

// ═══ TEXT SCRAMBLE — SAVE BUTTONS + HEADER TITLE ═══════════════
// Same scramble effect used on the on-page AI process readout, applied
// here to: any "Save" button's label on click, and the "Z EX" header
// title once on load.
const ZEN_POPUP_SCRAMBLE_CHARS = '!<>-_\\/[]{}—=+*^?#';

function zenScrambleText(el, finalText, opts) {
  if (!el) return;
  opts = opts || {};
  const speed = opts.speed || 30;
  const full = finalText;
  const length = full.length;
  const queue = [];
  for (let i = 0; i < length; i++) {
    const start = Math.floor(Math.random() * (opts.startSpread || 8));
    const end = start + Math.floor(Math.random() * (opts.settleSpread || 10)) + 3;
    queue.push({ to: full[i], start, end, char: '' });
  }
  let frame = 0;
  if (el._zenScrambleTimer) clearInterval(el._zenScrambleTimer);
  el._zenScrambleTimer = setInterval(() => {
    let output = '';
    let complete = 0;
    for (let i = 0; i < length; i++) {
      const q = queue[i];
      if (frame >= q.end) {
        complete++;
        output += q.to;
      } else if (frame >= q.start) {
        if (!q.char || Math.random() < 0.3) {
          q.char = q.to === ' ' ? ' ' : ZEN_POPUP_SCRAMBLE_CHARS[Math.floor(Math.random() * ZEN_POPUP_SCRAMBLE_CHARS.length)];
        }
        output += q.char;
      } else {
        output += ' ';
      }
    }
    el.textContent = output;
    frame++;
    if (complete === length) {
      clearInterval(el._zenScrambleTimer);
      el._zenScrambleTimer = null;
      el.textContent = full;
      if (typeof opts.onDone === 'function') opts.onDone();
    }
  }, speed);
}

// Continuously cycles a title element through a list of phrases using the
// same scramble effect, e.g. "Z EX" -> "ZENZORO" -> "ZEN ECOSYSTEM" -> loop.
// Plays the header name once per load: shows startText, holds briefly,
// then scrambles to endText and stops — no further looping.
function zenPlayTitleOnce(el, startText, endText, holdMs) {
  if (!el) return;
  if (el._zenLoopTimer) { clearTimeout(el._zenLoopTimer); el._zenLoopTimer = null; }
  const baseFontSize = parseFloat(getComputedStyle(el).fontSize) || 14;
  function fitFont(text) {
    if (text.length > 10) el.style.fontSize = (baseFontSize * 0.72) + 'px';
    else if (text.length > 7) el.style.fontSize = (baseFontSize * 0.86) + 'px';
    else el.style.fontSize = baseFontSize + 'px';
  }
  fitFont(startText);
  zenScrambleText(el, startText, { speed: 34, startSpread: 6, settleSpread: 14, onDone: () => {
    setTimeout(() => {
      fitFont(endText);
      zenScrambleText(el, endText, { speed: 34, startSpread: 6, settleSpread: 14, onDone: () => {
        // Sequence complete — now keep ZEX continuously self-glitching, same
        // pattern as the connected-model loop.
        zenLoopModelScramble(el, 2800);
      }});
    }, holdMs || 1600);
  }});
}

// Keeps the connected-model value re-scrambling in place on an interval so
// it reads as "alive" rather than a static label. Re-scrambles to the SAME
// current text each cycle (value only changes if the app sets a new one).
function zenLoopModelScramble(el, intervalMs) {
  if (!el) return;
  if (el._zenModelLoopTimer) clearInterval(el._zenModelLoopTimer);
  const interval = intervalMs || 3200;
  el._zenModelLoopTimer = setInterval(() => {
    const current = el.textContent.trim();
    if (!current || current === '—') return;
    zenScrambleText(el, current, { speed: 26, startSpread: 5, settleSpread: 10 });
  }, interval);
}

function zenAttachSaveScramble(btn, savedLabel) {
  if (!btn || btn._zenScrambleAttached) return;
  btn._zenScrambleAttached = true;
  const originalLabel = btn.textContent;
  btn.addEventListener('click', () => {
    zenScrambleText(btn, savedLabel || originalLabel, { speed: 26 });
    setTimeout(() => {
      if (!btn._zenScrambleTimer) zenScrambleText(btn, originalLabel, { speed: 26 });
    }, 1100);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Header/login title scramble-in, once, on load.
  // Dashboard header: plays once per load — "ZEN ECO." then settles to "ZEX".
  const dashTitle = document.querySelector('.dash-title');
  if (dashTitle) {
    zenPlayTitleOnce(dashTitle, 'ZEN ECO.', 'ZEX', 1600);
  }
  const zenTitle = document.querySelector('.zen-title');
  if (zenTitle) {
    const text = zenTitle.textContent.trim();
    zenScrambleText(zenTitle, text, { speed: 34, startSpread: 6, settleSpread: 14 });
  }

  // Connected-model name: keep cycling through the scramble once a value is set.
  zenLoopModelScramble(document.getElementById('activeApiDisplay'));

  // Attach scramble feedback to every Save-style button.
  zenAttachSaveScramble(document.getElementById('saveAllBtn'), 'SAVED ✓');
  zenAttachSaveScramble(document.getElementById('tgVerifyBtn'));
  zenAttachSaveScramble(document.getElementById('repSaveBtn'));

  zenStartRainLayer('zenRainLogin', { color: '#1a1a1a' });
  zenStartRainLayer('zenRainDash', { color: '#1a1a1a' });
});

// ── macOS-dock-style magnify on the bottom nav: nearby tabs grow smoothly
// as a finger/pointer moves across the bar, using the same cosine falloff
// as the dock component so the effect feels identical, just simplified for
// a fixed row of buttons instead of variable-width icons. ──
function zenInitDockMagnify() {
  const nav = document.getElementById('bottomNav');
  if (!nav) return;
  const tabs = Array.from(nav.querySelectorAll('.nav-tab'));
  if (!tabs.length) return;

  const maxScale = 1.22;
  const effectWidth = 130; // px influence radius around the touch point
  let targetX = null;
  let currentScales = tabs.map(() => 1);
  let rafId = null;

  function computeTargets(x) {
    if (x === null) return tabs.map(() => 1);
    return tabs.map(tab => {
      const rect = tab.getBoundingClientRect();
      const navRect = nav.getBoundingClientRect();
      const center = (rect.left - navRect.left) + rect.width / 2;
      const dist = Math.abs(center - x);
      if (dist > effectWidth / 2) return 1;
      const theta = (1 - (dist / (effectWidth / 2))) * Math.PI / 2;
      const factor = Math.sin(theta);
      return 1 + factor * (maxScale - 1);
    });
  }

  function tick() {
    const targets = computeTargets(targetX);
    let stillMoving = false;
    currentScales = currentScales.map((s, i) => {
      const diff = targets[i] - s;
      if (Math.abs(diff) > 0.003) stillMoving = true;
      return s + diff * 0.25;
    });
    tabs.forEach((tab, i) => {
      tab.style.transform = `scale(${currentScales[i].toFixed(3)})`;
    });
    if (stillMoving || targetX !== null) {
      rafId = requestAnimationFrame(tick);
    } else {
      rafId = null;
    }
  }

  function startTick() {
    if (!rafId) rafId = requestAnimationFrame(tick);
  }

  function setFromClientX(clientX) {
    const navRect = nav.getBoundingClientRect();
    targetX = clientX - navRect.left;
    startTick();
  }

  nav.addEventListener('touchstart', e => { if (e.touches[0]) setFromClientX(e.touches[0].clientX); }, { passive: true });
  nav.addEventListener('touchmove', e => { if (e.touches[0]) setFromClientX(e.touches[0].clientX); }, { passive: true });
  nav.addEventListener('touchend', () => { targetX = null; startTick(); });
  nav.addEventListener('touchcancel', () => { targetX = null; startTick(); });
  nav.addEventListener('mousemove', e => setFromClientX(e.clientX));
  nav.addEventListener('mouseleave', () => { targetX = null; startTick(); });
}

// ── Falling-letters background (DOM spans, visible through translucent cards) ──
function zenStartRainLayer(containerId, opts) {
  const container = document.getElementById(containerId);
  if (!container) return;
  opts = opts || {};
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const count = opts.count || 22;
  const color = opts.color || '#1a1a1a';
  const getHost = opts.getHost || (() => container.parentElement);

  for (let i = 0; i < count; i++) {
    const span = document.createElement('span');
    span.textContent = chars[Math.floor(Math.random() * chars.length)];
    const left = Math.random() * 100;
    const size = 12 + Math.random() * 6;
    const opacity = 0.16 + Math.random() * 0.18;
    const duration = 9 + Math.random() * 10;
    const delay = Math.random() * -duration;
    span.style.cssText = `left:${left}%;top:-5%;font-size:${size}px;color:${color};opacity:${opacity};animation:zenFall ${duration}s linear ${delay}s infinite;`;
    container.appendChild(span);
  }

  // Occasionally swap a random character so the field feels alive, not static —
  // brief green glitch flash (matrix-style "dud"), then back to normal color.
  setInterval(() => {
    if (document.hidden) return;
    const spans = container.children;
    if (!spans.length) return;
    const n = Math.min(3, spans.length);
    for (let k = 0; k < n; k++) {
      const s = spans[Math.floor(Math.random() * spans.length)];
      s.textContent = chars[Math.floor(Math.random() * chars.length)];
      s.classList.add('dud');
      setTimeout(() => s.classList.remove('dud'), 220);
    }
  }, 350);
}


// ── Activity tab: Follow Engine ──────────────────────────────
// Speed presets, in seconds. "safe" and "normal" are fixed ranges;
// "custom" reads from the min/max inputs the person fills in themselves.
const FOLLOW_SPEED_PRESETS = {
  safe:   { min: 120, max: 240 },
  normal: { min: 45,  max: 90  },
};

function followLoadSpeedSettings() {
  chrome.storage.local.get(['zenFollowSpeedMode', 'zenFollowCustomMin', 'zenFollowCustomMax'], (data) => {
    const sel = document.getElementById('followSpeedSelect');
    const row = document.getElementById('followCustomGapRow');
    const minInp = document.getElementById('followCustomMinInput');
    const maxInp = document.getElementById('followCustomMaxInput');
    const mode = ['safe', 'normal', 'custom'].includes(data.zenFollowSpeedMode) ? data.zenFollowSpeedMode : 'safe';
    if (sel) sel.value = mode;
    if (row) row.style.display = (mode === 'custom') ? 'flex' : 'none';
    if (minInp) minInp.value = data.zenFollowCustomMin || 60;
    if (maxInp) maxInp.value = data.zenFollowCustomMax || 120;

    if (sel) sel.addEventListener('change', () => {
      const v = sel.value;
      chrome.storage.local.set({ zenFollowSpeedMode: v });
      if (row) row.style.display = (v === 'custom') ? 'flex' : 'none';
    });
    if (minInp) minInp.addEventListener('change', () => chrome.storage.local.set({ zenFollowCustomMin: Number(minInp.value) || 60 }));
    if (maxInp) maxInp.addEventListener('change', () => chrome.storage.local.set({ zenFollowCustomMax: Number(maxInp.value) || 120 }));
  });
}
followLoadSpeedSettings();

async function followGetGapRangeMs() {
  if (window.ZexTiming) { const adv = await window.ZexTiming.gap('follow'); if (adv) return adv; }   // Timing page (Advanced)
  const data = await new Promise(r => chrome.storage.local.get(['zenFollowSpeedMode', 'zenFollowCustomMin', 'zenFollowCustomMax'], r));
  const mode = data.zenFollowSpeedMode || 'safe';
  if (mode === 'custom') {
    let min = Number(data.zenFollowCustomMin) || 60;
    let max = Number(data.zenFollowCustomMax) || 120;
    if (max < min) max = min;
    return { minMs: min * 1000, maxMs: max * 1000 };
  }
  const preset = FOLLOW_SPEED_PRESETS[mode] || FOLLOW_SPEED_PRESETS.safe;
  return { minMs: preset.min * 1000, maxMs: preset.max * 1000 };
}

// ── Activity tab: Follow Engine ──────────────────────────────
// Parses "X.com/username", "@username", "twitter.com/username", full
// status/profile links, or a bare username per line — into a clean,
// deduped, lowercase username list.
function followParseUsernames(raw) {
  if (!raw) return [];
  const lines = String(raw).split(/[\r\n,]+/);
  const out = [];
  const seen = new Set();
  for (let line of lines) {
    line = line.trim();
    if (!line) continue;
    let u = line;
    u = u.replace(/^https?:\/\//i, '');
    u = u.replace(/^(www\.)?(x\.com|twitter\.com)\//i, '');
    u = u.replace(/^@/, '');
    u = u.split(/[/?#]/)[0]; // drop any trailing path (e.g. /status/123) or query
    u = u.trim();
    if (!u) continue;
    if (!/^[A-Za-z0-9_]{1,15}$/.test(u)) continue; // not a valid X handle shape — skip silently
    const key = u.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(key);
  }
  return out;
}

function followSendMsg(msg) {
  return new Promise(resolve => {
    try { chrome.runtime.sendMessage(msg, resolve); }
    catch (e) { resolve(null); }
  });
}

let followStatusPoll = null;

function followRenderJob(job) {
  const doneCount = document.getElementById('followDoneCount');
  const remSub = document.getElementById('followRemainingSub');
  const runLbl = document.getElementById('followRunLabel');
  const startBtn = document.getElementById('followStartStopBtn');
  const tagsWrap = document.getElementById('followedTags');
  const listLbl = document.getElementById('followListSectionLabel');

  const followed = (job && job.followed) || [];
  const queueLen = (job && job.queue && job.queue.length) || 0;
  const idx = (job && job.currentIndex) || 0;
  const remaining = Math.max(0, queueLen - idx);
  const running = job && (job.status === 'navigating' || job.status === 'working' || job.status === 'idle');

  if (doneCount) doneCount.textContent = followed.length;
  if (remSub) remSub.textContent = `${remaining} remaining · ${queueLen} total in queue`;

  if (startBtn) startBtn.textContent = running ? 'Stop' : 'Start';
  if (runLbl) {
    if (running) runLbl.textContent = `ON — following now (${idx}/${queueLen})`;
    else if (job && job.status === 'done') runLbl.textContent = `Done — followed ${followed.length}`;
    else if (job && job.status === 'stopped' && remaining > 0) runLbl.textContent = `Paused — ${remaining} left, press Start to resume`;
    else runLbl.textContent = 'OFF — add usernames above, then Start';
  }

  if (tagsWrap) {
    if (followed.length) {
      listLbl.style.display = '';
      tagsWrap.innerHTML = followed.slice().reverse().map(u => `<span class="seh-kw-tag">@${escapeHtml(u)}</span>`).join('');
    } else {
      listLbl.style.display = 'none';
      tagsWrap.innerHTML = '';
    }
  }
}

async function refreshFollowStatus() {
  const res = await followSendMsg({ type: 'followStatus' });
  followRenderJob(res && res.job);
  if (followStatusPoll) clearInterval(followStatusPoll);
  followStatusPoll = setInterval(async () => {
    const panel = document.getElementById('activityFollowSection');
    if (!panel || panel.style.display === 'none') { clearInterval(followStatusPoll); followStatusPoll = null; return; }
    const r = await followSendMsg({ type: 'followStatus' });
    followRenderJob(r && r.job);
  }, 2000);
}

document.getElementById('followImportBtn')?.addEventListener('click', () => {
  document.getElementById('followFileInput')?.click();
});
document.getElementById('followFileInput')?.addEventListener('change', (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const box = document.getElementById('followListInput');
    if (box) {
      const existing = box.value ? box.value + '\n' : '';
      box.value = existing + String(reader.result || '');
    }
    const status = document.getElementById('followListStatus');
    if (status) { status.textContent = `Imported ${file.name}`; status.className = 'verify-status ok'; }
  };
  reader.onerror = () => {
    const status = document.getElementById('followListStatus');
    if (status) { status.textContent = 'Could not read that file'; status.className = 'verify-status err'; }
  };
  reader.readAsText(file);
  e.target.value = '';
});

document.getElementById('followAddToQueueBtn')?.addEventListener('click', async () => {
  const box = document.getElementById('followListInput');
  const status = document.getElementById('followListStatus');
  let usernames = followParseUsernames(box ? box.value : '');
  let _skippedFollowed = 0;
  try { if (window.ZexPeople) { const _n = usernames.length; usernames = usernames.filter((u) => !window.ZexPeople.isFollowing(u)); _skippedFollowed = _n - usernames.length; } } catch (e) {}
  if (!usernames.length && _skippedFollowed) {
    if (status) { status.textContent = `All ${_skippedFollowed} already in your Following list — skipped`; status.className = 'verify-status ok'; }
    if (box) box.value = '';
    return;
  }
  if (!usernames.length) {
    if (status) { status.textContent = 'No valid usernames found — one per line, e.g. X.com/username'; status.className = 'verify-status err'; }
    return;
  }
  const gap = await followGetGapRangeMs();
  const res = await followSendMsg({ type: 'followStart', usernames, minGapMs: gap.minMs, maxGapMs: gap.maxMs });
  if (res && res.ok) {
    if (status) { status.textContent = `Queued ${usernames.length} usernames — engine running` + (_skippedFollowed ? ` · ${_skippedFollowed} already followed, skipped` : ''); status.className = 'verify-status ok'; }
    if (box) box.value = '';
    followRenderJob(res.job);
    refreshFollowStatus();
  } else if (res && res.reason === 'no_targets') {
    if (status) { status.textContent = 'Everyone in that list is already followed'; status.className = 'verify-status ok'; }
  } else {
    if (status) { status.textContent = 'Could not start — try again'; status.className = 'verify-status err'; }
  }
});

document.getElementById('followStartStopBtn')?.addEventListener('click', async () => {
  const btn = document.getElementById('followStartStopBtn');
  const isStop = btn && btn.textContent.trim() === 'Stop';
  if (isStop) {
    const res = await followSendMsg({ type: 'followStop' });
    refreshFollowStatus();
  } else {
    // Resume with no new usernames — continues the existing queue from currentIndex.
    const gap = await followGetGapRangeMs();
    const res = await followSendMsg({ type: 'followStart', usernames: null, minGapMs: gap.minMs, maxGapMs: gap.maxMs });
    if (res && res.reason === 'no_targets') {
      const status = document.getElementById('followListStatus');
      if (status) { status.textContent = 'Nothing queued yet — paste or import a list first'; status.className = 'verify-status err'; }
    }
    refreshFollowStatus();
  }
});


// ── Activity tab: TAR Engine (Target Account List / Favourite X List) ──
const TAR_SPEED_PRESETS = {
  safe:   { min: 120, max: 240 },
  normal: { min: 45,  max: 90  },
};

function tarParseUsernames(raw) {
  // Same permissive parsing as the Follow Engine — plain username, @username,
  // or a full profile link, one per line (or comma-separated).
  if (!raw) return [];
  const lines = String(raw).split(/[\r\n,]+/);
  const out = [];
  const seen = new Set();
  for (let line of lines) {
    line = line.trim();
    if (!line) continue;
    let u = line;
    u = u.replace(/^https?:\/\//i, '');
    u = u.replace(/^(www\.)?(x\.com|twitter\.com)\//i, '');
    u = u.replace(/^@/, '');
    u = u.split(/[/?#]/)[0];
    u = u.trim();
    if (!u) continue;
    if (!/^[A-Za-z0-9_]{1,15}$/.test(u)) continue;
    const key = u.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(key);
  }
  return out;
}

function tarSendMsg(msg) {
  return new Promise(resolve => {
    try { chrome.runtime.sendMessage(msg, resolve); }
    catch (e) { resolve(null); }
  });
}

function tarLoadSpeedSettings() {
  chrome.storage.local.get(['zenTarSpeedMode', 'zenTarCustomMin', 'zenTarCustomMax'], (data) => {
    const sel = document.getElementById('tarSpeedSelect');
    const row = document.getElementById('tarCustomGapRow');
    const minInp = document.getElementById('tarCustomMinInput');
    const maxInp = document.getElementById('tarCustomMaxInput');
    const mode = ['safe', 'normal', 'custom'].includes(data.zenTarSpeedMode) ? data.zenTarSpeedMode : 'normal';
    if (sel) sel.value = mode;
    if (row) row.style.display = (mode === 'custom') ? 'flex' : 'none';
    if (minInp) minInp.value = data.zenTarCustomMin || 90;
    if (maxInp) maxInp.value = data.zenTarCustomMax || 180;

    if (sel) sel.addEventListener('change', () => {
      const v = sel.value;
      chrome.storage.local.set({ zenTarSpeedMode: v });
      if (row) row.style.display = (v === 'custom') ? 'flex' : 'none';
    });
    if (minInp) minInp.addEventListener('change', () => chrome.storage.local.set({ zenTarCustomMin: Number(minInp.value) || 90 }));
    if (maxInp) maxInp.addEventListener('change', () => chrome.storage.local.set({ zenTarCustomMax: Number(maxInp.value) || 180 }));
  });
}
tarLoadSpeedSettings();

async function tarGetGapRangeMs() {
  if (window.ZexTiming) { const adv = await window.ZexTiming.gap('tar'); if (adv) return adv; }   // Timing page (Advanced)
  const data = await new Promise(r => chrome.storage.local.get(['zenTarSpeedMode', 'zenTarCustomMin', 'zenTarCustomMax'], r));
  const mode = data.zenTarSpeedMode || 'normal';
  if (mode === 'custom') {
    let min = Number(data.zenTarCustomMin) || 90;
    let max = Number(data.zenTarCustomMax) || 180;
    if (max < min) max = min;
    return { minMs: min * 1000, maxMs: max * 1000 };
  }
  const preset = TAR_SPEED_PRESETS[mode] || TAR_SPEED_PRESETS.normal;
  return { minMs: preset.min * 1000, maxMs: preset.max * 1000 };
}

// ── Settings persistence (global — applies to both sources) ──
function tarLoadSettings() {
  chrome.storage.local.get(['zenTarPostsPerAccount', 'zenTarEngageMode', 'zenTarReplyModel', 'zenTarSource'], (d) => {
    const postsInp = document.getElementById('tarPostsPerAccountInput');
    const modeSel = document.getElementById('tarEngageModeSelect');
    const replySel = document.getElementById('tarReplyModelSelect');
    const replyRow = document.getElementById('tarReplyModelRow');
    const srcSel = document.getElementById('tarSourceSelect');
    if (postsInp) postsInp.value = d.zenTarPostsPerAccount || 2;
    if (modeSel) modeSel.value = d.zenTarEngageMode || 'like';
    if (replySel) replySel.value = d.zenTarReplyModel || 'model1';
    if (replyRow) replyRow.style.display = (modeSel && modeSel.value !== 'like') ? 'flex' : 'none';
    if (srcSel) srcSel.value = d.zenTarSource || 'targets';
    tarApplySourceUi(srcSel ? srcSel.value : 'targets');
  });
}
function tarApplySourceUi(source) {
  const targetsBlock = document.getElementById('tarTargetsBlock');
  const xlistBlock = document.getElementById('tarXListBlock');
  if (targetsBlock) targetsBlock.style.display = (source === 'xlist') ? 'none' : 'block';
  if (xlistBlock) xlistBlock.style.display = (source === 'xlist') ? 'block' : 'none';
}
document.getElementById('tarSourceSelect')?.addEventListener('change', (e) => {
  chrome.storage.local.set({ zenTarSource: e.target.value });
  tarApplySourceUi(e.target.value);
});
document.getElementById('tarPostsPerAccountInput')?.addEventListener('change', (e) => {
  const v = Math.max(1, Math.min(10, Number(e.target.value) || 2));
  e.target.value = v;
  chrome.storage.local.set({ zenTarPostsPerAccount: v });
});
document.getElementById('tarEngageModeSelect')?.addEventListener('change', (e) => {
  chrome.storage.local.set({ zenTarEngageMode: e.target.value });
  const replyRow = document.getElementById('tarReplyModelRow');
  if (replyRow) replyRow.style.display = (e.target.value !== 'like') ? 'flex' : 'none';
});
document.getElementById('tarReplyModelSelect')?.addEventListener('change', (e) => {
  chrome.storage.local.set({ zenTarReplyModel: e.target.value });
});
tarLoadSettings();

// ── Target Account List: textarea + .txt import ──
document.getElementById('tarTargetsImportBtn')?.addEventListener('click', () => {
  document.getElementById('tarTargetsFileInput')?.click();
});
document.getElementById('tarTargetsFileInput')?.addEventListener('change', (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const box = document.getElementById('tarTargetsInput');
    if (box) {
      const existing = box.value ? box.value + '\n' : '';
      box.value = existing + String(reader.result || '');
    }
    const status = document.getElementById('tarTargetsStatus');
    if (status) { status.textContent = `Imported ${file.name}`; status.className = 'verify-status ok'; }
  };
  reader.onerror = () => {
    const status = document.getElementById('tarTargetsStatus');
    if (status) { status.textContent = 'Could not read that file'; status.className = 'verify-status err'; }
  };
  reader.readAsText(file);
  e.target.value = '';
});

// ── Favourite List (X List) fetch ──
document.getElementById('tarXListFetchBtn')?.addEventListener('click', async () => {
  const input = document.getElementById('tarXListInput');
  const status = document.getElementById('tarXListStatus');
  const link = input ? input.value.trim() : '';
  if (!/^https?:\/\/(www\.)?(x|twitter)\.com\/i\/lists\/\d+/i.test(link)) {
    if (status) { status.textContent = 'Paste a valid X List link, e.g. https://x.com/i/lists/1234567890123456789'; status.className = 'verify-status err'; }
    return;
  }
  const btn = document.getElementById('tarXListFetchBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Fetching…'; }
  if (status) { status.textContent = 'Opening the list and collecting members — this can take a few seconds.'; status.className = 'verify-status'; }

  const res = await tarSendMsg({ type: 'tarFetchXListMembers', listLink: link });
  if (btn) { btn.disabled = false; btn.textContent = 'Fetch Members'; }

  const usernames = (res && res.usernames) || [];
  if (!usernames.length) {
    if (status) { status.textContent = 'No members found — make sure the list is accessible and try again.'; status.className = 'verify-status err'; }
    return;
  }
  if (status) { status.textContent = `Found ${usernames.length} members — starting TAR Engine.`; status.className = 'verify-status ok'; }
  await tarStartRun(usernames, link);
});

// ── Start / Resume / Stop ──
async function tarCollectSettings() {
  const gap = await tarGetGapRangeMs();
  const postsInp = document.getElementById('tarPostsPerAccountInput');
  const modeSel = document.getElementById('tarEngageModeSelect');
  const replySel = document.getElementById('tarReplyModelSelect');
  return {
    postsPerAccount: Math.max(1, Math.min(10, Number(postsInp && postsInp.value) || 2)),
    engageMode: (modeSel && modeSel.value) || 'like',
    replyModel: (replySel && replySel.value) || 'model1',
    minGapMs: gap.minMs, maxGapMs: gap.maxMs,
  };
}

async function tarStartRun(usernames, xListLink) {
  const settings = await tarCollectSettings();
  const opts = Object.assign({}, settings, {
    source: xListLink ? 'xlist' : 'targets',
    xListLink: xListLink || null,
  });
  const res = await tarSendMsg({ type: 'tarStart', usernames, opts });
  const status = document.getElementById('tarTargetsStatus');
  if (res && res.ok) {
    if (status) { status.textContent = `Queued ${usernames.length} accounts — engine running`; status.className = 'verify-status ok'; }
    const box = document.getElementById('tarTargetsInput');
    if (box && !xListLink) box.value = '';
  } else {
    if (status) { status.textContent = 'Could not start — check the list and try again'; status.className = 'verify-status err'; }
  }
  refreshTarStatus();
}

document.getElementById('tarStartBtn')?.addEventListener('click', async () => {
  const btn = document.getElementById('tarStartBtn');
  const isStop = btn && btn.textContent.trim() === 'Stop';
  if (isStop) {
    await tarSendMsg({ type: 'tarStop' });
    refreshTarStatus();
    return;
  }
  const srcSel = document.getElementById('tarSourceSelect');
  const source = srcSel ? srcSel.value : 'targets';
  if (source === 'xlist') {
    document.getElementById('tarXListFetchBtn')?.click();
    return;
  }
  const box = document.getElementById('tarTargetsInput');
  const status = document.getElementById('tarTargetsStatus');
  const usernames = tarParseUsernames(box ? box.value : '');
  if (!usernames.length) {
    if (status) { status.textContent = 'No valid usernames found — one per line, e.g. X.com/username'; status.className = 'verify-status err'; }
    return;
  }
  await tarStartRun(usernames, null);
});

document.getElementById('tarResumeBtn')?.addEventListener('click', async () => {
  const res = await tarSendMsg({ type: 'tarResume' });
  if (!res || !res.ok) {
    const status = document.getElementById('tarTargetsStatus');
    if (status) { status.textContent = 'Nothing to resume — start a new run above'; status.className = 'verify-status err'; }
  }
  refreshTarStatus();
});

// ── Status polling / progress render ──
let tarStatusPoll = null;

function tarRenderJob(job) {
  const engagedCount = document.getElementById('tarEngagedCount');
  const progressSub = document.getElementById('tarProgressSub');
  const runLbl = document.getElementById('tarRunLabel');
  const startBtn = document.getElementById('tarStartBtn');
  const resumeRow = document.getElementById('tarResumeRow');
  const doneTags = document.getElementById('tarDoneTags');
  const doneLbl = document.getElementById('tarDoneSectionLabel');

  const done = (job && job.accountsDone) || [];
  const queueLen = (job && job.queue && job.queue.length) || 0;
  const idx = (job && job.currentIndex) || 0;
  const remaining = Math.max(0, queueLen - idx);
  const running = job && (job.status === 'navigating' || job.status === 'working' || job.status === 'idle');
  const paused = job && job.status === 'stopped' && remaining > 0;

  if (engagedCount) engagedCount.textContent = (job && job.engagedTotal) || 0;
  if (progressSub) progressSub.textContent = `${done.length} accounts done · ${remaining} remaining`;

  if (startBtn) startBtn.textContent = running ? 'Stop' : 'Start';
  if (runLbl) {
    if (running) runLbl.textContent = `ON — working now (${idx}/${queueLen})`;
    else if (job && job.status === 'done') runLbl.textContent = `Done — engaged ${(job.engagedTotal) || 0} posts across ${done.length} accounts`;
    else if (paused) runLbl.textContent = `Paused — ${remaining} accounts left`;
    else runLbl.textContent = 'OFF — add targets above, then Start';
  }
  if (resumeRow) resumeRow.style.display = paused ? 'flex' : 'none';

  if (doneTags) {
    if (done.length) {
      if (doneLbl) doneLbl.style.display = '';
      doneTags.innerHTML = done.slice().reverse().map(u => `<span class="seh-kw-tag">@${escapeHtml(u)}</span>`).join('');
    } else {
      if (doneLbl) doneLbl.style.display = 'none';
      doneTags.innerHTML = '';
    }
  }
}

async function refreshTarStatus() {
  const res = await tarSendMsg({ type: 'tarStatus' });
  tarRenderJob(res && res.job);
  if (tarStatusPoll) clearInterval(tarStatusPoll);
  tarStatusPoll = setInterval(async () => {
    const panel = document.getElementById('activityTarSection');
    if (!panel || panel.style.display === 'none') { clearInterval(tarStatusPoll); tarStatusPoll = null; return; }
    const r = await tarSendMsg({ type: 'tarStatus' });
    tarRenderJob(r && r.job);
  }, 2000);
}


/* ══ TELEGRAM ENGAGE + SWEEP — popup controls ══════════════════════════
   The floating panels live on web.telegram.org (telegram.js); this only opens
   Telegram, mirrors run status, and holds the shared Auto Like setting.   */
let tgStatusPoll = null;

function tgSetLikeUi(on) {
  document.querySelectorAll('.tgLikeToggle').forEach(t => { t.checked = on; });
  document.querySelectorAll('.tgLikeLabel').forEach(l => {
    l.textContent = on ? 'ON — likes each post it replies to' : 'OFF — replies only';
  });
}
chrome.storage.local.get(['zenTgLikeOn'], d => tgSetLikeUi(d.zenTgLikeOn === true));
document.querySelectorAll('.tgLikeToggle').forEach(t => {
  t.addEventListener('change', () => {
    chrome.storage.local.set({ zenTgLikeOn: t.checked });
    tgSetLikeUi(t.checked);
  });
});

// Random Like % — FED / SEA / Telegram (Engage + Sweep share one). 100 = like every post.
function zexBindLikePct(sel, key) {
  const els = document.querySelectorAll(sel);
  if (!els.length) return;
  const clamp = (v) => { v = parseInt(v, 10); return isFinite(v) ? Math.min(100, Math.max(0, v)) : 100; };
  chrome.storage.local.get([key], d => {
    const v = typeof d[key] === 'number' ? d[key] : 100;
    els.forEach(e => { e.value = v; });
  });
  els.forEach(e => e.addEventListener('change', () => {
    const v = clamp(e.value);
    els.forEach(x => { x.value = v; });
    chrome.storage.local.set({ [key]: v });
  }));
}
zexBindLikePct('#feedLikePct', 'zenFeedLikePct');
zexBindLikePct('#searchLikePct', 'zenSearchLikePct');
zexBindLikePct('.tgLikePctInput', 'zenTgLikePct');

// Telegram step timings (seconds). Defaults: 1–2s per step, 8–20s before the next post.
const TG_TIMING_DEFAULT = { view: [1, 2], like: [1, 2], gen: [1, 2], post: [1, 2], next: [8, 20] };
function tgTimingRead() {
  const t = JSON.parse(JSON.stringify(TG_TIMING_DEFAULT));
  document.querySelectorAll('.tgTimingInput').forEach(inp => {
    const v = parseInt(inp.value, 10);
    if (isFinite(v) && v >= 0) t[inp.dataset.key][+inp.dataset.idx] = Math.min(v, 120);
  });
  // Next-post gap: Min/Max entered as minutes + seconds → stored as total seconds.
  const nv = p => { const e = document.querySelector('.tgNextInput[data-part="' + p + '"]'); const v = e ? parseInt(e.value, 10) : NaN; return isFinite(v) && v >= 0 ? v : 0; };
  t.next = [nv('minM') * 60 + nv('minS'), nv('maxM') * 60 + nv('maxS')];
  Object.keys(t).forEach(k => { if (t[k][1] < t[k][0]) t[k] = [t[k][1], t[k][0]]; });
  return t;
}
chrome.storage.local.get(['zenTgTiming'], d => {
  const t = d.zenTgTiming || {};
  document.querySelectorAll('.tgTimingInput').forEach(inp => {
    const arr = t[inp.dataset.key];
    if (Array.isArray(arr) && isFinite(arr[+inp.dataset.idx])) inp.value = arr[+inp.dataset.idx];
  });
  if (Array.isArray(t.next) && t.next.length === 2) {
    const set = (p, v) => { const e = document.querySelector('.tgNextInput[data-part="' + p + '"]'); if (e) e.value = v; };
    set('minM', Math.floor(t.next[0] / 60)); set('minS', t.next[0] % 60);
    set('maxM', Math.floor(t.next[1] / 60)); set('maxS', t.next[1] % 60);
  }
});
document.querySelectorAll('.tgNextInput').forEach(inp => {
  inp.addEventListener('change', () => chrome.storage.local.set({ zenTgTiming: tgTimingRead() }));
});
document.querySelectorAll('.tgTimingInput').forEach(inp => {
  inp.addEventListener('change', () => {
    // Telegram Engage and Telegram Sweep show the same setting — keep both copies equal.
    document.querySelectorAll('.tgTimingInput[data-key="' + inp.dataset.key + '"][data-idx="' + inp.dataset.idx + '"]').forEach(o => { if (o !== inp) o.value = inp.value; });
    chrome.storage.local.set({ zenTgTiming: tgTimingRead() });
  });
});

// Telegram Engage break: after N successful replies, rest min–max seconds. Defaults match the old fixed values.
const TG_BREAK_DEFAULT = { every: 5, min: 60, max: 120 };
function tgBreakRead() {
  const b = Object.assign({}, TG_BREAK_DEFAULT);
  document.querySelectorAll('.tgBreakInput').forEach(inp => {
    const v = parseInt(inp.value, 10);
    if (isFinite(v) && v >= 0) b[inp.dataset.key] = Math.min(v, inp.dataset.key === 'every' ? 500 : 3600);
  });
  if (b.max < b.min) { const x = b.min; b.min = b.max; b.max = x; }
  return b;
}
chrome.storage.local.get(['zenTgBreak'], d => {
  const b = d.zenTgBreak;
  if (!b || typeof b !== 'object') return;
  document.querySelectorAll('.tgBreakInput').forEach(inp => {
    if (isFinite(b[inp.dataset.key])) inp.value = b[inp.dataset.key];
  });
});
document.querySelectorAll('.tgBreakInput').forEach(inp => {
  inp.addEventListener('change', () => {
    const b = tgBreakRead();
    document.querySelectorAll('.tgBreakInput').forEach(i => { if (isFinite(b[i.dataset.key])) i.value = b[i.dataset.key]; });   // show the cleaned-up values
    chrome.storage.local.set({ zenTgBreak: b });
  });
});

// Saved sweep folders — created from the floating Sweep panel on Telegram.
const TG_FOLDER_REASONS = {
  session: 'Session expired — log in again.',
  queue_busy: 'Another queue is running — stop it first.',
  engage_busy: 'Group Engage is running — stop it first.',
  no_links: 'This folder has no links.',
};
let _tgShowHidden = false, _tgLastList = null;
const tgFolderHidden = (f) => !!f && f.auto === 'tgfail' && Date.now() - (f.createdAt || 0) > 86400000;   // hidden after 1 day — data stays saved
function tgFoldersRender(fullList) {
  _tgLastList = fullList;
  const box = document.getElementById('tgSweepFolders');
  if (!box) return;
  box.textContent = '';
  const all = Array.isArray(fullList) ? fullList : [];
  const nHidden = all.filter(tgFolderHidden).length;
  const list = _tgShowHidden ? all : all.filter((f) => !tgFolderHidden(f));
  if (nHidden) {
    const tg = document.createElement('button');
    tg.className = 'verify-btn'; tg.type = 'button'; tg.style.cssText = 'width:100%;margin:0 0 8px;padding:7px 2px;';
    tg.textContent = _tgShowHidden ? 'Hide old failed folders' : 'Show old failed folders (' + nHidden + ')';
    tg.addEventListener('click', () => { _tgShowHidden = !_tgShowHidden; tgFoldersRender(_tgLastList); });
    box.appendChild(tg);
  }
  if (!Array.isArray(list) || !list.length) {
    const e = document.createElement('div');
    e.className = 'keyword-hint';
    e.textContent = 'No saved folders yet.';
    box.appendChild(e);
    return;
  }
  list.forEach(f => {
    const card = document.createElement('div');
    card.className = 'switch-row';
    card.style.cssText = 'display:block;margin-bottom:8px;';
    const t = document.createElement('div');
    t.className = 'switch-title';
    t.style.cssText = 'font-size:12px;overflow-wrap:anywhere;';
    t.textContent = f.name;
    const d = document.createElement('div');
    d.className = 'switch-desc';
    d.textContent = (f.links ? f.links.length : 0) + ' links';
    const btns = document.createElement('div');
    btns.style.cssText = 'display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-top:8px;';
    const mkBtn = (label, fn) => {
      const b = document.createElement('button');
      b.className = 'verify-btn';
      b.type = 'button';
      b.style.cssText = 'width:100%;min-width:0;margin:0;padding:8px 2px;white-space:nowrap;';
      b.textContent = label;
      b.addEventListener('click', fn);
      return b;
    };
    const run = mkBtn('Run', async () => {
      const st = document.getElementById('tgSweepFolderStatus');
      const _errF = f.auto === 'zexerr';   // Error file: forget the old failed marks so every link is really retried
      const res = await followSendMsg({ type: 'zenTgSweepSend', links: (f.links || []).slice(), retryIds: _errF ? (f.links || []).map((u) => { const m = String(u).match(/status\/(\d+)/); return m ? m[1] : ''; }).filter(Boolean) : [] });
      if (st) {
        if (res && res.ok) { st.textContent = 'Started "' + f.name + '"' + (res.resumed ? ' — resuming, ' + res.resumed + ' already done skipped' : ''); st.className = 'verify-status ok'; }
        else { st.textContent = (res && TG_FOLDER_REASONS[res.reason]) || 'Could not start. Try again.'; st.className = 'verify-status err'; }
      }
    });
    const chk = mkBtn('Check', () => { if (typeof window.zexLinkCheckLoad === 'function') window.zexLinkCheckLoad(f.name, (f.links || []).slice()); });
    const exp = mkBtn('⬇ Export', () => {
      // One folder → its own .txt (one link per line — importable again with "Import .txt")
      const blob = new Blob([(f.links || []).join('\n')], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = (String(f.name || 'folder').replace(/[\\/:*?"<>|]+/g, '_').trim() || 'folder') + '.txt';
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    const del = mkBtn('✕', () => {
      chrome.storage.local.get(['zenTgSweepFolders'], dd => {
        const cur = Array.isArray(dd.zenTgSweepFolders) ? dd.zenTgSweepFolders : [];
        chrome.storage.local.set({ zenTgSweepFolders: cur.filter(x => x.id !== f.id) });
      });
    });
    btns.appendChild(run); btns.appendChild(chk); btns.appendChild(exp); btns.appendChild(del);
    card.appendChild(t); card.appendChild(d); card.appendChild(btns);
    box.appendChild(card);
  });
}
chrome.storage.local.get(['zenTgSweepFolders'], d => tgFoldersRender(d.zenTgSweepFolders));
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'local' && ch.zenTgSweepFolders) tgFoldersRender(ch.zenTgSweepFolders.newValue);
});

/* ── Import .txt file ── */
document.getElementById('tgSweepImportInput')?.addEventListener('change', function(e) {
  const file = e.target.files[0];
  if (!file) return;
  const st = document.getElementById('tgSweepImportStatus');
  const reader = new FileReader();
  reader.onload = function(ev) {
    const text = ev.target.result || '';
    // Parse both formats:
    // 1) plain URL per line: https://x.com/...
    // 2) @handle: https://x.com/... format
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    const urls = [];
    for (const line of lines) {
      // Try @handle: URL format
      const m = line.match(/https?:\/\/x\.com\/[^\s]+/);
      if (m) urls.push(m[0].replace(/\?s=\d+$/, ''));
    }
    // Same post = same status ID (x.com/i/status/1 and x.com/user/status/1 are one link).
    const _seenIds = new Set(), unique = [];
    for (const u of urls) { const _m = u.match(/status\/(\d+)/); const _k = _m ? _m[1] : u; if (_seenIds.has(_k)) continue; _seenIds.add(_k); unique.push(u); }
    const _dupN = urls.length - unique.length;
    if (!unique.length) {
      if (st) { st.textContent = 'No X links found in file.'; st.className = 'verify-status err'; }
      return;
    }
    // Create a new folder with filename as name
    const name = file.name.replace(/\.txt$/i, '').slice(0, 40);
    const folder = { id: Date.now().toString(), name, links: unique, importedAt: Date.now() };
    chrome.storage.local.get(['zenTgSweepFolders'], dd => {
      const cur = Array.isArray(dd.zenTgSweepFolders) ? dd.zenTgSweepFolders : [];
      chrome.storage.local.set({ zenTgSweepFolders: [...cur, folder] }, () => {
        if (st) { st.textContent = `✓ Imported "${name}" — ${unique.length} links` + (_dupN ? ` (${_dupN} duplicate${_dupN === 1 ? '' : 's'} removed)` : ''); st.className = 'verify-status ok'; }
        setTimeout(() => { if (st) st.textContent = ''; }, 3000);
      });
    });
    // Reset input so same file can be imported again
    e.target.value = '';
  };
  reader.readAsText(file);
});

/* ── Remove duplicate links: inside every folder, and the same post in two folders (kept in the first one). The ⚠ Error file is only de-duplicated inside itself. ── */
document.getElementById('tgSweepDedupeBtn')?.addEventListener('click', function() {
  const st = document.getElementById('tgSweepImportStatus');
  chrome.storage.local.get(['zenTgSweepFolders'], d => {
    const folders = Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders : [];
    const idOf = (u) => { const m = String(u).match(/status\/(\d+)/); return m ? m[1] : String(u); };
    const seenAll = new Set();
    let removed = 0;
    const ordered = folders.filter((f) => f && f.auto !== 'zexerr').concat(folders.filter((f) => f && f.auto === 'zexerr'));
    ordered.forEach((f) => {
      const inF = new Set(), keep = [];
      (Array.isArray(f.links) ? f.links : []).forEach((u) => {
        const k = idOf(u);
        if (inF.has(k) || (f.auto !== 'zexerr' && seenAll.has(k))) { removed++; return; }
        inF.add(k); keep.push(u);
      });
      if (f.auto !== 'zexerr') inF.forEach((k) => seenAll.add(k));
      f.links = keep;
    });
    chrome.storage.local.set({ zenTgSweepFolders: folders }, () => {
      if (st) { st.textContent = removed ? '✓ ' + removed + ' duplicate link' + (removed === 1 ? '' : 's') + ' removed' : 'No duplicate links found.'; st.className = 'verify-status ' + (removed ? 'ok' : ''); setTimeout(() => { st.textContent = ''; }, 4000); }
    });
  });
});

/* ── Export all folders as .txt ── */
document.getElementById('tgSweepExportBtn')?.addEventListener('click', function() {
  chrome.storage.local.get(['zenTgSweepFolders'], d => {
    const folders = Array.isArray(d.zenTgSweepFolders) ? d.zenTgSweepFolders : [];
    if (!folders.length) {
      const st = document.getElementById('tgSweepImportStatus');
      if (st) { st.textContent = 'No folders to export.'; st.className = 'verify-status err'; setTimeout(() => { st.textContent = ''; }, 2000); }
      return;
    }
    // Export each folder as a section
    let out = '';
    folders.forEach(f => {
      out += `# ${f.name} (${(f.links || []).length} links)\n`;
      (f.links || []).forEach(url => { out += url + '\n'; });
      out += '\n';
    });
    const blob = new Blob([out.trim()], { type: 'text/plain' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `zex_queue_${new Date().toISOString().slice(0,10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  });
});

/* ── Load delay settings ── */
chrome.storage.local.get(['zenTgSweepDelayMin','zenTgSweepDelayMax'], d => {
  const minEl = document.getElementById('tgSweepDelayMin');
  const maxEl = document.getElementById('tgSweepDelayMax');
  if (minEl && d.zenTgSweepDelayMin) minEl.value = d.zenTgSweepDelayMin;
  if (maxEl && d.zenTgSweepDelayMax) maxEl.value = d.zenTgSweepDelayMax;
});

/* ── Save delay settings ── */
document.getElementById('tgSweepDelaySave')?.addEventListener('click', function() {
  const minVal = parseInt(document.getElementById('tgSweepDelayMin')?.value || '30');
  const maxVal = parseInt(document.getElementById('tgSweepDelayMax')?.value || '60');
  const st = document.getElementById('tgSweepDelayStatus');
  if (minVal < 5 || maxVal < 5 || minVal > maxVal) {
    if (st) { st.textContent = 'Min must be ≥ 5 and less than Max.'; st.className = 'verify-status err'; }
    return;
  }
  chrome.storage.local.set({ zenTgSweepDelayMin: minVal, zenTgSweepDelayMax: maxVal }, () => {
    if (st) { st.textContent = `✓ Delay: ${minVal}–${maxVal}s per link`; st.className = 'verify-status ok'; }
    setTimeout(() => { if (st) st.textContent = ''; }, 2000);
    // Send to background so running queue picks it up immediately
    chrome.runtime.sendMessage({ type: 'zenTgSweepDelayUpdate', min: minVal, max: maxVal });
  });
});


/* ══ AUTO UNFOLLOW — popup controls ═══════════════════════════════════ */
const UNF_DEFAULT = { mode: 'nonfollowers', limit: 0, minSec: 15, maxSec: 20, breakEvery: 15, breakSec: 120 };
const UNF_IDS = { limit: 'unfLimit', minSec: 'unfMinSec', maxSec: 'unfMaxSec', breakEvery: 'unfBreakEvery', breakSec: 'unfBreakSec' };
function unfReadSettings() {
  const s = Object.assign({}, UNF_DEFAULT);
  const m = document.getElementById('unfMode');
  if (m) s.mode = m.value === 'all' ? 'all' : 'nonfollowers';
  Object.keys(UNF_IDS).forEach(k => {
    const e = document.getElementById(UNF_IDS[k]);
    const v = e ? parseInt(e.value, 10) : NaN;
    if (isFinite(v) && v >= 0) s[k] = v;
  });
  if (s.maxSec < s.minSec) { const t = s.minSec; s.minSec = s.maxSec; s.maxSec = t; }
  return s;
}
function unfSaveSettings() { chrome.storage.local.set({ zenUnfSettings: unfReadSettings() }); }
chrome.storage.local.get(['zenUnfSettings', 'zenUnfStats'], d => {
  const s = Object.assign({}, UNF_DEFAULT, d.zenUnfSettings || {});
  const m = document.getElementById('unfMode'); if (m) m.value = s.mode;
  Object.keys(UNF_IDS).forEach(k => { const e = document.getElementById(UNF_IDS[k]); if (e) e.value = s[k]; });
  unfRenderStats(d.zenUnfStats);
});
['unfMode', ...Object.values(UNF_IDS)].forEach(id => document.getElementById(id)?.addEventListener('change', unfSaveSettings));

function unfRenderStats(st) {
  st = st || {};
  const running = !!st.running;
  const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  set('unfDoneCount', st.unfollowed || 0);
  set('unfSub', (st.skipped || 0) + ' skipped · ' + (st.failed || 0) + ' failed');
  const startB = document.getElementById('unfStartBtn'), stopB = document.getElementById('unfStopBtn');
  if (startB) startB.style.display = running ? 'none' : '';
  if (stopB) stopB.style.display = running ? '' : 'none';
  const rs = document.getElementById('unfRunStatus');
  if (rs && st.status && (running || rs.dataset.keep !== '1')) { rs.textContent = st.status; rs.className = 'verify-status'; }
}
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'local' && ch.zenUnfStats) unfRenderStats(ch.zenUnfStats.newValue);
});
const UNF_REASONS = {
  session: 'Session expired — log in again.',
  no_handle: 'Verify your X account first (Home → X verify).',
  already_running: 'Auto Unfollow is already running.',
};
document.getElementById('unfStartBtn')?.addEventListener('click', async () => {
  unfSaveSettings();
  const rs = document.getElementById('unfRunStatus');
  const res = await followSendMsg({ type: 'unfStart', cfg: window.ZexTiming ? window.ZexTiming.unfCfg(unfReadSettings()) : unfReadSettings() });
  if (rs) {
    if (res && res.ok) { rs.dataset.keep = ''; rs.textContent = 'Started — opening your Following list…'; rs.className = 'verify-status ok'; }
    else { rs.dataset.keep = '1'; rs.textContent = (res && UNF_REASONS[res.reason]) || 'Could not start. Try again.'; rs.className = 'verify-status err'; }
  }
});
document.getElementById('unfStopBtn')?.addEventListener('click', () => followSendMsg({ type: 'unfStop' }));

function tgRenderStatus(st) {
  st = st || {};
  const a = st.active;
  const running = !!(a && a.running);

  // Group Engage
  const done = document.getElementById('tgEngageDoneCount');
  const sub = document.getElementById('tgEngageSub');
  const lbl = document.getElementById('tgEngageRunLabel');
  const stopBtn = document.getElementById('tgEngageStopBtn');
  const src = running ? a : (st.lastRun || {});
  if (done) done.textContent = src.doneCount || 0;
  if (sub) sub.textContent = `${src.skippedCount || 0} skipped · ${src.failedCount || 0} failed`;
  if (lbl) {
    if (running) {
      const onBreak = a.breakUntil && Date.now() < a.breakUntil;
      lbl.textContent = onBreak ? `ON — ${a.breakLabel || 'pausing'}`
        : a.phase === 'IDLE_X' ? 'ON — engaging a post on X'
        : a.waitStartedAt ? 'ON — waiting for a new link in the chat'
        : 'ON — finding the next link in Telegram';
    } else if (st.armed) lbl.textContent = 'Panel is open on Telegram — press Start session there';
    else if (st.lastRun && st.lastRun.reason) lbl.textContent = `Finished — ${st.lastRun.reason}`;
    else lbl.textContent = 'OFF — open Telegram and press Start session';
  }
  if (stopBtn) stopBtn.style.display = (running || st.armed) ? '' : 'none';

  // Link Sweep queue
  const job = st.sweepJob;
  const sDone = document.getElementById('tgSweepDoneCount');
  const sSub = document.getElementById('tgSweepSub');
  const sLbl = document.getElementById('tgSweepRunLabel');
  const sStop = document.getElementById('tgSweepStopBtn');
  const total = (job && job.queue && job.queue.length) || 0;
  const idx = (job && job.currentIndex) || 0;
  const sRunning = job && (job.status === 'navigating' || job.status === 'working' || job.status === 'idle');
  if (sDone) sDone.textContent = idx;
  if (sSub) sSub.textContent = `${Math.max(0, total - idx)} remaining · ${total} total in queue`;
  if (sLbl) {
    if (sRunning) sLbl.textContent = `ON — engaging now (${idx}/${total})`;
    else if (job && job.status === 'done') sLbl.textContent = `Done — engaged ${idx} link${idx === 1 ? '' : 's'}`;
    else if (st.sweepArmed) sLbl.textContent = 'Sweep panel is open on Telegram';
    else sLbl.textContent = 'OFF — sweep a chat first, then Send to queue';
  }
  if (sStop) sStop.style.display = sRunning ? '' : 'none';
}

async function refreshTgStatus() {
  const st = await followSendMsg({ type: 'zenTgStatus' });
  tgRenderStatus(st);
  if (tgStatusPoll) clearInterval(tgStatusPoll);
  tgStatusPoll = setInterval(async () => {
    const e = document.getElementById('activityTgEngageSection');
    const w = document.getElementById('activityTgSweepSection');
    const visible = (e && e.style.display !== 'none') || (w && w.style.display !== 'none');
    if (!visible) { clearInterval(tgStatusPoll); tgStatusPoll = null; return; }
    tgRenderStatus(await followSendMsg({ type: 'zenTgStatus' }));
  }, 2000);
}

async function tgOpen(type, statusId) {
  const status = document.getElementById(statusId);
  const res = await followSendMsg({ type });
  if (status) {
    if (res && res.ok) { status.textContent = 'Opened — use the Z EX panel on the Telegram tab'; status.className = 'verify-status ok'; }
    else { status.textContent = 'Could not open Telegram — try again'; status.className = 'verify-status err'; }
  }
  refreshTgStatus();
}
document.getElementById('tgEngageOpenBtn')?.addEventListener('click', () => tgOpen('zenTgOpenEngage', 'tgEngageOpenStatus'));
document.getElementById('tgSweepOpenBtn')?.addEventListener('click', () => tgOpen('zenTgOpenSweep', 'tgSweepOpenStatus'));
document.getElementById('tgEngageStopBtn')?.addEventListener('click', async () => {
  await followSendMsg({ type: 'zenTgStop' });
  refreshTgStatus();
});
document.getElementById('tgSweepStopBtn')?.addEventListener('click', async () => {
  await followSendMsg({ type: 'sessAutoStop', sessionPath: 'telegram_sweep' });
  refreshTgStatus();
});


/* ══ DASHBOARD — Animation + Stats (moved from inline script) ══ */
/* ══ DASHBOARD — Animation + Stats ══════════════════════════════════ */
;(function dbvInit(){
  'use strict';
  const $ = id => document.getElementById(id);
  const scr=$('dbvScreen'), status=$('dbvStatus'), badge=$('dbvBadge'),
        feed=$('dbvFeed'), tweet=$('dbvTweet'), aidots=$('dbvAidots'),
        actLike=$('dbvActLike'), actReply=$('dbvActReply'),
        compose=$('dbvCompose'), ctext=$('dbvCtext'), csend=$('dbvCsend'),
        doneOvl=$('dbvDoneOvl'), cursor=$('dbvCursor'), dotsEl=$('dbvDots'),
        searchbar=$('dbvSearchbar'), givTag=$('dbvGivTag');
  if(!scr) return;

  let eng='REP', stepIdx=0, stepTimer=null, typeTimer=null, visible=false;

  /* ── Cursor positions [left%, top%] ─────────────────────────── */
  const POS = {
    idle:    ['78%','8%'],
    ai:      ['47%','42%'],
    like:    ['37%','64%'],
    reply:   ['13%','64%'],
    send:    ['80%','88%'],
    center:  ['48%','38%'],
    search:  ['68%','18%'],
  };
  function moveCursor(pos){ cursor.style.left=pos[0]; cursor.style.top=pos[1]; }

  /* ── Flows per engine ─────────────────────────────────────────── */
  const FLOWS = {
    REP: [
      { ms:2000, label:'Scanning comment thread...',   state:'scan'    },
      { ms:1800, label:'AI generating reply...',       state:'ai'      },
      { ms:900,  label:'Liking the post...',           state:'like'    },
      { ms:900,  label:'Opening reply box...',         state:'rep-clk' },
      { ms:2400, label:'Typing reply...',              state:'type',   text:'Great insight! The tokenomics here align perfectly with the broader thesis 🔥' },
      { ms:800,  label:'Sending reply...',             state:'send'    },
      { ms:1000, label:'✓ Done — Next comment',        state:'done'    },
    ],
    FED: [
      { ms:1400, label:'Scrolling feed...',            state:'scroll'  },
      { ms:1400, label:'Post found! Analyzing...',     state:'hl'      },
      { ms:1800, label:'AI generating reply...',       state:'ai'      },
      { ms:900,  label:'Liking...',                    state:'like'    },
      { ms:900,  label:'Opening reply box...',         state:'rep-clk' },
      { ms:2200, label:'Typing reply...',              state:'type',   text:'Exactly! The fundamentals support this bullish thesis 💎 accumulation confirmed' },
      { ms:800,  label:'Sending...',                   state:'send'    },
      { ms:800,  label:'✓ Done — Scrolling',           state:'done'    },
    ],
    SEA: [
      { ms:1400, label:'Search query active...',       state:'search'  },
      { ms:1400, label:'Match found!',                 state:'hl'      },
      { ms:1800, label:'AI analyzing post...',         state:'ai'      },
      { ms:900,  label:'Opening reply box...',         state:'rep-clk' },
      { ms:2200, label:'Typing reply...',              state:'type',   text:'This is spot on! Accumulation phase confirmed, market is reacting 🚀' },
      { ms:800,  label:'Sending...',                   state:'send'    },
      { ms:800,  label:'✓ Done',                       state:'done'    },
    ],
    GIV: [
      { ms:1800, label:'Scanning for giveaways...',    state:'scan'    },
      { ms:1200, label:'🎁 Giveaway detected!',        state:'giv'     },
      { ms:1600, label:'Verifying with AI...',         state:'ai'      },
      { ms:900,  label:'Opening reply box...',         state:'rep-clk' },
      { ms:2400, label:'Dropping wallet address...',   state:'type',   text:'0x742d35Cc6634C0532925a3b8D4C9F6E3b4a1e91' },
      { ms:800,  label:'Sending...',                   state:'send'    },
      { ms:1000, label:'✓ Entered!',                   state:'done'    },
    ],
  };

  /* ── Reset to blank state ─────────────────────────────────────── */
  function reset(){
    scr.className='dbv-screen';
    tweet.className='dbv-tweet';
    feed.className='dbv-feed';
    aidots.className='dbv-aidots';
    compose.className='dbv-compose';
    doneOvl.className='dbv-done-ovl';
    searchbar.className='dbv-searchbar';
    givTag.className='dbv-giv-tag';
    actLike.className='dbv-act';
    actLike.querySelector('svg').style.fill='';
    cursor.className='dbv-cursor show';
    cursor.style.opacity='1';
    if(typeTimer){ clearInterval(typeTimer); typeTimer=null; }
    ctext.textContent='';
    csend.className='dbv-csend';
  }

  /* ── State handlers ───────────────────────────────────────────── */
  function doScan(){
    scr.classList.add('scanning');
    moveCursor(POS.idle);
  }
  function doAI(){
    scr.classList.remove('scanning');
    aidots.classList.add('show');
    moveCursor(POS.ai);
  }
  function doLike(){
    aidots.classList.remove('show');
    moveCursor(POS.like);
    setTimeout(()=>{ actLike.classList.add('liked'); actLike.querySelector('svg').style.fill='#f43f5e'; }, 350);
  }
  function doRepClick(){
    moveCursor(POS.reply);
    setTimeout(()=> compose.classList.add('show'), 500);
  }
  function doType(text){
    moveCursor(POS.send);
    let i=0;
    const ms = Math.max(30, Math.round(2300/text.length));
    typeTimer = setInterval(()=>{
      if(i<text.length) ctext.textContent += text[i++];
      else { clearInterval(typeTimer); typeTimer=null; }
    }, ms);
  }
  function doSend(){
    moveCursor(POS.send);
    setTimeout(()=> csend.classList.add('pulse'), 200);
  }
  function doDone(){
    if(typeTimer){ clearInterval(typeTimer); typeTimer=null; }
    compose.className='dbv-compose';
    doneOvl.classList.add('show');
    feed.classList.add('scrolled');
    setTimeout(()=>{ cursor.style.opacity='0'; }, 100);
  }
  function doScroll(){
    feed.classList.add('scrolled');
    scr.classList.add('scanning');
    moveCursor(POS.center);
    setTimeout(()=>{ feed.classList.remove('scrolled'); scr.classList.remove('scanning'); }, 700);
  }
  function doHL(){ tweet.classList.add('highlight'); moveCursor(POS.center); }
  function doSearch(){
    searchbar.classList.add('show');
    scr.classList.add('scanning');
    moveCursor(POS.search);
  }
  function doGiv(){
    tweet.classList.add('giv-glow','highlight');
    givTag.classList.add('show');
    moveCursor(POS.center);
  }

  const STATE_FN = {
    scan:    ()=> doScan(),
    ai:      ()=> doAI(),
    like:    ()=> doLike(),
    'rep-clk':()=> doRepClick(),
    send:    ()=> doSend(),
    done:    ()=> doDone(),
    scroll:  ()=> doScroll(),
    hl:      ()=> doHL(),
    search:  ()=> doSearch(),
    giv:     ()=> doGiv(),
    type:    (step)=> doType(step.text||''),
  };

  /* ── Dots ─────────────────────────────────────────────────────── */
  function buildDots(flow){
    dotsEl.innerHTML='';
    flow.forEach(()=>{ const d=document.createElement('div'); d.className='dbv-dot'; dotsEl.appendChild(d); });
  }
  function setDot(i){
    dotsEl.querySelectorAll('.dbv-dot').forEach((d,idx)=> d.classList.toggle('on', idx===i));
  }

  /* ── Run one step ─────────────────────────────────────────────── */
  function runStep(){
    if(!visible) return;
    const flow=FLOWS[eng];
    if(!flow) return;
    if(stepIdx>=flow.length) stepIdx=0;
    const step=flow[stepIdx];
    reset();
    setDot(stepIdx);
    status.style.opacity='0';
    setTimeout(()=>{ status.textContent=step.label; status.style.opacity='1'; }, 150);
    const fn = STATE_FN[step.state];
    if(fn) fn(step);
    stepIdx++;
    stepTimer=setTimeout(runStep, step.ms+80);
  }

  function startAnim(e){
    stopAnim();
    if(e) eng=e;
    stepIdx=0;
    badge.textContent=eng;
    buildDots(FLOWS[eng]);
    cursor.style.opacity='1';
    runStep();
  }
  function stopAnim(){
    clearTimeout(stepTimer); clearInterval(typeTimer);
    stepTimer=null; typeTimer=null;
  }

  /* ── Engine tab clicks ────────────────────────────────────────── */
  document.querySelectorAll('.dbv-etab').forEach(btn=>{
    btn.addEventListener('click',()=>{
      document.querySelectorAll('.dbv-etab').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      if(visible) startAnim(btn.dataset.e);
    });
  });

  /* ── Nav tab visibility ───────────────────────────────────────── */
  document.querySelectorAll('.nav-tab').forEach(btn=>{
    btn.addEventListener('click',()=>{
      if(btn.dataset.tabpanel==='tabPanelDashboard'){
        visible=true;
        setTimeout(()=>{ startAnim(eng); loadStats(); }, 350);
      } else {
        visible=false;
        stopAnim();
      }
    });
  });

  /* ── Name bar (avatar letter + name + TG) ───────────────────── */
  function loadStats(){
    if(typeof chrome==='undefined'||!chrome.storage) return;
    chrome.storage.local.get(['zenDeviceSession','loggedUserTG'], d=>{
      const sess=d.zenDeviceSession||{};
      const rawEmail=sess.email||'';
      const name=rawEmail.split('@')[0]||'—';
      const pn=$('dbvPname'); if(pn) pn.textContent=name;
      const av=$('dbvPavi');
      if(av){
        const m=name.match(/[A-Za-z]/);
        av.textContent=(m?m[0]:name.charAt(0)||'?').toUpperCase();
      }
      const pt=$('dbvPtg');
      if(pt) pt.textContent = d.loggedUserTG ? '@'+d.loggedUserTG.replace(/^@/,'') : 'TG not linked';
    });
  }

  // Live update
  if(typeof chrome!=='undefined'&&chrome.storage&&chrome.storage.onChanged){
    chrome.storage.onChanged.addListener((ch,area)=>{
      if(area!=='local'||!visible) return;
      if('zenDeviceSession' in ch||'loggedUserTG' in ch) loadStats();
    });
  }

  // Auto-start if dashboard is the active panel on open
  setTimeout(()=>{
    const panel=$('tabPanelDashboard');
    if(panel&&panel.classList.contains('active')){ visible=true; startAnim(eng); loadStats(); }
  }, 600);

})();


/* Custom day start (minutes after midnight, storage key zexDayStartMin, default 0). 06:00 -> a "day" runs 06:00 to 06:00.
   zexNow() is "now" shifted back by that amount, so its calendar date is the current dashboard day. */
window.ZEX_DS = 0;
function zexNow(){ return new Date(Date.now() - (window.ZEX_DS||0)*60000); }

/* ══ DASHBOARD — Daily Activity graph (keyword vs normal feed) + export/import ══
   Data: zenDailyLog = { 'YYYY-MM-DD': {total,rep,fed,sea,giv,fedKw,fedNormal,kw:{word:n}} }
   written by content.js. Days that pre-date the log are rebuilt from zenReplyHistory
   (no keyword info there, so those feed replies count as normal feed). */
;(function dgaInit(){
  'use strict';
  const $ = id => document.getElementById(id);
  if(!$('dgaCard') || typeof chrome==='undefined' || !chrome.storage) return;

  const NUM = ['total','rep','fed','sea','giv','fedKw','fedNormal','tg','get','tar'];
  const C_KW='#eab308', C_NORM='#94a3b8', C_OTH='#6366f1', C_TG='#06b6d4', C_GET='#f97316', C_TAR='#ec4899';
  let range=7, kwSel='', days={}, dayPick=null, chartMode='bar'; // days = merged view; dayPick = 'YYYY-MM-DD' when a single day is selected

  const esc = s => String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const pad = n => String(n).padStart(2,'0');
  const dayKey = d => d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
  const emptyDay = () => ({ total:0, rep:0, fed:0, sea:0, giv:0, fedKw:0, fedNormal:0, tg:0, get:0, tar:0, kw:{} });

  function cleanDay(e){
    if(!e || typeof e!=='object') return null;
    const o=emptyDay();
    NUM.forEach(k=>{ const v=Math.floor(Number(e[k])); o[k]=isFinite(v)&&v>0?Math.min(v,1000000):0; });
    if(e.kw && typeof e.kw==='object'){
      Object.keys(e.kw).slice(0,200).forEach(w=>{
        const v=Math.floor(Number(e.kw[w])); const name=String(w).trim().toLowerCase().slice(0,40);
        if(name && isFinite(v) && v>0) o.kw[name]=Math.min(v,1000000);
      });
    }
    return o.total||o.fed||o.rep||o.sea||o.giv||o.tg||o.get||o.tar ? o : null;
  }
  // Per-field max: safe to run repeatedly (re-importing the same file never double counts).
  function mergeDay(a,b){
    const o=emptyDay();
    NUM.forEach(k=>{ o[k]=Math.max(a?a[k]||0:0, b?b[k]||0:0); });
    const ka=(a&&a.kw)||{}, kb=(b&&b.kw)||{};
    new Set(Object.keys(ka).concat(Object.keys(kb))).forEach(w=>{ o.kw[w]=Math.max(ka[w]||0,kb[w]||0); });
    return o;
  }
  function fromHistory(hist){
    const out={};
    (Array.isArray(hist)?hist:[]).forEach(e=>{
      if(!e||!e.ts) return;
      const k=dayKey(new Date(e.ts-(window.ZEX_DS||0)*60000)); const d=out[k]||(out[k]=emptyDay());
      const t=String(e.src||e.eng||e.tone||'').toUpperCase();
      d.total++;
      if(t==='REP') d.rep++; else if(t==='SEA') d.sea++; else if(t==='GIV') d.giv++;
      else if(t==='TG') d.tg++; else if(t==='TAR') d.tar++; else if(t==='GET') d.get++;
      else if(t==='FED'||t==='FED-GIV'){
        d.fed++;
        if(Array.isArray(e.kw)&&e.kw.some(w=>!/^[@$]/.test(w))) d.fedKw++; else d.fedNormal++;
      }
      if(Array.isArray(e.kw)) e.kw.forEach(w=>{ w=String(w||'').trim().toLowerCase().slice(0,40); if(w) d.kw[w]=(d.kw[w]||0)+1; });
    });
    return out;
  }
  function buildView(log,hist){
    const view={}; const h=fromHistory(hist);
    Object.keys(h).forEach(k=>{ view[k]=h[k]; });
    Object.keys(log||{}).forEach(k=>{
      if(!/^\d{4}-\d{2}-\d{2}$/.test(k)) return;
      const c=cleanDay(log[k]); if(c) view[k]=mergeDay(view[k],c);
    });
    return view;
  }

  function dayKeyOffset(n){ const t=zexNow(); return dayKey(new Date(t.getFullYear(),t.getMonth(),t.getDate()-n)); }
  function shortDate(k){ const p=k.split('-'); return new Date(+p[0],+p[1]-1,+p[2]).toLocaleDateString(undefined,{day:'numeric',month:'short'}); }
  function longDate(k){ const p=k.split('-'); return new Date(+p[0],+p[1]-1,+p[2]).toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short',year:'numeric'}); }

  function rangeKeys(){
    if(dayPick) return [dayPick];
    const keys=Object.keys(days).sort();
    if(range===0) return keys.slice(-60);           // chart cap for ALL
    const out=[]; const now=zexNow();
    for(let i=range-1;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()-i); out.push(dayKey(d)); }
    return out;
  }
  function inRangeKeys(){
    if(dayPick) return days[dayPick]?[dayPick]:[];
    if(range===0) return Object.keys(days);
    const set=new Set(rangeKeys()); return Object.keys(days).filter(k=>set.has(k));
  }
  // The three series for one day, honouring the keyword filter.
  function series(d){
    if(!d) return { kw:0, norm:0, oth:0, tg:0, get:0, tar:0 };
    const oth=(d.rep||0)+(d.sea||0)+(d.giv||0);
    if(kwSel) return { kw:(d.kw&&d.kw[kwSel])||0, norm:d.fedNormal||0, oth:0, tg:0, get:0, tar:0 };
    return { kw:d.fedKw||0, norm:d.fedNormal||0, oth:oth, tg:d.tg||0, get:d.get||0, tar:d.tar||0 };
  }

  // Single-day view: one bar per category for the picked day.
  function renderDayChart(){
    const box=$('dgaChart'); const d=days[dayPick];
    const cap='<div class="dga-daycap">'+esc(longDate(dayPick))+(d?' · Total '+d.total:'')+'</div>';
    if(!d){ box.innerHTML=cap+'<div class="dga-empty">No activity on this day</div>'; return; }
    const bars=kwSel
      ? [[kwSel.length>10?kwSel.slice(0,9)+'…':kwSel,(d.kw&&d.kw[kwSel])||0,C_KW],['Normal',d.fedNormal||0,C_NORM]]
      : [['Keyword',d.fedKw||0,C_KW],['Normal',d.fedNormal||0,C_NORM],['REP',d.rep||0,C_OTH],['SEA',d.sea||0,'#0ea5e9'],['GIV',d.giv||0,'#10b981'],['TG',d.tg||0,C_TG],['GET',d.get||0,C_GET],['TAR',d.tar||0,C_TAR]];
    const max=Math.max(1,...bars.map(x=>x[1]));
    const W=330,H=132,L=22,R=4,T=14,B=18; const iw=W-L-R, ih=H-T-B;
    const slot=iw/bars.length, w=Math.min(40,slot*0.6);
    let g='';
    [0,0.5,1].forEach(f=>{
      const y=T+ih-ih*f;
      g+='<line class="dga-grid" x1="'+L+'" x2="'+(W-R)+'" y1="'+y+'" y2="'+y+'"/><text x="'+(L-4)+'" y="'+(y+3)+'" text-anchor="end">'+Math.round(max*f)+'</text>';
    });
    bars.forEach((x,i)=>{
      const cx=L+i*slot+slot/2, h=x[1]/max*ih, y=T+ih-h;
      if(x[1]) g+='<rect x="'+(cx-w/2).toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+h.toFixed(1)+'" rx="2" fill="'+x[2]+'"/>';
      g+='<text x="'+cx.toFixed(1)+'" y="'+(y-3).toFixed(1)+'" text-anchor="middle" style="fill:var(--text);font-weight:700">'+x[1]+'</text>'+
         '<text x="'+cx.toFixed(1)+'" y="'+(H-4)+'" text-anchor="middle">'+esc(x[0])+'</text>';
    });
    box.innerHTML=cap+'<svg class="dga-svg" viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Activity on '+esc(dayPick)+'">'+g+'</svg>';
  }

  // Line view: one line per category across the selected range.
  function renderLineChart(){
    const keys=rangeKeys(); const box=$('dgaChart'); if(!box) return;
    const rows=keys.map(k=>({k, s:series(days[k])}));
    const defs=[['Keyword','kw',C_KW],['Normal','norm',C_NORM],['REP/SEA/GIV','oth',C_OTH],['Telegram','tg',C_TG],['Get Reply','get',C_GET],['TAR','tar',C_TAR]]
      .filter(d=>rows.some(r=>r.s[d[1]]>0));
    if(!defs.length){ box.innerHTML='<div class="dga-empty">No activity in this range yet</div>'; return; }
    const max=Math.max(1,...rows.map(r=>Math.max(...defs.map(d=>r.s[d[1]]))));
    const W=330,H=140,L=22,R=8,T=10,B=16; const iw=W-L-R, ih=H-T-B;
    const px=i=>rows.length>1?L+i*(iw/(rows.length-1)):L+iw/2;
    const py=v=>T+ih-(v/max)*ih;
    let g='';
    [0,0.5,1].forEach(f=>{
      const y=T+ih-ih*f;
      g+='<line class="dga-grid" x1="'+L+'" x2="'+(W-R)+'" y1="'+y+'" y2="'+y+'"/><text x="'+(L-4)+'" y="'+(y+3)+'" text-anchor="end">'+Math.round(max*f)+'</text>';
    });
    defs.forEach(([name,key,col])=>{
      const pts=rows.map((r,i)=>px(i).toFixed(1)+','+py(r.s[key]).toFixed(1)).join(' ');
      if(rows.length>1) g+='<polyline points="'+pts+'" fill="none" stroke="'+col+'" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>';
      const dr=rows.length<=31?2.4:0;
      if(dr) rows.forEach((r,i)=>{ g+='<circle cx="'+px(i).toFixed(1)+'" cy="'+py(r.s[key]).toFixed(1)+'" r="'+dr+'" fill="'+col+'"><title>'+esc(r.k)+' — '+name+': '+r.s[key]+'</title></circle>'; });
    });
    const idx=[0,Math.floor((rows.length-1)/2),rows.length-1].filter((v,i,a)=>a.indexOf(v)===i);
    idx.forEach((i,n)=>{ g+='<text x="'+px(i).toFixed(1)+'" y="'+(H-3)+'" text-anchor="'+(n===0&&idx.length>1?'start':(i===rows.length-1&&idx.length>1?'end':'middle'))+'">'+esc(rows[i].k.slice(5))+'</text>'; });
    const leg='<div style="display:flex;flex-wrap:wrap;gap:4px 10px;margin-top:4px;font-family:Poppins,sans-serif;font-size:8px;font-weight:700;color:var(--dim);">'+
      defs.map(d=>'<span><span style="display:inline-block;width:8px;height:3px;border-radius:2px;background:'+d[2]+';margin-right:4px;vertical-align:middle"></span>'+d[0]+'</span>').join('')+'</div>';
    box.innerHTML='<svg class="dga-svg" viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Daily activity lines">'+g+'</svg>'+leg;
  }

  function renderChart(){
    if(dayPick){ renderDayChart(); return; }
    if(chartMode==='line'){ renderLineChart(); return; }
    const keys=rangeKeys(); const box=$('dgaChart'); if(!box) return;
    const rows=keys.map(k=>({k, s:series(days[k])}));
    const sum=s=>s.kw+s.norm+s.oth+s.tg+s.get+s.tar;
    const max=Math.max(1,...rows.map(r=>sum(r.s)));
    if(!rows.some(r=>sum(r.s))){ box.innerHTML='<div class="dga-empty">No activity in this range yet</div>'; return; }
    const W=330,H=124,L=22,R=4,T=8,B=16; const iw=W-L-R, ih=H-T-B;
    const bw=iw/rows.length, gap=Math.min(4,bw*0.25), w=Math.max(2,bw-gap);
    let g='';
    [0,0.5,1].forEach(f=>{
      const y=T+ih-ih*f;
      g+='<line class="dga-grid" x1="'+L+'" x2="'+(W-R)+'" y1="'+y+'" y2="'+y+'"/>'+
         '<text x="'+(L-4)+'" y="'+(y+3)+'" text-anchor="end">'+Math.round(max*f)+'</text>';
    });
    rows.forEach((r,i)=>{
      const x=L+i*bw+gap/2; let y=T+ih;
      const parts=[[r.s.tar,C_TAR],[r.s.get,C_GET],[r.s.tg,C_TG],[r.s.oth,C_OTH],[r.s.norm,C_NORM],[r.s.kw,C_KW]];
      parts.forEach(([v,c])=>{ if(!v) return; const h=v/max*ih; y-=h; g+='<rect x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+h.toFixed(1)+'" rx="1.5" fill="'+c+'"/>'; });
      g+='<rect x="'+x.toFixed(1)+'" y="'+T+'" width="'+w.toFixed(1)+'" height="'+ih+'" fill="transparent"><title>'+esc(r.k)+' — '+(kwSel?esc(kwSel)+': ':'keyword: ')+r.s.kw+', normal: '+r.s.norm+(kwSel?'':', other: '+r.s.oth+', TG: '+r.s.tg+', GET: '+r.s.get+', TAR: '+r.s.tar)+'</title></rect>';
    });
    const lab=(i)=>{ const k=rows[i].k; return k.slice(5); };
    const idx=[0,Math.floor((rows.length-1)/2),rows.length-1].filter((v,i,a)=>a.indexOf(v)===i);
    idx.forEach((i,n)=>{ const x=L+i*bw+bw/2; g+='<text x="'+x.toFixed(1)+'" y="'+(H-3)+'" text-anchor="'+(n===0&&idx.length>1?'start':(i===rows.length-1&&idx.length>1?'end':'middle'))+'">'+esc(lab(i))+'</text>'; });
    box.innerHTML='<svg class="dga-svg" viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Daily activity">'+g+'</svg>';
  }

  function render(){
    // keyword dropdown (all keywords seen, keeps current selection)
    const all={}; Object.keys(days).forEach(k=>Object.entries(days[k].kw||{}).forEach(([w,n])=>{ all[w]=(all[w]||0)+n; }));
    const words=Object.keys(all).sort((a,b)=>all[b]-all[a]);
    const sel=$('dgaKwSel');
    if(kwSel && !words.includes(kwSel)) kwSel='';
    sel.innerHTML='<option value="">All keywords</option>'+words.map(w=>'<option value="'+esc(w)+'"'+(w===kwSel?' selected':'')+'>'+esc(w)+' ('+all[w]+')</option>').join('');

    const ks=inRangeKeys(); let kw=0,norm=0,oth=0,tg=0,gt=0,tr=0; const rk={};
    ks.forEach(k=>{
      const s=series(days[k]); kw+=s.kw; norm+=s.norm; oth+=s.oth; tg+=s.tg; gt+=s.get; tr+=s.tar;
      Object.entries(days[k].kw||{}).forEach(([w,n])=>{ rk[w]=(rk[w]||0)+n; });
    });
    $('dgaTKw').textContent=kw; $('dgaTNorm').textContent=norm; $('dgaTOth').textContent=oth;
    $('dgaTTg').textContent=tg; $('dgaTGet').textContent=gt; $('dgaTTar').textContent=tr;
    $('dgaTKwL').textContent=kwSel?kwSel:'Keyword feed';
    const tot=kw+norm; const pk=tot?Math.round(kw/tot*100):0;
    const sp=$('dgaSplit').children; sp[0].style.width=pk+'%'; sp[1].style.width=(tot?100-pk:0)+'%';
    $('dgaSplitL').textContent='Keyword '+pk+'% ('+kw+')'; $('dgaSplitR').textContent='Normal '+(tot?100-pk:0)+'% ('+norm+')';

    const top=Object.entries(rk).sort((a,b)=>b[1]-a[1]).slice(0,8); const mx=top.length?top[0][1]:1;
    $('dgaKwList').innerHTML=top.length
      ? '<div class="dga-kwcols">'+top.map(([w,n],i)=>'<div class="dga-kwcol" title="'+esc(w)+' — '+n+'"><span class="dga-kwcount">'+n+'</span><div class="dga-kwbarwrap"><div class="dga-kwbar" style="height:'+Math.max(6,Math.round(n/mx*100))+'%;animation-delay:'+(i*70)+'ms"></div></div><span class="dga-kwlabel">'+esc(w)+'</span></div>').join('')+'</div>'
      : '<div class="dga-empty" style="padding:6px 0">No keyword / project tags in this range</div>';

    renderChart(); renderList(); syncBtns();
  }

  function syncBtns(){
    document.querySelectorAll('#dgaRange .dga-rbtn').forEach(b=>{
      let on=false;
      if(b.dataset.d!==undefined){
        const k=dayKeyOffset(Number(b.dataset.d));
        if(b.dataset.d==='2') b.textContent=shortDate(k);
        b.title=k; on=(dayPick===k);
      } else on=(!dayPick && Number(b.dataset.r)===range);
      b.classList.toggle('active',on);
    });
    document.querySelectorAll('#dgaMode .dga-rbtn').forEach(b=>b.classList.toggle('active',b.dataset.m===chartMode));
    const di=$('dgaDate'); if(di){ di.max=dayKey(zexNow()); di.value=dayPick||''; }
  }
  function pickDay(k){ dayPick=/^\d{4}-\d{2}-\d{2}$/.test(k||'')?k:null; render(); }

  function renderList(){
    const box=$('dgaList'); if(!box) return;
    const ks=Object.keys(days).sort().reverse();
    if(!ks.length){ box.innerHTML='<div class="dga-empty">No saved days yet</div>'; return; }
    box.innerHTML='<div class="dga-lrow hdr"><span>Date</span><span>Total</span><span>Keyword</span><span>Normal</span><span>Other</span></div>'+
      ks.map(k=>{ const d=days[k]; return '<div class="dga-lrow" data-k="'+esc(k)+'" title="Tap to view this day"><span>'+esc(k)+'</span><span>'+d.total+'</span><span>'+d.fedKw+'</span><span>'+d.fedNormal+'</span><span>'+(d.rep+d.sea+d.giv+(d.tg||0)+(d.get||0)+(d.tar||0))+'</span></div>'; }).join('');
  }

  function load(){
    chrome.storage.local.get(['zenDailyLog','zenReplyHistory'], d=>{
      days=buildView(d.zenDailyLog,d.zenReplyHistory); render();
    });
  }

  function status(msg,type){
    const el=$('dgaStatus'); if(!el) return;
    el.textContent=msg||''; el.className='dga-status'+(type?' '+type:'');
    clearTimeout(status._t); if(msg) status._t=setTimeout(()=>{ el.textContent=''; el.className='dga-status'; },6000);
  }

  // ── controls ──
  $('dgaRange').addEventListener('click',e=>{
    const b=e.target.closest('.dga-rbtn'); if(!b) return;
    if(b.dataset.d!==undefined){ pickDay(dayKeyOffset(Number(b.dataset.d))); return; }
    dayPick=null; range=Number(b.dataset.r)||0; render();
  });
  $('dgaMode').addEventListener('click',e=>{
    const b=e.target.closest('.dga-rbtn'); if(!b) return;
    chartMode=b.dataset.m==='line'?'line':'bar';
    try{ chrome.storage.local.set({zenDgaChartMode:chartMode}); }catch(_){}
    render();
  });
  try{ chrome.storage.local.get(['zenDgaChartMode'],d=>{ if(d&&d.zenDgaChartMode==='line'){ chartMode='line'; render(); } }); }catch(_){}
  $('dgaDate').addEventListener('change',e=>{ pickDay(e.target.value); });
  $('dgaList').addEventListener('click',e=>{ const r=e.target.closest('.dga-lrow[data-k]'); if(r) pickDay(r.dataset.k); });
  $('dgaKwSel').addEventListener('change',e=>{ kwSel=e.target.value||''; render(); });
  $('dgaSaved').addEventListener('click',()=>{ $('dgaList').classList.toggle('open'); });

  // ── day start (custom day end time) ──
  const dsIn=$('dgaDayStart');
  const minToHM=m=>pad(Math.floor(m/60))+':'+pad(m%60);
  function applyDayStart(m){
    m=Math.floor(Number(m)); window.ZEX_DS=(isFinite(m)&&m>=0&&m<1440)?m:0;
    if(dsIn && dsIn.value!==minToHM(window.ZEX_DS)) dsIn.value=minToHM(window.ZEX_DS);
  }
  try{ chrome.storage.local.get(['zexDayStartMin','zenDailyLog','zenReplyHistory'],d=>{ applyDayStart(d.zexDayStartMin); days=buildView(d.zenDailyLog,d.zenReplyHistory); render(); }); }catch(_){}
  if(dsIn) dsIn.addEventListener('change',()=>{
    const m=/^(\d{1,2}):(\d{2})$/.exec(dsIn.value||''); if(!m) return;
    const v=(+m[1])*60+(+m[2]);
    try{ chrome.storage.local.set({zexDayStartMin:v}); }catch(_){}
    applyDayStart(v); status('Day now runs '+minToHM(v)+' → '+minToHM(v)+' ✓','ok');
    chrome.storage.local.get(['zenDailyLog','zenReplyHistory'],d=>{ days=buildView(d.zenDailyLog,d.zenReplyHistory); render(); });
  });
  chrome.storage.onChanged.addListener((ch,area)=>{ if(area==='local'&&ch.zexDayStartMin){ applyDayStart(ch.zexDayStartMin.newValue); chrome.storage.local.get(['zenDailyLog','zenReplyHistory'],d=>{ days=buildView(d.zenDailyLog,d.zenReplyHistory); render(); }); } });

  // ── export ── (exports the merged view, so history-derived days are saved too)
  $('dgaExport').addEventListener('click',()=>{
    chrome.storage.local.get(['zenDailyLog','zenReplyHistory'], d=>{
      const view=buildView(d.zenDailyLog,d.zenReplyHistory);
      const n=Object.keys(view).length;
      if(!n){ status('Nothing to export yet.','err'); return; }
      const payload={ app:'ZEX', type:'dashboard-status', version:1, exportedAt:new Date().toISOString(), dayCount:n, days:view };
      const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
      const url=URL.createObjectURL(blob); const a=document.createElement('a');
      a.href=url; a.download='zex_dashboard_'+dayKey(new Date())+'.json';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),1500);
      status('Exported '+n+' day'+(n===1?'':'s')+' ✓','ok');
    });
  });

  // ── import (merge, never deletes) ──
  $('dgaImport').addEventListener('change',e=>{
    const input=e.target; const file=input.files&&input.files[0]; if(!file) return;
    if(file.size>5*1024*1024){ status('File too large.','err'); input.value=''; return; }
    const rd=new FileReader();
    rd.onerror=()=>{ status('Could not read that file.','err'); input.value=''; };
    rd.onload=ev=>{
      input.value='';
      let parsed; try{ parsed=JSON.parse(ev.target.result); }catch(_){ status('Invalid file — not valid JSON.','err'); return; }
      const src=parsed&&parsed.type==='dashboard-status'&&parsed.days&&typeof parsed.days==='object'?parsed.days:null;
      if(!src){ status('Not a ZEX dashboard export.','err'); return; }
      const incoming={}; Object.keys(src).slice(0,2000).forEach(k=>{ if(/^\d{4}-\d{2}-\d{2}$/.test(k)){ const c=cleanDay(src[k]); if(c) incoming[k]=c; } });
      const ik=Object.keys(incoming); if(!ik.length){ status('No valid days found in that file.','err'); return; }
      chrome.storage.local.get(['zenDailyLog'], d=>{
        const log=(d.zenDailyLog&&typeof d.zenDailyLog==='object')?d.zenDailyLog:{};
        ik.forEach(k=>{ log[k]=mergeDay(cleanDay(log[k]),incoming[k]); });
        const all=Object.keys(log).sort(); if(all.length>400) all.slice(0,all.length-400).forEach(k=>delete log[k]);
        chrome.storage.local.set({zenDailyLog:log},()=>{
          if(chrome.runtime.lastError){ status('Import failed: '+chrome.runtime.lastError.message,'err'); return; }
          load(); status('Imported '+ik.length+' day'+(ik.length===1?'':'s')+' ✓','ok');
        });
      });
    };
    rd.readAsText(file);
  });

  chrome.storage.onChanged.addListener((ch,area)=>{ if(area==='local'&&('zenDailyLog' in ch||'zenReplyHistory' in ch)) load(); });
  document.querySelectorAll('.nav-tab').forEach(b=>b.addEventListener('click',()=>{ if(b.dataset.tabpanel==='tabPanelDashboard') setTimeout(load,350); }));
  load();
})();


/* ══ DASHBOARD — Daily Summary card ══
   Data: zenAgentDayLog = { 'YYYY-MM-DD': { ok, fail, posted, by:{ENG:{ok,fail}}, err:{text:n} } } — written by background.js
   (zexDayTick). Reset / Auto Reset on the Agent dashboard never touches it. */
;(function dsInit(){
  'use strict';
  const $ = id => document.getElementById(id);
  if(!$('dsCard') || typeof chrome==='undefined' || !chrome.storage) return;
  let log = {}, sel = '';
  const pad = n => String(n).padStart(2,'0');
  const dayKey = d => d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
  const todayKey = () => dayKey(zexNow());
  const pct = (a,b) => b ? Math.round(a*100/b) : null;
  function mk(tag, css, text){ const n=document.createElement(tag); if(css) n.style.cssText=css; if(text!=null) n.textContent=text; return n; }
  function row(left, right, color){
    const r = mk('div','display:flex;justify-content:space-between;gap:8px;padding:4px 0;border-bottom:1px solid var(--border);font-size:11px;');
    r.appendChild(mk('span','min-width:0;overflow-wrap:anywhere;',left));
    r.appendChild(mk('b','flex:none;'+(color?'color:'+color+';':''),right));
    return r;
  }
  function dayName(k){
    if(k===todayKey()) return 'Today · '+k;
    const y=zexNow(); y.setDate(y.getDate()-1);
    return k===dayKey(y) ? 'Yesterday · '+k : k;
  }
  function render(){
    const keys = Object.keys(log).sort().reverse();
    if(!keys.includes(todayKey())) keys.unshift(todayKey());
    if(!sel || !keys.includes(sel)) sel = todayKey();
    const dsSel = $('dsDay');
    if(dsSel.dataset.n !== keys.join(',')){
      dsSel.textContent='';
      keys.slice(0,90).forEach(k=>{ const o=document.createElement('option'); o.value=k; o.textContent=dayName(k); dsSel.appendChild(o); });
      dsSel.dataset.n = keys.join(',');
    }
    dsSel.value = sel;
    const d = log[sel] || {ok:0,fail:0,posted:0,by:{},err:{}};
    const tot = (d.ok||0)+(d.fail||0), rate = pct(d.ok||0, tot);
    $('dsTotal').textContent = tot; $('dsOk').textContent = d.ok||0; $('dsFail').textContent = d.fail||0;
    const bar = $('dsBar').children; bar[0].style.width = tot?((d.ok||0)*100/tot)+'%':'0%'; bar[1].style.width = tot?((d.fail||0)*100/tot)+'%':'0%';
    $('dsRate').textContent = 'Success rate '+(rate==null?'—':rate+'%'); $('dsPosted').textContent = 'Posted '+(d.posted||0);
    const eng=$('dsEng'); eng.textContent='';
    const en = Object.keys(d.by||{}).sort((a,b)=>((d.by[b].ok+d.by[b].fail)-(d.by[a].ok+d.by[a].fail)));
    if(!en.length) eng.appendChild(mk('div','color:var(--dim);font-size:11px;padding:4px 0;','No activity this day.'));
    en.forEach(e=>{ const b=d.by[e], t=b.ok+b.fail, p=pct(b.ok,t); eng.appendChild(row(e, b.ok+' ✓  '+b.fail+' ✗  · '+(p==null?'—':p+'%'), b.fail>b.ok?'#dc2626':null)); });
    const er=$('dsErr'); er.textContent='';
    const ek = Object.keys(d.err||{}).sort((a,b)=>d.err[b]-d.err[a]).slice(0,6);
    if(!ek.length) er.appendChild(mk('div','color:var(--dim);font-size:11px;padding:4px 0;','No errors 🎉'));
    ek.forEach(t=>er.appendChild(row(t,'×'+d.err[t],'#dc2626')));
    const wk=$('dsWeek'); wk.textContent='';
    for(let i=0;i<7;i++){
      const dt=zexNow(); dt.setDate(dt.getDate()-i); const k=dayKey(dt), x=log[k]||{ok:0,fail:0}, t=x.ok+x.fail, p=pct(x.ok,t);
      const r=row(k.slice(5)+(i===0?' (today)':''), t?(x.ok+' ✓  '+x.fail+' ✗  · '+p+'%'):'—');
      r.style.cursor='pointer'; r.addEventListener('click',()=>{ sel=k; render(); });
      wk.appendChild(r);
    }
  }
  function load(){ chrome.storage.local.get(['zenAgentDayLog','zexDayStartMin'], d=>{ { const m=Math.floor(Number(d.zexDayStartMin)); window.ZEX_DS=(isFinite(m)&&m>=0&&m<1440)?m:0; } log=(d.zenAgentDayLog&&typeof d.zenAgentDayLog==='object')?d.zenAgentDayLog:{}; render(); }); }
  $('dsDay').addEventListener('change', e=>{ sel=e.target.value; render(); });
  $('dsCsv').addEventListener('click', ()=>{
    const ks=Object.keys(log).sort();
    if(!ks.length){ const st=$('dsStatus'); st.textContent='Nothing to export yet.'; st.className='dga-status err'; return; }
    const engs=[...new Set(ks.flatMap(k=>Object.keys(log[k].by||{})))].sort();
    const head=['date','total','success','failed','success_rate','posted'].concat(engs.flatMap(e=>[e+'_ok',e+'_fail']),['top_errors']);
    const lines=[head.join(',')];
    ks.forEach(k=>{
      const d=log[k], t=(d.ok||0)+(d.fail||0), p=pct(d.ok||0,t);
      const te=Object.keys(d.err||{}).sort((a,b)=>d.err[b]-d.err[a]).slice(0,3).map(x=>x+' x'+d.err[x]).join(' | ').replace(/"/g,'""');
      lines.push([k,t,d.ok||0,d.fail||0,p==null?'':p+'%',d.posted||0].concat(engs.flatMap(e=>[(d.by[e]||{}).ok||0,(d.by[e]||{}).fail||0]),['"'+te+'"']).join(','));
    });
    const blob=new Blob([lines.join('\n')],{type:'text/csv'}), url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download='zex_daily_summary_'+todayKey()+'.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  chrome.storage.onChanged.addListener((ch,area)=>{
    if(area!=='local') return;
    if(ch.zexDayStartMin){ const m=Math.floor(Number(ch.zexDayStartMin.newValue)); window.ZEX_DS=(isFinite(m)&&m>=0&&m<1440)?m:0; render(); }
    if(ch.zenAgentDayLog){ log=ch.zenAgentDayLog.newValue||{}; render(); }
  });
  document.querySelectorAll('.nav-tab').forEach(b=>b.addEventListener('click',()=>{ if(b.dataset.tabpanel==='tabPanelDashboard') setTimeout(load,350); }));
  load();
})();


/* ══ ACCOUNT LISTS (Keywords tab) — Blacklist / Whitelist ══
   zexBlackList: never engaged by any engine (content.js) and dropped from Sweep runs.
   zexWhiteList: Sweep opens links of these accounts first. Saved as soon as the box loses focus. */
;(function listsInit(){
  'use strict';
  const $ = id => document.getElementById(id);
  const bl=$('zexBlackBox'), wl=$('zexWhiteBox'), st=$('zexListsStatus');
  if(!bl || !wl || typeof chrome==='undefined' || !chrome.storage) return;
  const parse = t => [...new Set(String(t||'').split(/[\s,;\n]+/).map(h=>{ const m=h.trim().match(/(?:x|twitter)\.com\/([A-Za-z0-9_]+)/i); return (m?m[1]:h).replace(/^@/,'').toLowerCase(); }).filter(h=>/^[a-z0-9_]{1,15}$/.test(h)))];
  const fill = (box,arr) => { box.value = (Array.isArray(arr)?arr:[]).map(h=>'@'+h).join('\n'); };
  chrome.storage.local.get(['zexBlackList','zexWhiteList'], d=>{ fill(bl,d.zexBlackList); fill(wl,d.zexWhiteList); });
  function save(){
    const b=parse(bl.value), w=parse(wl.value).filter(h=>b.indexOf(h)<0);   // a blacklisted account can never also be whitelisted
    chrome.storage.local.set({ zexBlackList:b, zexWhiteList:w }, ()=>{
      fill(bl,b); fill(wl,w);
      if(st){ st.textContent='✓ Saved · '+b.length+' blacklisted · '+w.length+' whitelisted'; st.className='verify-status ok'; setTimeout(()=>{ st.textContent=''; },3000); }
    });
  }
  bl.addEventListener('change',save); wl.addEventListener('change',save);
})();


/* ══ EXPORT DEBUG LOG (System tab) — safe snapshot only: no API keys, tokens, emails or session data ══ */
;(function logExportInit(){
  'use strict';
  const btn=document.getElementById('zexLogExportBtn'), st=document.getElementById('zexLogExportStatus');
  if(!btn || typeof chrome==='undefined' || !chrome.storage) return;
  const KEYS=['zexTimingResolved','zenTgTiming','zenTgBreak','zenTgSweepDelayMin','zenTgSweepDelayMax','zenSweepAutoRetry','zenAgentAutoReset','zexEs1On','zexEs2On','zexEs2Pct',
    'zenSearchEngineOn','zenSearchAutoMode','zenFeedEngineOn','zenFeedAutoMode','zenAutoRepMode','zenGivEngineOn','zenGivAutoMode','zen_type_mode','zenTgLikeOn','zenRepSpeedMode',
    'zenAgentStats','zexErrLog','zenSkipLog','zexFailWhy','zSessAutoJobs','zSessAutoPending','zenAgentDayLog','zexDebugLog','zexBlackList','zexWhiteList','zenTgSweepFolders'];
  const pad=n=>String(n).padStart(2,'0'), ts=t=>{ const d=new Date(t); return pad(d.getMonth()+1)+'-'+pad(d.getDate())+' '+pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds()); };
  const j=(v,n)=>{ try{ return JSON.stringify(v).slice(0,n||600); }catch(e){ return String(v); } };
  btn.addEventListener('click', ()=>{
    chrome.storage.local.get(KEYS, d=>{
      const m=chrome.runtime.getManifest(), out=[];
      out.push('Z EX DEBUG LOG','Version: '+m.version,'Exported: '+new Date().toString(),'Browser: '+navigator.userAgent,'');
      out.push('── SETTINGS ──');
      ['zexTimingResolved','zenTgTiming','zenTgBreak','zenTgSweepDelayMin','zenTgSweepDelayMax','zenSweepAutoRetry','zenAgentAutoReset','zexEs1On','zexEs2On','zexEs2Pct','zenSearchEngineOn','zenSearchAutoMode','zenFeedEngineOn','zenFeedAutoMode','zenAutoRepMode','zenGivEngineOn','zenGivAutoMode','zen_type_mode','zenTgLikeOn','zenRepSpeedMode'].forEach(k=>{ if(d[k]!==undefined) out.push(k+': '+j(d[k],400)); });
      out.push('blacklist: '+((d.zexBlackList||[]).length)+' · whitelist: '+((d.zexWhiteList||[]).length)+' · sweep folders: '+((d.zenTgSweepFolders||[]).length),'');
      out.push('── AGENT COUNTERS ──',j(d.zenAgentStats,800),'');
      const jobs=d.zSessAutoJobs||{}; out.push('── SWEEP / SESSION JOBS ──');
      Object.keys(jobs).forEach(k=>{ const o=jobs[k]||{}; out.push(k+': status='+o.status+' index='+o.currentIndex+'/'+((o.queue||[]).length)+' retryRound='+(o.retryRound||0)+' failedUrls='+((o.failedUrls||[]).length)+' navAt='+(o.navAt?ts(o.navAt):'-')); });
      if(d.zSessAutoPending) out.push('pending: '+j(d.zSessAutoPending,300));
      out.push('');
      const today=(d.zenAgentDayLog||{})[(()=>{const x=zexNow();return x.getFullYear()+'-'+pad(x.getMonth()+1)+'-'+pad(x.getDate());})()];
      out.push('── TODAY (Daily Summary) ──',j(today,800),'');
      out.push('── LAST ERRORS (up to 40) ──');
      (d.zexErrLog||[]).slice(0,40).forEach(e=>out.push(ts(e.ts)+'  '+e.eng+'  '+e.msg));
      out.push('','── FAILED LINK REASONS (latest 40) ──');
      const fw=d.zexFailWhy||{}; Object.keys(fw).sort((a,b)=>(fw[b].ts||0)-(fw[a].ts||0)).slice(0,40).forEach(k=>out.push(ts(fw[k].ts)+'  '+k+'  '+fw[k].why));
      out.push('','── HISTORY SKIP/FAIL LOG (latest 40) ──');
      (d.zenSkipLog||[]).slice(0,40).forEach(x=>out.push(ts(x.ts)+'  '+(x.reason||'skipped')+'  '+(x.cur||'')+'  '+(x.sid||'')));
      out.push('','── Z EX LOG (last 500 lines) ──');
      (d.zexDebugLog||[]).forEach(x=>out.push(ts(x.t)+' ['+x.l+'] '+(x.p||'')+'  '+x.m));
      if(!(d.zexDebugLog||[]).length) out.push('(empty — log lines are collected from now on, reproduce the problem and export again)');
      const blob=new Blob([out.join('\n')],{type:'text/plain'}), url=URL.createObjectURL(blob), a=document.createElement('a');
      a.href=url; a.download='zex_debug_log_'+new Date().toISOString().slice(0,16).replace(/[:T]/g,'-')+'.txt'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
      if(st){ st.textContent='✓ Debug log saved'; st.className='verify-status ok'; setTimeout(()=>{ st.textContent=''; },3000); }
    });
  });
})();

/* ══════════════════════════════════════════════════════════════
   Auto Refresh Settings — Feed / Search / GIV engines
   Saves zenFeedRefreshTime, zenFeedRefreshGoal,
         zenSearchRefreshTime, zenSearchRefreshGoal,
         zenGivRefreshTime,  zenGivRefreshGoal
   to chrome.storage.local. content.js reads these.
   ══════════════════════════════════════════════════════════════ */
(function () {
  function setupRefresh(prefix, timeId, goalId, saveId, statusId) {
    const timeEl  = document.getElementById(timeId);
    const goalEl  = document.getElementById(goalId);
    const saveBtn = document.getElementById(saveId);
    const statusEl= document.getElementById(statusId);
    if (!saveBtn) return;

    // Load saved values
    const tKey = 'zen' + prefix + 'RefreshTime';
    const gKey = 'zen' + prefix + 'RefreshGoal';
    chrome.storage.local.get([tKey, gKey], (d) => {
      if (timeEl && d[tKey]) timeEl.value = d[tKey];
      if (goalEl && d[gKey]) goalEl.value = d[gKey];
    });

    saveBtn.addEventListener('click', () => {
      const t = parseInt(timeEl ? timeEl.value : '', 10) || 0;
      const g = parseInt(goalEl ? goalEl.value : '', 10) || 0;
      const data = {};
      data[tKey] = t > 0 ? t : 0;
      data[gKey] = g > 0 ? g : 0;
      chrome.storage.local.set(data, () => {
        if (statusEl) {
          statusEl.style.display = 'block';
          if (!t && !g) {
            statusEl.textContent = 'Auto Refresh disabled.';
            statusEl.style.color = 'var(--dim)';
          } else {
            const parts = [];
            if (t) parts.push(`Time: ${t} min`);
            if (g) parts.push(`Goal: ${g} replies`);
            statusEl.textContent = '✅ Saved — ' + parts.join(' | ');
            statusEl.style.color = 'var(--green)';
          }
          setTimeout(() => { if (statusEl) statusEl.style.display = 'none'; }, 3000);
        }
      });
    });
  }

  setupRefresh('Feed',   'feedRefreshTimeInput',   'feedRefreshGoalInput',   'feedRefreshSaveBtn',   'feedRefreshStatus');
  setupRefresh('Search', 'searchRefreshTimeInput', 'searchRefreshGoalInput', 'searchRefreshSaveBtn', 'searchRefreshStatus');
  setupRefresh('Giv',    'givRefreshTimeInput',    'givRefreshGoalInput',    'givRefreshSaveBtn',    'givRefreshStatus');
})();


// ── Support tab: copy WhatsApp number ──
document.addEventListener('click', function(e){
  const btn = e.target.closest && e.target.closest('.wa-copy');
  if (!btn) return;
  const txt = btn.dataset.copy || '';
  const done = function(){
    const old = btn.textContent;
    btn.textContent = 'Copied ✓';
    btn.classList.add('done');
    setTimeout(function(){ btn.textContent = old; btn.classList.remove('done'); }, 1500);
  };
  const fallback = function(){
    const ta = document.createElement('textarea');
    ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch(_) {}
    ta.remove();
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(txt).then(done).catch(fallback);
  } else { fallback(); }
});

//  Search Engine: Post Age Limit (applies to SEA + Link Collect) 
(function ageFilterInit() {
  const $ = (id) => document.getElementById(id);
  const on = $('ageOn'); if (!on) return;
  const mode = $('ageMode'), minN = $('ageMinN'), minU = $('ageMinU'), maxN = $('ageMaxN'), maxU = $('ageMaxU');
  const dIn = $('ageDateInput'), dAdd = $('ageDateAdd'), dTags = $('ageDateTags'), tF = $('ageTFrom'), tT = $('ageTTo'), st = $('ageStatus');
  const UNIT = { s: 1, m: 60, h: 3600, d: 86400 };
  let dates = [];
  const toSec = (n, u) => Math.max(0, Math.floor(Number(n) || 0)) * (UNIT[u] || 1);
  function fmtDate(k) { const p = k.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); }
  function renderDates() {
    dTags.innerHTML = '';
    dates.forEach((k) => {
      const tag = document.createElement('div'); tag.className = 'seh-kw-tag';
      const l = document.createElement('span'); l.textContent = fmtDate(k);
      const x = document.createElement('span'); x.className = 'seh-kw-tag-x'; x.textContent = '\u00d7';
      x.addEventListener('click', () => { dates = dates.filter((z) => z !== k); renderDates(); save(); });
      tag.appendChild(l); tag.appendChild(x); dTags.appendChild(tag);
    });
  }
  function show() {
    $('ageRangeBox').style.display = mode.value === 'age' ? '' : 'none';
    $('ageDatesBox').style.display = mode.value === 'dates' ? '' : 'none';
  }
  function save() {
    const cfg = {
      on: on.checked, mode: mode.value,
      minSec: toSec(minN.value, minU.value), maxSec: toSec(maxN.value, maxU.value),
      minN: Number(minN.value) || 0, minU: minU.value, maxN: Number(maxN.value) || 0, maxU: maxU.value,
      dates: dates.slice().sort(), tFrom: tF.value || '', tTo: tT.value || '',
    };
    let msg = '', err = false;
    if (cfg.on) {
      if (cfg.mode === 'age') {
        if (cfg.maxSec <= cfg.minSec) { msg = 'Oldest must be bigger than Newest'; err = true; }
        else msg = 'Only posts between ' + cfg.minN + cfg.minU + ' and ' + cfg.maxN + cfg.maxU + ' old';
      } else if (!cfg.dates.length) { msg = 'Add at least one date'; err = true; }
      else msg = 'Only posts from ' + cfg.dates.length + ' selected date' + (cfg.dates.length > 1 ? 's' : '') + (cfg.tFrom || cfg.tTo ? ' (' + (cfg.tFrom || '00:00') + ' - ' + (cfg.tTo || '23:59') + ')' : '');
    } else msg = 'OFF';
    if (st) { st.textContent = msg; st.className = 'verify-status' + (err ? ' err' : (cfg.on ? ' ok' : '')); }
    chrome.storage.local.set({ zenSearchAgeFilter: cfg });
  }
  chrome.storage.local.get(['zenSearchAgeFilter'], (d) => {
    const c = d.zenSearchAgeFilter || {};
    on.checked = c.on === true;
    if (c.mode) mode.value = c.mode;
    if (c.minN != null) minN.value = c.minN; if (c.minU) minU.value = c.minU;
    if (c.maxN != null) maxN.value = c.maxN; if (c.maxU) maxU.value = c.maxU;
    dates = Array.isArray(c.dates) ? c.dates.slice() : [];
    tF.value = c.tFrom || ''; tT.value = c.tTo || '';
    renderDates(); show(); save();
  });
  [on, mode, minN, minU, maxN, maxU, tF, tT].forEach((el) => el.addEventListener('change', () => { show(); save(); }));
  dAdd.addEventListener('click', () => {
    const v = dIn.value; if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return;
    if (dates.indexOf(v) < 0) dates.push(v);
    dates.sort(); dIn.value = ''; renderDates(); save();
  });
})();

// ── Extra Safety 1 / 2 toggles ──
(function () {
  const s1 = document.getElementById('es1Switch'), s2 = document.getElementById('es2Switch'), pct = document.getElementById('es2Pct'), box = document.getElementById('es2PctBox');
  if (!s1 || !s2) return;
  const l1 = document.getElementById('es1Label'), l2 = document.getElementById('es2Label');
  const paint = () => {
    l1.textContent = s1.checked ? 'Safety 1 is ON. If your browser shows "Something went wrong" due to automation or a network error, it will start automatically and visit your feed and profile for a while to give your account a short cooldown.' : 'If your browser shows "Something went wrong" due to automation or a network error, Safety 1 will start automatically and visit your feed and profile for a while to give your account a short cooldown.';
    l2.textContent = s2.checked ? 'Safety 2 is ON. It will randomly open a post before commenting to avoid a robotic pattern. Each post is opened based on your set % chance.' : 'Commenting with the same pattern may look robotic. Safety 2 helps by randomly opening a post before commenting. Each post is opened based on your set % chance.';
    if (box) box.style.display = s2.checked ? 'block' : 'none';
  };
  chrome.storage.local.get(['zexEs1On', 'zexEs2On', 'zexEs2Pct'], (d) => {
    d = d || {}; s1.checked = d.zexEs1On === true; s2.checked = d.zexEs2On === true;
    if (pct) pct.value = typeof d.zexEs2Pct === 'number' ? d.zexEs2Pct : 30;
    paint();
  });
  s1.addEventListener('change', () => { chrome.storage.local.set({ zexEs1On: s1.checked }); paint(); });
  s2.addEventListener('change', () => { chrome.storage.local.set({ zexEs2On: s2.checked }); paint(); });
  if (pct) pct.addEventListener('change', () => {
    let v = Math.round(Number(pct.value)); if (!isFinite(v)) v = 30; v = Math.min(100, Math.max(0, v)); pct.value = v;
    chrome.storage.local.set({ zexEs2Pct: v });
  });
})();

// ── Hard Refresh toggle ──
(function () {
  const sw = document.getElementById('hrSwitch'), lb = document.getElementById('hrLabel');
  if (!sw) return;
  const paint = () => { lb.textContent = sw.checked ? 'Hard Refresh is ON. If the system gets stuck, it will open Search in a new tab and close the stuck one so work can continue. Works up to 3 times every 30 minutes.' : 'If the system gets stuck, this feature helps it recover and continue working again.'; };
  chrome.storage.local.get(['zexHardRefreshOn'], (d) => { sw.checked = !!(d && d.zexHardRefreshOn === true); paint(); });
  sw.addEventListener('change', () => { chrome.storage.local.set({ zexHardRefreshOn: sw.checked }); paint(); });
})();


// ── Remember where the popup was closed ──
// Saves the open tab + scroll position; next time the popup opens it returns to the same place. Device-local (excluded from sync).
(function () {
  const KEY = 'zenLastNav';
  const body = () => document.querySelector('.dash-body');
  const cur = () => { const a = document.querySelector('.nav-tab.active'); return a && a.dataset.tabpanel; };
  const save = () => { const p = cur(); if (!p) return; const b = body(); try { chrome.storage.local.set({ [KEY]: { p: p, y: b ? b.scrollTop : 0, t: Date.now() } }); } catch (e) {} };
  let st = null;
  document.querySelectorAll('.nav-tab').forEach((b) => b.addEventListener('click', () => setTimeout(save, 0)));
  const bind = () => { const b = body(); if (b) b.addEventListener('scroll', () => { clearTimeout(st); st = setTimeout(save, 150); }, { passive: true }); };
  window.addEventListener('pagehide', save);
  document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
  const restore = (d) => {
    const s = d && d[KEY]; if (!s || !s.p) return;
    if (document.body.classList.contains('zp-locked')) return;                 // locked account: only the Active tab is allowed
    const btn = document.querySelector('.nav-tab[data-tabpanel="' + s.p + '"]');
    if (!btn || getComputedStyle(btn).display === 'none' || !document.getElementById(s.p)) return;
    if (cur() !== s.p) btn.click();
    const b = body(); if (b && s.y) { b.scrollTop = s.y; setTimeout(() => { if (b) b.scrollTop = s.y; }, 250); setTimeout(() => { if (b) b.scrollTop = s.y; }, 700); }
  };
  const go = () => { bind(); chrome.storage.local.get([KEY], restore); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(go, 50)); else setTimeout(go, 50);
})();
