// ══════════════════════════════════════════════════════════════
//  AUTO-STOP LIMITS — popup side.
//  Each engine page has its own "Auto-Stop Limit" block (data-lim-* attributes).
//  Comment engines (REP / FED / SEA / GIV / TAR) share ONE "comment" limit, so
//  their blocks stay in sync. Unfollow uses its own Limit field on the Auto Unfollow page.
//  Reads/writes chrome.storage.local.zenLimits; counting and stopping happen in limits_bg.js.
// ══════════════════════════════════════════════════════════════
(function () {
  var KINDS = ['comment', 'follow', 'tgSweep'];
  var LABEL = { comment: 'Comment', follow: 'Follow', tgSweep: 'TG Sweep' };
  var UNIT  = { comment: 'replies', follow: 'follows', tgSweep: 'links' };
  var DEF = { comment: { on: false, max: 50 }, follow: { on: false, max: 20 }, unfollow: { on: false, max: 50 }, tgSweep: { on: false, max: 30 } };
  var MAXV = 5000;
  var cfg = JSON.parse(JSON.stringify(DEF));
  var cnt = { comment: 0, follow: 0, tgSweep: 0 };
  var lastHit = null;

  function $all(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }
  function clampMax(v, kind) {
    v = Math.floor(Number(v));
    if (!isFinite(v) || v < 1) v = DEF[kind].max;
    return Math.min(MAXV, v);
  }
  function normalize(raw) {
    var out = {};
    Object.keys(DEF).forEach(function (k) {
      var r = (raw && raw[k]) || {};
      out[k] = { on: k !== 'unfollow' && r.on === true, max: clampMax(r.max, k) };
    });
    return out;
  }
  function save() { chrome.storage.local.set({ zenLimits: cfg }); }

  function render() {
    KINDS.forEach(function (k) {
      $all('[data-lim-on="' + k + '"]').forEach(function (on) { if (on.checked !== cfg[k].on) on.checked = cfg[k].on; });
      $all('[data-lim-max="' + k + '"]').forEach(function (mx) { if (document.activeElement !== mx) mx.value = cfg[k].max; });
      $all('[data-lim-prog="' + k + '"]').forEach(function (pr) {
        if (!cfg[k].on) { pr.textContent = 'No limit — runs until you stop it'; return; }
        var n = cnt[k] || 0;
        pr.textContent = 'Stops after ' + cfg[k].max + ' ' + UNIT[k] + (n ? ' · now ' + n + ' / ' + cfg[k].max : '');
      });
    });
    showHit(lastHit);
  }

  function showHit(h) {
    lastHit = h;
    $all('[data-lim-hit]').forEach(function (el) {
      var k = el.getAttribute('data-lim-hit');
      if (!h || h.kind !== k || Date.now() - (h.ts || 0) > 6 * 3600 * 1000) { el.style.display = 'none'; return; }
      el.style.display = 'block';
      el.textContent = '⏹ ' + LABEL[k] + ' limit (' + h.max + ') reached — stopped at ' + new Date(h.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    });
  }

  function init() {
    if (!document.querySelector('[data-lim-max]')) return;
    chrome.storage.local.get(['zenLimits', 'zenLimitCount', 'zenLimitHit'], function (d) {
      cfg = normalize(d.zenLimits);
      cnt = Object.assign(cnt, d.zenLimitCount || {});
      lastHit = d.zenLimitHit || null;
      render();
    });
    KINDS.forEach(function (k) {
      $all('[data-lim-on="' + k + '"]').forEach(function (on) {
        on.addEventListener('change', function () {
          cfg[k].on = on.checked;
          if (on.checked) { try { chrome.runtime.sendMessage({ type: 'zenLimitReset', kind: k }, function () { void chrome.runtime.lastError; }); } catch (e) {} }
          save(); render();
        });
      });
      $all('[data-lim-max="' + k + '"]').forEach(function (mx) {
        mx.addEventListener('change', function () {
          cfg[k].max = clampMax(mx.value, k); mx.value = cfg[k].max; save(); render();
        });
      });
    });
    $all('[data-lim-reset]').forEach(function (rb) {
      rb.addEventListener('click', function () {
        try { chrome.runtime.sendMessage({ type: 'zenLimitReset', kind: rb.getAttribute('data-lim-reset') }, function () { void chrome.runtime.lastError; }); } catch (e) {}
        chrome.storage.local.remove('zenLimitHit');
      });
    });
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== 'local') return;
      if (ch.zenLimits) { cfg = normalize(ch.zenLimits.newValue); render(); }
      if (ch.zenLimitCount) { cnt = Object.assign({ comment: 0, follow: 0, tgSweep: 0 }, ch.zenLimitCount.newValue || {}); render(); }
      if (ch.zenLimitHit) { showHit(ch.zenLimitHit.newValue || null); }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
