/* Z EX — People DB (shared by every engine, the Follow engine and the Dashboard "Following Analysis").
   chrome.storage.local.zexPeople = { v:1, m:{ handle: { s:score|null, f:1 (I follow them), c:1 (collected, not followed), src, t } } }
   Loaded in x.com content scripts and in the popup. One map, one source of truth:
     ZexPeople.isFollowing(h) → true when the account is already followed (engines / Follow engine skip it)
     ZexPeople.add(h, {s,f,c,src}) → merge (queued, saved ~1.5s later)          ZexPeople.has / get / score
     ZexPeople.export() / ZexPeople.importObj(obj) / ZexPeople.clear() / ZexPeople.stats() */
(function () {
  'use strict';
  if (window.ZexPeople) return;
  var KEY = 'zexPeople', cache = {}, pending = {}, timer = null, ready = false, waiters = [];
  function norm(h) { return String(h || '').replace(/^@/, '').trim().toLowerCase(); }
  function good(h) { return /^[a-z0-9_]{1,15}$/.test(h); }
  function ok(fn) { try { return fn(); } catch (e) { return undefined; } }
  function mergeInto(dst, h, p) {
    var o = dst[h] || {};
    if (p.s != null && isFinite(p.s)) o.s = p.s;
    if (p.f === 1) { o.f = 1; delete o.c; }
    else if (p.f === 0) { delete o.f; }
    if (p.c === 1 && o.f !== 1) o.c = 1;
    if (p.src && !o.src) o.src = p.src;
    o.t = p.t || Date.now();
    dst[h] = o;
  }
  function load() {
    ok(function () {
      chrome.storage.local.get([KEY], function (d) {
        void chrome.runtime.lastError;
        var st = d && d[KEY]; cache = (st && st.m && typeof st.m === 'object') ? st.m : {};
        ready = true; waiters.splice(0).forEach(function (f) { ok(f); });
      });
    });
  }
  function flush() {
    timer = null;
    var keys = Object.keys(pending); if (!keys.length) return;
    var batch = pending; pending = {};
    ok(function () {
      chrome.storage.local.get([KEY], function (d) {
        void chrome.runtime.lastError;
        var st = d && d[KEY], m = (st && st.m && typeof st.m === 'object') ? st.m : {};
        Object.keys(batch).forEach(function (h) { batch[h].forEach(function (p) { mergeInto(m, h, p); }); });
        var o = {}; o[KEY] = { v: 1, m: m }; cache = m;
        chrome.storage.local.set(o, function () { void chrome.runtime.lastError; });
      });
    });
  }
  function sched() { if (!timer) timer = setTimeout(flush, 1500); }
  ok(function () {
    chrome.storage.onChanged.addListener(function (c, a) {
      if (a === 'local' && c[KEY]) { var st = c[KEY].newValue; cache = (st && st.m) ? st.m : {}; }
    });
  });
  load();

  var P = window.ZexPeople = {
    whenReady: function (f) { if (ready) ok(f); else waiters.push(f); },
    norm: norm,
    has: function (h) { return !!cache[norm(h)]; },
    get: function (h) { return cache[norm(h)] || null; },
    isFollowing: function (h) { var o = cache[norm(h)]; return !!(o && o.f === 1); },
    score: function (h) { var o = cache[norm(h)]; return o && o.s != null ? o.s : null; },
    add: function (h, p) {
      h = norm(h); if (!good(h)) return;
      p = p || {};
      var q = { s: p.s, f: p.f, c: p.c, src: p.src, t: Date.now() };
      mergeInto(cache, h, q);                       // visible to every check right away
      (pending[h] = pending[h] || []).push(q); sched();
    },
    flushNow: flush,
    all: function () { return cache; },
    stats: function () {
      var n = 0, fo = 0, sc = 0, co = 0;
      Object.keys(cache).forEach(function (h) { var o = cache[h]; n++; if (o.f === 1) { fo++; if (o.s != null) sc++; } else if (o.c === 1) co++; });
      return { total: n, following: fo, followingScored: sc, collected: co };
    },
    export: function () {
      var rows = Object.keys(cache).map(function (h) { var o = cache[h]; return { u: h, s: o.s == null ? null : o.s, f: o.f === 1 ? 1 : 0, c: o.c === 1 ? 1 : 0, src: o.src || '', t: o.t || 0 }; });
      return { app: 'ZEX', kind: 'people-db', v: 1, exportedAt: Date.now(), count: rows.length, people: rows };
    },
    importObj: function (obj) {            // merge a file: never removes anything, newer score wins
      if (!obj || obj.kind !== 'people-db' || !Array.isArray(obj.people)) return { ok: false, added: 0, updated: 0 };
      var added = 0, upd = 0, m = {};
      obj.people.slice(0, 200000).forEach(function (r) {
        var h = norm(r && r.u); if (!good(h)) return;
        if (!cache[h] && !m[h]) added++; else upd++;
        mergeInto(m, h, { s: (r.s == null ? null : Number(r.s)), f: r.f ? 1 : undefined, c: r.c ? 1 : undefined, src: String(r.src || '').slice(0, 8), t: Number(r.t) || Date.now() });
      });
      return new Promise(function (res) {
        chrome.storage.local.get([KEY], function (d) {
          var st = d && d[KEY], base = (st && st.m && typeof st.m === 'object') ? st.m : {};
          Object.keys(m).forEach(function (h) { var o = base[h] || {}, n = m[h]; if (n.s != null) o.s = n.s; if (n.f === 1) { o.f = 1; delete o.c; } else if (n.c === 1 && o.f !== 1) o.c = 1; if (!o.src && n.src) o.src = n.src; o.t = Math.max(o.t || 0, n.t || 0); base[h] = o; });
          var o2 = {}; o2[KEY] = { v: 1, m: base }; cache = base;
          chrome.storage.local.set(o2, function () { res({ ok: true, added: added, updated: upd }); });
        });
      });
    },
    clear: function () { cache = {}; pending = {}; var o = {}; o[KEY] = { v: 1, m: {} }; ok(function () { chrome.storage.local.set(o); }); },
    // After a COMPLETE scan of my Following list: anyone marked as followed but not seen there any more is no longer followed.
    reconcile: function (seenSet) {
      return new Promise(function (res) {
        chrome.storage.local.get([KEY], function (d) {
          var st = d && d[KEY], m = (st && st.m && typeof st.m === 'object') ? st.m : {}, n = 0;
          Object.keys(m).forEach(function (h) { if (m[h].f === 1 && !seenSet[h]) { delete m[h].f; n++; } });
          var o = {}; o[KEY] = { v: 1, m: m }; cache = m;
          chrome.storage.local.set(o, function () { res(n); });
        });
      });
    }
  };
})();
