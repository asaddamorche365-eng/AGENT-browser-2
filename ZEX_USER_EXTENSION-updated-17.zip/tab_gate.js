// Tab gate — admin panel (Worker app-config "zex_tabs") can turn a tab OFF (hidden) or MAINTENANCE (maintenance screen).
// Home, ZEXPAY, Backup & FAQ and Support are never gated, so nobody gets locked out.
(function () {
  var GATE = ['tabPanelPost','tabPanelDashboard','tabPanelTone','tabPanelKeywords','tabPanelStyle','tabPanelHistory','tabPanelActivity','tabPanelBehaviour','tabPanelProxy'];
  var DEFAULT_MSG = 'This feature is being updated. Please check back soon.';
  var cfg = null, lastFetch = 0, busy = false;

  var st = document.createElement('style');
  st.textContent =
    '.tab-panel.zex-maint > *:not(.zex-maint-box){display:none!important}' +
    '.zex-maint-box{text-align:center;padding:48px 20px;border:1px dashed var(--border,#ccc);border-radius:14px;margin:12px 0}' +
    '.zex-maint-ico{font-size:34px;margin-bottom:10px}' +
    '.zex-maint-ttl{font-size:14px;font-weight:800;letter-spacing:.5px;margin-bottom:6px}' +
    '.zex-maint-msg{font-size:11px;color:var(--dim,#888);line-height:1.5;word-break:break-word}';
  document.head.appendChild(st);

  function modeOf(id) { var c = cfg && cfg[id]; return c && (c.mode === 'off' || c.mode === 'maint') ? c.mode : 'on'; }

  function apply() {
    GATE.forEach(function (id) {
      var m = modeOf(id);
      var btn = document.querySelector('.nav-tab[data-tabpanel="' + id + '"]');
      if (btn) btn.style.display = m === 'off' ? 'none' : '';
      var p = document.getElementById(id); if (!p) return;
      var box = p.querySelector(':scope > .zex-maint-box');
      p.classList.toggle('zex-maint', m === 'maint');
      if (m === 'maint') {
        if (!box) { box = document.createElement('div'); box.className = 'zex-maint-box'; p.insertBefore(box, p.firstChild); }
        box.innerHTML = '<div class="zex-maint-ico">\uD83D\uDEA7</div><div class="zex-maint-ttl">UNDER MAINTENANCE</div><div class="zex-maint-msg"></div>';
        box.querySelector('.zex-maint-msg').textContent = (cfg[id].msg || '').trim() || DEFAULT_MSG;
      } else if (box) box.remove();
    });
    var a = document.querySelector('.nav-tab.active');
    if (a && modeOf(a.dataset.tabpanel) === 'off') {
      var h = document.querySelector('.nav-tab[data-tabpanel="tabPanelHome"]'); if (h) h.click();
    }
  }

  function refresh(force) {
    if (busy || (!force && Date.now() - lastFetch < 30000)) return;
    if (typeof zAppConfig !== 'function') return;
    busy = true;
    zAppConfig(force).then(function (c) {
      lastFetch = Date.now();
      if (c) { var d = c.zex_tabs; cfg = (d && typeof d === 'object') ? d : null; apply(); }   // null from the server = no gates; network error keeps the last state
    }).catch(function () {}).then(function () { busy = false; });
  }

  document.querySelectorAll('.nav-tab').forEach(function (b) {
    b.addEventListener('click', function () { apply(); refresh(false); });
  });
  refresh(true);
  setInterval(function () { refresh(false); }, 60000);
})();
