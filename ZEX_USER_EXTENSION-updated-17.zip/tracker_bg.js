// ══════════════════════════════════════════════════════════════
//  ZEX WORKFLOW TRACKER — background side
//  Every run of the extension (manual / auto / Telegram) becomes one "track":
//    start → open X → engine (+model, +mode) → like / comment → save
//    → goal → refresh → continue → ... → shutdown (track over)
//  Stored in chrome.storage.local['zexTrack'] = { runs:[...], activeId }.
//  Browser/extension close is detected by windows.onRemoved and, as a
//  fallback, by a heartbeat: if the heartbeat stops, the run is closed at
//  the last time we saw it alive.
// ══════════════════════════════════════════════════════════════
const ZT_KEY = 'zexTrack';
const ZT_MAX_RUNS = 25;
const ZT_MAX_EVENTS = 600;
const ZT_STALE_MS = 3 * 60 * 1000;   // no heartbeat this long → browser was closed
const ZT_IDLE_MS = 30 * 60 * 1000;   // nothing happened + no engine ON → track over
const ZT_BEAT_ALARM = 'zexTrackBeat';
const ZT_SAFE_MAX = 3;   // "Something went wrong" after Reply, this many times in ONE session (run) → all engines stop

// engine → storage keys. REP has no separate "on" key: its auto flag is the switch.
const ZT_ENG = {
  FED: { on: 'zenFeedEngineOn',   auto: 'zenFeedAutoMode',   model: 'zenFeedPromptModel',   like: 'zenFeedLikeOn' },
  SEA: { on: 'zenSearchEngineOn', auto: 'zenSearchAutoMode', model: 'zenSearchPromptModel', like: 'zenSearchLikeOn' },
  GIV: { on: 'zenGivEngineOn',    auto: 'zenGivAutoMode' },
  REP: { on: null,                auto: 'zenAutoRepMode' },
};

// background jobs (message type → label)
const ZT_JOBS = {
  sessAutoStart: { name: 'SESSION' },  sessAutoStop: { name: 'SESSION', end: true },
  tarStart:      { name: 'TAR' },      tarStop:      { name: 'TAR', end: true },
  followStart:   { name: 'FOLLOW' },   followStop:   { name: 'FOLLOW', end: true },
  unfStart:      { name: 'UNFOLLOW' }, unfStop:      { name: 'UNFOLLOW', end: true },
};

let _ztChain = Promise.resolve();
function ztQ(fn) { const p = _ztChain.then(fn); _ztChain = p.catch(() => {}); return p; }

function ztLoad() {
  return new Promise((res) => chrome.storage.local.get([ZT_KEY], (d) => {
    const s = d && d[ZT_KEY];
    res(s && Array.isArray(s.runs) ? s : { runs: [], activeId: null });
  }));
}
function ztSave(s) {
  return new Promise((res) => chrome.storage.local.set({ [ZT_KEY]: s }, () => { void chrome.runtime.lastError; res(); }));
}
function ztActive(s) { return s.activeId ? (s.runs.find((r) => r.id === s.activeId) || null) : null; }
function ztPush(run, ev) {
  run.events.push(ev);
  if (run.events.length > ZT_MAX_EVENTS) run.events.splice(1, run.events.length - ZT_MAX_EVENTS); // keep the start node
}
function ztFinishIn(s, reason, ts) {
  const r = ztActive(s);
  if (!r) return false;
  ts = ts || Date.now();
  ztPush(r, { t: ts, type: 'shutdown', why: reason });
  r.endTs = ts; r.endReason = reason; s.activeId = null;
  return true;
}
function ztCreate(s, ts, source) {
  const r = { id: 'r' + ts.toString(36) + Math.random().toString(36).slice(2, 5), startTs: ts, lastSeen: ts, lastAct: ts, src: source || 'manual', jobs: 0, events: [{ t: ts, type: 'start' }] };
  s.runs.push(r); s.activeId = r.id;
  if (s.runs.length > ZT_MAX_RUNS) s.runs.splice(0, s.runs.length - ZT_MAX_RUNS);
  return r;
}

// Which engines are ON right now (with model / mode).
async function ztEngSnapshot() {
  const keys = [];
  Object.values(ZT_ENG).forEach((c) => [c.on, c.auto, c.model, c.like].forEach((k) => k && keys.push(k)));
  const d = await new Promise((r) => chrome.storage.local.get(keys, (x) => r(x || {})));
  const out = [];
  Object.keys(ZT_ENG).forEach((name) => {
    const c = ZT_ENG[name];
    const on = c.on ? d[c.on] === true : d[c.auto] === true;
    if (!on) return;
    out.push({ eng: name, model: c.model ? (d[c.model] === 'model2' ? '2' : '1') : '', mode: d[c.auto] === true ? 'auto' : 'manual', likeOn: c.like ? d[c.like] === true : false });
  });
  return out;
}

const ZT_FIELDS = ['eng', 'model', 'mode', 'h', 'link', 'n', 'why', 'name', 'likeOn', 'src', 'wc'];
const ZT_PASSIVE = { stuck: 1, lost: 1, net: 1, skip: 1 };   // recovery / network notes: shown in the map, but not "activity" (don't keep an idle run alive)
function ztClean(evt, now) {
  const ev = { t: now, type: String(evt.type || '') };
  ZT_FIELDS.forEach((k) => {
    if (evt[k] === undefined || evt[k] === null || evt[k] === '') return;
    ev[k] = typeof evt[k] === 'string' ? evt[k].slice(0, 140) : evt[k];
  });
  return ev;
}

function ztLog(evt) {
  return ztQ(async () => {
    if (!evt || !evt.type) return;
    const s = await ztLoad();
    const now = Date.now();
    let r = ztActive(s);
    let dirty = false;

    // Heartbeat stopped long ago → the browser (or extension) was closed in between.
    if (r && now - r.lastSeen > ZT_STALE_MS) { ztFinishIn(s, 'browser-closed', r.lastSeen); r = null; dirty = true; }

    const type = evt.type;
    let snap = null;
    if (!r) {
      if (type === 'open_x' || type === 'comment') {
        snap = await ztEngSnapshot();
        if (type === 'open_x' && !snap.length) { if (dirty) await ztSave(s); return; } // X opened with nothing running → not a run
      } else if (type !== 'engine_on' && type !== 'job') {
        if (dirty) await ztSave(s);
        return;
      }
      r = ztCreate(s, now, evt.src || (type === 'job' ? 'job' : 'manual'));
      dirty = true;
      const pushSnap = () => (snap || []).forEach((e) => ztPush(r, { t: now, type: 'engine_on', eng: e.eng, model: e.model, mode: e.mode, likeOn: e.likeOn }));
      if (type === 'comment') pushSnap();
      ztPush(r, ztClean(evt, now));
      if (type === 'open_x') pushSnap();
    } else {
      if (type === 'open_x') {
        const lastOpen = [...r.events].reverse().find((e) => e.type === 'open_x');
        if (lastOpen && now - lastOpen.t < 10 * 60 * 1000) { r.lastSeen = now; await ztSave(s); return; }
      }
      const last = r.events[r.events.length - 1];
      if (last && (type === 'engine_on' || type === 'engine_off') && last.type === type && last.eng === evt.eng) { r.lastSeen = now; await ztSave(s); return; }
      const dup = last && ZT_PASSIVE[type] && last.type === type && last.why === evt.why && (type !== 'skip' || last.link === (evt.link ? String(evt.link).slice(0, 140) : undefined)) && now - last.t < 20000;
      if (dup) { r.lastSeen = now; await ztSave(s); return; }
      ztPush(r, ztClean(evt, now));
    }

    if (type === 'comment') ztPush(r, { t: now + 1, type: 'save', eng: evt.eng });   // reply history is saved right after a confirmed post
    if (type === 'job') r.jobs = (r.jobs || 0) + 1;
    if (type === 'job_end') r.jobs = Math.max(0, (r.jobs || 0) - 1);

    r.lastSeen = now;
    if (type !== 'mode' && !ZT_PASSIVE[type]) r.lastAct = now;

    // Everything switched off → the track is over.
    if (type === 'engine_off' || type === 'job_end') {
      const still = await ztEngSnapshot();
      if (!still.length && (r.jobs || 0) <= 0) ztFinishIn(s, 'stopped', now + 2);
    }
    await ztSave(s);
  });
}

// ── Safety counter: counted per session (= workflow-map run), over all engines together, not only in a row ──
let _ztSafeChain = Promise.resolve();
function ztSafetyHit(eng) {
  const p = _ztSafeChain.then(async () => {
    const s = await ztQ(() => ztLoad());
    const r = ztActive(s);
    const rid = r ? r.id : 'norun';
    const d = await new Promise((res) => chrome.storage.local.get(['zexSafety'], (x) => res(x || {})));
    let z = d.zexSafety;
    if (!z || z.rid !== rid) z = { rid: rid, n: 0, stopped: false };
    if (z.stopped) return { stop: false, n: z.n };   // already stopped this session — other tabs' late hits are ignored
    z.n++;
    const stop = z.n >= ZT_SAFE_MAX;
    if (stop) z.stopped = true;
    await new Promise((res) => chrome.storage.local.set({ zexSafety: z }, res));
    if (stop) await ztLog({ type: 'safety', eng: eng || '', n: z.n });   // lands in the workflow map before the engines go off
    return { stop: stop, n: z.n };
  });
  _ztSafeChain = p.catch(() => {});
  return p;
}
// User starts an engine again → safety state is cleared (banner gone, counter back to 0).
function ztSafetyClear() {
  chrome.storage.local.get(['zexSafety', 'zexSafetyStop'], (d) => {
    if (d && d.zexSafety && d.zexSafety.stopped) chrome.storage.local.set({ zexSafety: { rid: d.zexSafety.rid, n: 0, stopped: false } });
    if (d && d.zexSafetyStop) chrome.storage.local.remove('zexSafetyStop');
  });
}

// Heartbeat / stale / idle housekeeping. If this runs, the browser is alive.
function ztBeat(checkOnly) {
  return ztQ(async () => {
    const s = await ztLoad();
    const r = ztActive(s);
    if (!r) return;
    const now = Date.now();
    if (now - r.lastSeen > ZT_STALE_MS) { ztFinishIn(s, 'browser-closed', r.lastSeen); await ztSave(s); return; }
    if (checkOnly) return;
    r.lastSeen = now;
    if (now - (r.lastAct || r.startTs) > ZT_IDLE_MS) {
      const snap = await ztEngSnapshot();
      if (!snap.length) ztFinishIn(s, 'idle', r.lastAct || now);
    }
    await ztSave(s);
  });
}

function ztFinishNow(reason) {
  return ztQ(async () => {
    const s = await ztLoad();
    if (ztActive(s)) { ztFinishIn(s, reason, Date.now()); await ztSave(s); }
  });
}

// ── wiring ──────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;
  if (msg.type === 'zexTrack' && msg.evt) { ztLog(msg.evt); return; }
  if (msg.type === 'zexSafetyHit') { ztSafetyHit(msg.eng).then(sendResponse, () => sendResponse({ stop: false, n: 0 })); return true; }
  if (msg.type === 'zexTrackImport') { ztImport(msg.payload).then(sendResponse, () => sendResponse({ ok: false, added: 0 })); return true; }
  const j = ZT_JOBS[msg.type];
  if (j) ztLog({ type: j.end ? 'job_end' : 'job', name: j.name, src: 'job' });
});

// Import from the popup (Export/Import in the workflow map). Goes through the same queue as live logging.
const ZT_EV_KEYS = ['t', 'type', 'eng', 'model', 'mode', 'h', 'link', 'n', 'why', 'name', 'likeOn', 'src'];
function ztSanitizeRun(r) {
  if (!r || typeof r !== 'object' || typeof r.id !== 'string' || !isFinite(r.startTs) || !Array.isArray(r.events)) return null;
  const events = [];
  r.events.slice(0, ZT_MAX_EVENTS).forEach((e) => {
    if (!e || typeof e !== 'object' || !isFinite(e.t) || typeof e.type !== 'string') return;
    const o = {};
    ZT_EV_KEYS.forEach((k) => {
      if (e[k] === undefined || e[k] === null) return;
      if (typeof e[k] === 'string') o[k] = e[k].slice(0, 140);
      else if (typeof e[k] === 'number' || typeof e[k] === 'boolean') o[k] = e[k];
    });
    o.t = +e.t; o.type = String(e.type).slice(0, 20);
    events.push(o);
  });
  if (!events.length) return null;
  const last = events[events.length - 1];
  return {
    id: r.id.slice(0, 40), startTs: +r.startTs, lastSeen: last.t, lastAct: last.t,
    src: typeof r.src === 'string' ? r.src.slice(0, 12) : 'manual', jobs: 0,
    endTs: isFinite(r.endTs) ? +r.endTs : last.t,
    endReason: typeof r.endReason === 'string' ? r.endReason.slice(0, 20) : 'imported',
    imported: true, events: events,
  };
}
function ztImport(payload) {
  return ztQ(async () => {
    if (!payload || !Array.isArray(payload.runs)) return { ok: false, added: 0 };
    const s = await ztLoad();
    let added = 0;
    payload.runs.slice(0, 100).forEach((raw) => {
      const r = ztSanitizeRun(raw);
      if (!r || r.id === s.activeId) return;
      const i = s.runs.findIndex((x) => x.id === r.id);
      if (i >= 0) s.runs[i] = r; else { s.runs.push(r); added++; }
    });
    s.runs.sort((a, b) => a.startTs - b.startTs);
    if (s.runs.length > ZT_MAX_RUNS) {
      const drop = s.runs.length - ZT_MAX_RUNS;
      s.runs = s.runs.filter((r, idx) => idx >= drop || r.id === s.activeId);
    }
    await ztSave(s);
    return { ok: true, added: added };
  });
}

// Engine switches (Feed / Search / GIV / Comment REP), model and Auto/Manual changes.
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local') return;
  Object.keys(ZT_ENG).forEach((name) => {
    const c = ZT_ENG[name];
    const k = c.on || c.auto;
    if (ch[k] && (ch[k].newValue === true) !== (ch[k].oldValue === true)) {
      if (ch[k].newValue === true) {
        ztSafetyClear();
        ztEngSnapshot().then((list) => {
          const e = list.find((x) => x.eng === name);
          ztLog({ type: 'engine_on', eng: name, model: e ? e.model : '', mode: e ? e.mode : 'manual', likeOn: e ? e.likeOn : false });
        });
      } else {
        ztLog({ type: 'engine_off', eng: name });
      }
    } else if (c.on && ch[c.auto] && (ch[c.auto].newValue === true) !== (ch[c.auto].oldValue === true)) {
      ztLog({ type: 'mode', eng: name, mode: ch[c.auto].newValue === true ? 'auto' : 'manual' });
    }
  });
});

// Browser closed (last window gone) → track over, data already saved.
try {
  if (chrome.windows && chrome.windows.onRemoved) {
    chrome.windows.onRemoved.addListener(() => {
      chrome.windows.getAll((ws) => { if (!ws || !ws.length) ztFinishNow('browser-closed'); });
    });
  }
} catch (e) {}

chrome.alarms.create(ZT_BEAT_ALARM, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => { if (a && a.name === ZT_BEAT_ALARM) ztBeat(false); });
ztBeat(true); // service worker just woke up: close a run whose heartbeat died while the browser was shut
