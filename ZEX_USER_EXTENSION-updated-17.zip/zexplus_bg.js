// ═══════════════════════════════════════════════════════════════════════
//  ZEX+ — background half (service worker, loaded by importScripts in background.js)
//
//  1. Emulation.setFocusEmulationEnabled   → background X tab thinks it is focused
//  2. Input.dispatchKeyEvent / insertText  → trusted keystrokes for reply typing
//  3. Network.emulateNetworkConditions     → slow-net test for retry logic
//  4. Input.dispatchTouchEvent             → touch-style tap (Kiwi / mobile)
//  5. chrome.idle + chrome.power           → keep the machine awake while an engine runs
//
//  Storage keys (all in chrome.storage.local, all default OFF):
//    zexplus_focus  bool            zexplus_key   bool
//    zexplus_touch  bool            zexplus_idle  bool
//    zexplus_net    'off' | 'fast3g' | 'slow3g' | '2g'
// ═══════════════════════════════════════════════════════════════════════
(function () {
  'use strict';
  if (self.ZexPlus) return;

  const KEYS = ['zexplus_focus', 'zexplus_key', 'zexplus_touch', 'zexplus_net', 'zexplus_idle'];
  const ENG = ['zenSearchEngineOn', 'zenFeedEngineOn', 'zenRepEngineOn', 'zenGivEngineOn'];
  const X_URLS = ['https://x.com/*', 'https://twitter.com/*'];
  const cfg = { focus: false, key: false, touch: false, net: 'off', idle: false };

  // bytes/second, ms — same numbers Chrome DevTools uses for its presets (2g is a touch slower)
  const NET = {
    fast3g: { latency: 150, downloadThroughput: 200000, uploadThroughput: 93750, connectionType: 'cellular3g' },
    slow3g: { latency: 400, downloadThroughput: 62500, uploadThroughput: 62500, connectionType: 'cellular3g' },
    '2g': { latency: 800, downloadThroughput: 28000, uploadThroughput: 14000, connectionType: 'cellular2g' },
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rnd = (a, b) => a + Math.random() * (b - a);
  const isXUrl = (u) => /^https:\/\/(x|twitter)\.com\//.test(u || '');

  // ── debugger helpers ────────────────────────────────────────────────
  const persisted = new Set();      // tabs where focus/net emulation is applied
  const blocked = new Set();        // tabs where the user pressed Cancel on the debug bar → leave alone
  const detachTimers = {};

  function attach(tabId) {
    return new Promise((res, rej) => {
      chrome.debugger.attach({ tabId }, '1.3', () => {
        const e = chrome.runtime.lastError;
        if (e && !/already attached/i.test(e.message || '')) return rej(new Error(e.message));
        res();
      });
    });
  }
  function send(tabId, method, params) {
    return new Promise((res, rej) => {
      chrome.debugger.sendCommand({ tabId }, method, params || {}, (r) => {
        const e = chrome.runtime.lastError;
        if (e) rej(new Error(e.message)); else res(r);
      });
    });
  }
  const needPersist = () => cfg.focus || cfg.net !== 'off';

  function clearDetach(tabId) { clearTimeout(detachTimers[tabId]); delete detachTimers[tabId]; }
  // One shared "detach after 3s of silence" timer per tab (background.js click/scroll use it too),
  // so a click followed by typing can never get the debugger pulled out from under it.
  function scheduleDetach(tabId) {
    clearDetach(tabId);
    detachTimers[tabId] = setTimeout(() => {
      delete detachTimers[tabId];
      if (needPersist() && persisted.has(tabId)) return;
      chrome.debugger.detach({ tabId }, () => { void chrome.runtime.lastError; });
    }, 3000);
  }

  // ── 1 + 3: persistent emulation (focus + network) ───────────────────
  async function applyPersistent(tabId) {
    if (blocked.has(tabId)) return;
    try {
      await attach(tabId);
      clearDetach(tabId);
      persisted.add(tabId);
      await send(tabId, 'Emulation.setFocusEmulationEnabled', { enabled: !!cfg.focus });
      if (cfg.net !== 'off' && NET[cfg.net]) {
        await send(tabId, 'Network.enable');
        await send(tabId, 'Network.emulateNetworkConditions', Object.assign({ offline: false }, NET[cfg.net]));
      } else if (persisted.has(tabId + ':net')) {
        await send(tabId, 'Network.emulateNetworkConditions', { offline: false, latency: 0, downloadThroughput: -1, uploadThroughput: -1 });
        await send(tabId, 'Network.disable');
      }
      if (cfg.net !== 'off') persisted.add(tabId + ':net'); else persisted.delete(tabId + ':net');
    } catch (e) {
      console.debug('[ZexPlus] persistent apply failed', tabId, e && e.message);
    }
  }
  async function releasePersistent(tabId) {
    try {
      await send(tabId, 'Emulation.setFocusEmulationEnabled', { enabled: false });
      if (persisted.has(tabId + ':net')) {
        await send(tabId, 'Network.emulateNetworkConditions', { offline: false, latency: 0, downloadThroughput: -1, uploadThroughput: -1 });
        await send(tabId, 'Network.disable');
      }
    } catch (e) {}
    persisted.delete(tabId); persisted.delete(tabId + ':net');
    scheduleDetach(tabId);
  }
  async function xTabs() {
    try { return await chrome.tabs.query({ url: X_URLS }); } catch (e) { return []; }
  }
  async function reconcile() {
    const tabs = await xTabs();
    if (needPersist()) { for (const t of tabs) applyPersistent(t.id); }
    else { for (const id of Array.from(persisted)) { if (typeof id === 'number') releasePersistent(id); } }
  }

  // Called from background.js click/scroll code: "may I detach now?"
  function keepAttached(tabId) {
    if (!needPersist() || blocked.has(tabId)) return false;
    applyPersistent(tabId);           // idempotent: makes sure emulation is really on this tab
    return true;
  }

  // ── 2: trusted keystrokes ───────────────────────────────────────────
  const US = {};
  (function buildMap() {
    for (let i = 0; i < 26; i++) {
      const lo = String.fromCharCode(97 + i), up = lo.toUpperCase();
      US[lo] = { code: 'Key' + up, vk: 65 + i, un: lo };
      US[up] = { code: 'Key' + up, vk: 65 + i, un: lo, shift: true };
    }
    '0123456789'.split('').forEach((d, i) => { US[d] = { code: 'Digit' + d, vk: 48 + i, un: d }; });
    ')!@#$%^&*('.split('').forEach((c, i) => { US[c] = { code: 'Digit' + i, vk: 48 + i, un: String(i), shift: true }; });
    US[' '] = { code: 'Space', vk: 32, un: ' ' };
    [[';', ':', 'Semicolon', 186], ['=', '+', 'Equal', 187], [',', '<', 'Comma', 188], ['-', '_', 'Minus', 189],
     ['.', '>', 'Period', 190], ['/', '?', 'Slash', 191], ['`', '~', 'Backquote', 192], ['[', '{', 'BracketLeft', 219],
     ['\\', '|', 'Backslash', 220], [']', '}', 'BracketRight', 221], ["'", '"', 'Quote', 222]].forEach((p) => {
      US[p[0]] = { code: p[2], vk: p[3], un: p[0] };
      US[p[1]] = { code: p[2], vk: p[3], un: p[0], shift: true };
    });
  })();

  async function pressChar(tabId, ch, hold) {
    if (ch === '\n' || ch === '\r') {
      const b = { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13, modifiers: 0 };
      await send(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown', text: '\r', unmodifiedText: '\r' }, b));
      await sleep(hold);
      await send(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, b));
      return;
    }
    const m = US[ch];
    if (!m) { await send(tabId, 'Input.insertText', { text: ch }); return; }     // emoji, Bengali, accents …
    const base = { key: ch, code: m.code, windowsVirtualKeyCode: m.vk, nativeVirtualKeyCode: m.vk, modifiers: m.shift ? 8 : 0 };
    await send(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown', text: ch, unmodifiedText: m.un }, base));
    await sleep(hold);
    await send(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, base));
  }

  async function typeText(msg, tabId) {
    const text = String(msg.text || '').slice(0, 1500);
    if (!text) return { ok: false, reason: 'empty' };
    clearDetach(tabId);
    await attach(tabId);
    try {
      if (msg.clear) {         // the content script already selected the old text → Backspace removes it
        const b = { key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8, modifiers: 0 };
        await send(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'rawKeyDown' }, b));
        await sleep(rnd(20, 45));
        await send(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, b));
        await sleep(rnd(40, 90));
      }
      if (!Array.isArray(msg.delays)) {                       // instant mode: one trusted insert
        await send(tabId, 'Input.insertText', { text });
      } else {                                                // human mode: real keyDown/keyUp per char
        let idx = 0;
        for (const ch of text) {
          const d = Number(msg.delays[idx]) || 0;
          const hold = Math.min(rnd(18, 48), Math.max(4, d * 0.6));
          await pressChar(tabId, ch, hold);
          idx += ch.length;
          const rest = d - hold;
          if (rest > 0) await sleep(rest);
        }
      }
      return { ok: true };
    } finally { scheduleDetach(tabId); }
  }

  // ── 4: touch tap ────────────────────────────────────────────────────
  async function tap(msg, tabId) {
    const x = Number(msg.x), y = Number(msg.y);
    if (!isFinite(x) || !isFinite(y)) return { ok: false, reason: 'bad_params' };
    clearDetach(tabId);
    await attach(tabId);
    const emu = !!msg.needEmu;      // desktop Chrome has no touch screen → emulate one for the tap only
    try {
      if (emu) await send(tabId, 'Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 1 });
      const pt = (dx, dy, f) => ({ x: x + dx, y: y + dy, radiusX: rnd(5, 11), radiusY: rnd(5, 11), rotationAngle: 0, force: f, id: 1 });
      await send(tabId, 'Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [pt(0, 0, rnd(0.3, 0.7))] });
      await sleep(rnd(45, 110));
      if (Math.random() < 0.5) {    // finger micro-slip, well under the tap-slop limit
        await send(tabId, 'Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [pt(rnd(-1, 1), rnd(-1, 1), rnd(0.3, 0.7))] });
        await sleep(rnd(12, 30));
      }
      await send(tabId, 'Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      return { ok: true };
    } finally {
      if (emu) { await sleep(120); try { await send(tabId, 'Emulation.setTouchEmulationEnabled', { enabled: false }); } catch (e) {} }
      scheduleDetach(tabId);
    }
  }

  // ── 5: idle + power ─────────────────────────────────────────────────
  let idleBound = false;
  async function wakeTabs() {
    for (const t of await xTabs()) { try { chrome.tabs.sendMessage(t.id, { type: 'zexplusWake' }, () => { void chrome.runtime.lastError; }); } catch (e) {} }
  }
  function initIdle() {
    if (!chrome.idle || idleBound) return;
    idleBound = true;
    try { chrome.idle.setDetectionInterval(60); } catch (e) {}
    chrome.idle.onStateChanged.addListener((state) => {
      chrome.storage.local.set({ zexplus_idle_state: { state, ts: Date.now() } });
      if (state === 'active' && cfg.idle) wakeTabs();       // came back from lock/idle → nudge engines + re-grab wake lock
    });
  }
  async function syncKeepAwake() {
    initIdle();
    if (!chrome.power) return;            // not granted yet / not supported on this browser (Kiwi) → content wake lock still works
    try {
      const d = await chrome.storage.local.get(ENG);
      if (cfg.idle && ENG.some((k) => d[k] === true)) chrome.power.requestKeepAwake('system');
      else chrome.power.releaseKeepAwake();
    } catch (e) {}
  }

  // ── wiring ──────────────────────────────────────────────────────────
  function loadCfg(d) {
    cfg.focus = d.zexplus_focus === true;
    cfg.key = d.zexplus_key === true;
    cfg.touch = d.zexplus_touch === true;
    cfg.net = (d.zexplus_net && (NET[d.zexplus_net] ? d.zexplus_net : 'off')) || 'off';
    cfg.idle = d.zexplus_idle === true;
  }
  chrome.storage.local.get(KEYS, (d) => { loadCfg(d || {}); reconcile(); syncKeepAwake(); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    const k = Object.keys(ch);
    if (k.some((x) => KEYS.indexOf(x) >= 0)) {
      chrome.storage.local.get(KEYS, (d) => { loadCfg(d || {}); reconcile(); syncKeepAwake(); });
    } else if (k.some((x) => ENG.indexOf(x) >= 0)) syncKeepAwake();
  });
  chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (info.status === 'complete' && needPersist() && isXUrl(tab && tab.url)) applyPersistent(tabId);
  });
  chrome.tabs.onRemoved.addListener((tabId) => { persisted.delete(tabId); persisted.delete(tabId + ':net'); blocked.delete(tabId); clearDetach(tabId); });
  chrome.debugger.onDetach.addListener((src, reason) => {
    if (!src || src.tabId == null) return;
    persisted.delete(src.tabId); persisted.delete(src.tabId + ':net');
    if (reason === 'canceled_by_user') blocked.add(src.tabId);     // user closed the debug bar → respect it
  });
  try { chrome.permissions.onAdded.addListener(() => { syncKeepAwake(); }); } catch (e) {}

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string') return;
    if (sender && sender.id && sender.id !== chrome.runtime.id) return;
    const tabId = (sender && sender.tab && sender.tab.id) || msg.tabId;
    if (msg.type === '__CDP_TYPE__' || msg.type === '__CDP_TAP__') {
      if (!tabId) { sendResponse({ ok: false, reason: 'no_tabId' }); return; }
      blocked.delete(tabId);          // an explicit action from the page = user wants it
      const job = msg.type === '__CDP_TYPE__' ? typeText(msg, tabId) : tap(msg, tabId);
      job.then(sendResponse, (e) => sendResponse({ ok: false, reason: String((e && e.message) || e) }));
      return true;
    }
    if (msg.type === 'zexplusStatus') {
      sendResponse({ cfg, persisted: Array.from(persisted).filter((x) => typeof x === 'number'), idle: !!chrome.idle, power: !!chrome.power });
      return;
    }
  });

  self.ZexPlus = { cfg, keepAttached, scheduleDetach, reconcile, syncKeepAwake };
})();
