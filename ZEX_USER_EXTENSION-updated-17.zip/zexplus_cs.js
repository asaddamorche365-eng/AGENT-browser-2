// ═══════════════════════════════════════════════════════════════════════
//  ZEX+ — content-script half (runs on x.com / twitter.com, loaded BEFORE content.js)
//  Exposes window.ZexPlus (same isolated world as content.js):
//    keyOn() / touchOn()        → feature switches (cached from storage)
//    typeCdp(editor, text, delays, opts) → trusted typing through the background (CDP)
//    tapCdp(x, y)               → touch-style tap through the background (CDP)
//    rows(green, dim)           → status rows for the Agent dashboard
//  Also: screen wake lock while an engine runs, and a Web Lock that keeps a hidden tab from being frozen.
// ═══════════════════════════════════════════════════════════════════════
(function () {
  'use strict';
  if (window.ZexPlus) return;

  const ENG = ['zenSearchEngineOn', 'zenFeedEngineOn', 'zenRepEngineOn', 'zenGivEngineOn'];
  const KEYS = ['zexplus_focus', 'zexplus_key', 'zexplus_touch', 'zexplus_net', 'zexplus_idle'].concat(ENG);
  const st = { focus: false, key: false, touch: false, net: 'off', idle: false, engOn: false, wl: false, lock: false };

  function load(d) {
    st.focus = d.zexplus_focus === true;
    st.key = d.zexplus_key === true;
    st.touch = d.zexplus_touch === true;
    st.net = d.zexplus_net || 'off';
    st.idle = d.zexplus_idle === true;
    st.engOn = ENG.some((k) => d[k] === true);
  }

  // ── wake lock (screen stays on while an engine runs) ──
  let wl = null;
  async function holdAwake() {
    try {
      if (!(st.idle && st.engOn) || wl || document.visibilityState !== 'visible' || !navigator.wakeLock) return;
      wl = await navigator.wakeLock.request('screen');
      st.wl = true;
      wl.addEventListener('release', () => { wl = null; st.wl = false; if (st.idle && st.engOn) setTimeout(holdAwake, 1000); });
    } catch (e) { wl = null; st.wl = false; }
  }
  async function dropAwake() { try { if (wl) await wl.release(); } catch (e) {} wl = null; st.wl = false; }

  // ── Web Lock: a page holding one is not frozen / intensively throttled while hidden ──
  let lockRelease = null;
  function holdLock() {
    if (lockRelease || !navigator.locks) return;
    try {
      navigator.locks.request('zexplus-keepalive', { mode: 'shared' }, () => new Promise((res) => { lockRelease = res; })).catch(() => {});
      st.lock = true;
    } catch (e) { lockRelease = null; }
  }
  function dropLock() { if (lockRelease) { try { lockRelease(); } catch (e) {} } lockRelease = null; st.lock = false; }

  function apply() {
    if (st.idle && st.engOn) holdAwake(); else dropAwake();
    if (st.focus && st.engOn) holdLock(); else dropLock();
  }

  chrome.storage.local.get(KEYS, (d) => { load(d || {}); apply(); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !Object.keys(ch).some((k) => KEYS.indexOf(k) >= 0)) return;
    chrome.storage.local.get(KEYS, (d) => { load(d || {}); apply(); });
  });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') holdAwake(); });
  chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'zexplusWake') { holdAwake(); } });

  // ── trusted typing ──
  const PLACEHOLDERS = ['Post your reply', 'What is happening?!', 'Post text', 'Add another post'];
  const norm = (s) => String(s || '').replace(/[\u200b\u00a0]/g, ' ').replace(/\s+/g, ' ').trim();
  function hasText(ed) {
    const t = norm(ed.innerText);
    return !!t && PLACEHOLDERS.indexOf(t) < 0;
  }
  async function typeCdp(editor, text, delays, opts) {
    opts = opts || {};
    if (!editor || !text || editor.tagName === 'TEXTAREA') return false;     // textarea keeps the old path
    try {
      let had = false;
      if (!opts.live) {
        editor.focus();
        try {
          const sel = window.getSelection();
          if (sel) { const r = document.createRange(); r.selectNodeContents(editor); sel.removeAllRanges(); sel.addRange(r); }
        } catch (e) {}
        had = hasText(editor);
      }
      const res = await chrome.runtime.sendMessage({ type: '__CDP_TYPE__', text: String(text), delays: delays || null, clear: had });
      if (!res || !res.ok) { console.debug('[ZexPlus] CDP typing failed → old path', res && res.reason); return false; }
      if (opts.live) return true;
      const want = norm(text).slice(0, 14), got = norm(editor.innerText);
      if (want && got.indexOf(want) < 0) { console.debug('[ZexPlus] CDP typing did not land → old path'); return false; }
      return true;
    } catch (e) { console.debug('[ZexPlus] CDP typing threw', e && e.message); return false; }
  }

  async function tapCdp(x, y) {
    try {
      const res = await chrome.runtime.sendMessage({ type: '__CDP_TAP__', x, y, needEmu: !(navigator.maxTouchPoints > 0) });
      return !!(res && res.ok);
    } catch (e) { return false; }
  }

  function rows(G, D) {
    const r = (k, on, v) => `<div style="display:flex;justify-content:space-between;"><span>${k}</span><b style="color:${on ? G : D};">${v}</b></div>`;
    let h = '';
    if (st.focus) h += r('FOCUS LOCK', true, 'ON');
    if (st.key) h += r('CDP TYPING', true, 'ON');
    if (st.touch) h += r('TOUCH TAP', true, 'ON');
    if (st.net !== 'off') h += r('NET TEST', true, String(st.net).toUpperCase());
    if (st.idle) h += r('KEEP AWAKE', st.wl, st.wl ? 'LOCK HELD' : (st.engOn ? 'WAITING' : 'IDLE'));
    return h;
  }

  window.ZexPlus = { keyOn: () => st.key, touchOn: () => st.touch, typeCdp, tapCdp, rows, state: st };
})();
