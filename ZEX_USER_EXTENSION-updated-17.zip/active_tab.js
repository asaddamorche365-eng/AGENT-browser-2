// Z EX — ZEXPAY tab: credits, crypto payment (verified server-side), redeem codes, first-payment / zero-credit lock.
// All calls go through background.js ("zexpayCall") → Cloudflare Worker. Nothing here is trusted by the server.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var NET_NAMES = { eth: 'Ethereum', base: 'Base', bnb: 'BNB Chain' };
  var FALLBACK = {
    packages: [{ usd: 4.9, credits: 5000, first_bonus: 1000 }, { usd: 6.9, credits: 7000, first_bonus: 0 }, { usd: 9.9, credits: 10000, first_bonus: 0 }],
    networks: { eth: { coins: ['USDT', 'USDC', 'ETH'] }, base: { coins: ['USDC', 'ETH'] }, bnb: { coins: ['USDT', 'USDC', 'BNB'] } },
    cost_per_comment: 2
  };
  var ERR = {
    BAD_PACKAGE: 'Invalid package.',
    BAD_NETWORK_OR_COIN: 'This coin is not supported on that network.',
    NOT_APPROVED: 'Your account is not approved yet.',
    TOO_MANY_OPEN_INTENTS: 'Too many open payments — finish one or wait for them to expire.',
    BUSY_TRY_LATER: 'Busy right now — try again in a minute.',
    PRICE_UNAVAILABLE: 'Price feed unavailable — try again shortly.',
    TX_NOT_FOUND: 'Transaction not found yet. Wait a minute after sending, then try again.',
    TX_FAILED: 'That transaction failed on-chain.',
    TX_OUT_OF_WINDOW: 'That transaction is outside this payment\u2019s time window.',
    NO_PAYMENT_TO_WALLET: 'No payment of the right token to our wallet was found in that transaction.',
    TX_ALREADY_USED: 'This transaction was already used.',
    INTENT_ALREADY_PAID: 'This payment was already completed.',
    INTENT_EXPIRED: 'This payment expired — create a new one (contact admin if you already paid).',
    INTENT_NOT_FOUND: 'Payment not found — create a new one.',
    BAD_TX_HASH: 'Invalid transaction hash.',
    CHAIN_RPC_FAILED: 'Blockchain check failed — try again in a minute.',
    INVALID_CODE: 'Invalid code.',
    CODE_USED: 'This code was already used.',
    BAD_CODE: 'Enter a code.',
    NETWORK: 'Network error — try again.',
    NO_AUTH: 'Please sign in again.'
  };
  var offerFetched = false;
  var st = { me: null, cfg: null, sel: { pkg: 4.9, net: 'eth', coin: 'USDT' }, intent: null,
    pollT: null, pollN: 0, leftT: null, meT: null, locked: false, session: null, bound: false };

  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function call(path, body) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'zexpayCall', path: path, body: body }, function (res) {
          if (chrome.runtime.lastError || !res) return resolve({ ok: false, error: 'NETWORK', data: null });
          resolve(res);
        });
      } catch (e) { resolve({ ok: false, error: 'NETWORK', data: null }); }
    });
  }
  function errText(r) {
    var e = r && r.error;
    if (e === 'AMOUNT_MISMATCH') {
      var d = (r.data && r.data.expected) ? ' Expected: ' + r.data.expected + ' ' + (r.data.coin || '') + '.' : '';
      return 'Amount does not match — you must send EXACTLY the amount shown.' + d + ' Contact admin if you already paid.';
    }
    return ERR[e] || ('Error: ' + (e || 'unknown'));
  }
  function setMsg(id, text, cls) { var m = $(id); if (!m) return; m.textContent = text || ''; m.className = 'act-msg' + (cls ? ' ' + cls : ''); }
  function goTab() { var b = document.querySelector('.nav-tab[data-tabpanel="tabPanelActive"]'); if (b) b.click(); }
  function copy(text, btn) {
    function done() { if (btn) { var o = btn.textContent; btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = o; }, 1200); } }
    function fallback() {
      try { var t = document.createElement('textarea'); t.value = text; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t); done(); } catch (e) {}
    }
    try { navigator.clipboard.writeText(text).then(done, fallback); } catch (e) { fallback(); }
  }

  // ── Access (days) card — same as before ─────────────────────────
  function renderAccess(session) {
    var pill = $('actStatus'), daysEl = $('actDays'), expEl = $('actExpiry'), bar = $('actBar');
    if (!pill) return;
    var exp = session && session.expiresAt ? session.expiresAt : 0;
    if (session && session.noExpiry && session.expInfo > Date.now()) exp = session.expInfo;   // real expiry set by admin (info only)
    var left = Math.max(0, exp - Date.now());
    var days = Math.ceil(left / 86400000);
    var cls = 'act-pill', txt = 'ACTIVE';
    if (!exp || left <= 0) { cls += ' off'; txt = 'EXPIRED'; }
    else if (days <= 3) { cls += ' warn'; txt = 'EXPIRING SOON'; }
    pill.innerHTML = '<span class="' + cls + '">' + txt + '</span>';
    daysEl.textContent = exp && left > 0 ? days + ' day' + (days === 1 ? '' : 's') : '0';
    expEl.textContent = exp ? new Date(exp).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '-';
    bar.style.width = (exp && left > 0 ? Math.min(100, Math.round(left / (30 * 86400000) * 100)) : 0) + '%';
  }
  function refreshAccess() {
    try { chrome.storage.local.get(['zenDeviceSession'], function (r) { renderAccess(r && r.zenDeviceSession); }); } catch (e) {}
  }

  // ── Account state (/v1/me) ──────────────────────────────────────
  function refreshMe() {
    return call('/v1/me').then(function (r) {
      if (!r.ok || !r.data) return st.me;
      st.me = r.data;
      try { chrome.storage.local.set({ zexpayMe: Object.assign({}, r.data, { t: Date.now() }) }); } catch (e) {}
      renderCredits(); applyLock();
      return st.me;
    });
  }
  function renderCredits() {
    var me = st.me; if (!me) return;
    var cost = me.cost_per_comment || 2, n = Number(me.credits) || 0, comments = Math.floor(n / cost);
    var sub = n <= 0 ? 'Out of credits' : '\u2248 ' + fmt(comments) + ' comments';
    if ($('zpCredits')) $('zpCredits').textContent = fmt(n);
    if ($('zpCreditsSub')) $('zpCreditsSub').textContent = sub;
    if ($('zpBal')) $('zpBal').textContent = fmt(n);
    if ($('zpBalSub')) $('zpBalSub').textContent = n <= 0 ? 'No credits — Z EX is paused until you top up.' : '\u2248 ' + fmt(comments) + ' comments left';
    if ($('zpCost')) $('zpCost').textContent = cost + ' credits / comment';
    var low = $('zpLowBar');
    if (low) {
      var show = me.needs_first_payment || n <= 0 || me.low;
      low.style.display = show ? 'flex' : 'none';
      low.className = 'zp-low' + (n <= 0 || me.needs_first_payment ? ' out' : '');
      if (show) {
        var t = me.needs_first_payment ? 'Activate your account with the first payment.' : (n <= 0 ? 'No credits left — Z EX is paused.' : 'Low credits — only ~' + fmt(comments) + ' comments left.');
        $('zpLowTxt').textContent = t;
        low.style.display = 'flex';
      }
    }
  }
  function applyLock() {
    var me = st.me, reason = me && me.lock_reason;
    var lock = reason === 'needs_first_payment' || reason === 'no_credits';
    document.body.classList.toggle('zp-locked', lock);
    var b = $('zpLockBanner');
    if (b) {
      if (lock) {
        b.style.display = 'block';
        b.textContent = reason === 'needs_first_payment'
          ? 'Activate your account: complete your first payment (or redeem a code) to start using Z EX. Everything stays locked until then.'
          : 'Your credits are finished \u2014 Z EX is paused. Buy credits or redeem a code to continue.';
      } else b.style.display = 'none';
    }
    var was = st.locked; st.locked = lock;
    if (lock && !was) goTab();
  }

  // ── Offer banner (admin panel → Worker app-config "zexpay_offer" { text, active }) ──────
  // Shown at the very top of the ZEXPAY tab. Plain text only (textContent — never HTML).
  // The last value is cached so it appears instantly and still shows if the server is briefly unreachable.
  function renderOffer(o) {
    var box = $('zpOfferBanner'), t = $('zpOfferTxt'); if (!box || !t) return;
    var text = o && o.active !== false && typeof o.text === 'string' ? o.text.trim().slice(0, 500) : '';
    if (!text) { box.style.display = 'none'; t.textContent = ''; return; }
    t.textContent = text; box.style.display = 'flex';
  }
  function loadOffer() {
    try { chrome.storage.local.get(['zexpayOfferCache'], function (r) { if (!offerFetched) renderOffer(r && r.zexpayOfferCache); }); } catch (e) {}
    if (typeof zAppConfig !== 'function') return;
    zAppConfig(false).then(function (cfg) {
      if (!cfg) return;                       // null = network error: keep the cached banner
      var d = cfg.zexpay_offer; offerFetched = true;
      if (d && typeof d === 'object') {
        renderOffer(d);
        try { chrome.storage.local.set({ zexpayOfferCache: { text: d.text || '', active: d.active !== false } }); } catch (e) {}
      } else {                                // unset / cleared by admin
        renderOffer(null);
        try { chrome.storage.local.remove(['zexpayOfferCache']); } catch (e) {}
      }
    }).catch(function () {});
  }

  // ── Packages / chips ────────────────────────────────────────────
  function loadConfig() {
    return call('/v1/packages').then(function (r) {
      if (r.ok && r.data && r.data.packages && r.data.networks) st.cfg = r.data;
      renderChips();
    });
  }
  function chips(id, items, selVal, onPick) {
    var g = $(id); if (!g) return; g.innerHTML = '';
    items.forEach(function (it) {
      var b = document.createElement('button'); b.type = 'button';
      b.className = 'act-chip' + (String(it.v) === String(selVal) ? ' sel' : '');
      b.textContent = it.t;
      if (it.sub) { var sm = document.createElement('div'); sm.textContent = it.sub; sm.style.cssText = 'font-size:9px;font-weight:700;margin-top:2px;opacity:.85;'; b.appendChild(sm); }
      b.addEventListener('click', function () { onPick(it.v); });
      g.appendChild(b);
    });
  }
  // Note under the packages: live offer bonus + first-purchase bonus of the SELECTED package (all from the Worker)
  function renderPkgNote(cfg) {
    var el = $('zpPkgNote'); if (!el) return;
    var p = (cfg.packages || []).filter(function (x) { return x.usd === st.sel.pkg; })[0];
    var lines = [];
    if (p && p.offer_active && p.offer_bonus > 0) {
      var end = p.offer_to ? ' \u00b7 ends ' + new Date(p.offer_to).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';
      lines.push('\ud83d\udd25 Offer: +' + fmt(p.offer_bonus) + ' bonus credits (total ' + fmt(p.total_now || (p.credits + p.offer_bonus)) + ')' + end);
    }
    if (p && p.first_bonus > 0) lines.push('New accounts: your first $' + p.usd + ' purchase includes +' + fmt(p.first_bonus) + ' bonus credits.');
    el.textContent = lines.join('\n'); el.style.whiteSpace = 'pre-line'; el.style.display = lines.length ? '' : 'none';
  }
  function renderChips() {
    var cfg = st.cfg || FALLBACK;
    if (!cfg.packages.some(function (p) { return p.usd === st.sel.pkg; })) st.sel.pkg = cfg.packages[0].usd;
    chips('zpPkgs', cfg.packages.map(function (p) {
      var live = p.offer_active && p.offer_bonus > 0;
      return { v: p.usd, t: '$' + p.usd + ' \u00b7 ' + fmt(p.credits) + (live ? ' +' + fmt(p.offer_bonus) : ''), sub: p.label ? String(p.label).slice(0, 40) : '' };
    }), st.sel.pkg, function (v) { st.sel.pkg = v; renderChips(); });
    renderPkgNote(cfg);
    var nets = Object.keys(cfg.networks);
    if (nets.indexOf(st.sel.net) < 0) st.sel.net = nets[0];
    chips('zpNets', nets.map(function (n) { return { v: n, t: NET_NAMES[n] || n }; }), st.sel.net, function (v) { st.sel.net = v; renderChips(); });
    var coins = (cfg.networks[st.sel.net] || {}).coins || [];
    if (coins.indexOf(st.sel.coin) < 0) st.sel.coin = coins[0];
    chips('zpCoins', coins.map(function (c) { return { v: c, t: c }; }), st.sel.coin, function (v) { st.sel.coin = v; renderChips(); });
  }

  // ── Payment intent ──────────────────────────────────────────────
  function persistIntent() {
    try {
      if (st.intent) chrome.storage.local.set({ zexpayIntent: { email: st.session && st.session.email, intent: st.intent, saved_at: Date.now() } });
      else chrome.storage.local.remove(['zexpayIntent']);
    } catch (e) {}
  }
  function restoreIntent() {
    try {
      chrome.storage.local.get(['zexpayIntent'], function (r) {
        var x = r && r.zexpayIntent;
        if (!x || !x.intent || !st.session || x.email !== st.session.email) return;
        if (Date.now() - x.saved_at > 24 * 3600 * 1000) { chrome.storage.local.remove(['zexpayIntent']); return; }
        st.intent = x.intent; showIntent();
      });
    } catch (e) {}
  }
  function makeIntent() {
    var btn = $('zpIntentBtn'); btn.disabled = true; setMsg('zpIntentMsg', 'Creating payment\u2026', '');
    call('/v1/pay/intent', { package: st.sel.pkg, network: st.sel.net, coin: st.sel.coin }).then(function (r) {
      btn.disabled = false;
      if (!r.ok || !r.data) { setMsg('zpIntentMsg', errText(r), 'err'); return; }
      st.intent = r.data; persistIntent(); showIntent();
      setMsg('zpIntentMsg', r.data.reused ? 'You already have an open payment for this choice \u2014 details below.' : '', 'ok');
    });
  }
  function tickLeft() {
    var i = st.intent, el = $('zpPayLeft'); if (!i || !el) return;
    var ms = i.expires_at - Date.now();
    if (ms > 0) { var m = Math.floor(ms / 60000), s = Math.floor((ms % 60000) / 1000); el.textContent = m + ':' + (s < 10 ? '0' : '') + s; }
    else el.textContent = 'ended';
  }
  function showIntent() {
    var i = st.intent, box = $('zpPayBox'); if (!i || !box) return;
    box.style.display = 'block';
    $('zpAmt').textContent = i.amount + ' ' + i.coin;
    $('zpPayNet').textContent = NET_NAMES[i.network] || i.network;
    $('zpPayCredits').textContent = fmt(i.credits) + (i.bonus_credits ? ' + ' + fmt(i.bonus_credits) + ' bonus' : '') + ' credits';
    $('zpWallet').value = i.wallet;
    $('zpPayWarn').textContent = 'Send EXACTLY ' + i.amount + ' ' + i.coin + ' on ' + (NET_NAMES[i.network] || i.network) +
      ' (all digits). A different amount or network will not be credited automatically. Wait for ' + i.min_confirmations + ' confirmations, then paste the transaction hash below.';
    $('zpVerifyBtn').disabled = false; setMsg('zpVerifyMsg', '', '');
    clearInterval(st.leftT); tickLeft(); st.leftT = setInterval(tickLeft, 1000);
  }
  function hideIntent() {
    st.intent = null; persistIntent(); clearInterval(st.leftT);
    var box = $('zpPayBox'); if (box) box.style.display = 'none';
    if ($('zpTx')) $('zpTx').value = '';
  }

  // ── Verify ──────────────────────────────────────────────────────
  function stopPoll() { clearTimeout(st.pollT); st.pollT = null; }
  function verify(auto) {
    if (!st.intent) return;
    var tx = ($('zpTx').value || '').trim();
    if (!/^0x[0-9a-fA-F]{64}$/.test(tx)) { setMsg('zpVerifyMsg', 'Enter a valid transaction hash (0x + 64 characters).', 'err'); return; }
    var btn = $('zpVerifyBtn'); btn.disabled = true;
    if (!auto) { stopPoll(); st.pollN = 0; setMsg('zpVerifyMsg', 'Checking on-chain\u2026', ''); }
    call('/v1/pay/verify', { intent_id: st.intent.intent_id, tx_hash: tx }).then(function (r) {
      if (r.ok && r.data) { stopPoll(); paid(r.data); return; }
      if (r.error === 'PENDING_CONFIRMATIONS') {
        var d = r.data || {};
        st.pollN++;
        if (st.pollN > 40) { btn.disabled = false; setMsg('zpVerifyMsg', 'Still waiting for confirmations \u2014 press VERIFY again in a few minutes.', 'warn'); return; }
        setMsg('zpVerifyMsg', 'Waiting for confirmations ' + (d.confirmations || 0) + '/' + (d.needed || '?') + ' \u2014 checking again automatically\u2026', 'warn');
        st.pollT = setTimeout(function () { verify(true); }, 15000);
        return;
      }
      stopPoll(); btn.disabled = false; setMsg('zpVerifyMsg', errText(r), 'err');
    });
  }
  function paid(d) {
    var added = d.credits_added ? '+' + fmt(d.credits_added) + ' credits' + (d.bonus_credits ? ' (incl. ' + fmt(d.bonus_credits) + ' bonus)' : '') : 'Payment already credited';
    hideIntent();
    setMsg('zpIntentMsg', '\u2705 ' + added + '. New balance: ' + fmt(d.credits) + '. Thank you!', 'ok');
    refreshMe(); loadHistory();
  }

  // ── Redeem ──────────────────────────────────────────────────────
  function redeem() {
    var code = ($('zpCode').value || '').trim();
    if (!code) { setMsg('zpRedeemMsg', ERR.BAD_CODE, 'err'); return; }
    var btn = $('zpRedeemBtn'); btn.disabled = true; setMsg('zpRedeemMsg', 'Checking\u2026', '');
    call('/v1/redeem', { code: code }).then(function (r) {
      btn.disabled = false;
      if (r.ok && r.data) {
        $('zpCode').value = '';
        setMsg('zpRedeemMsg', '\u2705 +' + fmt(r.data.credits_added) + ' credits added. Balance: ' + fmt(r.data.credits), 'ok');
        refreshMe(); loadHistory();
      } else setMsg('zpRedeemMsg', errText(r), 'err');
    });
  }

  // ── History ─────────────────────────────────────────────────────
  function loadHistory() {
    return call('/v1/pay/history').then(function (r) {
      var box = $('zpHist'); if (!box) return;
      box.innerHTML = '';
      var list = (r.ok && r.data && r.data.payments) || [];
      if (!list.length) { var n = document.createElement('div'); n.className = 'act-note'; n.textContent = r.ok ? 'No payments yet.' : 'Could not load history.'; box.appendChild(n); return; }
      list.slice(0, 8).forEach(function (p) {
        var row = document.createElement('div'); row.className = 'zp-hist-row';
        var a = document.createElement('span'); a.textContent = '+' + fmt(p.credits) + ' \u00b7 ' + (p.coin || '') + ' ' + String(p.network || '').toUpperCase();
        var b = document.createElement('span'); b.textContent = new Date(p.verified_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' \u00b7 ' + String(p.tx_hash || '').slice(0, 8) + '\u2026';
        row.appendChild(a); row.appendChild(b); box.appendChild(row);
      });
    });
  }

  // ── Wiring ──────────────────────────────────────────────────────
  function onTabOpen() { refreshAccess(); refreshMe(); loadConfig(); loadHistory(); loadOffer(); }
  function bind() {
    if (st.bound || !$('tabPanelActive')) return; st.bound = true;
    $('zpIntentBtn').addEventListener('click', makeIntent);
    $('zpVerifyBtn').addEventListener('click', function () { verify(false); });
    $('zpRedeemBtn').addEventListener('click', redeem);
    $('zpCopyAmt').addEventListener('click', function () { var i = st.intent; if (i) copy(i.amount, $('zpCopyAmt')); });
    $('zpCopyWallet').addEventListener('click', function () { var i = st.intent; if (i) copy(i.wallet, $('zpCopyWallet')); });
    if ($('zpLowBuy')) $('zpLowBuy').addEventListener('click', goTab);
    if ($('zpCreditsBox')) $('zpCreditsBox').addEventListener('click', function (e) { e.stopPropagation(); goTab(); });
    document.querySelectorAll('.nav-tab[data-tabpanel="tabPanelActive"]').forEach(function (b) { b.addEventListener('click', onTabOpen); });
    try { chrome.storage.onChanged.addListener(function (ch, area) { if (area === 'local' && ch.zenDeviceSession) refreshAccess(); }); } catch (e) {}
    renderChips();
  }

  window.ZP = {
    refreshMe: refreshMe,
    onDashboard: function (session) {
      st.session = session; bind(); renderAccess(session);
      refreshMe(); loadConfig(); restoreIntent(); loadOffer();
      clearInterval(st.meT); st.meT = setInterval(function () { refreshMe(); loadOffer(); }, 60000);
    },
    clear: function () {
      clearInterval(st.meT); clearInterval(st.leftT); stopPoll();
      st.me = null; st.intent = null; st.locked = false; st.session = null;
      offerFetched = false; renderOffer(null);
      document.body.classList.remove('zp-locked');
      var b = $('zpPayBox'); if (b) b.style.display = 'none';
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();
