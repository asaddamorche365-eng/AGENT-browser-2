// ═══════════════════════════════════════════════════════════════
// devices.js — multi-device presence (background service worker only)
// Every logged-in browser (PC / Android) writes a heartbeat to
//   Worker profile devices.{deviceId} (/v1/profile) = { name, type, os, browser, model, since, lastSeen }
// The Admin Panel reads it and shows the devices on the user card.
// Needs zauth.js loaded first (zGetSession, zGetToken) and background.js (ZEXPAY_URL).
// ═══════════════════════════════════════════════════════════════
var ZDEV_ALARM = 'zDevBeat';
var ZDEV_ID_KEY = 'zDeviceId';
var ZDEV_PRUNE_MS = 7 * 24 * 3600 * 1000;   // forget devices not seen for 7 days
var _zDevBeats = 0;

function zDevRandId() {
  var a = crypto.getRandomValues(new Uint8Array(8));
  return 'd' + Array.prototype.map.call(a, function (b) { return b.toString(16).padStart(2, '0'); }).join('');
}

async function zDevGetId() {
  var d = await chrome.storage.local.get([ZDEV_ID_KEY]);
  if (d[ZDEV_ID_KEY]) return d[ZDEV_ID_KEY];
  var id = zDevRandId();
  await chrome.storage.local.set({ zDeviceId: id });
  return id;
}

async function zDevInfo() {
  var ua = navigator.userAgent || '';
  var type = 'pc', os = 'Unknown', browser = 'Browser', model = '';
  if (/Android/i.test(ua)) { type = 'android'; os = 'Android'; }
  else if (/iPhone|iPad|iPod/i.test(ua)) { type = 'ios'; os = 'iOS'; }
  else if (/Windows NT 10/.test(ua)) os = 'Windows 10/11';
  else if (/Windows/.test(ua)) os = 'Windows';
  else if (/Mac OS X/.test(ua)) os = 'macOS';
  else if (/CrOS/.test(ua)) os = 'ChromeOS';
  else if (/Linux/.test(ua)) os = 'Linux';

  if (/Edg\//.test(ua)) browser = 'Edge';
  else if (/OPR\/|Opera/.test(ua)) browser = 'Opera';
  else if (/Firefox\//.test(ua)) browser = 'Firefox';
  else if (/Brave/i.test(ua) || (navigator.brave)) browser = 'Brave';
  else if (/Chrome\//.test(ua)) browser = 'Chrome';
  else if (/Safari\//.test(ua)) browser = 'Safari';

  // Real phone model (Chrome hides it in the UA string, but client hints still give it)
  try {
    if (type === 'android' && navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
      var h = await navigator.userAgentData.getHighEntropyValues(['model']);
      if (h && h.model) model = String(h.model).slice(0, 40);
    }
  } catch (e) {}

  var name = type === 'android' ? ('Android' + (model ? ' · ' + model : '')) : (type === 'ios' ? 'iPhone/iPad' : 'PC · ' + os);
  return { name: name, type: type, os: os, browser: browser, model: model };
}

var ZDEV_EVERY_MS = 10 * 60 * 1000;   // S4b: profile lives in D1 (one JSON, <= 8000 chars) -> beat every 10 min, keep <= 8 devices
var ZDEV_MAX = 8;
async function zDevProfileCall(method, body) {
  var tok = await zGetToken(); if (!tok) return null;
  var res = await fetch(ZEXPAY_URL + '/v1/profile', { method: method, headers: { 'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  var j = {}; try { j = await res.json(); } catch (e) {}
  return (res.ok && j.ok !== false) ? j : null;
}
async function zDevWrite(mutate) {
  var p = await zDevProfileCall('GET'); if (!p) return false;
  var devs = (p.profile && p.profile.devices && typeof p.profile.devices === 'object') ? p.profile.devices : {};
  mutate(devs);
  var now = Date.now();
  Object.keys(devs).forEach(function (k) { if (!devs[k] || now - (devs[k].lastSeen || 0) > ZDEV_PRUNE_MS) delete devs[k]; });
  var ids = Object.keys(devs).sort(function (a, b) { return (devs[b].lastSeen || 0) - (devs[a].lastSeen || 0); });
  ids.slice(ZDEV_MAX).forEach(function (k) { delete devs[k]; });
  return !!(await zDevProfileCall('POST', { patch: { devices: devs } }));
}

// Send one heartbeat. Only when this browser really has a valid ZEX login. force = skip the 10-minute throttle (fresh login).
async function zDevBeat(force) {
  try {
    var st = await chrome.storage.local.get(['zenDeviceSession', 'zDevLastBeat']);
    var ses = st && st.zenDeviceSession;
    if (!ses || !(ses.expiresAt > Date.now())) return;
    if (!force && Date.now() - (st.zDevLastBeat || 0) < ZDEV_EVERY_MS - 30000) return;
    var auth = await zGetSession();
    if (!auth || !auth.email || auth.email !== ses.email) return;
    var id = await zDevGetId();
    var info = await zDevInfo();
    var now = Date.now();
    var ok = await zDevWrite(function (devs) {
      devs[id] = { name: info.name, type: info.type, os: info.os, browser: info.browser, model: info.model, since: ses.loginTime || now, lastSeen: now };
    });
    if (ok) await chrome.storage.local.set({ zDevLastBeat: now });
  } catch (e) { console.warn('zDevBeat', e); }
}

// Remove this device from the list (called right before sign-out)
async function zDevRemoveSelf() {
  try {
    var auth = await zGetSession(); if (!auth || !auth.email) return;
    var id = await zDevGetId();
    await zDevWrite(function (devs) { delete devs[id]; });
    await chrome.storage.local.remove(['zDevLastBeat']);
  } catch (e) {}
}

function zDevStart() {
  chrome.alarms.get(ZDEV_ALARM, function (a) { if (!a) chrome.alarms.create(ZDEV_ALARM, { periodInMinutes: 1 }); });
  zDevBeat(false);
}

chrome.alarms.onAlarm.addListener(function (a) { if (a && a.name === ZDEV_ALARM) zDevBeat(false); });
chrome.runtime.onStartup.addListener(zDevStart);
chrome.runtime.onInstalled.addListener(zDevStart);

// Beat immediately after a fresh login (zenDeviceSession appears)
chrome.storage.onChanged.addListener(function (ch, area) {
  if (area === 'local' && ch.zenDeviceSession && ch.zenDeviceSession.newValue) zDevBeat(true);
});

// popup asks us to remove this device on logout
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'zDevLogout') return;
  zDevRemoveSelf().then(function () { sendResponse({ ok: true }); });
  return true;
});

zDevStart();
