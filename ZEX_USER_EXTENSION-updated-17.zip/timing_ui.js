/* Z EX — Timing Hub (popup).
   One page that holds every engine's delay settings.
   CLASSIC  = the old per-engine timing controls (untouched).
   ADVANCED = FAST / SLOW / CUSTOM per engine group, set here. Old controls are hidden.
   Saves chrome.storage.local.zexTiming (what the user picked) and
   chrome.storage.local.zexTimingResolved (plain numbers the engines read). */
(function () {
  'use strict';
  var KEY = 'zexTiming', RES = 'zexTimingResolved';

  // ── Presets (seconds). SLOW ≈ 2–3x FAST, with breaks twice as often. ──
  var FAST = { steps: [1, 2], next: [5, 7], breakEvery: 50, breakLen: [30, 50] };
  var SLOW = { steps: [3, 5], next: [12, 18], breakEvery: 25, breakLen: [75, 125] };
  // FLASH LITE: Flash behaviour but ~15-20% slower and human-looking (smooth eased scroll, hover before every click, uneven typing).
  // LITE_POST = whole-post time for the comment engines (Flash did ~10.4s/post on the phone → 10.4 × 1.2 ≈ 12.5s ≈ 4.8 posts/min).
  var LITE = { steps: [0.3, 0.8], next: [0.8, 1.6], tgNext: [1, 2.5], post: 12.5 };
  var FLASH = { steps: [0.1, 0.3], next: [0.3, 0.8], tgNext: [0, 1], breakEvery: 0, breakLen: [0, 0] };   // everything at max speed, no breaks
  var GAP_P = { fast: [45, 90], slow: [120, 240] };                       // Follow + TAR account gap
  var UNF_P = { fast: { gap: [15, 20], every: 15, len: 120 }, slow: { gap: [35, 50], every: 10, len: 240 } };
  var TG_OVERHEAD = 10;   // sec per post spent outside the timed steps (page load, AI, typing) — Telegram only

  // Per-item time below `min` shows a warning; `sug` is the suggested time.
  var SAFE = {
    comment: { min: 15, sug: 30 }, tg: { min: 15, sug: 30 },
    follow: { min: 45, sug: 90 }, tar: { min: 45, sug: 90 }, unf: { min: 10, sug: 20 }
  };
  var G = {
    comment: { title: 'COMMENT ENGINES', sub: 'REP · FED · Search · GIV · TAR replies', unit: 'post', units: 'posts', brk: true },
    tg: { title: 'TELEGRAM', sub: 'Engage + Sweep', unit: 'post', units: 'posts', brk: true },
    follow: { title: 'FOLLOW ENGINE', sub: 'gap between follows', unit: 'follow', units: 'follows', brk: false },
    tar: { title: 'TAR ACCOUNT GAP', sub: 'wait between target accounts', unit: 'account', units: 'accounts', brk: false },
    unf: { title: 'AUTO UNFOLLOW', sub: 'gap + breaks', unit: 'unfollow', units: 'unfollows', brk: true }
  };
  var ORDER = ['comment', 'tg', 'follow', 'tar', 'unf'];

  function defG(per, n, totalSec, bE, bMin, bMax) {
    return { mode: 'fast', method: 'per', per: per, n: n, totalSec: totalSec, breakEvery: bE, bMin: bMin, bMax: bMax };
  }
  function defaults() {
    return {
      ui: 'classic',
      g: {
        comment: defG(40, 50, 1200, 50, 30, 50),
        tg: defG(40, 50, 1200, 50, 30, 50),
        follow: defG(90, 100, 9000, 0, 0, 0),
        tar: defG(90, 20, 1800, 0, 0, 0),
        unf: defG(20, 100, 2000, 15, 100, 140)
      }
    };
  }

  var cfg = defaults();
  var resolved = null;
  var readyRes;
  var ready = new Promise(function (r) { readyRes = r; });

  // ── helpers ──
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function r1(v) { return Math.round(v * 10) / 10; }
  function num(v, d) { v = Number(v); return isFinite(v) ? v : d; }
  function fmt(s) {
    if (s < 10) return r1(s) + 's';
    s = Math.round(s);
    if (s < 60) return s + 's';
    if (s < 3600) { var m = Math.floor(s / 60), x = s % 60; return m + 'm' + (x ? ' ' + x + 's' : ''); }
    var h = Math.floor(s / 3600), mm = Math.round((s % 3600) / 60);
    if (mm === 60) { h++; mm = 0; }
    return h + 'h' + (mm ? ' ' + mm + 'm' : '');
  }
  function rng(r) { return r[0] === r[1] ? fmt(r[0]) : fmt(r[0]) + '–' + fmt(r[1]); }
  function perItem(c) {
    if (c.method === 'total') return Math.max(1, c.totalSec / Math.max(1, c.n));
    return Math.max(1, c.per);
  }

  // ── resolve one group's picks into plain numbers the engines use ──
  function resolveGroup(gk, c) {
    var T = perItem(c), p, o;
    if (gk === 'comment' || gk === 'tg') {
      if (c.mode === 'flash') {
        p = FLASH;
        o = { view: p.steps.slice(), like: p.steps.slice(), gen: p.steps.slice(), post: p.steps.slice(),
          next: (gk === 'tg' ? p.tgNext : p.next).slice(), target: null, breakEvery: 0, breakLen: [0, 0], flash: true };
      } else if (c.mode === 'flashlite') {
        p = LITE;
        o = { view: p.steps.slice(), like: p.steps.slice(), gen: [0.2, 0.6], post: [0.2, 0.6],
          next: (gk === 'tg' ? p.tgNext : p.next).slice(), target: (gk === 'tg' ? null : p.post), breakEvery: 0, breakLen: [0, 0], flash: true, lite: true };
      } else if (c.mode === 'fast' || c.mode === 'slow') {
        p = c.mode === 'fast' ? FAST : SLOW;
        o = { view: p.steps.slice(), like: p.steps.slice(), gen: p.steps.slice(), post: p.steps.slice(),
          next: p.next.slice(), target: null, breakEvery: p.breakEvery, breakLen: p.breakLen.slice() };
      } else {
        var s = clamp(T * 0.06, 1, 20), st = [r1(s * 0.7), r1(s * 1.3)];
        o = { view: st.slice(), like: st.slice(), gen: st.slice(), post: st.slice(), target: T,
          breakEvery: Math.max(0, Math.floor(c.breakEvery)),
          breakLen: [Math.min(c.bMin, c.bMax), Math.max(c.bMin, c.bMax)] };
        if (gk === 'tg') {
          // Telegram has no stopwatch: spend what's left of the budget on the "before next post" gap.
          var left = Math.max(3, T - 4 * s - TG_OVERHEAD);
          o.next = [Math.max(1, Math.round(left * 0.85)), Math.max(2, Math.round(left * 1.15))];
          o.target = null;
        } else {
          o.next = [Math.max(2, Math.round(T * 0.5)), Math.max(2, Math.round(T))];
        }
      }
      return o;
    }
    if (gk === 'follow' || gk === 'tar') {
      var g;
      if (c.mode === 'custom') g = [clamp(T * 0.7, 5, 7200), clamp(T * 1.3, 5, 7200)];
      else g = GAP_P[c.mode].slice();
      return { gap: [Math.round(g[0]), Math.round(g[1])], minMs: Math.round(g[0]) * 1000, maxMs: Math.round(g[1]) * 1000 };
    }
    // unfollow
    if (c.mode === 'custom') {
      return { minSec: Math.max(1, Math.round(T * 0.8)), maxSec: Math.max(1, Math.round(T * 1.2)),
        breakEvery: Math.max(0, Math.floor(c.breakEvery)), breakSec: Math.round((Math.min(c.bMin, c.bMax) + Math.max(c.bMin, c.bMax)) / 2) };
    }
    p = UNF_P[c.mode];
    return { minSec: p.gap[0], maxSec: p.gap[1], breakEvery: p.every, breakSec: p.len };
  }
  function resolveAll() {
    var out = { ui: cfg.ui, ts: Date.now() };
    ORDER.forEach(function (k) { out[k] = resolveGroup(k, cfg.g[k]); });
    return out;
  }

  // ── warning (only in CUSTOM) ──
  function warnFor(gk) {
    var c = cfg.g[gk];
    if (c.mode === 'flash') return '⚡ FLASH — every step, scroll and wait runs at max speed, no breaks. Fastest possible, but X may flag or limit the account. Use it carefully.';
    if (c.mode === 'flashlite') return '⚡ FLASH LITE — Flash-style speed (about 15-20% slower), with human-like scroll, hover before clicks and uneven typing. No breaks. Safer than FLASH, still fast.';
    if (c.mode !== 'custom') return '';
    var T = perItem(c), s = SAFE[gk], u = G[gk].unit;
    if (T >= s.min) return '';
    var perHr = Math.floor(3600 / s.sug);
    var txt = '⚠️ Very fast — ' + fmt(T) + ' per ' + u + '. X may flag or limit the account. ' +
      'Suggested: ' + fmt(s.sug) + ' per ' + u + ' (≈ ' + perHr + '/hour)';
    if (c.method === 'total') txt += ' — about ' + fmt(s.sug * c.n) + ' for ' + c.n + ' ' + G[gk].units;
    return txt + '.';
  }
  function extraNote(gk) {
    var c = cfg.g[gk];
    if (gk === 'follow' && c.mode === 'custom' && c.method === 'total' && c.n > 50)
      return 'ℹ️ ' + c.n + ' follows in one run is a lot. Splitting it over several days is safer.';
    return '';
  }

  // ── human summary of what's active ──
  function summary(gk) {
    var r = resolved ? resolved[gk] : resolveGroup(gk, cfg.g[gk]), c = cfg.g[gk], L = [];
    if (gk === 'comment' || gk === 'tg') {
      if (gk === 'tg') L.push('After post opens ' + rng(r.view));
      L.push((gk === 'comment' ? 'Like → comment ' : 'After liking ') + rng(r.like));
      L.push('After reply is generated ' + rng(r.gen));
      L.push('After clicking Reply ' + rng(r.post));
      if (r.target) L.push('Whole post takes about ' + fmt(r.target));
      else L.push('Before next post ' + rng(r.next));
      L.push(r.breakEvery > 0 ? 'Break every ' + r.breakEvery + ' replies · ' + rng(r.breakLen) : 'No breaks');
    } else if (gk === 'follow' || gk === 'tar') {
      L.push('Gap ' + rng(r.gap));
    } else {
      L.push('Gap ' + rng([r.minSec, r.maxSec]));
      L.push(r.breakEvery > 0 ? 'Break every ' + r.breakEvery + ' · ' + fmt(r.breakSec) : 'No breaks');
    }
    if (c.mode === 'flashlite') L.unshift('⚡ Flash Lite · human feel · about 15-20% slower than Flash');
    if (c.mode === 'custom') {
      var T = perItem(c);
      L.unshift('≈ ' + fmt(T) + ' per ' + G[gk].unit + ' · ≈ ' + (T >= 36 ? r1(3600 / T) : Math.round(3600 / T)) + '/hour');
    }
    return L.join('  ·  ');
  }

  // ── persistence ──
  var saveT = null;
  function save(now) {
    resolved = resolveAll();
    clearTimeout(saveT);
    var go = function () { try { var o = {}; o[KEY] = cfg; o[RES] = resolved; chrome.storage.local.set(o); } catch (e) {} };
    if (now) go(); else saveT = setTimeout(go, 250);
    document.body.classList.toggle('zex-adv', cfg.ui === 'advanced');
    updateNotes();
  }
  function merge(saved) {
    var d = defaults();
    if (saved && typeof saved === 'object') {
      if (saved.ui === 'advanced') d.ui = 'advanced';
      ORDER.forEach(function (k) {
        var s = saved.g && saved.g[k]; if (!s) return;
        var t = d.g[k];
        if (['fast', 'slow', 'custom'].indexOf(s.mode) >= 0 || ((s.mode === 'flash' || s.mode === 'flashlite') && (k === 'comment' || k === 'tg'))) t.mode = s.mode;
        if (s.mode === 'flashc' && (k === 'comment' || k === 'tg')) t.mode = 'flashlite';   // Flash Custom was removed → Flash Lite
        if (s.method === 'total') t.method = 'total';
        ['per', 'n', 'totalSec', 'breakEvery', 'bMin', 'bMax'].forEach(function (f) { t[f] = Math.max(f === 'per' || f === 'n' ? 1 : 0, num(s[f], t[f])); });
      });
    }
    return d;
  }

  // ── UI ──
  var css = [
    '.zt-adv-only{display:none}',
    'body.zex-adv .zt-adv-only{display:block}',
    'body.zex-adv .zt-classic{display:none!important}',
    '.zt-seg{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}',
    '.zt-seg button{flex:1 1 22%;padding:9px 4px;border:1px solid var(--border);background:var(--dark2);color:var(--text);font-size:12px;font-weight:700;cursor:pointer}',
    '.zt-seg button.on{background:var(--blue);border-color:#17181a;color:#17181a}',
    '.zt-card{background:rgba(255,255,255,0.88);border:1px solid var(--border);padding:12px 14px;margin-bottom:12px}',
    '.zt-title{font-size:13px;font-weight:800;color:var(--text)}',
    '.zt-sub{font-size:11px;color:var(--dim);margin-top:1px}',
    '.zt-sum{font-size:11px;color:var(--dim);line-height:1.6;margin-top:6px;word-break:break-word}',
    '.zt-row{display:flex;align-items:center;gap:6px;margin-top:8px;flex-wrap:wrap}',
    '.zt-row label{font-size:11px;color:var(--dim);flex:1 1 90px}',
    '.zt-in{flex:none;width:54px;text-align:center;padding:7px 2px;background:#f7f7f5;border:1px solid var(--border);color:#17181a;font-size:12px;font-weight:600;outline:none}',
    '.zt-u{font-size:11px;color:var(--dim)}',
    '.zt-warn{display:none;margin-top:10px;padding:8px 10px;background:#fff7ed;border:1px solid #fed7aa;color:#c2410c;font-size:11px;line-height:1.5}',
    '.zt-info{display:none;margin-top:8px;padding:8px 10px;background:#f7f7f5;border:1px solid var(--border);color:var(--dim);font-size:11px;line-height:1.5}',
    '.zt-note{margin:8px 0;padding:9px 11px;background:#fffbeb;border:1px solid #fde68a;color:#92400e;font-size:11px;line-height:1.5;cursor:pointer}',
    '.zt-note b{color:#17181a}'
  ].join('\n');

  function el(html) { var d = document.createElement('div'); d.innerHTML = html; return d.firstElementChild; }
  function inp(f, v, extra) { return '<input type="number" class="zt-in" data-f="' + f + '" min="0" step="1" value="' + v + '"' + (extra || '') + '>'; }

  function groupHtml(gk) {
    var c = cfg.g[gk], g = G[gk], h = '';
    h += '<div class="zt-card" data-g="' + gk + '"><div class="zt-title">' + g.title + '</div><div class="zt-sub">' + g.sub + '</div>';
    h += '<div class="zt-seg">';
    (gk === 'comment' || gk === 'tg' ? ['flash', 'flashlite', 'fast', 'slow', 'custom'] : ['fast', 'slow', 'custom']).forEach(function (m) {
      h += '<button data-act="mode" data-v="' + m + '" class="' + (c.mode === m ? 'on' : '') + '">' + (m === 'flashlite' ? '⚡ FLASH LITE' : (m === 'flash' ? '⚡ ' : '') + m.toUpperCase()) + '</button>';
    });
    h += '</div><div class="zt-sum" data-sum></div>';
    if (c.mode === 'custom') {
      h += '<div class="zt-seg"><button data-act="method" data-v="per" class="' + (c.method === 'per' ? 'on' : '') + '">Per ' + g.unit + '</button>' +
        '<button data-act="method" data-v="total" class="' + (c.method === 'total' ? 'on' : '') + '">Total time</button></div>';
      if (c.method === 'per') {
        h += '<div class="zt-row"><label>Time per ' + g.unit + '</label>' + inp('perM', Math.floor(c.per / 60)) + '<span class="zt-u">m</span>' + inp('perS', c.per % 60) + '<span class="zt-u">s</span></div>';
      } else {
        h += '<div class="zt-row"><label>' + g.units.charAt(0).toUpperCase() + g.units.slice(1) + '</label>' + inp('n', c.n) + '</div>';
        h += '<div class="zt-row"><label>Finish in</label>' + inp('totH', Math.floor(c.totalSec / 3600)) + '<span class="zt-u">h</span>' + inp('totM', Math.round((c.totalSec % 3600) / 60)) + '<span class="zt-u">m</span></div>';
      }
      if (g.brk) {
        h += '<div class="zt-row"><label>Break every</label>' + inp('breakEvery', c.breakEvery) + '<span class="zt-u">' + g.units + ' (0 = none)</span></div>';
        h += '<div class="zt-row"><label>Break length</label>' + inp('bMin', c.bMin) + '<span class="zt-u">–</span>' + inp('bMax', c.bMax) + '<span class="zt-u">s</span></div>';
      }
    }
    h += '<div class="zt-warn" data-warn></div><div class="zt-info" data-info></div></div>';
    return h;
  }

  var host = null;
  function render() {
    if (!host) return;
    var h = '<button class="activity-back-btn" id="ztBackBtn">‹ Back</button>';
    h += '<div class="sec-label">Timing</div>';
    h += '<div class="zt-card"><div class="zt-title">TIMING SYSTEM</div>';
    h += '<div class="zt-seg"><button data-act="ui" data-v="classic" class="' + (cfg.ui === 'classic' ? 'on' : '') + '">CLASSIC</button>' +
      '<button data-act="ui" data-v="advanced" class="' + (cfg.ui === 'advanced' ? 'on' : '') + '">ADVANCED</button></div>';
    h += '<div class="zt-sub">' + (cfg.ui === 'classic'
      ? 'Classic: every engine keeps its own timing controls, same as before.'
      : 'Advanced: all engine timing lives on this page. The old per-engine controls are hidden.') + '</div></div>';
    if (cfg.ui === 'advanced') ORDER.forEach(function (k) { h += groupHtml(k); });
    host.innerHTML = h;
    ORDER.forEach(refreshGroup);
  }
  function refreshGroup(gk) {
    var card = host && host.querySelector('.zt-card[data-g="' + gk + '"]'); if (!card) return;
    card.querySelector('[data-sum]').textContent = summary(gk);
    var w = card.querySelector('[data-warn]'), t = warnFor(gk);
    w.textContent = t; w.style.display = t ? 'block' : 'none';
    var i = card.querySelector('[data-info]'), n = extraNote(gk);
    i.textContent = n; i.style.display = n ? 'block' : 'none';
  }

  function onClick(e) {
    var b = e.target.closest('[data-act]'); if (!b) return;
    var act = b.dataset.act, v = b.dataset.v;
    if (act === 'ui') { cfg.ui = v; save(true); render(); return; }
    var card = b.closest('.zt-card[data-g]'); if (!card) return;
    var c = cfg.g[card.dataset.g];
    if (act === 'mode') c.mode = v;
    if (act === 'method') c.method = v;
    save(true); render();
  }
  function onInput(e) {
    var i = e.target; if (!i.classList.contains('zt-in')) return;
    var card = i.closest('.zt-card[data-g]'); if (!card) return;
    var gk = card.dataset.g, c = cfg.g[gk];
    var q = function (f) { var x = card.querySelector('[data-f="' + f + '"]'); var n = x ? parseInt(x.value, 10) : 0; return isFinite(n) && n >= 0 ? n : 0; };
    var f = i.dataset.f;
    if (f === 'perM' || f === 'perS') c.per = Math.max(1, q('perM') * 60 + q('perS'));
    else if (f === 'n') c.n = Math.max(1, q('n'));
    else if (f === 'totH' || f === 'totM') c.totalSec = Math.max(60, q('totH') * 3600 + q('totM') * 60);
    else if (f === 'breakEvery') c.breakEvery = q('breakEvery');
    else if (f === 'bMin') c.bMin = q('bMin');
    else if (f === 'bMax') c.bMax = q('bMax');
    save(false); refreshGroup(gk);
  }

  // ── notes shown on each engine page in Advanced mode (old controls hidden) ──
  var notes = [];
  function tagAll(list) { list.forEach(function (x) { if (x) x.classList.add('zt-classic'); }); }
  function addNote(before, gk) {
    if (!before || !before.parentNode) return;
    var n = el('<div class="zt-note zt-adv-only" data-ng="' + gk + '"></div>');
    n.addEventListener('click', openHub);
    before.parentNode.insertBefore(n, before);
    notes.push(n);
  }
  function updateNotes() {
    notes.forEach(function (n) {
      var gk = n.dataset.ng, c = cfg.g[gk];
      n.innerHTML = '⏱ <b>Timing: ' + (c.mode === 'flashlite' ? 'FLASH LITE' : c.mode.toUpperCase()) + '</b> — set in the Timing page. Tap to open ›';
    });
  }
  function q1(s, root) { return (root || document).querySelector(s); }
  function qa(s, root) { return Array.prototype.slice.call((root || document).querySelectorAll(s)); }
  function wireClassicControls() {
    // Comment engines: Reply Speed blocks + "comment after like" boxes
    ['rep', 'feed', 'search', 'giv'].forEach(function (k) {
      var lab = document.getElementById(k + 'SpeedSectionLabel'), box = document.getElementById(k + 'SpeedSection');
      tagAll([lab, box]); addNote(lab, 'comment');
    });
    qa('.zexLikeDelayInput').forEach(function (i) { var b = i.closest('.big-reply-box'); if (b) b.classList.add('zt-classic'); });
    // Follow + TAR gaps
    ['follow', 'tar'].forEach(function (k) {
      var lab = document.getElementById(k + 'SpeedSectionLabel'), box = document.getElementById(k + 'SpeedSection');
      tagAll([lab, box]); addNote(lab, k);
    });
    // Unfollow gap / break rows
    var u = ['unfMinSec', 'unfBreakEvery', 'unfBreakSec'].map(function (id) { var e = document.getElementById(id); return e && e.closest('.switch-row'); });
    tagAll(u); addNote(u[0], 'unf');
    // Telegram Engage + Sweep timing / break
    ['activityTgEngageSection', 'activityTgSweepSection'].forEach(function (id) {
      var sec = document.getElementById(id); if (!sec) return;
      var rows = [];
      qa('.tgTimingInput, .tgNextInput, .tgBreakInput', sec).forEach(function (x) { var r = x.closest('.switch-row'); if (r && rows.indexOf(r) < 0) rows.push(r); });
      var labs = qa('.sec-label', sec).filter(function (l) { return /^(Timing|Break)/.test(l.textContent.trim()); });
      var hints = qa('.keyword-hint', sec).filter(function (h) { return /Same timing as Telegram Engage|Keep the Telegram and X tabs/.test(h.textContent); });
      tagAll(rows); tagAll(labs); tagAll(hints);
      if (labs[0]) addNote(labs[0], 'tg');
    });
    // Sweep "Link Delay" block
    var dm = document.getElementById('tgSweepDelayMin');
    if (dm) {
      var box = dm.closest('.big-reply-box');
      if (box) {
        var hint = box.previousElementSibling, lab = hint && hint.previousElementSibling;
        tagAll([box, hint, lab, document.getElementById('tgSweepDelaySave'), document.getElementById('tgSweepDelayStatus')]);
      }
    }
    updateNotes();
  }

  function openHub() {
    var landing = document.getElementById('activityLanding');
    qa('.activity-section').forEach(function (s) { s.style.display = 'none'; });
    if (landing) landing.style.display = 'none';
    host.style.display = 'block';
    render();
    var body = q1('.dash-body'); if (body) body.scrollTop = 0;
    // the Activity tab may be hidden if we were sent here from another tab's note — nothing else to do
  }
  function closeHub() { host.style.display = 'none'; if (typeof window.showActivityLanding === 'function') window.showActivityLanding(); }

  function build() {
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    var landing = document.getElementById('activityLanding');
    var anchor = document.getElementById('chooseUnfollowAgentBtn');
    var list = anchor && anchor.parentNode;
    host = el('<div class="activity-section" id="activityTimingSection" style="display:none;"></div>');
    var sibling = document.getElementById('activityTgSweepSection');
    if (sibling && sibling.parentNode) sibling.parentNode.insertBefore(host, sibling.nextSibling);
    else if (landing && landing.parentNode) landing.parentNode.appendChild(host);
    host.addEventListener('click', onClick);
    host.addEventListener('input', onInput);
    host.addEventListener('click', function (e) { if (e.target.id === 'ztBackBtn') closeHub(); });
    if (list) {
      var card = el('<div class="agent-choice-card" id="chooseTimingAgentBtn">' +
        '<div class="agent-choice-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2"/><path d="M9 2h6"/></svg></div>' +
        '<div class="agent-choice-text"><div class="agent-choice-title">Timing</div><div class="agent-choice-desc">Speed &amp; delays for every engine, in one place</div></div>' +
        '<div class="agent-choice-arrow">›</div></div>');
      card.addEventListener('click', openHub);
      list.insertBefore(card, list.firstChild);
    }
    // Other code shows/hides the Activity sections by id — make sure the Timing page hides too.
    ['showActivityLanding', 'showActivitySection'].forEach(function (fn) {
      var orig = window[fn]; if (typeof orig !== 'function') return;
      window[fn] = function () { if (host) host.style.display = 'none'; return orig.apply(this, arguments); };
    });
    wireClassicControls();
  }

  function init() {
    build();
    chrome.storage.local.get([KEY], function (d) {
      cfg = merge(d[KEY]); resolved = resolveAll();
      document.body.classList.toggle('zex-adv', cfg.ui === 'advanced');
      updateNotes();
      try { var o = {}; o[RES] = resolved; chrome.storage.local.set(o); } catch (e) {}
      readyRes();
    });
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== 'local' || !ch[KEY]) return;
      var nv = merge(ch[KEY].newValue);
      if (JSON.stringify(nv) === JSON.stringify(cfg)) return;
      cfg = nv; resolved = resolveAll();
      document.body.classList.toggle('zex-adv', cfg.ui === 'advanced'); updateNotes();
      if (host && host.style.display !== 'none') render();
    });
  }

  // ── API for popup.js (Follow / TAR / Unfollow read their gaps at Start) ──
  window.ZexTiming = {
    ready: ready,
    isAdvanced: function () { return cfg.ui === 'advanced'; },
    gap: function (k) {          // → { minMs, maxMs } in Advanced, else null (Classic keeps its own)
      return ready.then(function () {
        if (cfg.ui !== 'advanced') return null;
        var r = resolved && resolved[k]; return r ? { minMs: r.minMs, maxMs: r.maxMs } : null;
      });
    },
    // Behaviour profiles: switch every group to the given presets at once (writes zexTiming + zexTimingResolved)
    applyProfile: function (t) {
      return ready.then(function () {
        cfg = merge(t); save(true);
        if (host && host.style.display !== 'none') render();
      });
    },
    unfCfg: function (base) {    // → base with the Advanced gap/break values laid over it
      if (cfg.ui !== 'advanced' || !resolved) return base;
      return Object.assign({}, base, resolved.unf);
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
