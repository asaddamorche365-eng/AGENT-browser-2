// Z EX — single closed Shadow DOM host for all floating UI (cursor, avatar,
// dashboard, toast, panels, unfollow widget). Loaded first in every content-script
// group; the guard makes a second load a no-op. Page scripts cannot reach inside
// a closed root, and the host is one node with a random id (no fixed zen-/zex- names
// on it). Elements inside are still used by reference, so existing code keeps working;
// only document-level lookups were switched to ZexShadow.$ / $$.
(function () {
  if (window.ZexShadow) return;
  let host = null, root = null;
  function ensure() {
    if (!host) {
      host = document.createElement('div');
      host.id = 'x' + Math.random().toString(36).slice(2, 10);
      host.style.cssText = 'display:contents;';
      root = host.attachShadow({ mode: 'closed' });
      try {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = chrome.runtime.getURL('style.css');
        root.appendChild(link);
      } catch (e) {}
    }
    if (!host.isConnected) (document.documentElement || document).appendChild(host);
    return root;
  }
  window.ZexShadow = {
    mount(el) { ensure().appendChild(el); return el; },
    $(sel) { return root ? root.querySelector(sel) : null; },
    $$(sel) { return root ? Array.from(root.querySelectorAll(sel)) : []; },
  };
})();
