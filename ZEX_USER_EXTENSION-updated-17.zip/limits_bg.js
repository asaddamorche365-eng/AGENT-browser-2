// ══════════════════════════════════════════════════════════════
//  AUTO-STOP LIMITS (background side)
//  One shared system for every engine. The user sets "stop after N"
//  for each action type; this file counts the actions and stops the
//  right engine(s) the moment the number is reached.
//
//  Storage:
//    zenLimits     = { comment:{on,max}, follow:{on,max}, unfollow:{on,max}, tgSweep:{on,max} }
//    zenLimitCount = { comment:n, follow:n, tgSweep:n }   (unfollow is counted by unfollow.js itself)
//    zenLimitHit   = { kind, max, ts }                    (last time a limit stopped something)
//
//  Who reports what:
//    comment  → content.js zenAgentRecord()  (REP / FED / SEA / GIV / TAR replies)  → message 'zenLimitTick'
//    follow   → followEngine result handler  (only real new follows, not "already following")
//    tgSweep  → Telegram Sweep result handler (only links actually engaged, not skipped)
//    unfollow → unfStart() hands the limit to unfollow.js as its own "Target"
//
//  When a limit is hit the counter goes back to 0, so the next Start
//  begins a fresh batch of N.
// ══════════════════════════════════════════════════════════════

var ZLIM_DEFAULT = {
  comment:  { on: false, max: 50 },
  follow:   { on: false, max: 20 },
  unfollow: { on: false, max: 50 },
  tgSweep:  { on: false, max: 30 },
};
var ZLIM_LABEL = { comment: 'Comment', follow: 'Follow', unfollow: 'Unfollow', tgSweep: 'TG Sweep' };
var ZLIM_MAX_ALLOWED = 5000;

// All reads/writes of the counters go through one promise chain so two
// replies finishing at the same moment (different tabs) can't overwrite each other.
var _zlimChain = Promise.resolve();
function _zlimQueue(fn) {
  var run = _zlimChain.then(fn, fn);
  _zlimChain = run.catch(function () {});
  return run;
}

function zlimNormalize(raw) {
  var out = {};
  Object.keys(ZLIM_DEFAULT).forEach(function (k) {
    var r = (raw && raw[k]) || {};
    var m = Math.floor(Number(r.max));
    if (!isFinite(m) || m < 1) m = ZLIM_DEFAULT[k].max;
    out[k] = { on: r.on === true, max: Math.min(ZLIM_MAX_ALLOWED, m) };
  });
  return out;
}

async function zlimGetCfg() {
  var d = await chrome.storage.local.get(['zenLimits']);
  return zlimNormalize(d.zenLimits);
}

// Adds n to a counter. Returns { counted, count, max, tripped }.
function zlimTick(kind, n) {
  n = n || 1;
  return _zlimQueue(async function () {
    var cfg = await zlimGetCfg();
    if (!cfg[kind] || !cfg[kind].on) return { counted: false, tripped: false };
    var d = await chrome.storage.local.get(['zenLimitCount']);
    var cnt = Object.assign({ comment: 0, follow: 0, tgSweep: 0 }, d.zenLimitCount || {});
    cnt[kind] = (cnt[kind] || 0) + n;
    var max = cfg[kind].max;
    if (cnt[kind] >= max) {
      cnt[kind] = 0;                                   // next Start = fresh batch
      await chrome.storage.local.set({ zenLimitCount: cnt, zenLimitHit: { kind: kind, max: max, ts: Date.now() } });
      await zlimStop(kind, max);
      return { counted: true, count: max, max: max, tripped: true };
    }
    await chrome.storage.local.set({ zenLimitCount: cnt });
    return { counted: true, count: cnt[kind], max: max, tripped: false };
  });
}

function zlimReset(kind) {
  return _zlimQueue(async function () {
    var d = await chrome.storage.local.get(['zenLimitCount']);
    var cnt = Object.assign({ comment: 0, follow: 0, tgSweep: 0 }, d.zenLimitCount || {});
    if (kind) cnt[kind] = 0; else cnt = { comment: 0, follow: 0, tgSweep: 0 };
    await chrome.storage.local.set({ zenLimitCount: cnt });
  });
}

// Stops whatever belongs to this action type.
async function zlimStop(kind, max) {
  try {
    if (kind === 'comment') {
      // Same keys the in-page STOP buttons use, so the popup toggles flip to OFF too.
      await chrome.storage.local.set({
        zenSearchEngineOn: false, zenSearchAutoMode: false,
        zenFeedEngineOn: false,   zenFeedAutoMode: false,
        zenRepEngineOn: false,    zenAutoRepMode: false,
        zenGivEngineOn: false,    zenGivAutoMode: false,
      });
      try { await tarEngineStop(); } catch (e) {}
    } else if (kind === 'follow') {
      await followEngineStop();
    } else if (kind === 'tgSweep') {
      await stopSessionAutoMode(ZEN_TG_SWEEP_PATH);
    }
  } catch (e) { console.warn('zlimStop failed', kind, e); }
  try { await bgNotify('⏹ Limit reached', ZLIM_LABEL[kind] + ' limit (' + max + ') reached — the engine has stopped.'); } catch (e) {}
}

// A comment engine just switched on while no other comment engine was running →
// that is a new run, so start counting from 0 again.
chrome.storage.onChanged.addListener(function (ch, area) {
  if (area !== 'local') return;
  var keys = ['zenSearchEngineOn', 'zenFeedEngineOn', 'zenRepEngineOn', 'zenGivEngineOn'];
  var turnedOn = keys.some(function (k) { return ch[k] && ch[k].newValue === true && ch[k].oldValue !== true; });
  if (!turnedOn) return;
  chrome.storage.local.get(keys, function (d) {
    var onCount = keys.filter(function (k) { return d && d[k] === true; }).length;
    if (onCount === 1) zlimReset('comment');
  });
});

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return;
  if (sender && sender.id && sender.id !== chrome.runtime.id) return;
  if (msg.type === 'zenLimitTick' && msg.kind === 'comment') {
    zlimTick('comment', 1).then(function (r) { sendResponse(r); }, function () { sendResponse({}); });
    return true;
  }
  if (msg.type === 'zenLimitReset') {
    zlimReset(msg.kind || null).then(function () { sendResponse({ ok: true }); });
    return true;
  }
});
