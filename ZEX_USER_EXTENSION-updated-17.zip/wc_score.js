/* Z EX — Wallchain score reader (x.com content script).
   Reads the small score badge that the Wallchain extension puts next to a name on X.
   Saves handle → score in chrome.storage.local.zexWcScores so every engine, History and
   the workflow map can show "@name · WC 123". No badge on the page = nothing saved.
   window.zexWcScore(handleOrArticle) → number | null   ·   window.zexWcDebug() → logs the header DOM of the first post. */
(function () {
  'use strict';
  if (window.__zexWc) return; window.__zexWc = true;
  var KEY = 'zexWcScores', MAX = 600;
  var byHandle = {}, bySid = {}, dirty = false;

  function parseNum(t) {
    t = String(t || '').trim().replace(/[\s,]/g, '');
    var m = /^([0-9]+(?:\.[0-9]+)?)([KkMm])?$/.exec(t);
    if (!m) return null;
    var v = parseFloat(m[1]); if (!isFinite(v)) return null;
    if (m[2]) v *= /[Kk]/.test(m[2]) ? 1000 : 1000000;
    return Math.round(v);
  }
  function leaves(root) {
    var out = [];
    (function walk(n) {
      var kids = n.children ? Array.prototype.slice.call(n.children) : [];
      if (n.shadowRoot) kids.push.apply(kids, Array.prototype.slice.call(n.shadowRoot.children));
      if (kids.length) kids.forEach(walk); else out.push(n);
    })(root);
    return out;
  }
  function hinted(el) {      // class / id / title / testid of the element or 4 parents mentions wallchain
    for (var i = 0, e = el; e && i < 4; i++, e = e.parentElement) {
      var s = [typeof e.className === 'string' ? e.className : '', e.id || '', e.getAttribute && e.getAttribute('title') || '',
        e.getAttribute && e.getAttribute('data-testid') || '', e.getAttribute && e.getAttribute('aria-label') || ''].join(' ').toLowerCase();
      if (/wallchain|wc-score|xscore|wc_score/.test(s)) return true;
    }
    return false;
  }
  // The name row of a post: [data-testid="User-Name"] and the row that holds it (the badge may sit beside it, not inside).
  function headerOf(article) {
    var u = article.querySelector('[data-testid="User-Name"]'); if (!u) return null;
    return { user: u, row: (u.parentElement && u.parentElement.parentElement) || u.parentElement || u };
  }
  function handleOf(article) {
    var u = article.querySelector('[data-testid="User-Name"]'); if (!u) return null;
    var as = u.querySelectorAll('a[href^="/"]');
    for (var i = 0; i < as.length; i++) { var m = (as[i].getAttribute('href') || '').match(/^\/([A-Za-z0-9_]+)$/); if (m) return m[1].toLowerCase(); }
    return null;
  }
  function sidOf(article) {
    var a = article.querySelector('a[href*="/status/"]'); if (!a) return null;
    var m = (a.getAttribute('href') || '').match(/\/status\/(\d+)/); return m ? m[1] : null;
  }
  // Score for one post: 1) an element that is clearly Wallchain's  2) a lone number in the name row that is not a link/button/time.
  function readArticle(article) {
    var h = headerOf(article); if (!h) return null;
    var cand = leaves(h.row).filter(function (e) {
      if (e.closest && e.closest('a, [role="button"], time, [data-testid="caret"], [data-testid="User-Name"] a')) return hinted(e);
      return true;
    });
    // Real X: the badge sits on the same line as the @handle. Keep only numbers on that line (drops tweet-body numbers).
    var hEl = null;
    leaves(h.user).forEach(function (l) { if (!hEl && /^@[A-Za-z0-9_]{1,15}$/.test((l.textContent || '').trim())) hEl = l; });
    var hr = hEl && hEl.getBoundingClientRect();
    var nums = [];
    cand.forEach(function (e) {
      var n = parseNum(e.textContent); if (n === null) return;
      if (hr && hr.height > 0) { var r = e.getBoundingClientRect(); if (Math.abs((r.top + r.height / 2) - (hr.top + hr.height / 2)) > 14) return; }
      nums.push({ e: e, n: n });
    });
    for (var i = 0; i < nums.length; i++) if (hinted(nums[i].e)) return nums[i].n;
    return nums.length === 1 ? nums[0].n : null;   // more than one loose number = unsure, say nothing
  }

  function scan() {
    var arts = document.querySelectorAll('article[data-testid="tweet"]');
    for (var i = 0; i < arts.length; i++) {
      var a = arts[i], sc = readArticle(a); if (sc === null) continue;
      var hd = handleOf(a), sid = sidOf(a);
      if (hd && byHandle[hd] !== sc) { byHandle[hd] = sc; dirty = true; }
      if (sid && bySid[sid] !== sc) { bySid[sid] = sc; dirty = true; }
    }
    // Profile pages (TAR): the badge next to the profile name
    try {
      var m = location.pathname.match(/^\/([A-Za-z0-9_]+)\/?$/), pn = document.querySelector('[data-testid="UserName"]');
      if (m && pn) {
        var row = pn.parentElement || pn, v = null, ls = leaves(row);
        for (var j = 0; j < ls.length; j++) { if (ls[j].closest('a, [role="button"]') && !hinted(ls[j])) continue; var n = parseNum(ls[j].textContent); if (n !== null && (hinted(ls[j]) || v === null)) v = n; }
        if (v !== null && byHandle[m[1].toLowerCase()] !== v) { byHandle[m[1].toLowerCase()] = v; dirty = true; }
      }
    } catch (e) {}
  }
  function flush() {
    if (!dirty) return; dirty = false;
    try {
      chrome.storage.local.get([KEY], function (d) {
        var st = (d && d[KEY] && typeof d[KEY] === 'object') ? d[KEY] : {}, now = Date.now();
        Object.keys(byHandle).forEach(function (k) { st[k] = { s: byHandle[k], t: now }; });
        var ks = Object.keys(st);
        if (ks.length > MAX) ks.sort(function (a, b) { return (st[a].t || 0) - (st[b].t || 0); }).slice(0, ks.length - MAX).forEach(function (k) { delete st[k]; });
        var o = {}; o[KEY] = st; chrome.storage.local.set(o);
      });
    } catch (e) {}
  }

  var timer = null;
  function sched() { if (timer) return; timer = setTimeout(function () { timer = null; try { scan(); flush(); } catch (e) {} }, 1200); }
  try { new MutationObserver(sched).observe(document.documentElement, { childList: true, subtree: true }); } catch (e) {}
  sched();

  window.zexWcScore = function (x) {      // x = article element, @handle, or status id
    try {
      if (x && x.nodeType === 1) { var s = readArticle(x); return s; }
      var k = String(x || '').replace(/^@/, '').toLowerCase();
      if (/^\d{8,}$/.test(k) && bySid[k] != null) return bySid[k];
      return byHandle[k] != null ? byHandle[k] : null;
    } catch (e) { return null; }
  };
  window.zexWcDebug = function () {
    var a = document.querySelector('article[data-testid="tweet"]'), h = a && headerOf(a);
    console.log('[ZEX WC] first post score:', a ? readArticle(a) : 'no post');
    console.log('[ZEX WC] header HTML:', h ? h.row.outerHTML : 'no User-Name');
    return h ? h.row.outerHTML : null;
  };
  // ── Settings (saved by the popup as chrome.storage.local.zexWc) ──
  var DEF = {
    feedFollow:   { on: false, min: 100, max: 105, limit: 20, only: false },
    searchFollow: { on: false, min: 100, max: 105, limit: 20, only: false },
    feedEngage:   { on: false, min: 100, max: 105 },
    searchEngage: { on: false, min: 100, max: 105 },
    rep:          { on: false, min: 100, max: 105 },
    unf:          { on: false, min: 100, max: 105 },
    tgEngage:     { on: false, min: 100, max: 105 },
    tgSweep:      { on: false, min: 100, max: 105 },
    feedCollect:  { on: false, min: 100, max: 105 },
    searchCollect:{ on: false, min: 100, max: 105 }
  };
  var cfg = JSON.parse(JSON.stringify(DEF));
  function mergeCfg(sv) {
    var o = JSON.parse(JSON.stringify(DEF));
    if (sv && typeof sv === 'object') Object.keys(o).forEach(function (k) {
      if (sv[k] && typeof sv[k] === 'object') Object.keys(o[k]).forEach(function (f) { if (sv[k][f] !== undefined) o[k][f] = sv[k][f]; });
    });
    return o;
  }
  try {
    chrome.storage.local.get(['zexWc'], function (d) { cfg = mergeCfg(d && d.zexWc); });
    chrome.storage.onChanged.addListener(function (c, a) { if (a === 'local' && c.zexWc) cfg = mergeCfg(c.zexWc.newValue); });
  } catch (e) {}
  window.zexWcCfg = function () { return cfg; };
  window.zexWcIn = function (sc, c) {
    if (sc == null || !c) return false;
    var lo = Math.min(Number(c.min) || 0, Number(c.max) || 0), hi = Math.max(Number(c.min) || 0, Number(c.max) || 0);
    return sc >= lo && sc <= hi;
  };
  window.zexWcHandle = handleOf;

  // Score of one row in a Following / Followers list (UserCell): Wallchain-hinted number first,
  // else the leftmost number on the same line as the @username (same fallback the Z3 unfollow used).
  window.zexWcCell = function (cell) {
    try {
      var ls = leaves(cell), nameEl = null, nums = [];
      ls.forEach(function (l) { if (!nameEl && /^@[A-Za-z0-9_]{1,15}$/.test((l.textContent || '').trim())) nameEl = l; });
      ls.forEach(function (l) {
        if (l.closest && l.closest('[role="button"]')) return;
        var n = parseNum(l.textContent); if (n !== null) nums.push({ e: l, n: n });
      });
      for (var i = 0; i < nums.length; i++) if (hinted(nums[i].e)) return nums[i].n;
      if (!nameEl || !nums.length) return null;
      var nr = nameEl.getBoundingClientRect(), best = null, mid = nr.top + nr.height / 2;
      nums.forEach(function (x) {
        var r = x.e.getBoundingClientRect();
        if (Math.abs(r.top + r.height / 2 - mid) <= 18 && (!best || r.left < best.left)) best = { left: r.left, n: x.n };
      });
      return best ? best.n : null;
    } catch (e) { return null; }
  };
})();
