// Runs in the PAGE's own JS world (manifest "world":"MAIN") at document_start.
// While Z EX is automating (content script sets <html data-zex-auto>), X's "Leave site? Changes that you made
// may not be saved." beforeunload prompt is suppressed — otherwise it freezes a Sweep / engine run whenever a
// compose page still holds text at the moment the extension moves to the next link. Manual use is untouched.
(function () {
  if (window.__zexNoPrompt) return;
  window.__zexNoPrompt = 1;
  // First beforeunload listener on window → runs before X's own handlers; stopping the chain means no prompt.
  window.addEventListener('beforeunload', function (e) {
    try { if (document.documentElement && document.documentElement.hasAttribute('data-zex-auto')) e.stopImmediatePropagation(); } catch (x) {}
  }, true);
})();
