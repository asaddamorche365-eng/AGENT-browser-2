/* Z EX — shared link database.
   One entry per X post ID = "this post must not be engaged again", plus the reason.
   Storage: chrome.storage.local, one key per post: zl_<id> = [code, engine, ts]
     code  d = already engaged (reply posted) · b = commented before ZEX · o = comments off · x = post deleted / page doesn't exist
   No size limit (manifest has unlimitedStorage). Every engine (REP / FED / SEA / GIV / TAR / Telegram)
   reads the same in-memory index, so a lookup is instant: ID found -> skip (reason goes to History),
   not found -> the engine just works as normal. Loaded once per page, kept in sync through storage events. */
(function (g) {
  if (g.ZexDB) return;
  var P = 'zl_';
  var CODES = { d: 'done', b: 'before', o: 'off', x: 'deleted' };
  var map = new Map();
  var isPage = typeof window !== 'undefined';
  var ready = !isPage;

  function load() {
    return new Promise(function (res) {
      try {
        chrome.storage.local.get(null, function (d) {
          try {
            for (var k in d) {
              if (k.indexOf(P) === 0 && Array.isArray(d[k])) map.set(k.slice(P.length), d[k]);
            }
          } catch (e) {}
          ready = true; res();
        });
      } catch (e) { ready = true; res(); }
    });
  }

  var ZexDB = {
    ready: isPage ? load() : Promise.resolve(),
    isReady: function () { return ready; },
    size: function () { return map.size; },
    has: function (id) { return !!id && map.has(String(id)); },
    // -> { code:'d'|'b'|'o', reason:'done'|'before'|'off', eng, ts } or null (= no data found)
    get: function (id) {
      var v = id ? map.get(String(id)) : null;
      return v ? { code: v[0], reason: CODES[v[0]] || '', eng: v[1] || '', ts: v[2] || 0 } : null;
    },
    // First write wins (same rule as "first engine wins" in History).
    set: function (id, code, eng) {
      id = String(id || '');
      if (!id || !CODES[code] || map.has(id)) return;
      var v = [code, eng || '', Date.now()];
      map.set(id, v);
      try { var o = {}; o[P + id] = v; chrome.storage.local.set(o); } catch (e) {}
    },
    // One-time import of the old capped lists (replied IDs, Reply History, comment-off / commented-before log).
    migrate: async function () {
      try {
        var f = await chrome.storage.local.get(['zexDbMigV1']);
        if (f.zexDbMigV1) return;
        var d = await chrome.storage.local.get(['zenRepliedStatusIds', 'zenRepliedBy', 'zenReplyHistory', 'zenSkipLog']);
        var by = (d.zenRepliedBy && typeof d.zenRepliedBy === 'object') ? d.zenRepliedBy : {};
        var out = {};
        var sidOf = function (u) { var m = String(u || '').match(/\/status\/(\d+)/); return m ? m[1] : ''; };
        if (Array.isArray(d.zenRepliedStatusIds)) for (var i = 0; i < d.zenRepliedStatusIds.length; i++) {
          var id = String(d.zenRepliedStatusIds[i]); var b = by[id] || {};
          out[P + id] = ['d', b.eng || '', b.ts || 0];
        }
        if (Array.isArray(d.zenReplyHistory)) for (var j = 0; j < d.zenReplyHistory.length; j++) {
          var h = d.zenReplyHistory[j]; var hid = sidOf(h && h.link);
          if (hid && !out[P + hid]) out[P + hid] = ['d', '', (h && h.ts) || 0];
        }
        if (Array.isArray(d.zenSkipLog)) for (var k = 0; k < d.zenSkipLog.length; k++) {
          var x = d.zenSkipLog[k];
          if (!x || !x.sid) continue;
          if (x.reason === 'comment_off') out[P + x.sid] = ['o', x.cur || '', x.ts || 0];
          else if (x.reason === 'commented_before') out[P + x.sid] = ['b', x.cur || '', x.ts || 0];
        }
        out.zexDbMigV1 = Date.now();
        await chrome.storage.local.set(out);
      } catch (e) { console.warn('[Z EX] link DB migration failed', e); }
    },
  };

  if (isPage) {
    try {
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area !== 'local') return;
        for (var k in ch) {
          if (k.indexOf(P) !== 0) continue;
          var nv = ch[k].newValue;
          if (nv === undefined) map.delete(k.slice(P.length));
          else if (Array.isArray(nv)) map.set(k.slice(P.length), nv);
        }
      });
    } catch (e) {}
  }
  g.ZexDB = ZexDB;
})(typeof self !== 'undefined' ? self : this);
