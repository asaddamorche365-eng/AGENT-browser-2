/* Z EX — dark / light theme.
   Runs in <head> (before first paint) so the saved theme is applied with no flash.
   Preference is stored in localStorage under "zexTheme" ("dark" | "light").
   First run with nothing saved: Windows -> dark (previous behaviour), everything else -> light. */
(function () {
  var KEY = 'zexTheme';
  var root = document.documentElement;

  function read() {
    try { return localStorage.getItem(KEY); } catch (e) { return null; }
  }
  function write(v) {
    try { localStorage.setItem(KEY, v); } catch (e) {}
  }
  function isDark() { return root.classList.contains('zex-dark'); }

  function sync() {
    var btn = document.getElementById('themeToggleBtn');
    if (!btn) return;
    var dark = isDark();
    btn.setAttribute('aria-pressed', dark ? 'true' : 'false');
    btn.title = dark ? 'Switch to light mode' : 'Switch to dark mode';
  }

  var saved = read();
  var startDark = saved ? saved === 'dark' : /Windows/.test(navigator.userAgent);
  root.classList.toggle('zex-dark', startDark);

  // Event delegation: works no matter when the button is parsed.
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest || !t.closest('#themeToggleBtn')) return;
    var next = !isDark();
    root.classList.toggle('zex-dark', next);
    write(next ? 'dark' : 'light');
    sync();
  });

  document.addEventListener('DOMContentLoaded', sync);
})();
