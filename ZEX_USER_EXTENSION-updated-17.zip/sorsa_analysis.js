/* ══════════════════════════════════════════════════════════════════
   ZEX — X Account Analysis (Sorsa API) · Dashboard tab
   API key: controlled ONLY from the Admin Panel (synced via popup.js →
           chrome.storage 'sorsaApiKey'). No key box inside Zex.
   STEP 1: Sorsa client + Overview analysis
           (profile, account info, Sorsa score, follower quality)
   STEP 2: posts analysis (engagement, best posting time, top posts,
           reply/quote ratio), top followers / following, 7-day new
           followers / following — STEPS[], fetchPosts(), render() below.
   ══════════════════════════════════════════════════════════════════ */
;(function sorsaAnalysis(){
  'use strict';
  const $ = id => document.getElementById(id);
  if (!$('sxCard') || typeof chrome === 'undefined' || !chrome.storage) return;

  const BASE = 'https://api.sorsa.io/v3';
  const KEY_STORE = 'sorsaApiKey';
  const CACHE_STORE = 'sorsaAnalysisCache';
  const POST_PAGES = 5;            // /user-tweets pages per analysis (~20 posts each, 1 request per page)
  const OLD_LOCAL_USAGE = 'sorsaUsage';   // legacy local counter — removed on load; usage now lives in the Worker (D1)

  /* ── Daily limits (per user, per UTC day) — usage is counted on the SERVER, limits come from Admin Panel ──────────────────────
     Provider gives 100 free requests/day shared by 2 users -> max 50 per user.
       Full analysis   = 9 calls + 5 post pages = 14 requests, max 2/day  -> 28
       Separate system = per-section limits below                          -> 22
                                                                     TOTAL <= 50   */
  let DAILY_CAP  = 50;      // defaults — overridden by Firebase `sorsaLimits` (Admin Panel → API tab)
  let FULL_LIMIT = 2;
  const SECTIONS = [
    { id:'profile',      label:'Profile',          steps:['info','about'],                 limit:2 },  // 2 req x 2 = 4
    { id:'score',        label:'Sorsa Score',      steps:['score','scoreChanges'],         limit:2 },  // 2 req x 2 = 4
    { id:'quality',      label:'Follower Quality', steps:['followerStats'],                limit:3 },  // 1 req x 3 = 3
    { id:'posts',        label:'Posts',            posts:true,                            limit:1 },  // 5 req x 1 = 5
    { id:'topFollowers', label:'Top Followers',    steps:['topFollowers'],                 limit:2 },  // 1 req x 2 = 2
    { id:'topFollowing', label:'Top Following',    steps:['topFollowing'],                 limit:2 },  // 1 req x 2 = 2
    { id:'weekly',       label:'Last 7 Days',      steps:['newFollowers','newFollowing'],  limit:1 },  // 2 req x 1 = 2
  ];                                                                                          // = 22

  const DEFAULT_SEC = {}; SECTIONS.forEach(x => { DEFAULT_SEC[x.id] = x.limit; });

  /* ── helpers ─────────────────────────────────────────────────── */
  const store = {
    get: keys => new Promise(r => chrome.storage.local.get(keys, r)),
    set: obj  => new Promise(r => chrome.storage.local.set(obj, r)),
  };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt = n => {
    n = Number(n); if (!isFinite(n)) return '—';
    const a = Math.abs(n);
    if (a >= 1e9) return (n/1e9).toFixed(1).replace(/\.0$/,'') + 'B';
    if (a >= 1e6) return (n/1e6).toFixed(1).replace(/\.0$/,'') + 'M';
    if (a >= 1e4) return (n/1e3).toFixed(1).replace(/\.0$/,'') + 'K';
    return n.toLocaleString('en-US');
  };
  const fmtScore = n => {
    n = Number(n); if (!isFinite(n)) return '—';
    return Math.abs(n) >= 1000 ? fmt(n) : (Math.round(n * 100) / 100).toLocaleString('en-US');
  };
  const fmtDate = iso => {
    const d = new Date(iso); if (isNaN(d)) return '—';
    return d.toLocaleDateString('en-US', { year:'numeric', month:'short', day:'numeric' });
  };
  const ageOf = iso => {
    const d = new Date(iso); if (isNaN(d)) return '—';
    const now = new Date();
    let m = (now.getFullYear() - d.getFullYear()) * 12 + now.getMonth() - d.getMonth();
    if (now.getDate() < d.getDate()) m--;
    if (m < 1) return Math.max(0, Math.floor((now - d) / 864e5)) + 'd';
    const y = Math.floor(m / 12), mo = m % 12;
    return y ? `${y}y ${mo}m` : `${mo}m`;
  };
  const relTime = ts => {
    const s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
    if (s < 60) return 'just now';
    if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago';
    return Math.floor(s / 86400) + 'd ago';
  };
  const safeImg = u => (typeof u === 'string' && /^https:\/\//i.test(u))
    ? u.replace('_normal.', '_400x400.') : '';

  /* ── Daily usage tracking — SERVER side (Worker D1 sorsa_usage) ──
     Same counter for every device / login: logout + login can't reset it.
     Every analysis first RESERVES its requests with an ETag-checked write,
     so two devices can't both slip through the limit at the same time.   */
  const utcDay = () => new Date().toISOString().slice(0, 10);
  const blankUsage = () => ({ day: utcDay(), full: 0, reqs: 0, sec: {} });
  let usage = blankUsage();
  const normUsage = u => (u && u.day === utcDay())
    ? { day: u.day, full: Number(u.full) || 0, reqs: Number(u.reqs) || 0, sec: (u.sec && typeof u.sec === 'object') ? Object.assign({}, u.sec) : {} }
    : blankUsage();
  const fullCost = () => STEPS.length + POST_PAGES;
  // STEP 6b: limits + usage live in the Worker (D1). The extension only asks / reserves.
  function zcall(path, body) {
    return new Promise(res => {
      try { chrome.runtime.sendMessage({ type: 'zexpayCall', path, body }, r => res((chrome.runtime.lastError || !r) ? { ok: false, error: 'NETWORK' } : r)); }
      catch (e) { res({ ok: false, error: 'NETWORK' }); }
    });
  }
  const applyLimits = d => {
    d = d || {};
    const n = (v, def) => (v === null || v === undefined || v === '' || !isFinite(+v) || +v < 0) ? def : Math.floor(+v);
    DAILY_CAP  = n(d.cap, 50);
    FULL_LIMIT = n(d.full, 2);
    SECTIONS.forEach(x => { x.limit = n(d.sec && d.sec[x.id], DEFAULT_SEC[x.id]); });
  };
  async function loadLimits() {
    const r = await zcall('/v1/sorsa/usage');
    if (!r.ok) return;                                // offline / not allowed → keep what we have
    applyLimits(r.data && r.data.limits);
    usage = normUsage(r.data && r.data.usage);
  }
  async function loadUsage() { return usage; }        // already loaded together with the limits
  async function syncUsage() { await loadLimits(); paintSep(); }
  const failReason = r => (r.error === 'SORSA_LIMIT') ? 'limit' : (r.error === 'NETWORK') ? 'offline'
    : (r.error === 'BUSY') ? 'busy' : (r.error === 'NO_AUTH') ? 'nologin' : 'other';
  // sec = section object, or null for a full analysis. Server decides the cost and counts BEFORE any Sorsa call.
  async function reserveUsage(sec, cost) {
    const r = await zcall('/v1/sorsa/reserve', { sec: sec ? sec.id : null });
    if (r.ok) { usage = normUsage(r.data && r.data.usage); return { ok: true }; }
    if (r.error === 'SORSA_LIMIT' && r.data && r.data.usage) usage = normUsage(r.data.usage);
    return { ok: false, reason: failReason(r), message: SX_ERR[r.error] || '' };
  }
  // Whole attempt failed → give the attempt back (server keeps 1 request charged: the call really went out).
  async function releaseUsage(secId, cost) {
    const r = await zcall('/v1/sorsa/release', { sec: secId || null });
    if (r.ok) usage = normUsage(r.data && r.data.usage);
    return r;
  }
  const SX_ERR = {
    X_NOT_VERIFIED: 'Verify your X account in the ZEX popup first.',
    NEEDS_FIRST_PAYMENT: 'Activate your account with the first payment.',
    NO_CREDITS: 'No credits left — top up to continue.',
    NOT_APPROVED: 'Access not active — contact admin.',
    EXPIRED: 'Access expired — contact admin.',
    API_LOCKED: 'Contact Admin',
    NO_SORSA_KEY: 'ZEX API is not connected. Please contact the admin.',
    HANDLE_MISMATCH: 'This X handle is not linked to your account.',
    DAILY_LIMIT: 'Daily limit reached. Try again tomorrow.',
    NETWORK: 'Network error — try again.',
  };
  function limitMsg(rv, sec) {
    if (rv.reason === 'other') return rv.message || 'Request failed — try again.';
    if (rv.reason === 'offline') return "Couldn't verify your daily limit. Check your connection and try again.";
    if (rv.reason === 'nologin') return 'Please log in first.';
    if (rv.reason === 'busy')    return 'Server is busy — please try again.';
    return sec ? `Daily limit reached for ${sec.label}. Try again tomorrow.`
               : `You can only analyse your account daily ${FULL_LIMIT === 1 ? '1 time' : FULL_LIMIT + ' times'}`;
  }
  const secCost = sec => sec.posts ? POST_PAGES : sec.steps.length;
  const secLeft = sec => Math.max(0, sec.limit - (usage.sec[sec.id] || 0));

  /* ── Sorsa client ────────────────────────────────────────────── */
  async function sorsaFetch(key, method, path, opts) {
    opts = opts || {};
    const r = await zcall('/v1/sorsa', opts.body ? { path, body: opts.body } : { path, query: opts.query || {} });
    if (r.ok) return r.data && r.data.result;
    const m = /^SORSA_(\d+)$/.exec(r.error || '');
    const err = new Error(SX_ERR[r.error] || (r.data && r.data.detail) || r.message || 'Request failed');
    err.status = m ? (+m[1] === 404 ? 404 : (+m[1] === 401 || +m[1] === 403 ? +m[1] : (+m[1] === 429 ? 429 : 502))) : 0;
    throw err;
  }
  function errMsg(e) {
    const s = e && e.status;
    if (s === 401) return 'Invalid API key';
    if (s === 403) return 'Access denied for this API key';
    if (s === 404) return 'Not found';
    if (s === 429) return 'Rate limit hit or no requests left on this key';
    if (s === 500 || s === 502 || s === 503) return 'ZEX server error — please try again in a moment';
    if (s === 0)   return e.message || 'Network problem';
    return (e && e.message) || 'Request failed';
  }

  /* ── Analysis pipeline ───────────────────────────────────────── */
  // Each entry = one Sorsa call. Step 2 appends more entries here.
  const STEPS = [
    { id:'info',          label:'profile',          path:'/info',            required:true },
    { id:'about',         label:'account info',     path:'/about' },
    { id:'score',         label:'Sorsa score',      path:'/score' },
    { id:'scoreChanges',  label:'score changes',    path:'/score-changes' },
    { id:'followerStats', label:'follower quality', path:'/followers-stats' },
    { id:'topFollowers',  label:'top followers',    path:'/top-followers' },
    { id:'topFollowing',  label:'top following',    path:'/top-following' },
    { id:'newFollowers',  label:'new followers',    path:'/new-followers-7d' },
    { id:'newFollowing',  label:'new following',    path:'/new-following-7d' },
  ];

  // Keep only what the analysis needs (cache stays small).
  function compactTweet(t) {
    const num = v => Number(v) || 0;
    const text = String(t.full_text || t.text || '');
    const isRt = !!t.retweeted_status || /^RT @/.test(text);
    const kind = isRt ? 'rt' : (t.is_reply ? 'reply' : (t.is_quote_status ? 'quote' : 'post'));
    const media = Array.isArray(t.entities) && t.entities.some(e => e && /^(photo|video|animated_gif)$/.test(e.type));
    return { id: String(t.id), t: text.slice(0, 160), ts: Date.parse(t.created_at) || 0,
             l: num(t.likes_count), r: num(t.retweet_count), p: num(t.reply_count), q: num(t.quote_count),
             v: num(t.view_count), b: num(t.bookmark_count), k: kind, m: media ? 1 : 0 };
  }

  async function fetchPosts(key, username, onPage) {
    const items = [], seen = new Set();
    let cursor = null;
    for (let page = 1; page <= POST_PAGES; page++) {
      let res;
      try {
        const body = { username, with_replies: true };
        if (cursor) body.next_cursor = cursor;
        res = await sorsaFetch(key, 'POST', '/user-tweets', { body });
      } catch (e) {
        if (!items.length) throw e;            // nothing yet -> real error; otherwise keep partial data
        break;
      }
      const list = (res && Array.isArray(res.tweets)) ? res.tweets : [];
      list.forEach(t => { if (t && t.id != null && !seen.has(String(t.id))) { seen.add(String(t.id)); items.push(compactTweet(t)); } });
      if (onPage) onPage(page);
      cursor = res && res.next_cursor;
      if (!cursor || !list.length) break;
    }
    return { items };
  }

  async function collect(key, username, onProgress) {
    const out = { username, fetchedAt: Date.now(), data: {}, errors: {}, ts: {} };
    const total = STEPS.length + 1;            // +1 = posts (several pages)
    let done = 0;
    const run = async ep => {
      try {
        out.data[ep.id] = await sorsaFetch(key, 'GET', ep.path, { query: { username } });
        out.ts[ep.id] = Date.now();
      } catch (e) {
        out.errors[ep.id] = { status: e.status || 0, message: e.message };
      }
      onProgress(++done, total, ep.label);
    };
    // Profile first: bad key / wrong handle stops here, before spending more requests.
    await run(STEPS[0]);
    if (!out.data.info) {
      const e = out.errors.info || {};
      const err = new Error(e.status === 404 ? `@${username} not found on X` : (e.message || 'Request failed'));
      err.status = e.status;
      throw err;
    }
    const jobs = STEPS.slice(1).map(run);
    jobs.push((async () => {
      try {
        out.data.posts = await fetchPosts(key, username, pg => onProgress(done, total, `posts page ${pg}/${POST_PAGES}`));
        out.ts.posts = Date.now();
      } catch (e) {
        out.errors.posts = { status: e.status || 0, message: e.message };
      }
      onProgress(++done, total, 'posts');
    })());
    await Promise.all(jobs);
    return out;
  }

  /* ── Rendering ───────────────────────────────────────────────── */
  const statBox = (val, lbl) =>
    `<div class="sx-stat"><div class="sx-sv">${esc(val)}</div><div class="sx-sl">${esc(lbl)}</div></div>`;

  function missingNote(res, id, what) {
    const e = res.errors[id];
    if (!e) return '';
    const msg = e.status === 404
      ? `${what} not available — this account isn't indexed in ZEX's crypto database.`
      : `${what} unavailable: ${esc(errMsg(e))}`;
    return `<div class="sx-note">${msg}</div>`;
  }

  function renderProfile(res) {
    const u = res.data.info, a = res.data.about;
    if (!u) return `<div class="sx-sec"><div class="sx-sec-t">Profile</div>${missingNote(res, 'info', 'Profile')}${missingNote(res, 'about', 'Account info')}</div>`;
    const img = safeImg(u.profile_image_url);
    const followers = Number(u.followers_count) || 0;
    const following = Number(u.followings_count) || 0;
    const ratio = following > 0 ? (followers / following) : null;
    const chips = [];
    if (u.verified)           chips.push('<span class="sx-chip ok">✓ Verified</span>');
    if (u.protected)          chips.push('<span class="sx-chip warn">🔒 Protected</span>');
    if (u.can_dm)             chips.push('<span class="sx-chip">✉ DMs open</span>');
    if (u.possibly_sensitive) chips.push('<span class="sx-chip warn">⚠ Sensitive flag</span>');
    const metaBits = [];
    if (u.location) metaBits.push('📍 ' + esc(u.location));
    if (a && a.country) metaBits.push('🌍 ' + esc(a.country));
    if (u.created_at) metaBits.push(`📅 Joined ${esc(fmtDate(u.created_at))} · ${esc(ageOf(u.created_at))}`);

    let aboutHtml = '';
    if (a && typeof a.username_change_count === 'number') {
      aboutHtml = `<div class="sx-kv"><span>Username changes</span><b>${a.username_change_count}` +
        (a.username_change_count > 0 && a.last_username_change_at ? ` · last ${esc(fmtDate(a.last_username_change_at))}` : '') +
        `</b></div>`;
    }

    return `
      <div class="sx-sec">
        <div class="sx-sec-t">Profile</div>
        <div class="sx-prof">
          ${img ? `<img class="sx-avi" src="${esc(img)}" alt="" referrerpolicy="no-referrer">` : '<div class="sx-avi sx-avi-ph">𝕏</div>'}
          <div class="sx-pi">
            <div class="sx-pn">${esc(u.display_name || u.username)}</div>
            <div class="sx-ph">@${esc(u.username || res.username)}</div>
          </div>
        </div>
        ${u.description ? `<div class="sx-bio">${esc(u.description)}</div>` : ''}
        ${chips.length ? `<div class="sx-chips">${chips.join('')}</div>` : ''}
        ${metaBits.length ? `<div class="sx-meta">${metaBits.map(b => `<span>${b}</span>`).join('')}</div>` : ''}
        <div class="sx-grid">
          ${statBox(fmt(followers), 'Followers')}
          ${statBox(fmt(following), 'Following')}
          ${statBox(fmt(u.tweets_count), 'Posts')}
          ${statBox(fmt(u.favourites_count), 'Likes given')}
          ${statBox(fmt(u.media_count), 'Media')}
          ${statBox(ratio == null ? '—' : (ratio >= 100 ? fmt(Math.round(ratio)) : ratio.toFixed(2)), 'Follower ratio')}
        </div>
        ${aboutHtml}
        ${missingNote(res, 'about', 'Account info')}
      </div>`;
  }

  function delta(v) {
    v = Number(v);
    if (!isFinite(v)) return '<span class="sx-d">—</span>';
    const cls = v > 0 ? 'up' : (v < 0 ? 'dn' : '');
    const sign = v > 0 ? '▲ +' : (v < 0 ? '▼ ' : '');
    return `<span class="sx-d ${cls}">${sign}${esc(fmtScore(v))}</span>`;
  }

  function renderScore(res) {
    const s = res.data.score, c = res.data.scoreChanges;
    if (!s && !c) return `<div class="sx-sec"><div class="sx-sec-t">Sorsa Score</div>${missingNote(res, 'score', 'Sorsa score')}</div>`;
    return `
      <div class="sx-sec">
        <div class="sx-sec-t">Sorsa Score <span class="sx-tag">crypto influence</span></div>
        <div class="sx-score-row">
          <div class="sx-score">${s ? esc(fmtScore(s.score)) : '—'}</div>
          <div class="sx-deltas">
            <div class="sx-dl"><span>7 days</span>${c ? delta(c.week_delta) : '<span class="sx-d">—</span>'}</div>
            <div class="sx-dl"><span>30 days</span>${c ? delta(c.month_delta) : '<span class="sx-d">—</span>'}</div>
          </div>
        </div>
        ${!s ? missingNote(res, 'score', 'Sorsa score') : ''}
        ${!c ? missingNote(res, 'scoreChanges', 'Score changes') : ''}
      </div>`;
  }

  function renderFollowerQuality(res) {
    const f = res.data.followerStats;
    if (!f) return `<div class="sx-sec"><div class="sx-sec-t">Follower Quality</div>${missingNote(res, 'followerStats', 'Follower quality')}</div>`;
    const total = Number(f.followers_count) || 0;
    const rows = [
      ['Influencers', f.influencers_count],
      ['Projects', f.projects_count],
      ['VC staff', f.venture_capitals_count],
    ];
    const max = Math.max(1, ...rows.map(r => Number(r[1]) || 0));
    return `
      <div class="sx-sec">
        <div class="sx-sec-t">Follower Quality <span class="sx-tag">ZEX-tracked</span></div>
        <div class="sx-kv"><span>Categorized followers</span><b>${esc(fmt(total))}</b></div>
        <div class="sx-bars">
          ${rows.map(([l, v]) => {
            const n = Number(v) || 0;
            const pct = total > 0 ? Math.round(n / total * 100) : 0;
            return `<div class="sx-bar"><span class="sx-bl">${esc(l)}</span>
              <div class="sx-bt"><div class="sx-bf" style="width:${Math.round(n / max * 100)}%"></div></div>
              <span class="sx-bc">${esc(fmt(n))}<i>${pct}%</i></span></div>`;
          }).join('')}
        </div>
        <div class="sx-note">Counts only followers that crypto influencers, projects - Not your full follower list buddy</div>
      </div>`;
  }

  /* ── STEP 2 renderers ───────────────────────────────────────── */
  const pct = (n, d) => d > 0 ? Math.round(n / d * 100) : 0;
  const avg = arr => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
  const fmtAvg = n => n >= 100 ? fmt(Math.round(n)) : (Math.round(n * 10) / 10).toLocaleString('en-US');
  const HOURS12 = h => (h % 12 === 0 ? 12 : h % 12) + (h < 12 ? 'am' : 'pm');
  const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  // Data that was never fetched (old cached result) vs failed.
  function absent(res, id, what) {
    if (res.errors[id]) return missingNote(res, id, what);
    return `<div class="sx-note">Press Analyze to load ${esc(what)}.</div>`;
  }

  function bestBuckets(items, keyFn, size) {
    const sum = new Array(size).fill(0), cnt = new Array(size).fill(0);
    items.forEach(i => { const k = keyFn(i); sum[k] += i.l + i.r + i.p + i.q; cnt[k]++; });
    const avgs = sum.map((v, k) => cnt[k] ? v / cnt[k] : 0);
    const minCnt = cnt.some(c => c >= 2) ? 2 : 1;
    const ranked = avgs.map((a, k) => ({ k, a, c: cnt[k] })).filter(x => x.c >= minCnt).sort((x, y) => y.a - x.a);
    return { avgs, cnt, ranked };
  }

  function renderPosts(res) {
    const P = res.data.posts;
    if (!P) return `<div class="sx-sec"><div class="sx-sec-t">Posts Analysis</div>${absent(res, 'posts', 'posts analysis')}</div>`;
    const items = P.items || [];
    if (!items.length) return `<div class="sx-sec"><div class="sx-sec-t">Posts Analysis</div><div class="sx-note">No public posts found for this account.</div></div>`;

    const n = items.length;
    const kinds = { post: 0, reply: 0, quote: 0, rt: 0 };
    items.forEach(i => { kinds[i.k] = (kinds[i.k] || 0) + 1; });
    const own = items.filter(i => i.k !== 'rt');               // reposts have no engagement of their own
    const eng = i => i.l + i.r + i.p + i.q;
    const stamps = items.map(i => i.ts).filter(Boolean);
    const spanDays = stamps.length > 1 ? (Math.max(...stamps) - Math.min(...stamps)) / 864e5 : 0;
    const perDay = spanDays > 0 ? n / Math.max(spanDays, 1) : null;

    const withViews = own.filter(i => i.v > 0);
    const sumEngV = withViews.reduce((a, i) => a + eng(i), 0);
    const sumViews = withViews.reduce((a, i) => a + i.v, 0);
    const followers = Number(res.data.info && res.data.info.followers_count) || 0;
    const avgEng = avg(own.map(eng));
    const rateViews = sumViews > 0 ? sumEngV / sumViews * 100 : null;
    const rateFol = followers > 0 && own.length ? avgEng / followers * 100 : null;
    const mediaPct = pct(own.filter(i => i.m).length, own.length);

    // best time (originals + quotes if we have enough of them, else everything authored)
    const originals = own.filter(i => i.k === 'post' || i.k === 'quote');
    const timed = (originals.length >= 8 ? originals : own).filter(i => i.ts);
    const hrs = bestBuckets(timed, i => new Date(i.ts).getHours(), 24);
    const dys = bestBuckets(timed, i => new Date(i.ts).getDay(), 7);
    const hMax = Math.max(1, ...hrs.avgs);
    const topHours = hrs.ranked.slice(0, 3).map(x => `${HOURS12(x.k)}`).join(' · ');
    const topDays = dys.ranked.slice(0, 2).map(x => DAYS[x.k]).join(' · ');

    const pool = own.filter(i => i.k !== 'reply');
    const top = (pool.length >= 3 ? pool : own).slice().sort((a, b) => eng(b) - eng(a)).slice(0, 3);
    const uname = res.username;

    const seg = [['post','Posts','#eab308'], ['reply','Replies','#60a5fa'], ['quote','Quotes','#a78bfa'], ['rt','Reposts','#94a3b8']];
    const legendBits = seg.map(([k, l, c]) =>
      `<span class="sx-lg"><i style="background:${c}"></i>${l} ${pct(kinds[k] || 0, n)}%</span>`).join('');
    const barBits = seg.filter(([k]) => kinds[k]).map(([k, , c]) =>
      `<div style="width:${(kinds[k] / n * 100).toFixed(2)}%;background:${c}"></div>`).join('');

    const hourBars = hrs.avgs.map((a, h) =>
      `<div class="sx-hb" title="${esc(HOURS12(h))} · ${hrs.cnt[h]} post(s)"><div style="height:${hrs.cnt[h] ? Math.max(8, Math.round(a / hMax * 100)) : 0}%"></div></div>`).join('');

    const topHtml = top.map((t, idx) => `
      <a class="sx-tp" href="https://x.com/${encodeURIComponent(uname)}/status/${encodeURIComponent(t.id)}" target="_blank" rel="noopener">
        <div class="sx-tp-n">${idx + 1}</div>
        <div class="sx-tp-b">
          <div class="sx-tp-t">${esc(t.t || '(media only)')}</div>
          <div class="sx-tp-m"><span>♥ ${esc(fmt(t.l))}</span><span>↻ ${esc(fmt(t.r))}</span><span>💬 ${esc(fmt(t.p))}</span>${t.v ? `<span>👁 ${esc(fmt(t.v))}</span>` : ''}</div>
        </div>
      </a>`).join('');

    return `
      <div class="sx-sec">
        <div class="sx-sec-t">Posts Analysis <span class="sx-tag">last ${n} posts</span></div>
        <div class="sx-grid">
          ${statBox(perDay == null ? '—' : fmtAvg(perDay), 'Posts / day')}
          ${statBox(rateViews == null ? (rateFol == null ? '—' : rateFol.toFixed(2) + '%') : rateViews.toFixed(2) + '%', rateViews == null ? 'Eng. / follower' : 'Eng. rate (views)')}
          ${statBox(mediaPct + '%', 'With media')}
          ${statBox(fmtAvg(avg(own.map(i => i.l))), 'Avg likes')}
          ${statBox(fmtAvg(avg(own.map(i => i.r))), 'Avg reposts')}
          ${statBox(fmtAvg(avg(own.map(i => i.p))), 'Avg replies')}
        </div>
        ${withViews.length ? `<div class="sx-kv"><span>Avg views per post</span><b>${esc(fmt(Math.round(sumViews / withViews.length)))}</b></div>` : ''}
        <div class="sx-sub">Reply / quote ratio</div>
        <div class="sx-typebar">${barBits}</div>
        <div class="sx-legend">${legendBits}</div>
        <div class="sx-kv"><span>Replies per original post</span><b>${(kinds.post || 0) > 0 ? ((kinds.reply || 0) / kinds.post).toFixed(2) : '—'}</b></div>
        <div class="sx-kv"><span>Quotes per original post</span><b>${(kinds.post || 0) > 0 ? ((kinds.quote || 0) / kinds.post).toFixed(2) : '—'}</b></div>
      </div>
      <div class="sx-sec">
        <div class="sx-sec-t">Best Posting Time <span class="sx-tag">your local time</span></div>
        ${hrs.ranked.length ? `
          <div class="sx-kv"><span>Top hours</span><b>${esc(topHours)}</b></div>
          <div class="sx-kv"><span>Top days</span><b>${esc(topDays)}</b></div>
          <div class="sx-hours">${hourBars}</div>
          <div class="sx-hl"><span>12am</span><span>6am</span><span>12pm</span><span>6pm</span><span>11pm</span></div>
          <div class="sx-note">Average engagement per hour of the day, from ${timed.length} posts. Small samples are noisy — treat as a hint.</div>`
        : `<div class="sx-note">Not enough dated posts to find a pattern.</div>`}
      </div>
      <div class="sx-sec">
        <div class="sx-sec-t">Top Posts</div>
        ${topHtml || '<div class="sx-note">No posts to rank.</div>'}
        ${res.errors.posts ? missingNote(res, 'posts', 'Some posts') : ''}
      </div>`;
  }

  function userRow(u, right, sub) {
    const name = u.username || '';
    const img = (typeof u.profile_image_url === 'string' && /^https:\/\//i.test(u.profile_image_url)) ? u.profile_image_url : '';
    return `<a class="sx-ur" href="https://x.com/${encodeURIComponent(name)}" target="_blank" rel="noopener">
      ${img ? `<img class="sx-uavi" src="${esc(img)}" alt="" referrerpolicy="no-referrer">` : '<span class="sx-uavi sx-avi-ph"></span>'}
      <span class="sx-un"><b>${esc(u.display_name || name)}${u.verified ? ' <em>✓</em>' : ''}</b><i>@${esc(name)}${sub ? ' · ' + esc(sub) : ''}</i></span>
      <span class="sx-ur-r">${right}</span>
    </a>`;
  }
  function userList(users, rowFn, limit) {
    const head = users.slice(0, limit).map(rowFn).join('');
    const rest = users.slice(limit);
    return head + (rest.length
      ? `<details class="sx-det"><summary>Show ${rest.length} more</summary>${rest.map(rowFn).join('')}</details>` : '');
  }
  const usersOf = d => (d && Array.isArray(d.users)) ? d.users.filter(Boolean) : [];

  function renderTopUsers(res, id, title, tag) {
    const d = res.data[id];
    if (!d) return `<div class="sx-sec"><div class="sx-sec-t">${esc(title)}</div>${absent(res, id, title.toLowerCase())}</div>`;
    const users = usersOf(d);
    return `
      <div class="sx-sec">
        <div class="sx-sec-t">${esc(title)}${tag ? ` <span class="sx-tag">${esc(tag)}</span>` : ''}</div>
        ${users.length
          ? userList(users, u => userRow(u,
              `<span class="sx-sc">${u.score != null ? esc(fmtScore(u.score)) : '—'}</span><span class="sx-scl">score</span>`,
              fmt(u.followers_count) + ' followers'), 5)
          : '<div class="sx-note">Nobody tracked by ZEX yet.</div>'}
      </div>`;
  }

  function renderWeekly(res) {
    const nf = res.data.newFollowers, ng = res.data.newFollowing;
    if (!nf && !ng) {
      return `<div class="sx-sec"><div class="sx-sec-t">Last 7 Days</div>${absent(res, 'newFollowers', 'new followers')}${res.errors.newFollowing ? missingNote(res, 'newFollowing', 'New following') : ''}</div>`;
    }
    const fu = usersOf(nf), gu = usersOf(ng);
    const dateOf = u => {
      const iso = u.followerDate || u.followingDate || u.follow_date || u.followed_at;
      return iso ? fmtDate(iso) : '';
    };
    const row = u => userRow(u, `<span class="sx-scl">${esc(dateOf(u))}</span>`, fmt(u.followers_count) + ' followers');
    const block = (label, users, id) => users.length
      ? `<div class="sx-sub">${esc(label)} <b>${users.length}</b></div>${userList(users, row, 4)}`
      : `<div class="sx-sub">${esc(label)} <b>0</b></div>${res.errors[id] ? missingNote(res, id, label) : ''}`;
    return `
      <div class="sx-sec">
        <div class="sx-sec-t">Last 7 Days <span class="sx-tag">ZEX-tracked accounts</span></div>
        <div class="sx-grid two">
          ${statBox(nf ? '+' + fu.length : '—', 'New followers')}
          ${statBox(ng ? '+' + gu.length : '—', 'New following')}
        </div>
        ${block('New followers', fu, 'newFollowers')}
        ${block('New following', gu, 'newFollowing')}
        <div class="sx-note">Only crypto influencers, projects and VCs that ZEX tracks are counted — not every new follow.</div>
      </div>`;
  }

  // Per-section "how old is this data" tag, put at the right end of the section title.
  function stamp(html, res, ids) {
    const t = Math.max(0, ...ids.map(id => (res.ts && res.ts[id]) || (res.data[id] ? res.fetchedAt : 0)));
    if (!t) return html;
    return html.replace(/(<div class="sx-sec-t">[\s\S]*?)(<\/div>)/,
      (m, a, b) => a + '<span class="sx-ago">' + esc(relTime(t)) + '</span>' + b);
  }

  function render(res) {
    const box = $('sxResults');
    const has = (...ids) => ids.some(id => res.data[id] || res.errors[id]);
    let html = '';
    if (has('info', 'about'))                html += stamp(renderProfile(res), res, ['info', 'about']);
    if (has('score', 'scoreChanges'))        html += stamp(renderScore(res), res, ['score', 'scoreChanges']);
    if (has('followerStats'))                html += stamp(renderFollowerQuality(res), res, ['followerStats']);
    if (has('posts'))                        html += stamp(renderPosts(res), res, ['posts']);
    if (has('topFollowers'))                 html += stamp(renderTopUsers(res, 'topFollowers', 'Top Followers', 'by Sorsa score'), res, ['topFollowers']);
    if (has('topFollowing'))                 html += stamp(renderTopUsers(res, 'topFollowing', 'Top Following', ''), res, ['topFollowing']);
    if (has('newFollowers', 'newFollowing')) html += stamp(renderWeekly(res), res, ['newFollowers', 'newFollowing']);
    box.innerHTML = html;
    lastRes = res;
    paintBar();
  }

  /* ── UI state ────────────────────────────────────────────────── */
  let apiKey = '';
  let busy = false;
  let lastRes = null, isOld = false, hidden = false;
  const HIDE_STORE = 'sxResultsHidden';
  function setHidden(v) { hidden = !!v; store.set({ [HIDE_STORE]: hidden }); }

  function setStatus(msg, kind) {
    const el = $('sxStatus');
    el.textContent = msg || '';
    el.className = 'sx-status' + (kind ? ' ' + kind : '');
  }
  async function refreshKey() {
    // Sorsa key is server-side; only ask whether one is connected (/v1/me has_sorsa).
    const r = await zcall('/v1/me');
    apiKey = (r.ok && r.data && r.data.has_sorsa) ? 'zex' : '';
    return apiKey;
  }

  async function getHandle() {
    const d = await store.get(['zenDeviceSession']);
    const s = d.zenDeviceSession || {};
    return String(s.xHandle || '').replace(/^@/, '').trim();
  }
  async function paintTarget() {
    const h = await getHandle();
    const el = $('sxTarget');
    el.textContent = h ? '@' + h : 'No X account linked';
    el.classList.toggle('none', !h);
    return h;
  }

  async function analyze() {
    if (busy) return;
    await loadLimits(); await loadUsage();
    if (usage.full >= FULL_LIMIT || usage.reqs + fullCost() > DAILY_CAP) {
      setStatus(limitMsg({ reason: 'limit' }, null), 'err');
      paintSep();
      return;
    }
    if (!(await refreshKey())) {
      setStatus('ZEX API is not connected. Please contact the admin.', 'err');
      return;
    }
    const handle = await paintTarget();
    if (!handle) {
      setStatus('No X account linked to this login. Verify your X username first (Session tab).', 'err');
      return;
    }
    busy = true;
    const btn = $('sxAnalyze'); btn.disabled = true; btn.textContent = 'Analyzing…';
    setStatus('Starting…');
    try {
      const rv = await reserveUsage(null, fullCost());   // server-side check + count BEFORE any Sorsa call
      if (!rv.ok) { setStatus(limitMsg(rv, null), 'err'); return; }
      let res;
      try { res = await collect(apiKey, handle, (d, t, label) => setStatus(`Fetched ${label} (${d}/${t})`)); }
      catch (e) { await releaseUsage(null, fullCost()); throw e; }   // profile failed → attempt not counted
      await store.set({ [CACHE_STORE]: res });
      isOld = false; setHidden(false);
      render(res);
      const failed = Object.keys(res.errors).length;
      setStatus(failed ? `Done — ${failed} section(s) unavailable` : 'Analysis complete', failed ? '' : 'ok');
    } catch (e) {
      setStatus(errMsg(e) === 'Not found' ? e.message : (e.message && e.status !== 401 && e.status !== 429 ? e.message : errMsg(e)), 'err');
      if (e.status === 401) { setStatus('The ZEX key was rejected. Please tell the admin to update it.', 'err'); }
    } finally {
      busy = false;
      btn.disabled = false; btn.textContent = 'Analyze';
      paintSep();
    }
  }

  /* ── Saved-result bar: old/new label + hide/show ─────────────── */
  function paintBar() {
    const el = $('sxBar'), box = $('sxResults');
    if (!el) return;
    if (!lastRes || !lastRes.data || !Object.keys(lastRes.data).length) {
      el.style.display = 'none'; el.innerHTML = ''; if (box) box.style.display = ''; return;
    }
    const fullOk = usage.full < FULL_LIMIT && usage.reqs + fullCost() <= DAILY_CAP;
    const secOk  = SECTIONS.some(x => secLeft(x) > 0 && usage.reqs + secCost(x) <= DAILY_CAP);
    let note = '', off = false;
    if (isOld) {
      if (fullOk)      note = 'New data available — press Analyze';
      else if (secOk)  note = 'New data available — use Analyze separately';
      else           { note = 'No requests left today — new data available tomorrow'; off = true; }
    }
    el.style.display = '';
    el.innerHTML =
      `<div class="sx-rb-top"><span class="sx-badge ${isOld ? '' : 'new'}">${isOld ? 'Old data' : 'New data'}</span>` +
      `<span class="sx-rb-time">${esc(relTime(lastRes.fetchedAt))}</span>` +
      `<button class="sx-hide" type="button" id="sxHideBtn">${hidden ? 'Show' : 'Hide'}</button></div>` +
      (note ? `<div class="sx-rb-note${off ? ' off' : ''}">${esc(note)}</div>` : '');
    if (box) box.style.display = hidden ? 'none' : '';
  }

  /* ── Separate (single-section) analysis ──────────────────────── */
  function paintSep() {
    const box = $('sxSep'); if (!box) return;
    paintBar();
    box.innerHTML = SECTIONS.map(sec => {
      const left = secLeft(sec);
      return `<button class="sx-sbtn" type="button" data-sec="${sec.id}"${(left <= 0 || busy) ? ' disabled' : ''}>` +
             `<b>${esc(sec.label)}</b><i>${left > 0 ? left + ' left today' : 'limit reached'}</i></button>`;
    }).join('');
  }

  async function analyzeSection(id) {
    if (busy) return;
    const sec = SECTIONS.find(x => x.id === id); if (!sec) return;
    await loadLimits(); await loadUsage();
    const cost = secCost(sec);
    if (secLeft(sec) <= 0 || usage.reqs + cost > DAILY_CAP) {
      setStatus(`Daily limit reached for ${sec.label}. Try again tomorrow.`, 'err');
      paintSep();
      return;
    }
    if (!(await refreshKey())) { setStatus('ZEX API is not connected. Please contact the admin.', 'err'); return; }
    const handle = await paintTarget();
    if (!handle) { setStatus('No X account linked to this login. Verify your X username first (Session tab).', 'err'); return; }

    busy = true; paintSep();
    const btn = $('sxAnalyze'); btn.disabled = true;
    setStatus(`Fetching ${sec.label}…`);
    try {
      const rv = await reserveUsage(sec, cost);          // server-side check + count BEFORE any Sorsa call
      if (!rv.ok) { setStatus(limitMsg(rv, sec), 'err'); return; }
      // merge into the saved result (same account) so other sections stay visible
      const d = await store.get([CACHE_STORE]);
      let res = d[CACHE_STORE];
      if (!res || !res.username || res.username.toLowerCase() !== handle.toLowerCase()) {
        res = { username: handle, fetchedAt: Date.now(), data: {}, errors: {}, ts: {} };
      }
      res.ts = res.ts || {};
      const put = (k, v) => { res.data[k] = v; res.ts[k] = Date.now(); delete res.errors[k]; };
      const fail = (k, e) => { res.errors[k] = { status: e.status || 0, message: e.message }; };
      let ok = 0;
      if (sec.posts) {
        try { put('posts', await fetchPosts(apiKey, handle)); ok++; } catch (e) { fail('posts', e); }
      } else {
        await Promise.all(sec.steps.map(async stepId => {
          const ep = STEPS.find(x => x.id === stepId);
          try { put(stepId, await sorsaFetch(apiKey, 'GET', ep.path, { query: { username: handle } })); ok++; }
          catch (e) { fail(stepId, e); }
        }));
      }
      res.fetchedAt = Date.now();
      if (!ok) await releaseUsage(sec.id, cost);          // nothing worked → attempt not counted
      await store.set({ [CACHE_STORE]: res });
      isOld = false; setHidden(false);
      render(res);
      setStatus(ok ? `${sec.label} updated` : (errMsg(res.errors[sec.steps ? sec.steps[0] : 'posts'] || {}) || 'Request failed'), ok ? 'ok' : 'err');
    } catch (e) {
      setStatus(errMsg(e), 'err');
    } finally {
      busy = false; btn.disabled = false; paintSep();
    }
  }

  async function showCached() {
    const handle = await getHandle();
    const d = await store.get([CACHE_STORE]);
    const c = d[CACHE_STORE];
    if (c && handle && c.username && c.username.toLowerCase() === handle.toLowerCase() && c.data && Object.keys(c.data).length) {
      isOld = (Date.now() - (c.fetchedAt || 0)) > 120000;
      render(c);
      setStatus('');
    } else {
      lastRes = null;
      $('sxResults').innerHTML = '';
      setStatus('');
      paintBar();
    }
  }

  /* ── wire up ─────────────────────────────────────────────────── */
  $('sxAnalyze').addEventListener('click', analyze);
  $('sxBar').addEventListener('click', e => {
    if (e.target.closest('#sxHideBtn')) { setHidden(!hidden); paintBar(); }
  });
  $('sxSep').addEventListener('click', e => {
    const b = e.target.closest('.sx-sbtn'); if (b && !b.disabled) analyzeSection(b.dataset.sec);
  });

  document.querySelectorAll('.nav-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.tabpanel === 'tabPanelDashboard' && !busy) { paintTarget(); showCached(); refreshKey(); syncUsage(); }
    });
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && ch.zenDeviceSession && !busy) { paintTarget(); showCached(); refreshKey(); syncUsage(); }
  });

  (async function init() {
    hidden = !!(await store.get([HIDE_STORE]))[HIDE_STORE];
    try { chrome.storage.local.remove([OLD_LOCAL_USAGE]); } catch (e) {}
    await loadLimits(); await loadUsage();
    paintSep();
    await refreshKey();
    await paintTarget();
    await showCached();
  })();
})();
