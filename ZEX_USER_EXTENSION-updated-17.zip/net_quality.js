// ZEX NETWORK QUALITY — shared by the X page (content script) and the popup header.
// Measures the device's real connection two ways:
//   1) navigator.connection  (effectiveType / downlink / rtt / saveData) — what the browser reports
//   2) a tiny live probe     (round-trip to x.com every ~15s, median of the last 3) — what we actually get
// Quality: GOOD · FAIR · SLOW · POOR · OFFLINE.
// The stuck-watchdog uses stuckMult() so a slow network gets more patience instead of a false "stuck",
// and OFFLINE just pauses the watchdog until the connection is back.
(function () {
  if (window.ZexNet) return;

  var PROBE_EVERY = 15000;
  var PROBE_TIMEOUT = 8000;
  var MULT = { good: 1, fair: 1.5, slow: 2, poor: 3 };
  var LABEL = { good: 'GOOD', fair: 'FAIR', slow: 'SLOW', poor: 'POOR', offline: 'OFFLINE' };
  var COLOR = { good: '#22c55e', fair: '#a3e635', slow: '#facc15', poor: '#ef4444', offline: '#6b7280' };

  var samples = [];       // last probe results in ms (8000 = timeout/fail)
  var hist = [];          // longer history (last 12) — only used to draw the header Network Line
  var listeners = [];
  var started = false;
  var timer = null;
  var state = { q: 'good', ms: 0, type: '', down: 0, rtt: 0, saveData: false, online: true, ts: 0 };

  function conn() { return navigator.connection || navigator.mozConnection || navigator.webkitConnection || null; }
  function median(a) { var s = a.slice().sort(function (x, y) { return x - y; }); return s[Math.floor(s.length / 2)]; }

  function classify() {
    var c = conn();
    state.online = navigator.onLine !== false;
    state.type = c && c.effectiveType ? String(c.effectiveType).toUpperCase() : '';
    state.down = c && isFinite(c.downlink) ? c.downlink : 0;
    state.rtt = c && isFinite(c.rtt) ? c.rtt : 0;
    state.saveData = !!(c && c.saveData);
    state.ms = samples.length ? Math.round(median(samples)) : 0;

    var q = 'good';
    if (!state.online) q = 'offline';
    else {
      var ms = samples.length ? median(samples) : (state.rtt || 0);
      if (ms >= 2500) q = 'poor';
      else if (ms >= 1000) q = 'slow';
      else if (ms >= 400) q = 'fair';
      // the browser's own estimate can only make it worse, never better
      var t = (c && c.effectiveType) || '';
      if (t === 'slow-2g' || t === '2g') q = 'poor';
      else if (t === '3g' && (q === 'good' || q === 'fair')) q = 'slow';
      if (c && c.downlink && c.downlink < 0.4 && q !== 'poor') q = 'slow';
    }
    return q;
  }

  function emit(prevQ) {
    var cur = state.q;
    listeners.slice().forEach(function (fn) { try { fn(state, prevQ); } catch (e) {} });
    void cur;
  }

  function refresh() {
    var prev = state.q;
    state.q = classify();
    state.ts = Date.now();
    emit(prev);
  }

  function probeUrl() {
    var origin = '';
    try { if (/^https?:$/.test(location.protocol)) origin = location.origin; } catch (e) {}
    return (origin || 'https://x.com') + '/favicon.ico?zexnet=' + Date.now();
  }

  async function probe() {
    if (navigator.onLine === false) { refresh(); return; }
    var t0 = performance.now();
    var ms;
    var ctl = typeof AbortController === 'function' ? new AbortController() : null;
    var to = setTimeout(function () { try { ctl && ctl.abort(); } catch (e) {} }, PROBE_TIMEOUT);
    try {
      await fetch(probeUrl(), { method: 'GET', cache: 'no-store', credentials: 'omit', mode: 'no-cors', signal: ctl ? ctl.signal : undefined });
      ms = Math.round(performance.now() - t0);
    } catch (e) {
      ms = PROBE_TIMEOUT;   // online but nothing came back in time → treat as very poor
    } finally { clearTimeout(to); }
    samples.push(ms);
    if (samples.length > 3) samples.shift();
    hist.push(ms);
    if (hist.length > 14) hist.shift();
    refresh();
  }

  function loop() {
    if (!document.hidden) probe();
    timer = setTimeout(loop, PROBE_EVERY);
  }

  var api = {
    state: state,
    label: function () { return LABEL[state.q] || 'GOOD'; },
    color: function () { return COLOR[state.q] || COLOR.good; },
    isOffline: function () { return state.q === 'offline'; },
    // How much longer than normal a step may take before it counts as "stuck".
    stuckMult: function () { return MULT[state.q] || 1; },
    summary: function () {
      var parts = [LABEL[state.q] || 'GOOD'];
      if (state.q !== 'offline') {
        if (state.ms) parts.push(state.ms >= PROBE_TIMEOUT ? 'timeout' : state.ms + 'ms');
        if (state.type) parts.push(state.type);
        if (state.down) parts.push(state.down + 'Mbps');
      }
      return parts.join(' · ');
    },
    subscribe: function (fn) { if (typeof fn === 'function') listeners.push(fn); },
    history: function () { return hist.slice(); },
    probeNow: function () { return probe(); },
    start: function () {
      if (started) return;
      started = true;
      window.addEventListener('online', function () { samples = []; hist = []; refresh(); probe(); });
      window.addEventListener('offline', function () { refresh(); });
      var c = conn();
      if (c && c.addEventListener) c.addEventListener('change', function () { refresh(); });
      document.addEventListener('visibilitychange', function () { if (!document.hidden) probe(); });
      refresh();
      loop();
    },
  };
  window.ZexNet = api;
  api.start();

  // ── Popup header: Network Line + ms (only exists in popup.html) ───────────
  // A small stepped line of the recent probe results (taller = slower) with the live ms next to it.
  function bindPill() {
    var pill = document.getElementById('zexNetPill');
    if (!pill) return;
    var line = pill.querySelector('.zex-net-line');
    var txt = pill.querySelector('.zex-net-txt');
    var W = 36, H = 14, PAD = 2;
    function pts() {
      var h = api.history();
      if (!h.length) return [];
      var max = Math.max(300, Math.min(1500, Math.max.apply(null, h)));   // scale: 300ms..1.5s
      var n = Math.max(h.length, 2), out = [];
      for (var k = 0; k < h.length; k++) {
        var x = PAD + (W - PAD * 2) * (k + (n - h.length)) / (n - 1);
        var y = H - PAD - (H - PAD * 2) * Math.min(h[k], max) / max;   // low ms = low on the line
        out.push([x, y]);
      }
      return out;
    }
    function paint() {
      var col = api.color(), off = state.q === 'offline', p = pts(), d = '';
      if (off || !p.length) {
        d = 'M' + PAD + ' ' + (H / 2) + 'H' + (W - PAD);
      } else {
        d = 'M' + p[0][0].toFixed(1) + ' ' + p[0][1].toFixed(1);
        for (var k = 1; k < p.length; k++) {                      // stepped (pixel) segments
          d += 'H' + p[k][0].toFixed(1) + 'V' + p[k][1].toFixed(1);
        }
      }
      if (line) {
        var last = p.length ? p[p.length - 1] : [W - PAD, H / 2];
        line.innerHTML =
          '<path d="M' + PAD + ' ' + (H - 1) + 'H' + (W - PAD) + '" stroke="' + col + '" stroke-opacity=".25" stroke-width="1" fill="none"/>' +
          '<path d="' + d + '" stroke="' + col + '" stroke-width="1.6" fill="none" stroke-linejoin="miter"' + (off ? ' stroke-dasharray="3 2"' : '') + '/>' +
          (off ? '' : '<rect x="' + (last[0] - 1.5).toFixed(1) + '" y="' + (last[1] - 1.5).toFixed(1) + '" width="3" height="3" fill="' + col + '"/>');
      }
      var h = api.history(), lastMs = h.length ? h[h.length - 1] : 0;
      if (txt) txt.textContent = off ? 'OFF' : (lastMs ? (lastMs >= PROBE_TIMEOUT ? '—' : lastMs + 'ms') : '…');
      txt && (txt.style.color = col);
      pill.title = 'Network: ' + api.summary() + ' (tap to re-test)';
    }
    pill.addEventListener('click', function () { if (txt) txt.textContent = '…'; probe(); });
    api.subscribe(paint);
    paint();
    // Popup only: while it is open, re-test every 3s so the line and ms move on their own.
    // (The X page keeps the light 15s probe.)
    var busy = false;
    setInterval(function () {
      if (document.hidden || busy || state.q === 'offline') return;
      busy = true;
      Promise.resolve(probe()).then(function () { busy = false; }, function () { busy = false; });
    }, 3000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindPill);
  else bindPill();
})();
