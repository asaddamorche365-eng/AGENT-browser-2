// ZEX WORKFLOW MAP — popup side (Support and System tab)
// Reads chrome.storage.local['zexTrack'] (written by tracker_bg.js) and draws the run as a
// flow: start → open X → engine → like/comment → save → goal → refresh → continue → track over.
(function () {
  const KEY = 'zexTrack';
  const $ = (id) => document.getElementById(id);
  const flow = $('zmFlow'), sel = $('zmRunSel'), stats = $('zmStats');
  if (!flow || !sel) return;

  // Wallchain scores (wc_score.js) — shown next to every name: "@name · WC 123"
  let wcMap = {};
  const loadWc = () => { try { chrome.storage.local.get(['zexWcScores'], (d) => { wcMap = (d && d.zexWcScores) || {}; }); } catch (e) {} };
  loadWc();
  try { chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.zexWcScores) wcMap = c.zexWcScores.newValue || {}; }); } catch (e) {}
  const nameWc = (e, h) => {
    h = h == null ? e.h : h; if (!h) return '';
    let v = e.wc;
    if (v == null) { const k = String(h).replace(/^@/, '').toLowerCase(); if (wcMap[k]) v = wcMap[k].s; }
    return v == null ? h : h + ' · WC ' + v;
  };

  // Total error view: every failed reply / step logged by the engines (zexErrLog), shown for the selected run's time span.
  let errLog = [], errOpen = false;
  const loadErr = () => { try { chrome.storage.local.get(['zexErrLog'], (d) => { errLog = Array.isArray(d && d.zexErrLog) ? d.zexErrLog : []; if (!timer) render(); }); } catch (e) {} };
  loadErr();
  try { chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.zexErrLog) { errLog = Array.isArray(c.zexErrLog.newValue) ? c.zexErrLog.newValue : []; if (!timer && !flow.classList.contains('zm-playing')) render(); } }); } catch (e) {}

  let data = { runs: [], activeId: null };
  let selectedId = null;
  let timer = null;
  let renderTimer = null;

  const ENG = { TG: 'TELEGRAM', FED: 'FED', SEA: 'SEA', GIV: 'GIV', REP: 'COMMENT REP', TAR: 'TAR', MAN: 'MANUAL' };
  const WHY = { 'browser-closed': 'Browser / extension closed', stopped: 'All engines stopped', idle: 'No activity for a while', imported: 'Imported run' };
  const SHORT = { 'browser-closed': 'closed', stopped: 'stopped', idle: 'idle', imported: 'imported' };

  const pad = (n) => String(n).padStart(2, '0');
  const fmtClock = (t) => { const d = new Date(t); return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); };
  const fmtDay = (t) => { const d = new Date(t); return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); };
  function fmtDur(ms) {
    const s = Math.max(0, Math.round(ms / 1000));
    if (s < 60) return s + 's';
    const m = Math.floor(s / 60);
    if (m < 60) return m + 'm' + (s % 60 ? ' ' + (s % 60) + 's' : '');
    return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
  }
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  // ── events → steps ────────────────────────────────────────────
  function buildSteps(run) {
    const ev = run.events || [];
    const steps = [];
    let curMode = 'manual', comments = 0, i = 0, sinceLink = false;
    while (i < ev.length) {
      const e = ev[i];
      let s = null;
      switch (e.type) {
        case 'start': s = { k: 'start', title: 'ZEX START', sub: fmtDay(e.t) }; break;
        case 'open_x':
          if (steps.length && steps[steps.length - 1].k === 'tglink') break; // Telegram opens X by itself for each link
          s = { k: 'open', title: 'OPEN X', sub: fmtClock(e.t) }; break;
        case 'tg_link':
          sinceLink = false;
          s = { k: 'tglink', title: (e.name === 'SWEEP' ? 'SWEEP LINK' : 'TG LINK') + (e.n ? ' #' + e.n : ''), sub: nameWc(e) || 'opening on X', chips: [e.name === 'SWEEP' ? 'TG SWEEP' : 'TELEGRAM'] };
          break;
        case 'tg_done':
          if (e.why === 'fail') s = { k: 'fail', title: 'LINK FAILED', sub: nameWc(e) };
          else if (!sinceLink) s = { k: 'comment', title: 'REPLIED', sub: nameWc(e), chips: ['TELEGRAM'] };
          break;
        case 'tg_break': s = { k: 'off', title: 'BREAK', sub: fmtDur((e.n || 0) * 1000) }; break;
        case 'engine_on':
          curMode = e.mode === 'auto' ? 'auto' : 'manual';
          s = { k: 'engine', title: (ENG[e.eng] || e.eng || 'ENGINE') + ' ENGINE',
                sub: [e.model ? 'Model ' + e.model : '', curMode.toUpperCase()].filter(Boolean).join(' · '),
                chips: e.likeOn ? ['LIKE ON'] : [] };
          break;
        case 'engine_off': s = { k: 'off', title: (ENG[e.eng] || e.eng || 'ENGINE') + ' OFF', sub: fmtClock(e.t) }; break;
        case 'mode': curMode = e.mode === 'auto' ? 'auto' : 'manual'; s = { k: 'off', title: 'MODE → ' + curMode.toUpperCase(), sub: ENG[e.eng] || '' }; break;
        case 'wc_visit': {   // Follow By Wallchain Score opened a profile
          const T = { followed: 'FOLLOWED', already: 'ALREADY FOLLOWED' };
          s = { k: e.why === 'followed' ? 'follow' : 'wcvisit', title: T[e.why] || 'PROFILE VISITED', sub: nameWc(e), chips: [ENG[e.eng] || '', 'WALLCHAIN'].filter(Boolean) };
          break;
        }
        case 'job': s = { k: 'engine', title: (e.name || 'JOB') + ' STARTED', sub: fmtClock(e.t) }; break;
        case 'job_end': s = { k: 'off', title: (e.name || 'JOB') + ' STOPPED', sub: e.why || fmtClock(e.t) }; break;
        case 'like': {
          // Like + Comment on the same post = one step (the pair the engine does per post)
          let j = i + 1, hit = null;
          while (j < ev.length && ev[j].t - e.t < 240000) {
            if (ev[j].type === 'comment') { hit = ev[j]; break; }
            if (ev[j].type === 'like' || ev[j].type === 'shutdown') break;
            j++;
          }
          if (hit && (!e.link || !hit.link || e.link === hit.link)) {
            comments++; sinceLink = true;
            const saved = ev[j + 1] && ev[j + 1].type === 'save';
            s = { k: 'lc', title: 'LIKE + COMMENT', sub: nameWc(hit.wc != null ? hit : e, hit.h || e.h) + ' · #' + comments, mode: hit.mode, chips: [(hit.mode || curMode).toUpperCase(), ENG[hit.eng] || ''].concat(saved ? ['SAVED'] : []) };
            i = j + (saved ? 2 : 1);
            s.t = hit.t; steps.push(s); continue;
          }
          s = { k: 'like', title: 'LIKE POST', sub: nameWc(e) };
          break;
        }
        case 'comment': {
          comments++; sinceLink = true;
          const saved = ev[i + 1] && ev[i + 1].type === 'save';
          s = { k: 'comment', title: 'COMMENT', sub: (nameWc(e)) + ' · #' + comments, mode: e.mode, chips: [(e.mode || curMode).toUpperCase(), ENG[e.eng] || ''].concat(saved ? ['SAVED'] : []) };
          if (saved) { s.t = e.t; steps.push(s); i += 2; continue; }
          break;
        }
        case 'save': break; // shown as a SAVED chip on the comment step
        case 'goal': s = { k: 'goal', title: 'GOAL REACHED', sub: (ENG[e.eng] || '') + (e.why === 'time' ? ' · time limit' : ' · reply goal') }; break;
        case 'stuck':
          s = e.why === 'hard'
            ? { k: 'warn', title: 'STUCK → PAGE RELOAD', sub: 'stuck again · reloading to restart', chips: e.name ? ['NET ' + e.name] : [] }
            : { k: 'warn', title: 'STUCK → SOFT FIX', sub: 'no progress for 1 min · hung post skipped · engine restarted' + (e.n ? ' (#' + e.n + ')' : ''), chips: e.name ? ['NET ' + e.name] : [] };
          break;
        case 'skip': {
          const SW = { no_get_reply: 'GET Reply did not appear · retried · post skipped', stuck: 'engine hung on this post · post skipped', failed: 'reply failed · post skipped' };
          s = { k: 'warn', title: 'POST SKIPPED', sub: (e.h ? e.h + ' · ' : '') + (SW[e.why] || 'moved on to the next post'), chips: [ENG[e.eng] || ''].filter(Boolean) };
          break;
        }
        case 'lost':
          s = { k: 'warn', title: 'MISCLICK / WRONG PAGE', sub: e.why === 'return' ? 'went back to the last good page' : 'going back' + (e.h ? ' · ' + e.h : '') };
          break;
        case 'net': {
          const T = { offline: ['NETWORK OFFLINE', 'engines wait for the connection'], online: ['BACK ONLINE', 'engines continue'], slow: ['NETWORK SLOW', 'more patience before "stuck"'], recovered: ['NETWORK OK', 'back to normal speed'] }[e.why];
          if (T) s = { k: e.why === 'online' || e.why === 'recovered' ? 'resume' : 'warn', title: T[0], sub: T[1] + (e.n && e.n < 8000 ? ' · ' + e.n + 'ms' : '') };
          break;
        }
        case 'safety': s = { k: 'warn', title: 'SAFETY STOP', sub: (e.n || 3) + '× "Something went wrong" in this session · all engines stopped · take a break', chips: ['AUTO STOP'] }; break;
        case 'refresh': s = { k: 'refresh', title: 'REFRESH', sub: 'system takes a refresh' }; break;
        case 'resume': s = { k: 'resume', title: 'CONTINUE', sub: 'engine resumed' }; break;
        case 'shutdown': s = { k: 'end', title: 'TRACK OVER', sub: WHY[e.why] || 'Closed', chips: ['DATA SAVED'] }; break;
        default: break;
      }
      if (s) { if (s.t == null) s.t = e.t; steps.push(s); }
      i++;
    }
    return { steps, comments, likes: ev.filter((x) => x.type === 'like').length, refreshes: ev.filter((x) => x.type === 'refresh').length, fixes: ev.filter((x) => x.type === 'stuck' || x.type === 'lost' || x.type === 'skip').length, mode: curMode };
  }

  // ── drawing ───────────────────────────────────────────────────
  function nodeEl(s) {
    const n = el('div', 'zm-node zm-k-' + s.k);
    n.appendChild(el('div', 'zm-t', s.title));
    if (s.sub) n.appendChild(el('div', 'zm-s', s.sub));
    if (s.chips && s.chips.filter(Boolean).length) {
      const c = el('div', 'zm-chips');
      s.chips.filter(Boolean).forEach((x) => c.appendChild(el('span', 'zm-chip' + (x === 'SAVED' || x === 'DATA SAVED' ? ' ok' : ''), x)));
      n.appendChild(c);
    }
    return n;
  }
  function connEl(prev, next, mode) {
    const c = el('div', 'zm-conn');
    c.appendChild(el('div', 'zm-fill'));
    const gap = next.t - prev.t;
    const acting = /^(lc|like|comment)$/.test(next.k) || /^(open|resume|engine)$/.test(prev.k);
    if (next.k === 'tglink' && gap >= 5000) {
      c.classList.add('zm-has-br');
      c.appendChild(el('div', 'zm-br r', 'WAITING · ' + fmtDur(gap)));
    } else if (gap >= 15000 && acting && next.k !== 'end' && prev.k !== 'goal' && prev.k !== 'tglink') {
      const m = (next.mode || mode) === 'auto';
      c.classList.add('zm-has-br');
      c.appendChild(el('div', 'zm-br ' + (m ? 'r' : 'l'), (m ? 'SCROLLING · ' : 'JUST SITTING · ') + fmtDur(gap)));
    }
    return c;
  }

  function fillSelect() {
    const prev = selectedId;
    sel.textContent = '';
    const runs = data.runs.slice().reverse();
    runs.forEach((r) => {
      const live = r.id === data.activeId;
      const o = el('option', '', fmtDay(r.startTs) + ' · ' + (live ? 'LIVE' : (SHORT[r.endReason] || 'done')));
      o.value = r.id; sel.appendChild(o);
    });
    if (!runs.length) { selectedId = null; return; }
    selectedId = runs.some((r) => r.id === prev) ? prev : runs[0].id;
    sel.value = selectedId;
  }

  function render() {
    stopPlay();
    fillSelect();
    flow.textContent = ''; stats.textContent = '';
    flow.classList.remove('zm-playing');
    const run = data.runs.find((r) => r.id === selectedId);
    $('zmPlay').disabled = !run;
    if (!run) {
      flow.appendChild(el('div', 'zm-empty', 'No runs yet. Turn on an engine and open x.com — the map starts by itself and saves every step.'));
      return;
    }
    const b = buildSteps(run);
    const live = run.id === data.activeId;
    const end = run.endTs || Date.now();
    const runErrs = errLog.filter((x) => x.ts >= run.startTs - 1000 && x.ts <= end + 5000);
    [['LIKES', b.likes], ['COMMENTS', b.comments], ['REFRESH', b.refreshes]].concat(b.fixes ? [['FIXES', b.fixes]] : []).concat([['ERRORS', runErrs.length]]).concat([['TIME', fmtDur(end - run.startTs)]]).forEach((p) => {
      const c = el('div', 'zm-stat'); c.appendChild(el('b', '', String(p[1]))); c.appendChild(el('span', '', p[0]));
      if (p[0] === 'ERRORS') {
        c.style.cursor = 'pointer'; c.style.borderColor = runErrs.length ? '#ef4444' : ''; if (runErrs.length) c.firstChild.style.color = '#ef4444';
        c.title = 'Tap: total error view'; c.addEventListener('click', () => { errOpen = !errOpen; render(); });
      }
      stats.appendChild(c);
    });
    if (errOpen) {
      const box = el('div', '');
      box.style.cssText = 'width:100%;flex-basis:100%;margin-top:6px;max-height:190px;overflow-y:auto;background:var(--dark2);border:1px solid #ef4444;border-radius:8px;padding:6px 8px;font-size:10px;line-height:1.5;';
      box.appendChild(el('div', '', 'TOTAL ERRORS — this session (' + runErrs.length + ')')).style.cssText = 'font-weight:800;color:#ef4444;margin-bottom:4px;';
      if (!runErrs.length) box.appendChild(el('div', '', 'No errors in this session.'));
      runErrs.forEach((x) => {
        const row = el('div', ''); row.style.cssText = 'padding:3px 0;border-bottom:1px solid rgba(239,68,68,.15);word-break:break-word;';
        const a = el('span', '', fmtClock(x.ts) + ' '); a.style.opacity = '.6'; const b2 = el('b', '', (x.eng || '?') + ' '); const m = el('span', '', x.msg || ''); m.style.color = '#ef4444';
        row.appendChild(a); row.appendChild(b2); row.appendChild(m); box.appendChild(row);
      });
      stats.appendChild(box);
    }

    let steps = b.steps;
    let hidden = 0;
    if (steps.length > 160) { hidden = steps.length - 150; steps = steps.slice(0, 2).concat([{ k: 'off', title: '… ' + hidden + ' EARLIER STEPS', sub: 'still saved in Export', t: steps[2].t }], steps.slice(-148)); }

    steps.forEach((s, idx) => {
      if (idx > 0) flow.appendChild(connEl(steps[idx - 1], s, b.mode));
      flow.appendChild(nodeEl(s));
    });
    if (live) {
      flow.appendChild(el('div', 'zm-conn')).appendChild(el('div', 'zm-fill'));
      const n = el('div', 'zm-node zm-k-live'); n.appendChild(el('div', 'zm-t', 'RUNNING…')); n.appendChild(el('div', 'zm-s', 'tracking live')); flow.appendChild(n);
    }
  }

  // ── animated replay ───────────────────────────────────────────
  function stopPlay() { if (timer) { clearTimeout(timer); timer = null; } flow.classList.remove('zm-playing'); }
  function play() {
    if (!flow.children.length || flow.querySelector('.zm-empty')) return;
    stopPlay();
    const kids = Array.from(flow.children);
    flow.classList.add('zm-playing');
    kids.forEach((k) => { k.classList.add('zm-hide'); k.classList.remove('zm-run', 'zm-pop'); });
    let i = 0;
    (function step() {
      if (i >= kids.length) { timer = null; setTimeout(() => flow.classList.remove('zm-playing'), 500); return; }
      const k = kids[i++];
      k.classList.remove('zm-hide');
      let wait = 260;
      if (k.classList.contains('zm-conn')) { void k.offsetWidth; k.classList.add('zm-run'); wait = k.classList.contains('zm-has-br') ? 560 : 330; }
      else { k.classList.add('zm-pop'); try { k.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} wait = k.classList.contains('zm-k-end') ? 200 : 520; }
      timer = setTimeout(step, wait);
    })();
  }

  // ── export / import ───────────────────────────────────────────
  function doExport() {
    if (!data.runs.length) return;
    const d = new Date();
    const name = 'zex-workflow-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.json';
    const blob = new Blob([JSON.stringify({ app: 'ZEX', kind: 'workflow-map', v: 1, exportedAt: Date.now(), runs: data.runs }, null, 1)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    note('Exported ' + data.runs.length + ' run' + (data.runs.length === 1 ? '' : 's'));
  }
  function note(msg) { const n = $('zmNote'); if (!n) return; n.textContent = msg; setTimeout(() => { if (n.textContent === msg) n.textContent = ''; }, 3500); }
  function doImport(file) {
    if (!file) return;
    const fr = new FileReader();
    fr.onload = () => {
      let obj = null;
      try { obj = JSON.parse(String(fr.result || '')); } catch (e) {}
      if (!obj || !Array.isArray(obj.runs)) { note('Not a ZEX workflow file'); return; }
      chrome.runtime.sendMessage({ type: 'zexTrackImport', payload: obj }, (res) => {
        void chrome.runtime.lastError;
        note(res && res.ok ? 'Imported ' + res.added + ' new run' + (res.added === 1 ? '' : 's') : 'Import failed');
      });
    };
    fr.onerror = () => note('Could not read the file');
    fr.readAsText(file);
  }

  // ── wiring ────────────────────────────────────────────────────
  function load() {
    chrome.storage.local.get([KEY], (d) => {
      const s = d && d[KEY];
      data = s && Array.isArray(s.runs) ? s : { runs: [], activeId: null };
      render();
    });
  }
  sel.addEventListener('change', () => { selectedId = sel.value; render(); });
  $('zmPlay').addEventListener('click', play);
  $('zmExport').addEventListener('click', doExport);
  $('zmImport').addEventListener('click', () => $('zmFile').click());
  $('zmFile').addEventListener('change', (e) => { doImport(e.target.files && e.target.files[0]); e.target.value = ''; });

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !ch[KEY]) return;
    if (timer || flow.classList.contains('zm-playing')) return; // don't disturb a replay
    clearTimeout(renderTimer);
    renderTimer = setTimeout(load, 250);
  });
  document.querySelectorAll('.nav-tab').forEach((b) => b.addEventListener('click', () => { if (b.dataset.tabpanel === 'tabPanelSystem') load(); }));
  load();
})();
