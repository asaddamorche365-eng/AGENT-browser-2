// Z EX — Backup & FAQ page (full tab). Export / import everything in chrome.storage.local.
(function () {
  // embedded in the extension (iframe)? hide our own header and tell the parent how tall we are
  if (/[?&]embed=1/.test(location.search) && window.parent !== window) {
    document.documentElement.classList.add('embed');
    const tell = () => { try { window.parent.postMessage({ zexHubH: document.documentElement.scrollHeight }, '*'); } catch (e) {} };
    window.addEventListener('load', tell);
    try { new ResizeObserver(tell).observe(document.body); } catch (e) { setInterval(tell, 800); }
  }
  const $ = (id) => document.getElementById(id);
  const pad = (n) => String(n).padStart(2, '0');
  const BAD_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

  // Never exported / never restored: live run state & ON/OFF switches (so nothing starts by itself),
  // device binding and one-time payment state.
  const VOLATILE = new Set(['zenTgActive','zenTgWidgetArmed','zenTgSweepArmed','zenTgSweepState','zenSearchCollectOn','zenSearchCollectCfg','zenSearchCollectState','zTarJob','zFollowJob','zSessAutoJobs',
    'zenUnfRun','zenUnfStats','zenRepMode','zexDebugLog','zDeviceId','zexpayIntent','xVerifyMuteUntil','xVerifyFailCount','zenRepSavedLink']);
  const VOLATILE_RE = /EngineOn$/;
  const isVolatile = (k) => VOLATILE.has(k) || VOLATILE_RE.test(k);

  const GROUPS = [
    { id: 'history', name: 'History & stats', sub: 'Replies, skip log, daily log, counters', keys: ['zenReplyHistory','zenSkipLog','zenDailyLog','zenRecentReplies','zenRepliedStatusIds','zenRepliedBy','zenGetReplyClicks','zenReplyCount','zenFeedDraftCount','zenSearchDraftCount','zenRepDraftCount','zenGivDraftCount','zenTarEngagedCount','zenAgentStats','zenAgentDayLog','zenDgaChartMode','zenPostTags','zenAgentResume'], histMerge: true },
    { id: 'workflow', name: 'Workflow map runs', sub: 'Past runs shown in Support and System', keys: ['zexTrack'] },
    { id: 'style', name: 'Style & voice', sub: 'Trained styles, your examples', keys: ['zenTrainedStyles','zenStyleExamples','zenActiveStyleId','replyStyle','zenRagMode'] },
    { id: 'keywords', name: 'Keywords & filters', sub: 'Search / GIV / FED keywords, filters', keys: ['zenSearchKeywords','zenGivKeywords','zenFeedTargetKeywords','zenFeedTargetFilterOn','zenSearchFilters','zenSearchRawOn','zenSearchRawQuery','zenProfVisit','zenSearchAgeFilter'] },
    { id: 'telegram', name: 'Telegram', sub: 'Saved folders, swept links, timing', keys: ['zenTgSweepFolders','zenTgSweepDone','zenTgSweepDelayMin','zenTgSweepDelayMax','zenTgTiming','zenTgBreak','zenTgLikeOn'], histMerge: true },
    { id: 'settings', name: 'All other settings', sub: 'Tone, engines config, cursor, templates…', keys: null },
    { id: 'creds', name: 'Login & proxy', sub: 'Login session, proxy server + password', keys: ['zenDeviceSession','zexpayMe','zenProxyConfig'], warn: true, off: true }
  ];
  const CAPS = { zenReplyHistory: 300, zenSkipLog: 300 };

  function groupOf(key) {
    for (const g of GROUPS) if (g.keys && g.keys.indexOf(key) >= 0) return g.id;
    return 'settings';
  }
  const sizeOf = (v) => { try { return JSON.stringify(v).length; } catch (e) { return 0; } };
  const fmtSize = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(2) + ' MB';
  const count = (v) => Array.isArray(v) ? v.length : (v && typeof v === 'object') ? Object.keys(v).length : 1;
  function say(el, text, cls) { el.textContent = text; el.className = 'msg' + (cls ? ' ' + cls : ''); }
  const get = (keys) => new Promise((res) => chrome.storage.local.get(keys, (d) => { void chrome.runtime.lastError; res(d || {}); }));
  const set = (obj) => new Promise((res) => chrome.storage.local.set(obj, () => { const e = chrome.runtime.lastError; res(e ? e.message : null); }));

  // bucket a flat {key: value} object into groups → { gid: {keys:[], items:n, size:n} }
  function bucket(data) {
    const out = {};
    GROUPS.forEach((g) => { out[g.id] = { keys: [], items: 0, size: 0 }; });
    Object.keys(data).forEach((k) => {
      if (BAD_KEYS.has(k) || isVolatile(k)) return;
      const b = out[groupOf(k)];
      b.keys.push(k); b.items += count(data[k]); b.size += sizeOf(data[k]);
    });
    return out;
  }
  function renderGroups(box, buckets, opts) {
    box.innerHTML = '';
    GROUPS.forEach((g) => {
      const b = buckets[g.id];
      const empty = !b || !b.keys.length;
      const row = document.createElement('label');
      row.className = 'grp' + (g.warn ? ' warn' : '') + (empty ? ' dis' : '');
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.value = g.id;
      cb.checked = !empty && !g.off;
      const n = document.createElement('span'); n.className = 'n';
      n.innerHTML = '<span></span><small></small>';
      n.firstChild.textContent = g.name;
      n.lastChild.textContent = g.warn ? 'Keep this file private — it can log someone in' : g.sub;
      const c = document.createElement('span'); c.className = 'c';
      c.textContent = empty ? '—' : b.items + ' · ' + fmtSize(b.size);
      row.append(cb, n, c); box.appendChild(row);
    });
  }
  const picked = (box) => Array.from(box.querySelectorAll('input:checked')).map((x) => x.value);

  // ── load + summary ────────────────────────────────────────────
  let live = {};
  async function refresh() {
    live = await get(null);
    const b = bucket(live);
    let items = 0, size = 0, keys = 0;
    Object.keys(b).forEach((g) => { items += b[g].items; size += b[g].size; keys += b[g].keys.length; });
    $('stSummary').textContent = keys ? keys + ' data keys · ' + items + ' items · about ' + fmtSize(size) : 'Nothing stored yet.';
    renderGroups($('exGroups'), b);
  }

  // ── export ────────────────────────────────────────────────────
  $('exBtn').addEventListener('click', async () => {
    await refresh();
    const sel = picked($('exGroups'));
    if (!sel.length) { say($('exMsg'), 'Pick at least one item.', 'err'); return; }
    const data = {};
    Object.keys(live).forEach((k) => {
      if (BAD_KEYS.has(k) || isVolatile(k)) return;
      if (sel.indexOf(groupOf(k)) >= 0) data[k] = live[k];
    });
    const n = Object.keys(data).length;
    if (!n) { say($('exMsg'), 'Nothing to export in those items.', 'err'); return; }
    const payload = { app: 'ZEX', kind: 'full-backup', v: 1, ext: chrome.runtime.getManifest().version, exportedAt: Date.now(), groups: sel, data };
    const d = new Date();
    const name = 'zex-backup-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.json';
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    say($('exMsg'), 'Downloaded ' + name + ' (' + n + ' keys).', 'ok');
  });

  // ── import ────────────────────────────────────────────────────
  let pending = null;
  $('imPick').addEventListener('click', () => $('imFile').click());
  $('imFile').addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0]; e.target.value = '';
    if (!f) return;
    const fr = new FileReader();
    fr.onerror = () => say($('imMsg'), 'Could not read that file.', 'err');
    fr.onload = () => {
      let obj = null;
      try { obj = JSON.parse(String(fr.result || '')); } catch (x) {}
      if (!obj || obj.app !== 'ZEX' || obj.kind !== 'full-backup' || !obj.data || typeof obj.data !== 'object' || Array.isArray(obj.data)) {
        pending = null; ['imInfo', 'imMode', 'imBtn'].forEach((i) => { $(i).hidden = true; }); $('imGroups').innerHTML = '';
        say($('imMsg'), 'This is not a Z EX backup file.', 'err'); return;
      }
      const data = {};
      Object.keys(obj.data).forEach((k) => { if (!BAD_KEYS.has(k) && !isVolatile(k)) data[k] = obj.data[k]; });
      pending = data;
      const b = bucket(data);
      const when = obj.exportedAt ? new Date(obj.exportedAt).toLocaleString() : 'unknown date';
      $('imInfo').textContent = 'Backup from ' + when + (obj.ext ? ' · Z EX v' + obj.ext : '') + ' · ' + Object.keys(data).length + ' keys';
      $('imInfo').hidden = false; $('imMode').hidden = false; $('imBtn').hidden = false;
      renderGroups($('imGroups'), b);
      say($('imMsg'), 'Choose what to restore, then tap IMPORT.', '');
    };
    fr.readAsText(f);
  });

  const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
  const itemKey = (x) => { if (x && typeof x === 'object') { if (x.id != null) return 'id:' + x.id; try { return JSON.stringify(x); } catch (e) { return String(Math.random()); } } return typeof x + ':' + x; };
  const itemTs = (x) => x && typeof x === 'object' ? (+x.ts || +x.t || +x.time || 0) : 0;

  function mergeVal(key, cur, inc, hist) {
    if (cur === undefined || cur === null) return inc;
    if (Array.isArray(cur) && Array.isArray(inc)) {
      const seen = new Set(), out = [];
      cur.concat(inc).forEach((x) => { const k = itemKey(x); if (!seen.has(k)) { seen.add(k); out.push(x); } });
      if (out.some((x) => itemTs(x))) out.sort((a, b) => itemTs(b) - itemTs(a));
      return CAPS[key] ? out.slice(0, CAPS[key]) : out;
    }
    if (isObj(cur) && isObj(inc)) return hist ? Object.assign({}, inc, cur) : Object.assign({}, cur, inc);
    if (typeof cur === 'number' && typeof inc === 'number' && hist) return Math.max(cur, inc);
    return inc;
  }

  $('imBtn').addEventListener('click', async () => {
    if (!pending) return;
    const sel = picked($('imGroups'));
    if (!sel.length) { say($('imMsg'), 'Pick at least one item.', 'err'); return; }
    if (sel.indexOf('creds') >= 0 && !confirm('You are restoring login/proxy details. Only do this with your own backup. Continue?')) return;
    const mode = (document.querySelector('input[name="mode"]:checked') || {}).value || 'merge';
    $('imBtn').disabled = true;
    try {
      const keys = Object.keys(pending).filter((k) => sel.indexOf(groupOf(k)) >= 0);
      const cur = await get(keys.filter((k) => k !== 'zexTrack'));
      const histOf = (k) => { const g = GROUPS.find((x) => x.id === groupOf(k)); return !!(g && g.histMerge); };
      const out = {};
      let runsAdded = null;
      keys.forEach((k) => {
        if (k === 'zexTrack') return;
        out[k] = mode === 'replace' ? pending[k] : mergeVal(k, cur[k], pending[k], histOf(k));
      });
      const err = Object.keys(out).length ? await set(out) : null;
      if (err) { say($('imMsg'), 'Import failed: ' + err, 'err'); return; }
      if (keys.indexOf('zexTrack') >= 0 && pending.zexTrack && Array.isArray(pending.zexTrack.runs)) {
        runsAdded = await new Promise((res) => chrome.runtime.sendMessage({ type: 'zexTrackImport', payload: pending.zexTrack }, (r) => { void chrome.runtime.lastError; res(r && r.ok ? r.added : 0); }));
      }
      await refresh();
      say($('imMsg'), 'Done. Restored ' + Object.keys(out).length + ' keys' + (runsAdded !== null ? ' + ' + runsAdded + ' workflow runs' : '') + '. Reopen the popup and refresh your X tab to see everything.', 'ok');
    } catch (e) {
      say($('imMsg'), 'Import failed: ' + (e && e.message || e), 'err');
    } finally { $('imBtn').disabled = false; }
  });

  // ── tabs ──────────────────────────────────────────────────────
  document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === t));
    document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('active', p.id === t.dataset.p));
    try { history.replaceState(null, '', '#' + (t.dataset.p === 'pFaq' ? 'faq' : 'backup')); } catch (e) {}
  }));
  if (location.hash === '#faq') document.querySelector('.tab[data-p="pFaq"]').click();

  // ── FAQ ───────────────────────────────────────────────────────
  function renderFaq(q) {
    const box = $('faqList'); box.innerHTML = '';
    const needle = (q || '').trim().toLowerCase();
    (window.ZEX_FAQ || []).forEach((g) => {
      const items = g.items.filter((it) => !needle || (it[0] + ' ' + it[1]).toLowerCase().indexOf(needle) >= 0);
      if (!items.length) return;
      const h = document.createElement('div'); h.className = 'fgrp'; h.textContent = g.group; box.appendChild(h);
      items.forEach((it) => {
        const d = document.createElement('details'); d.className = 'q'; if (needle) d.open = true;
        const s = document.createElement('summary'); s.textContent = it[0];
        const a = document.createElement('div'); a.className = 'a'; a.innerHTML = it[1];
        d.append(s, a); box.appendChild(d);
      });
    });
    if (!box.children.length) box.innerHTML = '<div class="hint">No match. Try another word.</div>';
  }
  $('faqSearch').addEventListener('input', (e) => renderFaq(e.target.value));
  renderFaq('');
  refresh();

  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local') { clearTimeout(refresh._t); refresh._t = setTimeout(refresh, 600); } });
})();
