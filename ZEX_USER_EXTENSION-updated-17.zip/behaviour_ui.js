/* Z EX — Behaviour profiles (popup).
   A profile = one bundle of "how the extension acts": Timing presets + typing / click / safety / ZEX+ / like switches.
   Tap APPLY and every one of those settings changes at once; the engines pick the new values up by themselves.
   Login, keys, keywords, lists, tone and style are NEVER touched by a profile.
   Storage: zexBehProfiles = [{id,name,vals}] (your own profiles), zexBehActive = id of the last applied profile. */
(function () {
  'use strict';
  var PK = 'zexBehProfiles', AK = 'zexBehActive', TK = 'zexTiming';

  // flat storage keys a profile controls  (key → value used when the profile says nothing = default OFF)
  var FLAT = {
    zen_cdp_click: false, zen_type_mode: false, zen_type_style: 'style',
    zexEs1On: false, zexEs2On: false, zexEs2Pct: 30, zexHardRefreshOn: false,
    zenSweepAutoRetry: { on: true, max: 2 },
    zexplus_focus: false, zexplus_key: false, zexplus_touch: false, zexplus_idle: false, zexplus_net: 'off',
    zenFeedLikeOn: false, zenSearchLikeOn: false, zenGivLikeOn: false
  };
  var FKEYS = Object.keys(FLAT);

  function tm(c, t, f, a, u) {
    var g = {}; g.comment = { mode: c }; g.tg = { mode: t }; g.follow = { mode: f }; g.tar = { mode: a }; g.unf = { mode: u };
    return { ui: 'advanced', g: g };
  }
  function mk(over, timing) { var v = {}; FKEYS.forEach(function (k) { v[k] = JSON.parse(JSON.stringify(FLAT[k])); }); Object.keys(over).forEach(function (k) { v[k] = over[k]; }); return { flat: v, timing: timing }; }

  var BUILT = [
    { id: 'b_safe', name: 'SAFE', icon: '🛡', desc: 'Slowest and most careful. Long gaps, breaks, human typing, all safety on. Best for a new or valuable account.',
      vals: mk({ zen_cdp_click: true, zen_type_mode: true, zexEs1On: true, zexEs2On: true, zexEs2Pct: 50, zexHardRefreshOn: true, zenFeedLikeOn: true, zenSearchLikeOn: true, zenGivLikeOn: true }, tm('slow', 'slow', 'slow', 'slow', 'slow')) },
    { id: 'b_balanced', name: 'BALANCED', icon: '⚖', desc: 'Normal pace with human typing and the safety nets. A good everyday setting.',
      vals: mk({ zen_cdp_click: true, zen_type_mode: true, zexEs1On: true, zexHardRefreshOn: true, zenFeedLikeOn: true, zenSearchLikeOn: true }, tm('fast', 'fast', 'slow', 'slow', 'slow')) },
    { id: 'b_fast', name: 'FAST', icon: '🚀', desc: 'Flash Lite speed for comments (quick but human-looking), fast gaps for follow / unfollow. Safety nets stay on.',
      vals: mk({ zen_cdp_click: true, zexEs1On: true, zexHardRefreshOn: true }, tm('flashlite', 'flashlite', 'fast', 'fast', 'fast')) },
    { id: 'b_flash', name: 'FLASH', icon: '⚡', desc: 'Maximum speed, no breaks, no extras. Fastest possible but X may limit the account. Use carefully.',
      vals: mk({}, tm('flash', 'flash', 'fast', 'fast', 'fast')) },
    { id: 'b_stealth', name: 'STEALTH PHONE', icon: '🕶', desc: 'For Kiwi / phone runs in the background: slow pace, real (trusted) keystrokes and taps, hidden tabs act focused, screen stays awake. Shows the "being debugged" bar.',
      vals: mk({ zen_cdp_click: true, zen_type_mode: true, zen_type_style: 'live', zexEs1On: true, zexHardRefreshOn: true, zexplus_focus: true, zexplus_key: true, zexplus_touch: true, zexplus_idle: true, zenFeedLikeOn: true, zenSearchLikeOn: true }, tm('slow', 'slow', 'slow', 'slow', 'slow')) }
  ];

  var $ = function (id) { return document.getElementById(id); };
  var host, custom = [], active = '', cur = null, editing = '';
  var get = function (k) { return new Promise(function (r) { chrome.storage.local.get(k, r); }); };
  var set = function (o) { return new Promise(function (r) { chrome.storage.local.set(o, r); }); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var same = function (a, b) { try { return JSON.stringify(a) === JSON.stringify(b); } catch (e) { return false; } };

  // ── read the current settings as a profile "vals" object ──
  async function snapshot() {
    var d = await get(FKEYS.concat([TK]));
    var flat = {};
    FKEYS.forEach(function (k) {
      var v = d[k]; if (v === undefined) v = FLAT[k];
      if (typeof FLAT[k] === 'boolean') v = v === true;
      flat[k] = v;
    });
    return { flat: flat, timing: d[TK] && typeof d[TK] === 'object' ? d[TK] : null };
  }
  function timingModes(t) {
    if (!t || !t.g) return null;
    return ['comment', 'tg', 'follow', 'tar', 'unf'].map(function (k) { return t.g[k] && t.g[k].mode || 'fast'; });
  }
  function matches(vals, snap) {
    if (!same(vals.flat, snap.flat)) return false;
    if (!vals.timing) return true;
    var a = timingModes(vals.timing), b = timingModes(snap.timing);
    return !!b && snap.timing.ui === 'advanced' && same(a, b);
  }

  // ── apply ──
  async function apply(p) {
    var o = {};
    FKEYS.forEach(function (k) { var v = p.vals.flat && p.vals.flat[k]; o[k] = v === undefined ? FLAT[k] : v; });
    o[AK] = p.id;
    await set(o);
    if (p.vals.timing && window.ZexTiming && window.ZexTiming.applyProfile) await window.ZexTiming.applyProfile(p.vals.timing);
    if (o.zexplus_idle && chrome.permissions) {   // keep-awake needs these optional permissions; this click is the user gesture
      try { chrome.permissions.request({ permissions: ['idle'] }, function () { void chrome.runtime.lastError; }); } catch (e) {}
      try { chrome.permissions.request({ permissions: ['power'] }, function () { void chrome.runtime.lastError; }); } catch (e) {}
    }
    say('✓ ' + p.name + ' applied — refreshing the settings…', 'ok');
    setTimeout(function () { location.reload(); }, 700);   // every control in the popup re-reads its saved value
  }

  // ── storage of own profiles ──
  async function load() {
    var d = await get([PK, AK]);
    custom = Array.isArray(d[PK]) ? d[PK].filter(function (p) { return p && p.id && p.vals; }) : [];
    active = d[AK] || '';
    cur = await snapshot();
  }
  function saveCustom() { return set({ zexBehProfiles: custom }); }
  var uid = function () { return 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); };
  function all() { return BUILT.concat(custom); }

  // ── UI ──
  var st = null;
  function say(t, cls) {
    var el = $('behMsg'); if (!el) return;
    el.textContent = t; el.className = 'verify-status ' + (cls || '');
    clearTimeout(st); if (t && cls !== 'ok') st = setTimeout(function () { el.textContent = ''; }, 4000);
  }
  function chips(v) {
    var f = v.flat || {}, c = [], m = timingModes(v.timing);
    if (m) c.push('Timing: ' + (m[0] === 'flashlite' ? 'FLASH LITE' : m[0].toUpperCase()) + (new Set(m.slice(2)).size === 1 && m[2] !== m[0] ? ' · gaps ' + m[2].toUpperCase() : ''));
    if (f.zen_type_mode) c.push('Human typing' + (f.zen_type_style === 'live' ? ' (live)' : ''));
    if (f.zen_cdp_click) c.push('Stealth click');
    if (f.zexEs1On) c.push('Safety 1');
    if (f.zexEs2On) c.push('Safety 2 · ' + f.zexEs2Pct + '%');
    if (f.zexHardRefreshOn) c.push('Hard refresh');
    if (f.zexplus_focus) c.push('Focus lock');
    if (f.zexplus_key) c.push('Trusted typing');
    if (f.zexplus_touch) c.push('Touch tap');
    if (f.zexplus_idle) c.push('Keep awake');
    if (f.zexplus_net && f.zexplus_net !== 'off') c.push('Net ' + f.zexplus_net);
    if (f.zenFeedLikeOn || f.zenSearchLikeOn || f.zenGivLikeOn) c.push('Likes');
    return c;
  }
  function css() {
    if ($('behCss')) return;
    var s = document.createElement('style'); s.id = 'behCss';
    s.textContent =
      '.beh-card{border:1.5px solid var(--border,#ececec);border-radius:14px;background:var(--dark3,#fff);padding:12px;margin:0 0 10px}' +
      '.beh-card.on{border-color:#eab308;box-shadow:0 0 0 2px rgba(234,179,8,.18)}' +
      '.beh-top{display:flex;align-items:center;gap:8px}.beh-ic{font-size:20px;line-height:1}' +
      '.beh-name{font:800 13px Poppins,sans-serif;color:var(--text,#17181a);letter-spacing:.3px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
      '.beh-tag{font:700 9px Poppins,sans-serif;padding:2px 7px;border-radius:99px;background:#eab308;color:#17181a}' +
      '.beh-tag.mod{background:transparent;border:1px solid #eab308;color:#ca8a04}' +
      '.beh-desc{font:500 11px/1.45 Poppins,sans-serif;color:var(--dim,#8a8d93);margin:6px 0}' +
      '.beh-chips{display:flex;flex-wrap:wrap;gap:4px;margin:6px 0 8px}' +
      '.beh-chip{font:600 9.5px Poppins,sans-serif;padding:2px 7px;border-radius:99px;background:var(--dark2,#f7f7f5);color:var(--text,#17181a);border:1px solid var(--border,#ececec)}' +
      '.beh-btns{display:flex;gap:6px;flex-wrap:wrap}' +
      '.beh-b{font:700 10.5px Poppins,sans-serif;padding:7px 12px;border-radius:9px;border:1.5px solid var(--border,#ececec);background:var(--dark2,#f7f7f5);color:var(--text,#17181a);cursor:pointer}' +
      '.beh-b.pri{background:#eab308;border-color:#eab308;color:#17181a}.beh-b.del{color:#dc2626}' +
      '.beh-b:disabled{opacity:.55;cursor:default}' +
      '.beh-in{width:100%;box-sizing:border-box;margin:6px 0}';
    document.head.appendChild(s);
  }
  function card(p, builtin) {
    var on = p.id === active, drift = on && cur && !matches(p.vals, cur);
    var h = '<div class="beh-card' + (on ? ' on' : '') + '" data-id="' + esc(p.id) + '"><div class="beh-top"><span class="beh-ic">' + (p.icon || '🎛') + '</span>';
    if (editing === p.id) h += '<input class="verify-input beh-in" id="behRen" maxlength="30" value="' + esc(p.name) + '" style="margin:0;flex:1">';
    else h += '<span class="beh-name">' + esc(p.name) + '</span>';
    if (on) h += '<span class="beh-tag">ACTIVE</span>' + (drift ? '<span class="beh-tag mod">CHANGED</span>' : '');
    h += '</div>';
    if (p.desc) h += '<div class="beh-desc">' + esc(p.desc) + '</div>';
    h += '<div class="beh-chips">' + chips(p.vals).map(function (c) { return '<span class="beh-chip">' + esc(c) + '</span>'; }).join('') + '</div>';
    h += '<div class="beh-btns"><button class="beh-b pri" data-a="apply" type="button">' + (on && !drift ? '✓ ACTIVE' : 'APPLY') + '</button>';
    if (!builtin) {
      h += editing === p.id ? '<button class="beh-b" data-a="rensave" type="button">SAVE NAME</button>' : '<button class="beh-b" data-a="ren" type="button">RENAME</button>';
      h += '<button class="beh-b" data-a="upd" type="button" title="Overwrite this profile with the settings the extension has right now">UPDATE FROM CURRENT</button>';
      h += '<button class="beh-b" data-a="exp" type="button">EXPORT</button><button class="beh-b del" data-a="del" type="button">DELETE</button>';
    }
    return h + '</div></div>';
  }
  function render() {
    if (!host) return;
    var act = all().filter(function (p) { return p.id === active; })[0];
    var h = '<div class="keyword-hint" style="margin:0 0 10px;">A <b>Behaviour</b> profile changes how the whole extension acts in one tap: Timing, typing, clicking, safety nets, ZEX+ tools and likes. ' +
      'Login, keys, keywords, lists, tone and style are never changed.</div>';
    h += '<div class="sec-label">Now running: ' + (act ? esc(act.name) + (cur && !matches(act.vals, cur) ? ' (changed since)' : '') : 'your own mix of settings') + '</div>';
    h += '<div class="sec-label" style="margin-top:12px;">Ready-made</div>' + BUILT.map(function (p) { return card(p, true); }).join('');
    h += '<div class="sec-label" style="margin-top:12px;">My profiles</div>';
    h += custom.length ? custom.map(function (p) { return card(p, false); }).join('') : '<div class="keyword-hint" style="margin:0 0 10px;">None yet. Set the extension up the way you like, then save it below.</div>';
    h += '<input class="verify-input beh-in" id="behName" maxlength="30" placeholder="Name for a new profile, e.g. Night run" autocomplete="off">';
    h += '<button class="save-all-btn" id="behSave" type="button" style="margin-top:4px;">＋ SAVE CURRENT SETTINGS AS A PROFILE</button>';
    h += '<div class="beh-btns" style="margin-top:8px;"><button class="beh-b" id="behImp" type="button">IMPORT PROFILE FILE</button><button class="beh-b" id="behExpAll" type="button">EXPORT ALL MY PROFILES</button><input type="file" id="behFile" accept="application/json,.json" hidden></div>';
    h += '<div class="verify-status" id="behMsg"></div>';
    host.innerHTML = h;
  }
  async function refresh() { await load(); render(); }

  function download(name, obj) {
    var b = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' }), u = URL.createObjectURL(b), a = document.createElement('a');
    a.href = u; a.download = name; a.click(); setTimeout(function () { URL.revokeObjectURL(u); }, 1000);
  }
  function clean(v) {   // only accept known keys / simple values from an imported file
    var out = { flat: {}, timing: null };
    FKEYS.forEach(function (k) {
      var x = v && v.flat ? v.flat[k] : undefined;
      if (typeof FLAT[k] === 'boolean') out.flat[k] = x === true;
      else if (k === 'zen_type_style') out.flat[k] = x === 'live' ? 'live' : 'style';
      else if (k === 'zexplus_net') out.flat[k] = ['fast3g', 'slow3g', '2g'].indexOf(x) >= 0 ? x : 'off';
      else if (k === 'zexEs2Pct') out.flat[k] = Math.min(100, Math.max(0, Math.round(Number(x)) || 30));
      else if (k === 'zenSweepAutoRetry') out.flat[k] = { on: !(x && x.on === false), max: Math.min(3, Math.max(1, Math.round(Number(x && x.max)) || 2)) };
    });
    var t = v && v.timing;
    if (t && t.g) {
      var ok = { comment: ['fast', 'slow', 'flash', 'flashlite'], tg: ['fast', 'slow', 'flash', 'flashlite'], follow: ['fast', 'slow'], tar: ['fast', 'slow'], unf: ['fast', 'slow'] };
      var g = {}; Object.keys(ok).forEach(function (k) { g[k] = { mode: t.g[k] && ok[k].indexOf(t.g[k].mode) >= 0 ? t.g[k].mode : 'fast' }; });
      out.timing = { ui: 'advanced', g: g };
    }
    return out;
  }

  function wire() {
    host.addEventListener('click', async function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.id === 'behSave') {
        var nm = ($('behName').value || '').trim().slice(0, 30);
        if (!nm) { say('Type a name first.', 'err'); return; }
        var snap = await snapshot();
        var p = { id: uid(), name: nm, vals: snap };
        custom.push(p); await saveCustom(); await set({ zexBehActive: p.id });
        say('✓ Saved "' + nm + '"', 'ok'); refresh(); return;
      }
      if (b.id === 'behImp') { $('behFile').click(); return; }
      if (b.id === 'behExpAll') { if (!custom.length) { say('No profiles of your own to export.', 'err'); return; } download('zex_behaviour_profiles.json', { zexBehaviour: 1, profiles: custom.map(function (p) { return { name: p.name, vals: p.vals }; }) }); return; }
      var c = b.closest('.beh-card'); if (!c || !b.dataset.a) return;
      var id = c.dataset.id, p = all().filter(function (x) { return x.id === id; })[0]; if (!p) return;
      var a = b.dataset.a;
      if (a === 'apply') { b.disabled = true; await apply(p); }
      else if (a === 'ren') { editing = id; render(); var r = $('behRen'); if (r) r.focus(); }
      else if (a === 'rensave') { var v = ($('behRen').value || '').trim().slice(0, 30); if (v) { p.name = v; await saveCustom(); } editing = ''; refresh(); }
      else if (a === 'upd') { p.vals = await snapshot(); await saveCustom(); await set({ zexBehActive: p.id }); say('✓ "' + p.name + '" updated with your current settings', 'ok'); refresh(); }
      else if (a === 'exp') download('zex_behaviour_' + p.name.replace(/[^a-z0-9]+/gi, '_') + '.json', { zexBehaviour: 1, profiles: [{ name: p.name, vals: p.vals }] });
      else if (a === 'del') {
        if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = 'TAP AGAIN TO DELETE'; setTimeout(function () { if (b.isConnected) { b.dataset.sure = ''; b.textContent = 'DELETE'; } }, 3000); return; }
        custom = custom.filter(function (x) { return x.id !== id; }); await saveCustom();
        if (active === id) await set({ zexBehActive: '' });
        refresh();
      }
    });
    host.addEventListener('change', function (e) {
      if (e.target.id !== 'behFile') return;
      var f = e.target.files && e.target.files[0]; if (!f) return;
      var rd = new FileReader();
      rd.onload = async function () {
        try {
          var j = JSON.parse(String(rd.result || ''));
          var list = j && j.zexBehaviour && Array.isArray(j.profiles) ? j.profiles : null;
          if (!list) throw new Error('bad');
          var n = 0; list.slice(0, 30).forEach(function (x) { if (x && x.name && x.vals) { custom.push({ id: uid(), name: String(x.name).slice(0, 30), vals: clean(x.vals) }); n++; } });
          await saveCustom(); say('✓ Imported ' + n + ' profile' + (n === 1 ? '' : 's'), 'ok'); refresh();
        } catch (er) { say('This is not a Z EX behaviour file.', 'err'); }
      };
      rd.readAsText(f); e.target.value = '';
    });
    // the user changed a setting by hand → the card should show CHANGED
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== 'local') return;
      if (FKEYS.some(function (k) { return ch[k]; }) || ch[TK]) { clearTimeout(wire.t); wire.t = setTimeout(function () { if (!editing) refresh(); }, 400); }
    });
  }

  function init() {
    host = $('behHost'); if (!host) return;
    css(); wire(); refresh();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
