// Z EX FAQ — edit here. Each item: [question, answer-html]
window.ZEX_FAQ = [
 { group: 'GETTING STARTED', items: [
  ['🏠 Home — login & connection', 'Sign in, check you are connected, then let the extension work. If something stops working, <b>start here first</b>: log out and in again fixes most things.'],
  ['📊 Dashboard', 'Live stats. REP / FED / SEA / GIV each have their own chart. It only counts what the extension actually posted.'],
  ['💸 ZEXPAY — credits & payment', 'Pick a package, pick a network, send the <b>exact amount</b>, paste your tx hash, tap Verify. Wrong amount or wrong network = not verified. Your access time shows on Home.'],
  ['🔒 Why are other tabs hidden?', 'When your access has expired the extension shows only ZEXPAY. Renew there and everything comes back.'],
  ['📱 Does it work on phone?', 'Yes — Kiwi Browser (Android) and desktop Chrome. Keep the X tab open; the popup can be closed, engines keep running.']
 ]},
 { group: 'REPLY SETTINGS', items: [
  ['🎭 Tone', 'The vibe of your replies: Smart, Funny, Alpha, Human and more. <b>Use Grammar</b> cleans punctuation per tone. <b>Big Reply Config</b> sets word count + tone for long replies. <b>Custom Tone</b> lets you write your own.'],
  ['🧠 Style — your voice', 'Add examples of how you really write and the AI copies it. Save them as a <b>Trained Style</b> and switch styles anytime. More (and cleaner) examples = better match.'],
  ['🔑 Keywords & SK1 mode', 'Keyword Reply sends short answers to Gm / Gn / HHM style posts. <b>SK1 Mode</b> keeps replies extra short. Custom keywords let you pick which posts get attention.'],
  ['🤖 Smart Model Switch', 'If the active AI model fails or is busy, it falls back to another one automatically (AUTO FALLBACK). Leave it on.'],
  ['🏷️ Project name in reply', 'Adds your project name to replies when it fits. Turn off if you do not want it everywhere.'],
  ['🖱️ Click mode, Typing mode, Cursor', '<b>RL Stealth Click</b> clicks like a real finger. <b>Human Typing</b> types the reply character by character. <b>Animated Cursor</b> + Cursor Appearance only change the look (custom image supported).'],
  ['📜 History', 'Every reply that was posted, newest first (last 300). Clear All removes the list. Back it up first in the BACKUP tab if you want to keep it.']
 ]},
 { group: 'ENGINES (Activity tab)', items: [
  ['💬 Comment REP', 'Answers the comments on <b>your own post</b>. Choose reply percentage and speed. Auto = it works on its own; Manual = you confirm each draft.'],
  ['📰 FED Engine', 'Replies to posts on your home feed. <b>Target Post Filter</b> limits it to posts with your words. <b>Auto Refresh</b> reloads the feed when posts run out.'],
  ['🔎 Search Engine', 'Searches a keyword and replies to the results. Use Search Filters to narrow by type, likes, language etc.'],
  ['Keyword & project tags', 'Every comment gets a tag. Search / Link Collect: read from your X search box, also for manual searches (filters like min_faves: or lang: are ignored). With many projects, e.g. ("ZeruAI" OR @zerufinance OR "Quip Network" OR @quipnetwork), each post gets the project it mentions first; the name + @handle pair counts as one project. Feed: the $TICKER / @project in the post. Tags show on History cards and in the Dashboard keyword list.'],
  ['Agent dashboard: STOP / RESUME', 'Every engine row (SEA, FED, REP, GIV, TAR, TG Engage, TG Sweep) has STOP while it runs. When it is off the same row shows START / RESUME. TAR, TG Engage and TG Sweep continue from where they stopped.'],
  ['Collect from the dashboard', 'Search by hand on X, open the Agent dashboard and press START on the LINK COLLECT row. It scrolls this search and saves the posts to the folder chosen in Search Engine > Link Collect (or a new folder). Posts get the words you searched as tags.'],
  ['Post Age Limit', 'Search Engine > Post Age Limit: engage / collect only posts inside a window (for example 1 sec to 19 hours old) or only posts from the dates you pick (optional time of day). Older posts are skipped and the run stops when it reaches them. Use Latest results. Only Search + Link Collect use it.'],
  ['🎁 GIV Engine', 'Finds giveaway / WL posts and drops your wallet using your Reply Template. Set the wallet and trigger keywords first. AI verify can double-check a post is a real giveaway.'],
  ['➕ Follow Engine', 'Follows a list of accounts one by one with a gap between each. If it pauses mid-run it shows "Paused mid-run" and you can continue. Already-followed accounts are skipped.'],
  ['➖ Auto Unfollow', 'Cleans your Following list. Choose who to unfollow, a limit, gap between unfollows, and break every N. Slow gaps are safer.'],
  ['🎯 TAR Engine', 'Likes and replies on fresh posts from your target accounts (pasted list or an X List). Set posts per account, account gap and speed.'],
  ['✈️ Telegram Engage', 'Follows a Telegram group, opens the X links people post, and replies. Timing controls how long it waits at each step; Break pauses it every N links.'],
  ['🧹 Telegram Sweep', 'Grabs every X link in a chat (or saved folder) into a queue and works through it. <b>Link Delay</b> = random wait between your min and max. It keeps running if the popup is closed; Stop cancels what is left.'],
  ['🛑 Why did an engine stop?', 'X rate limits, a closed X tab, a logged-out X account, or expired access. Open the <b>Workflow Map</b> (Support and System) to see exactly where the last run ended.']
 ]},
 { group: 'BACKUP & RESTORE', items: [
  ['💾 What does BACKUP save?', 'Everything stored by the extension: reply history, skip log, daily log, counters, workflow runs, styles, keywords & filters, Telegram folders/timing, and all other settings. One .json file.'],
  ['⬇ How do I export?', 'Backup tab → tick what you want → <b>Download Backup</b>. The file lands in your Downloads folder.'],
  ['⬆ How do I import?', 'Backup tab → <b>Choose Backup File</b> → pick the .json → choose items → <b>Import &amp; Restore</b>. Every item goes back to the right place automatically. Then reopen the popup and refresh your X tab.'],
  ['🔀 Merge or Replace?', '<b>Merge</b> (default) keeps what you have and adds what is missing — lists are combined without duplicates, numbers keep the higher value. <b>Replace</b> makes the backup win for every item it contains. Items not in the file are never deleted.'],
  ['🔑 Is my login included?', 'No, not by default. "Login &amp; proxy" is a separate switch that is OFF. Turn it on only if you want the login session and proxy password in the file — then keep the file private. After a restore on another device you may need to log in again.'],
  ['🚦 Will engines start after import?', 'No. ON/OFF switches and live run state are never saved or restored, so nothing starts by itself. Turn engines on yourself.'],
  ['📦 Moving to a new phone / reinstall', 'Export before you uninstall (uninstalling wipes the data), keep the file, then install, open Backup &amp; FAQ and import.'],
  ['🗺️ Workflow Map export/import', 'The map still has its own small Export/Import in Support and System (runs only). The Backup tab already includes those runs.']
 ]},
 { group: 'OTHER', items: [
  ['🌐 Proxy (BETA)', 'Routes browser traffic through your proxy. Off = normal connection. <b>Quick Setup: Cloudflare WARP</b> fills SOCKS5 127.0.0.1:40000 for you (install WARP and enable Proxy Mode first). All traffic including X login goes through it — only use trusted providers.'],
  ['🛟 Support and System', 'Contact links, Workflow Map (replays what the extension did step by step), and a shortcut to this Backup &amp; FAQ page.'],
  ['🌗 Dark / light theme', 'Use the ◐ button at the top of the popup or this page. The choice is remembered.'],
  ['🆘 Something is broken', 'Order to try: 1) refresh the X tab, 2) log out / in on Home, 3) turn engines off and on, 4) Export a backup, then reinstall, 5) contact support with a screenshot.']
 ]}
];
